# OpenCoven Integration Guide

This document describes the extensibility seams in `coven-code` for OpenCoven-specific work.  
It is a living document — update it as new integration surfaces are added.

---

## Upstream sync strategy

Internal Rust crate names (`claurst-core`, `claurst-tui`, `claurst-acp`, etc.) are **intentionally preserved**
from upstream [Claurst](https://github.com/Kuberwastaken/claurst) to keep `git merge upstream/main` low-friction.

```bash
git fetch upstream
git merge upstream/main   # resolve conflicts in user-facing surfaces only
```

Only user-visible surfaces (binary name, env vars, data dirs, ACP registry, docs, README, npm package)
are rebranded. This boundary is explicit and documented below.

---

## Rebranded surfaces (safe to update without upstream conflict)

| Surface | File(s) | Current value |
|---|---|---|
| Binary name | `src-rust/crates/cli/src/main.rs`, `src-rust/crates/cli/src/bin/coven-cave.rs` | `coven-code`; `coven-cave` alias |
| npm package | `npm/package.json` | `@opencoven/coven-code` |
| Data/cache dirs | `src-rust/crates/core/src/snapshot/`, `skill_discovery.rs`, `update_check.rs`, `app.rs` | `coven-code/` |
| Engine home (standalone) | `src-rust/crates/core/src/lib.rs` (`config_home`) | `~/.coven-code/` |
| Engine home (under coven CLI) | `src-rust/crates/core/src/lib.rs` (`config_home`) | `~/.coven/code/` — migrated in-place from `~/.coven-code/` on first launch; legacy path is symlinked to new location |
| Shared config layer | `src-rust/crates/core/src/lib.rs` (`SharedSettings`, `load_hierarchical`) | `~/.coven/settings.json` — cross-tool defaults layered UNDER the engine and project settings |
| Env var prefix | throughout `src-rust/` | `COVEN_CODE_*` |
| User-Agent | `src-rust/crates/tools/src/web_search.rs`, `update_check.rs` | `CovenCode/x.y` |
| System prompt identity | `src-rust/crates/core/src/system_prompt.rs` | "You are Coven Code…" |
| ACP registry template | `src-rust/crates/acp/registry-template/agent.json` | `coven-code` |
| Install scripts | `install.sh`, `install.ps1`, `npm/install.js` | `OpenCoven/coven-code` |

## Intentionally preserved upstream names (internal crate identifiers)

These are **not** user-visible and are kept for merge-friendliness:

- Crate names: `claurst-core`, `claurst-tui`, `claurst-api`, `claurst-tools`, `claurst-query`,
  `claurst-mcp`, `claurst-bridge`, `claurst-buddy`, `claurst-plugins`, `claurst-acp`,
  `claurst-commands`
- Cargo workspace `[workspace]` resolver and member paths
- Internal Rust module paths and `use` statements referencing `claurst_*`

---

## Extensibility seams

### 1. Provider adapters — `src-rust/crates/api/src/providers/`

Every provider implements `LlmProvider`. To add an OpenCoven-specific or private provider:
1. Create `my_provider.rs` implementing `LlmProvider`.
2. Register it in `providers/mod.rs`.
3. Add routing in `src-rust/crates/api/src/registry.rs` (`provider_from_key` /
   `provider_from_config` / `runtime_provider_for`) and, if it needs a stable
   id, a constant in `src-rust/crates/core/src/provider_id.rs`. (There is no
   provider enum in `core/settings`; the only `Provider` enum is the
   two-variant client selector in `crates/api/src/lib.rs`.)

### 2. Plugin system — `src-rust/crates/plugins/`

Plugin discovery and loading start at `load_plugins` in `crates/plugins/src/lib.rs`,
which returns a `PluginRegistry`. Reloading uses `reload_plugins` and reports a
`ReloadDiff`; hook registration lives in `hooks.rs`.

### 3. ACP server — `src-rust/crates/acp/`

JSON-RPC 2.0 over stdio (`coven-code acp`). This is the recommended Coven orchestration entry point.  
RPC dispatch lives in `AgentServer` in `crates/acp/src/server.rs`.
See `registry-template/agent.json` for how Coven registers this agent.

### 4. Command/slash registry — `src-rust/crates/commands/`

Add new `/slash` commands by implementing the `SlashCommand` trait and registering in `commands/src/lib.rs`.

### 5. TUI theme — `src-rust/crates/tui/src/theme_colors.rs`

Target OpenCoven brand palette:
- Primary: `#8B5CF6` (violet-500)
- Accent: `#EC4899` (pink-500)
- Background/surface: existing dark palette

Replace `default_theme()` return values when brand assets are finalized.

### 6. Companion mascot — `src-rust/crates/tui/src/mascot.rs`

`mascot.rs` defines `CompanionPose` for animation state. The familiar glyph is
composed in `familiar_card.rs` using the archetype resolved by `familiar_theme.rs`.
Fresh installs do not receive a built-in named familiar.

### 7. Memory / session hooks — `src-rust/crates/core/src/memdir.rs`, `session_storage.rs`

`memdir.rs`: controls where MEMORY.md / memory files live.  
`session_storage.rs`: session persistence format.  
Hook Coven's memory layer here to sync agent sessions with OpenCoven's session/memory store.

### 8. Tool registry — `src-rust/crates/tools/src/`

All built-in tools live here (file ops, bash, web fetch/search, git, etc.).  
Add Coven-specific tools (e.g. `coven_session_tool.rs`) and register in `tools/src/lib.rs`.

---

## Shared settings (`~/.coven/settings.json`)

When running under the unified `coven` CLI, a small whitelist of
cross-tool defaults can be placed at `~/.coven/settings.json`.
This is the **lowest-precedence** layer: values are used only when the
engine-global settings (`~/.coven/code/settings.json`) and project
settings (`.coven-code/settings.json`) do not override them.

### Load order (lowest → highest)

1. `~/.coven/settings.json` — shared, whitelisted keys only
2. `~/.coven/code/settings.json` — engine-global
3. `<project>/.coven-code/settings.json` — project

When there is no `~/.coven/` directory (standalone mode, no coven CLI),
the shared layer is absent and coven-code behaves exactly as before
(engine + project only).

### Whitelisted keys

| Key | Type | Description |
|---|---|---|
| `model` | string | Default model (e.g. `"claude-opus-4-8"`) |
| `theme` | string | UI theme: `"default"`, `"dark"`, `"light"`, `"deuteranopia"`, or a custom string |
| `permission_mode` | string | Permission posture: `"default"`, `"acceptEdits"`, `"bypassPermissions"`, `"plan"` |

Any other keys in `~/.coven/settings.json` are silently ignored by
coven-code, so future Coven tools can extend the schema without breaking
older engine versions.

### Example

```json
{
  "model": "claude-sonnet-4-6",
  "theme": "dark",
  "permission_mode": "acceptEdits"
}
```

### Implementation

`SharedSettings` struct in `src-rust/crates/core/src/lib.rs` (inside
`pub mod config`).  `SharedSettings::load()` reads the file via
`coven_shared::coven_home()`.  `SharedSettings::apply_to(&mut Settings)`
fills whitelisted fields only when the engine-global still has the
built-in default value (for `Option` fields: `None`; for enum fields:
the `Default` variant).

---

## Engine contract

coven-code is the engine behind the unified `coven` CLI. The exact CLI/env/
stream surfaces coven depends on are specified in
[coven/docs/ENGINE-CONTRACT.md](https://github.com/OpenCoven/coven/blob/main/docs/ENGINE-CONTRACT.md)
(`contract_version: 1`). Do not change flags, output formats, or exit codes
listed there without bumping the contract version and coordinating a coven
`engine.lock` update. The merge overview, user migration steps, and Cave
integration plan live in [docs/unification.md](docs/unification.md).

---

## Release checklist

Prepare a release from the reviewed main commit with explicit publication
authorization. A new release must be strictly newer than every existing version
tag; use a new version for fixes rather than replacing published assets.

1. Select patch or minor scope from the changes since the last shipped tag.
   Resolve security, migration and public-contract gates before publication.
2. Run `python3 scripts/bump-version.py vMAJOR.MINOR.PATCH` from the repository
   root. The script owns Cargo workspace/lock versions, npm version, README and
   documentation stamps, and the ACP registry version and five archive URLs.
   Do not edit these version fields manually.
3. Run `python3 scripts/check-release-version.py vMAJOR.MINOR.PATCH`. It reads
   remote tags and rejects equal/older versions and inconsistent stamps. Network
   failure is a preflight failure, not evidence that a version is available.
4. Verify the exact stamped tree: workspace formatting, check, Clippy and tests;
   [reverse consumer contracts](docs/reverse-contract-ci.md); headless schemas;
   installer tests; upgrade/rollback fixtures; and required terminal acceptance.
5. Review release notes against the previous shipped tag, including migration
   steps and compatibility limits. Build and verify all five release archives:
   Windows x86_64 ZIP, Linux x86_64/aarch64 and macOS x86_64/aarch64 tarballs.
   Each contains `coven-code` (Windows: `coven-code.exe`). Require the final
   checksum manifest and verify archive contents and native smoke tests before
   declaring the candidate ready. Do not infer platform support from compilation
   alone.
6. After authorized Git delivery and passing exact-commit CI, dispatch
   `.github/workflows/release.yml` from the approved main commit with the chosen
   version. The workflow publishes a GitHub Release; it is not a dry run.
   Verify the uploaded archives, installers and checksum manifest before
   announcing the release or updating managed engine pins.
7. Keep `publish_npm` false. `@opencoven/coven-code` is deprecated; npm publication
   is an explicit opt-in through the release workflow, not a routine release step.

A package-version bump does not replace a required engine-contract version bump
or consumer coordination. Retain a verified prior binary and backup of affected
engine data for rollback; do not assume a standalone install replaces the engine
selected by the unified `coven` CLI. Human/native-platform checks and final
publication authorization remain separate from automated local checks.

The [auto-release workflow](.github/workflows/auto-release.yml) provides the
release-bot marker path: it stamps versions and dispatches the release workflow.
Its marker jobs run only for pushes by `opencoven-bot`.
