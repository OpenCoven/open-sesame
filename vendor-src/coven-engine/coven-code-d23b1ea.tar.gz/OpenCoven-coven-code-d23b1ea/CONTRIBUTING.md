# Contributing to OpenCoven

Thank you for your interest in contributing. Coven Code is licensed under GPL-3.0 (see [LICENSE.md](./LICENSE.md)) and is community-driven. We want contributing to be easy, open, and safe for everyone.

## Developer Certificate of Origin (DCO)

OpenCoven uses the **Developer Certificate of Origin (DCO) v1.1** for all contributions. This is a lightweight mechanism — not a CLA — that asks you to certify that you have the right to submit what you're submitting.

By making a contribution to this project, you certify that:

> (a) The contribution was created in whole or in part by you and you have the right to submit it under the open source license indicated in the file; or
>
> (b) The contribution is based upon previous work that, to the best of your knowledge, is covered under an appropriate open source license and you have the right under that license to submit that work with modifications, whether created in whole or in part by you, under the same open source license (unless you are permitted to submit under a different license), as indicated in the file; or
>
> (c) The contribution was provided directly to you by some other person who certified (a), (b) or (c) and you have not modified it.
>
> (d) You understand and agree that this project and the contribution are public and that a record of the contribution (including all personal information you submit with it, including your sign-off) is maintained indefinitely and may be redistributed consistent with this project or the open source license(s) involved.

### How to Sign Off

Add a `Signed-off-by` line to your commit message:

```
git commit -s -m "Your commit message"
```

This produces:

```
Your commit message

Signed-off-by: Your Name <your.email@example.com>
```

### Patent Non-Assertion

By contributing, you additionally agree not to assert any patent claims — now held or later acquired — against this project or its users that arise from your contribution. This is in addition to the patent license that section 11 of GPL-3.0 requires from every contributor.

## What We're Looking For

- Bug fixes and reliability improvements
- Documentation and example improvements
- New skills, tools, and integrations
- Performance improvements
- Community-requested features

## What We're Not

OpenCoven is not a contribution vehicle for proprietary forks. If you are building a closed-source derivative of OpenCoven's architecture, please do not use contribution as a means to learn implementation details that are not yet public. We welcome genuine collaborators.

## Getting Started

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Make your changes with signed-off commits: `git commit -s`
4. Open a pull request with a clear description

## Questions?

Join the Discord: https://discord.gg/OpenCoven
