// claurst-api: Anthropic API client with streaming SSE support for Coven Code
// Rust port.
//
// Handles:
// - POST /v1/messages with streaming
// - SSE event parsing (message_start, content_block_start, content_block_delta,
//   content_block_stop, message_delta, message_stop, error)
// - Delta types: text_delta, input_json_delta, thinking_delta, signature_delta
// - Rate-limit (429) and overloaded (529) retry with exponential back-off
// - Authentication via API key from env or config

use claurst_core::constants::{ANTHROPIC_API_VERSION, ANTHROPIC_BETA_HEADER};
use claurst_core::error::ClaudeError;
use claurst_core::types::{ContentBlock, Message, MessageContent, Role, ToolDefinition, UsageInfo};
use futures::StreamExt;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::mpsc;
use tracing::debug;

// ---------------------------------------------------------------------------
// Modules
// ---------------------------------------------------------------------------
pub mod cch;
pub mod codex_adapter;

// Provider-agnostic unified types (Phase 1A).
pub mod provider_error;
pub mod provider_types;

// Provider abstraction traits (Phase 1B).
pub mod auth;
pub mod provider;
mod sse_lines;
pub mod stream_parser;
pub mod transform;

// Provider registry (Phase 1C).
pub mod registry;

// Concrete provider adapters (Phase 1D).
pub mod providers;

// Model Registry (Phase 3).
pub mod model_registry;

// Provider-aware error handling (Phase 6).
pub mod error_handling;

// Message transform layer — concrete transformers (Phase 4).
pub mod transformers;

// ---------------------------------------------------------------------------
// Public re-exports
// ---------------------------------------------------------------------------
pub use client::AnthropicClient;
pub use streaming::{AnthropicStreamEvent, StreamHandler};
pub use types::*;

// Phase 1A re-exports — provider-agnostic layer.
pub use provider_error::ProviderError;
pub use provider_types::*;

// Phase 1B re-exports — provider abstraction traits.
pub use auth::{AuthProvider, LoginFlow};
pub use provider::{LlmProvider, ModelInfo};
pub use stream_parser::{JsonLinesStreamParser, SseStreamParser, StreamParser};
pub use transform::MessageTransformer;

// Phase 1C re-exports — provider registry.
pub use registry::ProviderRegistry;

// Phase 1D re-exports — concrete provider adapters.
pub use providers::AnthropicProvider;
pub use providers::CodexProvider;

// Phase 3 re-exports — model registry.
pub use model_registry::{
    effective_model_for_config, CostBreakdown, ExperimentalMode, InterleavedReasoning, Modality,
    ModelEntry, ModelRegistry, ModelStatus, ProviderEntry, ProviderOverride,
};

// Phase 6 re-exports — provider-aware error handling.
pub use error_handling::{is_context_overflow, parse_error_response, RetryConfig};

// Phase 4 re-exports — concrete message transformers.
pub use transformers::AnthropicTransformer;

// ---------------------------------------------------------------------------
// request / response types
// ---------------------------------------------------------------------------
pub mod types {
    use super::*;

    /// The request body sent to `POST /v1/messages`.
    #[derive(Debug, Clone, Serialize)]
    pub struct CreateMessageRequest {
        pub model: String,
        pub max_tokens: u32,
        pub messages: Vec<ApiMessage>,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub system: Option<SystemPrompt>,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub tools: Option<Vec<ApiToolDefinition>>,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub temperature: Option<f32>,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub top_p: Option<f32>,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub top_k: Option<u32>,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub stop_sequences: Option<Vec<String>>,
        pub stream: bool,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub thinking: Option<ThinkingConfig>,
        /// Output configuration — carries the `effort` control on models that
        /// use adaptive thinking (Opus 4.7+, Opus 4.8, Fable 5).
        #[serde(skip_serializing_if = "Option::is_none")]
        pub output_config: Option<OutputConfig>,
    }

    /// `output_config` request field. Currently only carries `effort`, which
    /// replaces `budget_tokens` as the reasoning-depth control on models with
    /// adaptive thinking.
    #[derive(Debug, Clone, Serialize, Deserialize)]
    pub struct OutputConfig {
        #[serde(skip_serializing_if = "Option::is_none")]
        pub effort: Option<String>,
    }

    impl OutputConfig {
        /// Build an `output_config` with the given effort level
        /// (`"low" | "medium" | "high" | "max"`).
        pub fn with_effort(effort: impl Into<String>) -> Self {
            Self {
                effort: Some(effort.into()),
            }
        }
    }

    #[derive(Debug, Clone, Serialize, Deserialize)]
    pub struct ThinkingConfig {
        #[serde(rename = "type")]
        pub thinking_type: String,
        /// Manual extended-thinking budget. Omitted for adaptive thinking,
        /// which is required on Claude Opus 4.7+, Opus 4.8, and Fable 5
        /// (those models reject `budget_tokens` with a 400).
        #[serde(skip_serializing_if = "Option::is_none")]
        pub budget_tokens: Option<u32>,
    }

    impl ThinkingConfig {
        pub fn enabled(budget: u32) -> Self {
            Self {
                thinking_type: "enabled".to_string(),
                budget_tokens: Some(budget),
            }
        }

        /// Adaptive thinking — the model decides when and how much to think.
        /// Reasoning depth is controlled via the `effort` parameter instead of
        /// a fixed `budget_tokens`. Required on Opus 4.7+, Opus 4.8, Fable 5.
        pub fn adaptive() -> Self {
            Self {
                thinking_type: "adaptive".to_string(),
                budget_tokens: None,
            }
        }
    }

    /// System prompt - either a single string or structured blocks with cache.
    #[derive(Debug, Clone, Serialize, Deserialize)]
    #[serde(untagged)]
    pub enum SystemPrompt {
        Text(String),
        Blocks(Vec<SystemBlock>),
    }

    #[derive(Debug, Clone, Serialize, Deserialize)]
    pub struct SystemBlock {
        #[serde(rename = "type")]
        pub block_type: String,
        pub text: String,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub cache_control: Option<CacheControl>,
    }

    #[derive(Debug, Clone, Serialize, Deserialize)]
    pub struct CacheControl {
        #[serde(rename = "type")]
        pub control_type: String,
    }

    impl CacheControl {
        pub fn ephemeral() -> Self {
            Self {
                control_type: "ephemeral".to_string(),
            }
        }
    }

    /// Simplified message type for the API wire format.
    #[derive(Debug, Clone, Serialize, Deserialize)]
    pub struct ApiMessage {
        pub role: String,
        pub content: Value,
    }

    impl From<&Message> for ApiMessage {
        fn from(msg: &Message) -> Self {
            let role = match msg.role {
                Role::User => "user",
                Role::Assistant => "assistant",
            };
            let content = match &msg.content {
                MessageContent::Text(t) => Value::String(t.clone()),
                MessageContent::Blocks(blocks) => {
                    serde_json::to_value(blocks).unwrap_or(Value::Null)
                }
            };
            Self {
                role: role.to_string(),
                content,
            }
        }
    }

    /// Tool definition in the API wire format.
    #[derive(Debug, Clone, Serialize, Deserialize)]
    pub struct ApiToolDefinition {
        pub name: String,
        pub description: String,
        pub input_schema: Value,
        #[serde(skip_serializing_if = "Option::is_none")]
        pub cache_control: Option<CacheControl>,
    }

    impl From<&ToolDefinition> for ApiToolDefinition {
        fn from(td: &ToolDefinition) -> Self {
            Self {
                name: td.name.clone(),
                description: td.description.clone(),
                input_schema: td.input_schema.clone(),
                cache_control: None,
            }
        }
    }

    /// Non-streaming response from `POST /v1/messages`.
    #[derive(Debug, Clone, Deserialize)]
    pub struct CreateMessageResponse {
        pub id: String,
        #[serde(rename = "type")]
        pub response_type: String,
        pub role: String,
        pub content: Vec<Value>,
        pub model: String,
        pub stop_reason: Option<String>,
        pub stop_sequence: Option<String>,
        pub usage: UsageInfo,
    }

    /// Error body returned by the API.
    #[derive(Debug, Clone, Deserialize)]
    pub struct ApiErrorResponse {
        #[serde(rename = "type")]
        pub error_type: String,
        pub error: ApiErrorDetail,
    }

    #[derive(Debug, Clone, Deserialize)]
    pub struct ApiErrorDetail {
        #[serde(rename = "type")]
        pub error_type: String,
        pub message: String,
    }
}

// ---------------------------------------------------------------------------
// SSE streaming types
// ---------------------------------------------------------------------------
pub mod streaming {
    use super::*;

    /// Events emitted by the Anthropic SSE streaming parser.
    #[derive(Debug, Clone)]
    pub enum AnthropicStreamEvent {
        /// The overall message has started; carries the message id and model.
        MessageStart {
            id: String,
            model: String,
            usage: UsageInfo,
        },
        /// A new content block has begun.
        ContentBlockStart {
            index: usize,
            content_block: ContentBlock,
        },
        /// Incremental delta for an existing content block.
        ContentBlockDelta { index: usize, delta: ContentDelta },
        /// A content block is finished.
        ContentBlockStop { index: usize },
        /// Final message-level delta (stop_reason, usage).
        MessageDelta {
            stop_reason: Option<String>,
            usage: Option<UsageInfo>,
        },
        /// The message is complete.
        MessageStop,
        /// An error occurred during streaming.
        Error { error_type: String, message: String },
        /// A ping/keep-alive event.
        Ping,
    }

    /// The delta payload inside a `content_block_delta` event.
    #[derive(Debug, Clone, Serialize, Deserialize)]
    #[serde(tag = "type", rename_all = "snake_case")]
    pub enum ContentDelta {
        TextDelta { text: String },
        InputJsonDelta { partial_json: String },
        ThinkingDelta { thinking: String },
        SignatureDelta { signature: String },
    }

    /// Trait for anything that wants to consume streaming events in real time.
    pub trait StreamHandler: Send + Sync {
        fn on_event(&self, event: &AnthropicStreamEvent);
    }

    /// A no-op handler useful for non-interactive / batch mode.
    pub struct NullStreamHandler;
    impl StreamHandler for NullStreamHandler {
        fn on_event(&self, _event: &AnthropicStreamEvent) {}
    }
}

// ---------------------------------------------------------------------------
// SSE line parser
// ---------------------------------------------------------------------------
mod sse_parser {
    /// Parsed SSE frame.
    #[derive(Debug)]
    pub struct SseFrame {
        pub event: Option<String>,
        pub data: String,
    }

    /// Incrementally accumulates raw bytes/lines and yields complete frames.
    pub struct SseLineParser {
        event_type: Option<String>,
        data_buf: String,
    }

    impl SseLineParser {
        pub fn new() -> Self {
            Self {
                event_type: None,
                data_buf: String::new(),
            }
        }

        /// Feed one line (without the trailing newline).  Returns `Some(frame)`
        /// when a blank line signals the end of an event.
        pub fn feed_line(&mut self, line: &str) -> Option<SseFrame> {
            if line.is_empty() {
                // Blank line = end of event
                if self.data_buf.is_empty() && self.event_type.is_none() {
                    return None; // spurious blank line
                }
                let frame = SseFrame {
                    event: self.event_type.take(),
                    data: std::mem::take(&mut self.data_buf),
                };
                return Some(frame);
            }

            if let Some(rest) = line.strip_prefix("event:") {
                self.event_type = Some(rest.trim().to_string());
            } else if let Some(rest) = line.strip_prefix("data:") {
                if !self.data_buf.is_empty() {
                    self.data_buf.push('\n');
                }
                self.data_buf.push_str(rest.trim());
            } else if line.starts_with(':') {
                // SSE comment / keep-alive – ignore
            }

            None
        }
    }
}

// ---------------------------------------------------------------------------
// Models endpoint types (public)
// ---------------------------------------------------------------------------

/// A model entry returned by `GET /v1/models`.
#[derive(Debug, Clone, serde::Deserialize)]
pub struct AvailableModel {
    pub id: String,
    pub display_name: Option<String>,
    /// Unix timestamp of when the model was created (seconds).
    pub created_at: Option<i64>,
}

// ---------------------------------------------------------------------------
// Anthropic client
// ---------------------------------------------------------------------------
pub mod client {
    use super::*;

    /// Provider selection for API calls.
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
    pub enum Provider {
        /// Use Anthropic's API
        #[default]
        Anthropic,
        /// Use OpenAI Codex via OAuth
        Codex,
    }

    /// Configuration for the HTTP client.
    #[derive(Clone)]
    pub struct ClientConfig {
        pub api_key: String,
        pub api_base: String,
        pub api_version: String,
        pub beta_features: String,
        pub max_retries: u32,
        pub initial_retry_delay: Duration,
        pub max_retry_delay: Duration,
        pub request_timeout: Duration,
        /// When true, send `Authorization: Bearer <api_key>` instead of `x-api-key`.
        /// Used for Claude.ai subscription (OAuth user:inference scope) tokens.
        pub use_bearer_auth: bool,
        /// Which provider to use for API calls.
        pub provider: Provider,
    }

    impl std::fmt::Debug for ClientConfig {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            f.debug_struct("ClientConfig")
                .field("api_key", &"[REDACTED]")
                .field("api_base", &"[REDACTED]")
                .field("api_version", &self.api_version)
                .field("beta_features", &self.beta_features)
                .field("max_retries", &self.max_retries)
                .field("initial_retry_delay", &self.initial_retry_delay)
                .field("max_retry_delay", &self.max_retry_delay)
                .field("request_timeout", &self.request_timeout)
                .field("use_bearer_auth", &self.use_bearer_auth)
                .field("provider", &self.provider)
                .finish()
        }
    }

    impl Default for ClientConfig {
        fn default() -> Self {
            Self {
                api_key: String::new(),
                api_base: claurst_core::constants::ANTHROPIC_API_BASE.to_string(),
                api_version: ANTHROPIC_API_VERSION.to_string(),
                beta_features: ANTHROPIC_BETA_HEADER.to_string(),
                max_retries: 5,
                initial_retry_delay: Duration::from_secs(1),
                max_retry_delay: Duration::from_secs(60),
                request_timeout: Duration::from_secs(600),
                use_bearer_auth: false,
                provider: Provider::Anthropic,
            }
        }
    }

    /// The main Anthropic API client.
    pub struct AnthropicClient {
        http: reqwest::Client,
        config: ClientConfig,
        goal_authority: Option<(
            claurst_core::goal::GoalTurn,
            claurst_core::goal::GoalTurnPermission,
        )>,
    }

    impl AnthropicClient {
        /// Returns `true` when the client was constructed without an API key.
        ///
        /// The query loop checks this to know whether it should fall back to
        /// a runtime-built provider (e.g. from keys stored via `/connect`).
        pub fn api_key_is_empty(&self) -> bool {
            self.config.api_key.is_empty()
        }

        /// Returns `true` when this client is configured to use Bearer-token
        /// authorization instead of an Anthropic API key.
        pub fn is_oauth(&self) -> bool {
            self.config.use_bearer_auth
        }

        /// Compute the `anthropic-beta` header value for an outbound request.
        ///
        /// On the subscription-OAuth (Bearer) path the `oauth-2025-04-20`
        /// flag is required by `/v1/messages`; it is appended to the
        /// configured beta features (unless already present).
        pub(crate) fn anthropic_beta_header(&self) -> String {
            const OAUTH_BETA: &str = "oauth-2025-04-20";
            let base = &self.config.beta_features;
            if self.config.use_bearer_auth && !base.contains(OAUTH_BETA) {
                if base.is_empty() {
                    OAUTH_BETA.to_string()
                } else {
                    format!("{},{}", OAUTH_BETA, base)
                }
            } else {
                base.clone()
            }
        }

        /// Build a new client.  Panics if `config.api_key` is empty.
        pub fn new(config: ClientConfig) -> anyhow::Result<Self> {
            // Allow empty key at construction — validation is deferred to
            // the first API call, so non-Anthropic provider setups can still
            // create this client without an Anthropic key configured.
            let http = reqwest::Client::builder()
                .timeout(config.request_timeout)
                .build()?;

            Ok(Self {
                http,
                config,
                goal_authority: None,
            })
        }

        /// Bind all requests (including internal retries and compaction) to
        /// the same captured goal. The shared HTTP pool and wire format stay unchanged.
        pub fn for_goal_turn(
            &self,
            turn: &claurst_core::goal::GoalTurn,
            permission: claurst_core::goal::GoalTurnPermission,
        ) -> Self {
            Self {
                http: self.http.clone(),
                config: self.config.clone(),
                goal_authority: Some((turn.clone(), permission)),
            }
        }

        fn check_goal_authority(
            authority: Option<&(
                claurst_core::goal::GoalTurn,
                claurst_core::goal::GoalTurnPermission,
            )>,
        ) -> Result<(), ClaudeError> {
            if let Some((turn, permission)) = authority {
                let actual = turn.validate().map_err(|error| {
                    ClaudeError::Api(format!("Goal authority revoked: {error}"))
                })?;
                if actual != *permission {
                    return Err(ClaudeError::Api(
                        "Goal permits only its final response".into(),
                    ));
                }
            }
            Ok(())
        }

        async fn wait_for_goal_revocation(
            authority: Option<&(
                claurst_core::goal::GoalTurn,
                claurst_core::goal::GoalTurnPermission,
            )>,
        ) -> ClaudeError {
            if authority.is_none() {
                return futures::future::pending().await;
            }
            loop {
                if let Err(error) = Self::check_goal_authority(authority) {
                    return error;
                }
                tokio::time::sleep(Duration::from_millis(100)).await;
            }
        }

        /// Convenience constructor that resolves the key from config/env.
        pub fn from_config(cfg: &claurst_core::config::Config) -> anyhow::Result<Self> {
            let api_key = cfg
                .resolve_api_key()
                .ok_or_else(|| anyhow::anyhow!("No API key found"))?;
            let api_base = cfg.resolve_api_base();

            Self::new(ClientConfig {
                api_key,
                api_base,
                ..Default::default()
            })
        }

        // ---- Non-streaming create message --------------------------------

        /// Send a non-streaming `POST /v1/messages` and return the full response.
        pub async fn create_message(
            &self,
            mut request: CreateMessageRequest,
        ) -> Result<CreateMessageResponse, ClaudeError> {
            Self::check_goal_authority(self.goal_authority.as_ref())?;
            // Deferred key validation — fail here rather than at construction
            // so that non-Anthropic provider setups don't crash on startup.
            if self.config.api_key.is_empty() && self.config.provider != Provider::Codex {
                return Err(ClaudeError::Auth(
                    "No API key for the selected model. Sign in to Claude with \
                     `coven-code auth login` (or set ANTHROPIC_API_KEY / configure \
                     COVEN_CODE_ANTHROPIC_OAUTH_CLIENT_ID), or use Codex with \
                     `--provider codex` after running `coven-code auth login --provider codex`."
                        .to_string(),
                ));
            }
            // Route to Codex if configured
            if self.config.provider == Provider::Codex {
                return self.create_message_codex(&request).await;
            }

            request.stream = false;
            let body = serde_json::to_value(&request).map_err(ClaudeError::Json)?;

            let resp = self.send_with_retry(&body).await?;
            let status = resp.status();
            let text = resp.text().await.map_err(ClaudeError::Http)?;

            if !status.is_success() {
                return Err(self.parse_api_error(status.as_u16(), &text));
            }

            serde_json::from_str(&text).map_err(ClaudeError::Json)
        }

        /// Send a request to OpenAI Codex API instead of Anthropic.
        async fn create_message_codex(
            &self,
            request: &CreateMessageRequest,
        ) -> Result<CreateMessageResponse, ClaudeError> {
            // Convert Anthropic format to OpenAI format
            let openai_req = codex_adapter::anthropic_to_openai_request(request);

            // Send to Codex endpoint
            let client = reqwest::Client::new();
            let resp = client
                .post(codex_adapter::CODEX_RESPONSES_ENDPOINT)
                .header("Authorization", format!("Bearer {}", self.config.api_key))
                .header("Content-Type", "application/json")
                .json(&openai_req)
                .timeout(self.config.request_timeout)
                .send()
                .await
                .map_err(|e| ClaudeError::Other(format!("Codex request failed: {}", e)))?;

            let status = resp.status();
            let text = resp.text().await.map_err(ClaudeError::Http)?;

            if !status.is_success() {
                return Err(self.parse_api_error(status.as_u16(), &text));
            }

            // Parse OpenAI response and convert to Anthropic format
            let openai_resp: Value = serde_json::from_str(&text).map_err(ClaudeError::Json)?;
            let (content, stop_reason, input_tokens, output_tokens) =
                codex_adapter::parse_openai_response(&openai_resp);

            let response = codex_adapter::build_anthropic_response(
                &content,
                &stop_reason,
                input_tokens,
                output_tokens,
                &request.model,
            );

            Ok(response)
        }

        // ---- Streaming create message ------------------------------------

        /// Send a streaming `POST /v1/messages`.  Events are dispatched to the
        /// provided `handler` in real time, and also forwarded into the returned
        /// channel so the caller can drive a select loop.
        /// Closing or dropping that receiver requests cancellation of the HTTP
        /// reader and callbacks. Shutdown is cooperative; it does not interrupt
        /// synchronous callback execution.
        pub async fn create_message_stream(
            &self,
            mut request: CreateMessageRequest,
            handler: Arc<dyn StreamHandler>,
        ) -> Result<mpsc::Receiver<streaming::AnthropicStreamEvent>, ClaudeError> {
            Self::check_goal_authority(self.goal_authority.as_ref())?;
            // Deferred key validation
            if self.config.api_key.is_empty() && self.config.provider != Provider::Codex {
                return Err(ClaudeError::Auth(
                    "No API key for the selected model. Sign in to Claude with \
                     `coven-code auth login` (or set ANTHROPIC_API_KEY / configure \
                     COVEN_CODE_ANTHROPIC_OAUTH_CLIENT_ID), or use Codex with \
                     `--provider codex` after running `coven-code auth login --provider codex`."
                        .to_string(),
                ));
            }
            // Codex provider doesn't support streaming yet
            if self.config.provider == Provider::Codex {
                return Err(ClaudeError::Other(
                    "Codex provider does not support streaming yet".to_string(),
                ));
            }

            request.stream = true;
            let body = serde_json::to_value(&request).map_err(ClaudeError::Json)?;

            let resp = self.send_with_retry(&body).await?;
            let status = resp.status();

            if !status.is_success() {
                let text = resp.text().await.map_err(ClaudeError::Http)?;
                return Err(self.parse_api_error(status.as_u16(), &text));
            }

            let (tx, rx) = mpsc::channel(256);

            // Receiver drop still stops the SSE reader; goal revocation also
            // stops a compaction or other consumer that has no query event loop.
            let authority = self.goal_authority.clone();
            tokio::spawn(async move {
                // The returned receiver owns demand for both callbacks and bytes.
                // Stop even if the server never sends another chunk after cancellation.
                let result = tokio::select! {
                    biased;
                    _ = tx.closed() => return,
                    error = Self::wait_for_goal_revocation(authority.as_ref()) => Err(error),
                    result = Self::process_sse_stream(resp.bytes_stream(), handler, tx.clone()) => result,
                };
                if let Err(e) = result {
                    let _ = tx
                        .send(streaming::AnthropicStreamEvent::Error {
                            error_type: "stream_error".into(),
                            message: e.to_string(),
                        })
                        .await;
                }
            });

            Ok(rx)
        }

        // ---- Models list ------------------------------------------------

        /// Fetch available models from `GET /v1/models`.
        ///
        /// Returns a list of models the current API key has access to.
        /// Falls back gracefully: returns an empty `Vec` on any error so
        /// callers can fall back to the hardcoded default list instead of
        /// surfacing an error.
        pub async fn fetch_available_models(&self) -> anyhow::Result<Vec<crate::AvailableModel>> {
            let url = format!("{}/v1/models", self.config.api_base);

            let mut req = self
                .http
                .get(&url)
                .header("anthropic-version", &self.config.api_version)
                .header("content-type", "application/json");
            if self.config.use_bearer_auth {
                req = req.header("Authorization", format!("Bearer {}", self.config.api_key));
            } else {
                req = req.header("x-api-key", &self.config.api_key);
            }

            let resp = req.send().await?;

            if !resp.status().is_success() {
                anyhow::bail!("models endpoint returned {}", resp.status());
            }

            #[derive(serde::Deserialize)]
            struct ModelsResponse {
                data: Vec<crate::AvailableModel>,
            }

            let body: ModelsResponse = resp.json().await?;
            Ok(body.data)
        }

        // ---- Internal helpers --------------------------------------------

        /// Build the common request and execute with retry logic.
        async fn send_with_retry(&self, body: &Value) -> Result<reqwest::Response, ClaudeError> {
            let url = format!("{}/v1/messages", self.config.api_base);
            let mut attempts = 0u32;
            let mut delay = self.config.initial_retry_delay;

            // Serialize body to JSON string for CCH signing
            let body_str = serde_json::to_string(body)
                .map_err(|e| ClaudeError::Api(format!("Failed to serialize request: {}", e)))?;
            let body_bytes = body_str.as_bytes();

            loop {
                attempts += 1;

                // Use Bearer auth when explicitly configured; otherwise use x-api-key.
                let use_oauth = self.config.use_bearer_auth;

                // Subscription OAuth (Bearer) requests to /v1/messages require the
                // `oauth-2025-04-20` beta flag; without it the API rejects the
                // request. Append it only on the Bearer path.
                let anthropic_beta = self.anthropic_beta_header();

                let mut req = self
                    .http
                    .post(&url)
                    .header("anthropic-version", &self.config.api_version)
                    .header("anthropic-beta", &anthropic_beta)
                    .header("content-type", "application/json")
                    .header("accept", "text/event-stream");

                if use_oauth {
                    req = req.header("Authorization", format!("Bearer {}", self.config.api_key));
                } else {
                    // Compute CCH billing hash and attach on the API-key path
                    // only — this is the codepath the official client uses
                    // for direct API customers.
                    let cch_hash = cch::compute_cch(body_bytes);
                    let billing_header = format!(
                        "cc_version=0.1; cc_entrypoint=claude_code; {}; cc_workload=claude_code;",
                        cch_hash
                    );
                    req = req
                        .header("x-anthropic-billing-header", billing_header)
                        .header("x-api-key", &self.config.api_key);
                }

                let req = req.body(body_str.clone());

                Self::check_goal_authority(self.goal_authority.as_ref())?;
                let resp = tokio::select! {
                    biased;
                    error = Self::wait_for_goal_revocation(self.goal_authority.as_ref()) => return Err(error),
                    response = async {
                        if let Some((turn, _)) = &self.goal_authority {
                            turn.mark_request_attempted();
                        }
                        req.send().await
                    } => response.map_err(ClaudeError::Http)?,
                };
                let status = resp.status().as_u16();

                // 200-299: success
                if resp.status().is_success() {
                    return Ok(resp);
                }

                // 429 (rate limit) or 529 (overloaded): retry
                if status == 429 || status == 529 {
                    // Honour Retry-After header if present
                    let retry_after = resp
                        .headers()
                        .get("retry-after")
                        .and_then(|v| v.to_str().ok())
                        .and_then(|v| v.parse::<u64>().ok());

                    let wait = retry_after.map(Duration::from_secs).unwrap_or(delay);

                    // Waiting inside the request looks like a stalled turn to
                    // the caller. Short waits are absorbed silently; anything
                    // longer (or retries exhausted) surfaces a structured
                    // rate-limit error so the UI can run its recovery flow
                    // (visible countdown, model switch, immediate retry).
                    const MAX_SILENT_WAIT: Duration = Duration::from_secs(20);
                    if attempts <= self.config.max_retries && wait <= MAX_SILENT_WAIT {
                        debug!(
                            status,
                            attempt = attempts,
                            wait_secs = wait.as_secs(),
                            "Retryable API error, backing off"
                        );
                        tokio::select! {
                            biased;
                            error = Self::wait_for_goal_revocation(self.goal_authority.as_ref()) => return Err(error),
                            _ = tokio::time::sleep(wait) => {},
                        }
                        delay = (delay * 2).min(self.config.max_retry_delay);
                        continue;
                    }

                    let text = Self::read_error_body(resp).await;
                    return Err(self.parse_api_error_with_retry(status, &text, retry_after));
                }

                // Non-retryable error – return immediately
                let text = Self::read_error_body(resp).await;
                return Err(self.parse_api_error(status, &text));
            }
        }

        // Keep the known HTTP status and retry policy when the diagnostic body
        // cannot be read, rather than replacing them with a transport error.
        async fn read_error_body(response: reqwest::Response) -> String {
            let status = response.status().as_u16();
            match response.text().await {
                Ok(body) => body,
                Err(error) => {
                    let failure = if error.is_timeout() {
                        "timed out"
                    } else {
                        "could not be read"
                    };
                    format!(
                        "HTTP {status} error response body {failure}: {}",
                        error.without_url()
                    )
                }
            }
        }

        /// Parse an API error body into a typed `ClaudeError`.
        pub(crate) fn parse_api_error(&self, status: u16, body: &str) -> ClaudeError {
            self.parse_api_error_with_retry(status, body, None)
        }

        /// Like [`Self::parse_api_error`], but threads a caller-extracted
        /// `Retry-After` delay into rate-limit errors so downstream recovery
        /// UI can show a real countdown instead of a dead-end message.
        pub(crate) fn parse_api_error_with_retry(
            &self,
            status: u16,
            body: &str,
            retry_after_secs: Option<u64>,
        ) -> ClaudeError {
            if let Ok(err) = serde_json::from_str::<ApiErrorResponse>(body) {
                match status {
                    401 => ClaudeError::Auth(err.error.message),
                    429 => ClaudeError::RateLimit {
                        retry_after_secs,
                        message: Some(err.error.message),
                    },
                    529 => ClaudeError::ApiStatus {
                        status,
                        message: format!("Overloaded: {}", err.error.message),
                    },
                    _ => ClaudeError::ApiStatus {
                        status,
                        message: err.error.message,
                    },
                }
            } else if status == 429 {
                ClaudeError::RateLimit {
                    retry_after_secs,
                    message: if body.trim().is_empty() {
                        None
                    } else {
                        Some(body.to_string())
                    },
                }
            } else {
                ClaudeError::ApiStatus {
                    status,
                    message: body.to_string(),
                }
            }
        }

        /// Read an SSE byte stream, parse frames, and emit `AnthropicStreamEvent`s.
        async fn process_sse_stream(
            mut byte_stream: impl futures::Stream<Item = Result<bytes::Bytes, reqwest::Error>> + Unpin,
            handler: Arc<dyn StreamHandler>,
            tx: mpsc::Sender<streaming::AnthropicStreamEvent>,
        ) -> Result<(), ClaudeError> {
            use sse_parser::SseLineParser;

            let mut parser = SseLineParser::new();
            let mut lines = crate::sse_lines::SseLines::default();
            let mut terminal_received = false;

            loop {
                let Some(chunk_result) = (tokio::select! {
                    _ = tx.closed() => return Ok(()),
                    chunk = byte_stream.next() => chunk,
                }) else {
                    break;
                };
                let chunk = chunk_result.map_err(ClaudeError::Http)?;
                for line in lines.feed(&chunk) {
                    let line = line.trim_end_matches('\r');
                    if let Some(frame) = parser.feed_line(line) {
                        if let Some(event) = Self::frame_to_event(&frame.event, &frame.data) {
                            terminal_received |= matches!(
                                &event,
                                streaming::AnthropicStreamEvent::MessageStop
                                    | streaming::AnthropicStreamEvent::Error { .. }
                            );
                            handler.on_event(&event);
                            if tx.send(event).await.is_err() {
                                // Receiver dropped – stop reading.
                                return Ok(());
                            }
                        }
                    }
                }
            }

            if !terminal_received {
                return Err(ClaudeError::Api(
                    "Anthropic stream ended before message_stop".to_string(),
                ));
            }
            Ok(())
        }

        /// Convert a parsed SSE frame into a typed `AnthropicStreamEvent`.
        fn frame_to_event(
            event_type: &Option<String>,
            data: &str,
        ) -> Option<streaming::AnthropicStreamEvent> {
            let event_name = event_type.as_deref().unwrap_or("");

            match event_name {
                "ping" => Some(streaming::AnthropicStreamEvent::Ping),

                "message_start" => {
                    let v: Value = serde_json::from_str(data).ok()?;
                    let msg = v.get("message")?;
                    let id = msg.get("id")?.as_str()?.to_string();
                    let model = msg.get("model")?.as_str()?.to_string();
                    let usage = msg
                        .get("usage")
                        .and_then(|u| serde_json::from_value::<UsageInfo>(u.clone()).ok())
                        .unwrap_or_default();

                    Some(streaming::AnthropicStreamEvent::MessageStart { id, model, usage })
                }

                "content_block_start" => {
                    let v: Value = serde_json::from_str(data).ok()?;
                    let index = v.get("index")?.as_u64()? as usize;
                    let block_value = v.get("content_block")?;
                    let content_block: ContentBlock =
                        serde_json::from_value(block_value.clone()).ok()?;
                    Some(streaming::AnthropicStreamEvent::ContentBlockStart {
                        index,
                        content_block,
                    })
                }

                "content_block_delta" => {
                    let v: Value = serde_json::from_str(data).ok()?;
                    let index = v.get("index")?.as_u64()? as usize;
                    let delta_value = v.get("delta")?;
                    let delta: streaming::ContentDelta =
                        serde_json::from_value(delta_value.clone()).ok()?;
                    Some(streaming::AnthropicStreamEvent::ContentBlockDelta { index, delta })
                }

                "content_block_stop" => {
                    let v: Value = serde_json::from_str(data).ok()?;
                    let index = v.get("index")?.as_u64()? as usize;
                    Some(streaming::AnthropicStreamEvent::ContentBlockStop { index })
                }

                "message_delta" => {
                    let v: Value = serde_json::from_str(data).ok()?;
                    let delta = v.get("delta")?;
                    let stop_reason = delta
                        .get("stop_reason")
                        .and_then(|s| s.as_str())
                        .map(|s| s.to_string());
                    // Message deltas can omit input/cache counters. Keep this
                    // wire shape separate from complete usage records.
                    #[derive(Default, Deserialize)]
                    #[serde(default)]
                    struct DeltaUsage {
                        input_tokens: u64,
                        output_tokens: u64,
                        cache_creation_input_tokens: u64,
                        cache_read_input_tokens: u64,
                    }
                    let usage = v
                        .get("usage")
                        .and_then(|u| serde_json::from_value::<DeltaUsage>(u.clone()).ok())
                        .map(|u| UsageInfo {
                            input_tokens: u.input_tokens,
                            output_tokens: u.output_tokens,
                            cache_creation_input_tokens: u.cache_creation_input_tokens,
                            cache_read_input_tokens: u.cache_read_input_tokens,
                        });
                    Some(streaming::AnthropicStreamEvent::MessageDelta { stop_reason, usage })
                }

                "message_stop" => Some(streaming::AnthropicStreamEvent::MessageStop),

                "error" => {
                    let v: Value = serde_json::from_str(data).ok()?;
                    let error = v.get("error")?;
                    let error_type = error
                        .get("type")
                        .and_then(|s| s.as_str())
                        .unwrap_or("unknown")
                        .to_string();
                    let message = error
                        .get("message")
                        .and_then(|s| s.as_str())
                        .unwrap_or("Unknown error")
                        .to_string();
                    Some(streaming::AnthropicStreamEvent::Error {
                        error_type,
                        message,
                    })
                }

                _ => {
                    debug!(event = event_name, "Unhandled SSE event type");
                    None
                }
            }
        }
    }

    #[cfg(test)]
    mod tests {
        use super::*;

        #[test]
        fn client_config_debug_omits_api_key() {
            let config = ClientConfig {
                api_key: "canary-client-key".into(),
                api_base: "https://canary-url-key@api.invalid/?token=canary-query".into(),
                ..Default::default()
            };
            let rendered = format!("{config:?}");
            for secret in ["canary-client-key", "canary-url-key", "canary-query"] {
                assert!(!rendered.contains(secret), "{rendered}");
            }
            assert!(rendered.contains("Anthropic"));
            assert_eq!(config.api_key, "canary-client-key");
        }

        #[test]
        fn message_delta_preserves_output_only_usage() {
            let event = AnthropicClient::frame_to_event(
                &Some("message_delta".into()),
                r#"{"delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":7}}"#,
            )
            .expect("message delta");
            assert!(matches!(
                event,
                streaming::AnthropicStreamEvent::MessageDelta {
                    usage: Some(UsageInfo {
                        input_tokens: 0,
                        output_tokens: 7,
                        ..
                    }),
                    ..
                }
            ));
        }
    }

    #[cfg(test)]
    mod byte_boundary_tests {
        use super::*;
        use std::sync::Mutex;

        #[derive(Default)]
        struct Recorder(Mutex<Vec<String>>);
        impl StreamHandler for Recorder {
            fn on_event(&self, event: &streaming::AnthropicStreamEvent) {
                self.0.lock().unwrap().push(format!("{event:?}"));
            }
        }

        async fn events(chunks: Vec<bytes::Bytes>) -> Vec<String> {
            let recorder = Arc::new(Recorder::default());
            let (tx, mut rx) = mpsc::channel(32);
            let result = AnthropicClient::process_sse_stream(
                futures::stream::iter(chunks.into_iter().map(Ok)),
                recorder.clone(),
                tx,
            )
            .await;
            let mut events = Vec::new();
            while let Some(event) = rx.recv().await {
                events.push(format!("{event:?}"));
            }
            assert_eq!(
                events,
                *recorder.0.lock().unwrap(),
                "callbacks and channel must match"
            );
            if events
                .iter()
                .any(|event| event.starts_with("MessageStop") || event.starts_with("Error {"))
            {
                assert!(result.is_ok(), "terminal event must complete: {result:?}");
            } else {
                assert!(
                    matches!(result, Err(ClaudeError::Api(message)) if message.contains("before message_stop")),
                    "incomplete stream must fail"
                );
            }
            events
        }

        #[tokio::test]
        async fn raw_sse_keeps_lossy_decoding_and_discards_unterminated_frames() {
            let malformed = b"event: content_block_delta\ndata: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"\xff\"}}\n\n";
            let actual = events(
                malformed
                    .iter()
                    .map(|byte| bytes::Bytes::from(vec![*byte]))
                    .collect(),
            )
            .await;
            assert_eq!(actual.len(), 1);
            assert!(actual[0].contains('\u{fffd}'));
            for wire in [
                b"event: ping\ndata: {}".as_slice(),
                b"event: ping\ndata: {}\n",
            ] {
                assert!(events(vec![bytes::Bytes::copy_from_slice(wire)])
                    .await
                    .is_empty());
            }
        }

        #[tokio::test]
        async fn raw_sse_preserves_unicode_at_every_byte_split() {
            let text = "é中\u{10000}";
            let wire = format!(
                "event: content_block_delta\r\ndata: {}\r\n\r\nevent: content_block_delta\r\ndata: {}\r\n\r\nevent: error\r\ndata: {}\r\n\r\n",
                serde_json::json!({"index":0,"delta":{"type":"text_delta","text":text}}),
                serde_json::json!({"index":1,"delta":{"type":"input_json_delta","partial_json":format!("{{\"name\":\"{text}\"}}")}}),
                serde_json::json!({"error":{"type":"fixture","message":text}}),
            );
            let expected = events(vec![bytes::Bytes::copy_from_slice(wire.as_bytes())]).await;
            assert_eq!(expected.len(), 3);
            assert!(expected.iter().all(|event| event.contains(text)));
            for split in std::iter::once(wire.find('é').unwrap() + 1).chain(0..=wire.len()) {
                let actual = events(vec![
                    bytes::Bytes::copy_from_slice(&wire.as_bytes()[..split]),
                    bytes::Bytes::copy_from_slice(&wire.as_bytes()[split..]),
                ])
                .await;
                assert_eq!(actual, expected, "split at byte {split}");
            }
            assert_eq!(
                events(
                    wire.bytes()
                        .map(|byte| bytes::Bytes::from(vec![byte]))
                        .collect()
                )
                .await,
                expected
            );
        }

        #[tokio::test]
        async fn raw_sse_waits_for_real_blank_line_and_preserves_multiline_data() {
            let (input, stream) = futures::channel::mpsc::unbounded();
            let recorder = Arc::new(Recorder::default());
            let (tx, mut rx) = mpsc::channel(32);
            let work = AnthropicClient::process_sse_stream(stream, recorder.clone(), tx);
            tokio::pin!(work);
            input
                .unbounded_send(Ok(bytes::Bytes::from_static(
                    b"event: content_block_delta\n",
                )))
                .unwrap();
            assert!(futures::poll!(&mut work).is_pending());
            input
                .unbounded_send(Ok(bytes::Bytes::from_static(b"data: {\"index\":0,\n")))
                .unwrap();
            assert!(futures::poll!(&mut work).is_pending());
            input
                .unbounded_send(Ok(bytes::Bytes::from_static(
                    b"data: \"delta\":{\"type\":\"text_delta\",\"text\":\"kept\"}}\n",
                )))
                .unwrap();
            assert!(futures::poll!(&mut work).is_pending());
            assert!(
                recorder.0.lock().unwrap().is_empty(),
                "frame dispatched without a blank line"
            );
            input
                .unbounded_send(Ok(bytes::Bytes::from_static(b"\n")))
                .unwrap();
            drop(input);
            assert!(matches!(
                work.await,
                Err(ClaudeError::Api(message)) if message.contains("before message_stop")
            ));
            assert!(
                matches!(rx.recv().await, Some(streaming::AnthropicStreamEvent::ContentBlockDelta { delta: streaming::ContentDelta::TextDelta { text }, .. }) if text == "kept")
            );
            assert!(rx.recv().await.is_none());
        }
    }
}

// ---------------------------------------------------------------------------
// Convenience builder for CreateMessageRequest
// ---------------------------------------------------------------------------

impl CreateMessageRequest {
    /// Create a minimal request builder.
    pub fn builder(model: impl Into<String>, max_tokens: u32) -> CreateMessageRequestBuilder {
        CreateMessageRequestBuilder {
            model: model.into(),
            max_tokens,
            messages: vec![],
            system: None,
            tools: None,
            temperature: None,
            top_p: None,
            top_k: None,
            stop_sequences: None,
            thinking: None,
            output_config: None,
        }
    }
}

pub struct CreateMessageRequestBuilder {
    model: String,
    max_tokens: u32,
    messages: Vec<ApiMessage>,
    system: Option<SystemPrompt>,
    tools: Option<Vec<ApiToolDefinition>>,
    temperature: Option<f32>,
    top_p: Option<f32>,
    top_k: Option<u32>,
    stop_sequences: Option<Vec<String>>,
    thinking: Option<ThinkingConfig>,
    output_config: Option<OutputConfig>,
}

impl CreateMessageRequestBuilder {
    pub fn messages(mut self, msgs: Vec<ApiMessage>) -> Self {
        self.messages = msgs;
        self
    }

    pub fn add_message(mut self, msg: ApiMessage) -> Self {
        self.messages.push(msg);
        self
    }

    pub fn system(mut self, s: SystemPrompt) -> Self {
        self.system = Some(s);
        self
    }

    pub fn system_text(mut self, text: impl Into<String>) -> Self {
        self.system = Some(SystemPrompt::Text(text.into()));
        self
    }

    pub fn tools(mut self, tools: Vec<ApiToolDefinition>) -> Self {
        self.tools = Some(tools);
        self
    }

    pub fn temperature(mut self, t: f32) -> Self {
        self.temperature = Some(t);
        self
    }

    pub fn top_p(mut self, p: f32) -> Self {
        self.top_p = Some(p);
        self
    }

    pub fn top_k(mut self, k: u32) -> Self {
        self.top_k = Some(k);
        self
    }

    pub fn stop_sequences(mut self, seqs: Vec<String>) -> Self {
        self.stop_sequences = Some(seqs);
        self
    }

    pub fn thinking(mut self, config: ThinkingConfig) -> Self {
        self.thinking = Some(config);
        self
    }

    /// Set the `effort` level (`"low" | "medium" | "high" | "max"`), sent via
    /// `output_config.effort`. Used in place of `budget_tokens` on models with
    /// adaptive thinking (Opus 4.7+, Opus 4.8, Fable 5).
    pub fn effort(mut self, effort: impl Into<String>) -> Self {
        self.output_config = Some(OutputConfig::with_effort(effort));
        self
    }

    pub fn build(self) -> CreateMessageRequest {
        CreateMessageRequest {
            model: self.model,
            max_tokens: self.max_tokens,
            messages: self.messages,
            system: self.system,
            tools: self.tools,
            temperature: self.temperature,
            top_p: self.top_p,
            top_k: self.top_k,
            stop_sequences: self.stop_sequences,
            stream: true,
            thinking: self.thinking,
            output_config: self.output_config,
        }
    }
}

// ---------------------------------------------------------------------------
// Accumulated message builder – reconstructs a full Message from stream events
// ---------------------------------------------------------------------------

/// Collects streaming events and produces a finished `Message` plus usage info.
pub struct StreamAccumulator {
    id: Option<String>,
    model: Option<String>,
    /// Completed blocks paired with their stream indexes so open and completed
    /// blocks can be reconstructed in their original order at finalization.
    content_blocks: Vec<(usize, ContentBlock)>,
    /// Partial accumulators keyed by block index.
    partials: std::collections::HashMap<usize, PartialBlock>,
    stop_reason: Option<String>,
    usage: UsageInfo,
    received_message_stop: bool,
}

#[derive(Debug)]
enum PartialBlock {
    Text(String),
    ToolUse {
        id: String,
        name: String,
        initial_input: Value,
        json_buf: Option<String>,
    },
    Thinking {
        thinking_buf: String,
        signature_buf: String,
    },
    Other(ContentBlock),
}

impl PartialBlock {
    fn into_content_block(self) -> ContentBlock {
        match self {
            Self::Text(text) => ContentBlock::Text { text },
            Self::ToolUse {
                id,
                name,
                initial_input,
                json_buf,
            } => {
                let input = match json_buf {
                    Some(json) => serde_json::from_str(&json).unwrap_or(Value::String(json)),
                    None => initial_input,
                };
                ContentBlock::ToolUse { id, name, input }
            }
            Self::Thinking {
                thinking_buf,
                signature_buf,
            } => ContentBlock::Thinking {
                thinking: thinking_buf,
                signature: signature_buf,
            },
            Self::Other(block) => block,
        }
    }
}

impl Default for StreamAccumulator {
    fn default() -> Self {
        Self::new()
    }
}

impl StreamAccumulator {
    pub fn new() -> Self {
        Self {
            id: None,
            model: None,
            content_blocks: vec![],
            partials: Default::default(),
            stop_reason: None,
            usage: UsageInfo::default(),
            received_message_stop: false,
        }
    }

    /// Feed a stream event. Call this for every event received from the stream.
    pub fn on_event(&mut self, event: &streaming::AnthropicStreamEvent) {
        use streaming::AnthropicStreamEvent;
        match event {
            AnthropicStreamEvent::MessageStart { id, model, usage } => {
                self.id = Some(id.clone());
                self.model = Some(model.clone());
                self.usage = usage.clone();
            }

            AnthropicStreamEvent::ContentBlockStart {
                index,
                content_block,
            } => {
                let partial = match content_block {
                    ContentBlock::Text { text } => PartialBlock::Text(text.clone()),
                    ContentBlock::ToolUse { id, name, input } => PartialBlock::ToolUse {
                        id: id.clone(),
                        name: name.clone(),
                        initial_input: input.clone(),
                        json_buf: None,
                    },
                    ContentBlock::Thinking {
                        thinking,
                        signature,
                    } => PartialBlock::Thinking {
                        thinking_buf: thinking.clone(),
                        signature_buf: signature.clone(),
                    },
                    other => PartialBlock::Other(other.clone()),
                };
                self.partials.insert(*index, partial);
            }

            AnthropicStreamEvent::ContentBlockDelta { index, delta } => {
                match delta {
                    streaming::ContentDelta::TextDelta { .. } => {
                        self.partials
                            .entry(*index)
                            .or_insert_with(|| PartialBlock::Text(String::new()));
                    }
                    streaming::ContentDelta::ThinkingDelta { .. }
                    | streaming::ContentDelta::SignatureDelta { .. } => {
                        self.partials
                            .entry(*index)
                            .or_insert_with(|| PartialBlock::Thinking {
                                thinking_buf: String::new(),
                                signature_buf: String::new(),
                            });
                    }
                    streaming::ContentDelta::InputJsonDelta { .. } => {}
                }
                if let Some(partial) = self.partials.get_mut(index) {
                    match (partial, delta) {
                        (PartialBlock::Text(buf), streaming::ContentDelta::TextDelta { text }) => {
                            buf.push_str(text);
                        }
                        (
                            PartialBlock::ToolUse { json_buf, .. },
                            streaming::ContentDelta::InputJsonDelta { partial_json },
                        ) => {
                            json_buf
                                .get_or_insert_with(String::new)
                                .push_str(partial_json);
                        }
                        (
                            PartialBlock::Thinking { thinking_buf, .. },
                            streaming::ContentDelta::ThinkingDelta { thinking },
                        ) => {
                            thinking_buf.push_str(thinking);
                        }
                        (
                            PartialBlock::Thinking { signature_buf, .. },
                            streaming::ContentDelta::SignatureDelta { signature },
                        ) => {
                            signature_buf.push_str(signature);
                        }
                        _ => {}
                    }
                }
            }

            AnthropicStreamEvent::ContentBlockStop { index } => {
                if let Some(partial) = self.partials.remove(index) {
                    self.content_blocks
                        .push((*index, partial.into_content_block()));
                }
            }

            AnthropicStreamEvent::MessageDelta { stop_reason, usage } => {
                if let Some(sr) = stop_reason {
                    self.stop_reason = Some(sr.clone());
                }
                if let Some(u) = usage {
                    self.merge_usage(u);
                }
            }

            AnthropicStreamEvent::MessageStop => self.received_message_stop = true,
            AnthropicStreamEvent::Ping => {}
            AnthropicStreamEvent::Error { .. } => {}
        }
    }

    /// Feed a provider-agnostic event through the same indexed lossless
    /// accumulation used by Anthropic's native stream.
    pub fn on_provider_event(&mut self, event: &crate::provider_types::StreamEvent) {
        use crate::provider_types::{StopReason, StreamEvent};
        use streaming::{AnthropicStreamEvent, ContentDelta};

        let anthropic_event = match event {
            StreamEvent::MessageStart { id, model, usage } => AnthropicStreamEvent::MessageStart {
                id: id.clone(),
                model: model.clone(),
                usage: usage.clone(),
            },
            StreamEvent::ContentBlockStart {
                index,
                content_block,
            } => AnthropicStreamEvent::ContentBlockStart {
                index: *index,
                content_block: content_block.clone(),
            },
            StreamEvent::TextDelta { index, text } => AnthropicStreamEvent::ContentBlockDelta {
                index: *index,
                delta: ContentDelta::TextDelta { text: text.clone() },
            },
            StreamEvent::ThinkingDelta { index, thinking } => {
                AnthropicStreamEvent::ContentBlockDelta {
                    index: *index,
                    delta: ContentDelta::ThinkingDelta {
                        thinking: thinking.clone(),
                    },
                }
            }
            StreamEvent::ReasoningDelta { index, reasoning } => {
                AnthropicStreamEvent::ContentBlockDelta {
                    index: *index,
                    delta: ContentDelta::ThinkingDelta {
                        thinking: reasoning.clone(),
                    },
                }
            }
            StreamEvent::InputJsonDelta {
                index,
                partial_json,
            } => AnthropicStreamEvent::ContentBlockDelta {
                index: *index,
                delta: ContentDelta::InputJsonDelta {
                    partial_json: partial_json.clone(),
                },
            },
            StreamEvent::SignatureDelta { index, signature } => {
                AnthropicStreamEvent::ContentBlockDelta {
                    index: *index,
                    delta: ContentDelta::SignatureDelta {
                        signature: signature.clone(),
                    },
                }
            }
            StreamEvent::ContentBlockStop { index } => {
                AnthropicStreamEvent::ContentBlockStop { index: *index }
            }
            StreamEvent::MessageDelta { stop_reason, usage } => {
                let stop_reason = stop_reason.as_ref().map(|reason| match reason {
                    StopReason::EndTurn => "end_turn".to_string(),
                    StopReason::StopSequence => "stop_sequence".to_string(),
                    StopReason::MaxTokens => "max_tokens".to_string(),
                    StopReason::ToolUse => "tool_use".to_string(),
                    StopReason::ContentFiltered => "content_filtered".to_string(),
                    StopReason::Other(reason) => reason.clone(),
                });
                AnthropicStreamEvent::MessageDelta {
                    stop_reason,
                    usage: usage.clone(),
                }
            }
            StreamEvent::MessageStop => AnthropicStreamEvent::MessageStop,
            StreamEvent::Ping => AnthropicStreamEvent::Ping,
            StreamEvent::Error {
                error_type,
                message,
            } => AnthropicStreamEvent::Error {
                error_type: error_type.clone(),
                message: message.clone(),
            },
        };
        self.on_event(&anthropic_event);
    }

    fn merge_usage(&mut self, update: &UsageInfo) {
        self.usage.input_tokens = self.usage.input_tokens.max(update.input_tokens);
        self.usage.output_tokens = self.usage.output_tokens.max(update.output_tokens);
        self.usage.cache_creation_input_tokens = self
            .usage
            .cache_creation_input_tokens
            .max(update.cache_creation_input_tokens);
        self.usage.cache_read_input_tokens = self
            .usage
            .cache_read_input_tokens
            .max(update.cache_read_input_tokens);
    }

    /// Finalize and produce the accumulated `Message`.
    pub fn finish(self) -> (Message, UsageInfo, Option<String>) {
        let mut content_blocks = self.content_blocks;
        content_blocks.extend(
            self.partials
                .into_iter()
                .map(|(index, partial)| (index, partial.into_content_block())),
        );
        content_blocks.sort_unstable_by_key(|(index, _)| *index);
        let msg =
            Message::assistant_blocks(content_blocks.into_iter().map(|(_, block)| block).collect());
        (msg, self.usage, self.stop_reason)
    }

    pub fn stop_reason(&self) -> Option<&str> {
        self.stop_reason.as_deref()
    }

    pub fn usage(&self) -> &UsageInfo {
        &self.usage
    }

    pub fn model(&self) -> Option<&str> {
        self.model.as_deref()
    }

    /// Provider-assigned message identifier, if one arrived before finalization.
    pub fn message_id(&self) -> Option<&str> {
        self.id.as_deref()
    }

    /// Whether the stream supplied the explicit protocol completion event.
    pub fn received_message_stop(&self) -> bool {
        self.received_message_stop
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sse_parser_basic() {
        let mut parser = sse_parser::SseLineParser::new();
        assert!(parser.feed_line("event: message_start").is_none());
        assert!(parser
            .feed_line(r#"data: {"message":{"id":"m1","model":"claude","usage":{"input_tokens":0,"output_tokens":0}}}"#)
            .is_none());
        let frame = parser.feed_line("").expect("should produce frame");
        assert_eq!(frame.event.as_deref(), Some("message_start"));
        assert!(frame.data.contains("m1"));
    }

    #[test]
    fn test_create_message_request_builder() {
        let req = CreateMessageRequest::builder("claude-opus-4-6", 4096)
            .system_text("You are helpful.")
            .temperature(0.7)
            .build();
        assert_eq!(req.model, "claude-opus-4-6");
        assert_eq!(req.max_tokens, 4096);
        assert!(req.stream);
    }

    #[tokio::test]
    async fn dropping_stream_receiver_closes_a_stalled_sse_connection() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind stalled SSE listener");
        let addr = listener.local_addr().expect("stalled SSE listener address");
        let (request_active_tx, request_active_rx) = tokio::sync::oneshot::channel();
        let (connection_closed_tx, connection_closed_rx) = tokio::sync::oneshot::channel();

        tokio::spawn(async move {
            let (mut stream, _) = listener.accept().await.expect("accept SSE request");
            let mut request = Vec::new();
            let mut buffer = [0_u8; 1024];
            let headers_end = loop {
                let read = stream.read(&mut buffer).await.expect("read SSE request");
                assert_ne!(read, 0, "SSE client closed before sending a request");
                request.extend_from_slice(&buffer[..read]);
                if let Some(end) = request.windows(4).position(|window| window == b"\r\n\r\n") {
                    break end + 4;
                }
            };
            let headers = std::str::from_utf8(&request[..headers_end])
                .expect("SSE request headers are UTF-8");
            let content_length = headers
                .lines()
                .find_map(|line| line.strip_prefix("content-length:"))
                .expect("SSE request has a content length")
                .trim()
                .parse::<usize>()
                .expect("SSE request content length is valid");
            while request.len() < headers_end + content_length {
                let read = stream
                    .read(&mut buffer)
                    .await
                    .expect("read SSE request body");
                assert_ne!(read, 0, "SSE client closed while sending the request body");
                request.extend_from_slice(&buffer[..read]);
            }

            stream
                .write_all(
                    b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nConnection: keep-alive\r\n\r\n",
                )
                .await
                .expect("write stalled SSE response headers");
            stream.flush().await.expect("flush stalled SSE response");
            let _ = request_active_tx.send(());

            let mut byte = [0_u8; 1];
            loop {
                if stream
                    .read(&mut byte)
                    .await
                    .expect("wait for stalled SSE connection closure")
                    == 0
                {
                    let _ = connection_closed_tx.send(());
                    return;
                }
            }
        });

        let client = AnthropicClient::new(client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base: format!("http://{addr}"),
            max_retries: 0,
            ..Default::default()
        })
        .expect("create Anthropic client");
        let receiver = client
            .create_message_stream(
                CreateMessageRequest::builder("claude-test", 1).build(),
                Arc::new(streaming::NullStreamHandler),
            )
            .await
            .expect("create stalled message stream");

        tokio::time::timeout(Duration::from_secs(1), request_active_rx)
            .await
            .expect("stalled SSE request must become active")
            .expect("stalled SSE server must report the active request");
        drop(receiver);

        tokio::time::timeout(Duration::from_secs(1), connection_closed_rx)
            .await
            .expect("dropping the receiver must close the stalled SSE connection")
            .expect("stalled SSE server must observe connection closure");
    }

    #[test]
    fn oauth_bearer_appends_oauth_beta_flag() {
        let cfg = client::ClientConfig {
            api_key: "oauth-token".to_string(),
            use_bearer_auth: true,
            beta_features: "effort-2025-11-24".to_string(),
            ..Default::default()
        };
        let client = AnthropicClient::new(cfg).expect("client");
        let header = client.anthropic_beta_header();
        assert!(header.contains("oauth-2025-04-20"), "header={header}");
        assert!(header.contains("effort-2025-11-24"), "header={header}");
    }

    #[test]
    fn api_key_path_omits_oauth_beta_flag() {
        let cfg = client::ClientConfig {
            api_key: "sk-ant-xyz".to_string(),
            use_bearer_auth: false,
            beta_features: "effort-2025-11-24".to_string(),
            ..Default::default()
        };
        let client = AnthropicClient::new(cfg).expect("client");
        let header = client.anthropic_beta_header();
        assert!(!header.contains("oauth-2025-04-20"), "header={header}");
        assert_eq!(header, "effort-2025-11-24");
    }

    #[test]
    fn anthropic_429_preserves_provider_message_and_retry_after() {
        let client = AnthropicClient::new(client::ClientConfig::default()).expect("client");
        let err = client.parse_api_error_with_retry(
            429,
            r#"{"type":"error","error":{"type":"rate_limit_error","message":"model is temporarily unavailable"}}"#,
            Some(42),
        );

        match err {
            ClaudeError::RateLimit {
                retry_after_secs,
                message,
            } => {
                assert_eq!(retry_after_secs, Some(42));
                assert_eq!(message.as_deref(), Some("model is temporarily unavailable"));
            }
            other => panic!("expected RateLimit, got {other:?}"),
        }
    }

    #[test]
    fn adaptive_thinking_serializes_without_budget_tokens() {
        let req = CreateMessageRequest::builder("claude-opus-4-8", 8192)
            .thinking(ThinkingConfig::adaptive())
            .effort("high")
            .build();
        let body = serde_json::to_value(&req).unwrap();
        assert_eq!(body["thinking"]["type"], "adaptive");
        // budget_tokens must be omitted for adaptive thinking (the API 400s on it).
        assert!(body["thinking"].get("budget_tokens").is_none());
        assert_eq!(body["output_config"]["effort"], "high");
    }

    #[test]
    fn enabled_thinking_keeps_budget_tokens() {
        let req = CreateMessageRequest::builder("claude-opus-4-6", 8192)
            .thinking(ThinkingConfig::enabled(10_000))
            .build();
        let body = serde_json::to_value(&req).unwrap();
        assert_eq!(body["thinking"]["type"], "enabled");
        assert_eq!(body["thinking"]["budget_tokens"], 10_000);
        // No effort/output_config unless explicitly set.
        assert!(body.get("output_config").is_none());
    }

    #[test]
    fn test_stream_accumulator_text() {
        let mut acc = StreamAccumulator::new();
        acc.on_event(&streaming::AnthropicStreamEvent::MessageStart {
            id: "m1".into(),
            model: "claude".into(),
            usage: UsageInfo::default(),
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 0,
            content_block: ContentBlock::Text {
                text: String::new(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 0,
            delta: streaming::ContentDelta::TextDelta {
                text: "Hello ".into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 0,
            delta: streaming::ContentDelta::TextDelta {
                text: "world!".into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStop { index: 0 });
        acc.on_event(&streaming::AnthropicStreamEvent::MessageDelta {
            stop_reason: Some("end_turn".into()),
            usage: None,
        });
        acc.on_event(&streaming::AnthropicStreamEvent::MessageStop);

        let (msg, _usage, stop) = acc.finish();
        assert_eq!(msg.get_text(), Some("Hello world!"));
        assert_eq!(stop.as_deref(), Some("end_turn"));
    }

    #[test]
    fn stream_accumulator_finish_keeps_open_blocks_in_stream_index_order() {
        let mut acc = StreamAccumulator::new();

        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 0,
            content_block: ContentBlock::Text {
                text: "partial ".into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 0,
            delta: streaming::ContentDelta::TextDelta {
                text: "text".into(),
            },
        });

        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 1,
            content_block: ContentBlock::ToolUse {
                id: "completed-tool".into(),
                name: "completed".into(),
                input: serde_json::json!({}),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 1,
            delta: streaming::ContentDelta::InputJsonDelta {
                partial_json: r#"{"complete":true}"#.into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStop { index: 1 });

        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 2,
            content_block: ContentBlock::Thinking {
                thinking: "partial ".into(),
                signature: "sig-".into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 2,
            delta: streaming::ContentDelta::ThinkingDelta {
                thinking: "thinking".into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 2,
            delta: streaming::ContentDelta::SignatureDelta {
                signature: "partial".into(),
            },
        });

        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 3,
            content_block: ContentBlock::Text {
                text: "completed".into(),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStop { index: 3 });

        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 4,
            content_block: ContentBlock::ToolUse {
                id: "partial-tool".into(),
                name: "partial".into(),
                input: serde_json::json!({}),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 4,
            delta: streaming::ContentDelta::InputJsonDelta {
                partial_json: r#"{"preserved":"json"}"#.into(),
            },
        });

        let (message, _, _) = acc.finish();
        let claurst_core::types::MessageContent::Blocks(blocks) = message.content else {
            panic!("stream accumulator must return block content");
        };

        assert!(matches!(&blocks[0], ContentBlock::Text { text } if text == "partial text"));
        assert!(matches!(
            &blocks[1],
            ContentBlock::ToolUse { id, name, input }
                if id == "completed-tool"
                    && name == "completed"
                    && input == &serde_json::json!({"complete": true})
        ));
        assert!(matches!(
            &blocks[2],
            ContentBlock::Thinking { thinking, signature }
                if thinking == "partial thinking" && signature == "sig-partial"
        ));
        assert!(matches!(&blocks[3], ContentBlock::Text { text } if text == "completed"));
        assert!(matches!(
            &blocks[4],
            ContentBlock::ToolUse { id, name, input }
                if id == "partial-tool"
                    && name == "partial"
                    && input == &serde_json::json!({"preserved": "json"})
        ));
    }

    #[test]
    fn stream_accumulator_preserves_incomplete_tool_json() {
        let raw_json = r#"{"path":"unfinished"#;
        let mut acc = StreamAccumulator::new();
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
            index: 0,
            content_block: ContentBlock::ToolUse {
                id: "incomplete-tool".into(),
                name: "Write".into(),
                input: serde_json::json!({}),
            },
        });
        acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
            index: 0,
            delta: streaming::ContentDelta::InputJsonDelta {
                partial_json: raw_json.into(),
            },
        });

        let (message, _, _) = acc.finish();
        assert!(matches!(
            &message.content,
            claurst_core::types::MessageContent::Blocks(blocks)
                if matches!(
                    &blocks[0],
                    ContentBlock::ToolUse { input, .. } if input == &Value::String(raw_json.into())
                )
        ));
    }

    #[test]
    fn stream_accumulator_preserves_tool_start_input_without_deltas() {
        for input in [serde_json::json!({}), serde_json::json!({"path": "ready"})] {
            for stopped in [false, true] {
                let mut acc = StreamAccumulator::new();
                acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
                    index: 0,
                    content_block: ContentBlock::ToolUse {
                        id: "tool".into(),
                        name: "Read".into(),
                        input: input.clone(),
                    },
                });
                if stopped {
                    acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStop { index: 0 });
                }
                let (message, _, _) = acc.finish();
                assert!(matches!(message.content_blocks().as_slice(),
                    [ContentBlock::ToolUse { input: actual, .. }] if actual == &input));
            }
        }
    }

    #[test]
    fn stream_accumulator_json_deltas_replace_tool_start_input() {
        for (delta, expected) in [
            (r#"{"path":"delta"}"#, serde_json::json!({"path": "delta"})),
            (
                r#"{"path":"unfinished"#,
                Value::String(r#"{"path":"unfinished"#.into()),
            ),
            ("", Value::String(String::new())),
        ] {
            let mut acc = StreamAccumulator::new();
            acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockStart {
                index: 0,
                content_block: ContentBlock::ToolUse {
                    id: "tool".into(),
                    name: "Read".into(),
                    input: serde_json::json!({"path":"start"}),
                },
            });
            acc.on_event(&streaming::AnthropicStreamEvent::ContentBlockDelta {
                index: 0,
                delta: streaming::ContentDelta::InputJsonDelta {
                    partial_json: delta.into(),
                },
            });
            let (message, _, _) = acc.finish();
            assert!(matches!(message.content_blocks().as_slice(),
                [ContentBlock::ToolUse { input, .. }] if input == &expected));
        }
    }

    #[test]
    fn stream_accumulator_usage_is_cumulative_not_additive() {
        let mut acc = StreamAccumulator::new();
        acc.on_event(&streaming::AnthropicStreamEvent::MessageStart {
            id: "message".into(),
            model: "model".into(),
            usage: UsageInfo {
                input_tokens: 10,
                output_tokens: 1,
                cache_creation_input_tokens: 2,
                cache_read_input_tokens: 3,
            },
        });
        for output_tokens in [4, 7, 7] {
            acc.on_event(&streaming::AnthropicStreamEvent::MessageDelta {
                stop_reason: None,
                usage: Some(UsageInfo {
                    output_tokens,
                    ..UsageInfo::default()
                }),
            });
        }
        let (_, usage, _) = acc.finish();
        assert_eq!(usage.input_tokens, 10);
        assert_eq!(usage.output_tokens, 7);
        assert_eq!(usage.cache_creation_input_tokens, 2);
        assert_eq!(usage.cache_read_input_tokens, 3);
    }
}
