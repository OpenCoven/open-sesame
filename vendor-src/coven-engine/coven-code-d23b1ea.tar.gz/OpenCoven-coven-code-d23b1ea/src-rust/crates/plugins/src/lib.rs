// claurst-plugins: Plugin runtime for the Coven Code CLI.
//
// This crate handles plugin discovery, manifest parsing, hook registration,
// and the /plugin + /reload-plugins command definitions.
//
// Dependency order: cc-plugins → cc-core only.
// cc-commands → cc-plugins (not the other way around).

pub mod hooks;
pub mod loader;
pub mod manifest;
pub mod marketplace;
pub mod plugin;
pub mod registry;
mod trust;

// Re-export the most commonly used items at the crate root.
pub use hooks::{register_plugin_hooks, HookOutcome, HookRegistry, RegisteredHook};
pub use loader::{default_user_plugins_dir, discover_plugins, project_plugins_dir};
pub use manifest::{
    HookEventKind, PluginAuthor, PluginHookEntry, PluginHookMatcher, PluginHooksConfig,
    PluginLspServer, PluginManifest, PluginMcpServer, UserConfigValueType,
};
pub use plugin::{
    CommandRunAction, LoadedPlugin, PluginCommandDef, PluginError, PluginSource, ReloadDiff,
};
pub use registry::PluginRegistry;
pub use trust::save_plugin_enabled;

// ---------------------------------------------------------------------------
// Capability enforcement
// ---------------------------------------------------------------------------

/// Effectful actions require an explicit manifest capability. Missing and empty
/// grants deny those actions; static responses require no grant.
pub fn check_plugin_capability(def: &PluginCommandDef) -> Result<(), String> {
    let Some(required) = def.run_action.required_capability() else {
        return Ok(());
    };
    if has_capability(def.plugin_capabilities.as_deref(), required) {
        Ok(())
    } else {
        Err(format!(
            "Plugin '{}' is not allowed to use capability '{}'. \
             Add '{}' to the 'capabilities' list in its manifest to enable this action.",
            def.plugin_name, required, required
        ))
    }
}

pub(crate) fn has_capability(granted: Option<&[String]>, required: &str) -> bool {
    granted.is_some_and(|grants| grants.iter().any(|grant| grant == required))
}

use once_cell::sync::Lazy;
use std::path::Path;
use std::sync::Arc;

// ---------------------------------------------------------------------------
// Global hook registry (set once at startup, read during tool execution)
// ---------------------------------------------------------------------------

static GLOBAL_HOOK_REGISTRY: Lazy<parking_lot::RwLock<Option<Arc<HookRegistry>>>> =
    Lazy::new(|| parking_lot::RwLock::new(None));

// ---------------------------------------------------------------------------
// Global plugin registry (set once at startup, read by commands / tools)
// ---------------------------------------------------------------------------

static GLOBAL_PLUGIN_REGISTRY: Lazy<parking_lot::RwLock<Option<Arc<PluginRegistry>>>> =
    Lazy::new(|| parking_lot::RwLock::new(None));

/// Store the fully-loaded `PluginRegistry` into a process-global static so
/// that slash commands and tools can query it without carrying the registry
/// through every call frame.
pub fn set_global_registry(registry: PluginRegistry) {
    *GLOBAL_PLUGIN_REGISTRY.write() = Some(Arc::new(registry));
}

/// Access the global `PluginRegistry`, if it has been set.
pub fn global_plugin_registry() -> Option<Arc<PluginRegistry>> {
    GLOBAL_PLUGIN_REGISTRY.read().clone()
}

/// Refresh active plugins after a project transition without activating startup discovery.
/// A matching registry retains its existing plugins, including explicit extra paths.
pub async fn refresh_cached_plugins(project_dir: &std::path::Path) {
    let Some(registry) = global_plugin_registry() else {
        return;
    };
    if registry.matches_project(project_dir) {
        return;
    }

    // Retire the previous project's hooks before discovering the new project.
    set_global_hooks(HookRegistry::new());
    let registry = load_plugins(project_dir, &[]).await;
    set_global_hooks(registry.build_hook_registry());
    set_global_registry(registry);
}

/// Store the hook registry built from loaded plugins into a process-global
/// static so that `run_global_pre_tool_hook` / `run_global_post_tool_hook`
/// can access it from anywhere without passing the registry around.
pub fn set_global_hooks(registry: HookRegistry) {
    *GLOBAL_HOOK_REGISTRY.write() = Some(Arc::new(registry));
}

/// Run all `PreToolUse` hooks registered by plugins for the given tool.
///
/// Returns `HookOutcome::Deny` if any blocking hook returns a non-zero exit
/// code, otherwise `HookOutcome::Allow`.
pub fn run_global_pre_tool_hook(
    tool_name: &str,
    tool_input: &serde_json::Value,
    working_dir: &Path,
) -> hooks::HookOutcome {
    let registry = match GLOBAL_HOOK_REGISTRY.read().clone() {
        Some(r) => r,
        None => return hooks::HookOutcome::Allow,
    };

    let event_key = HookEventKind::PreToolUse.to_string();
    let hooks_for_event = match registry.get(&event_key) {
        Some(h) => h,
        None => return hooks::HookOutcome::Allow,
    };

    let event_json = serde_json::json!({
        "event": "PreToolUse",
        "tool_name": tool_name,
        "tool_input": tool_input,
    })
    .to_string();

    for hook in hooks_for_event {
        // Apply matcher filter if present
        if let Some(ref matcher) = hook.matcher {
            if !matcher.is_empty() && !hooks::glob_match(matcher, tool_name) {
                continue;
            }
        }
        match hooks::run_hook_sync(hook, &event_json, working_dir) {
            hooks::HookOutcome::Deny(reason) => return hooks::HookOutcome::Deny(reason),
            hooks::HookOutcome::Allow | hooks::HookOutcome::Error(_) => {}
        }
    }

    hooks::HookOutcome::Allow
}

/// Run all `PostToolUse` hooks registered by plugins for the given tool.
/// Post-tool hooks are informational; the return value is not used to block.
pub fn run_global_post_tool_hook(
    tool_name: &str,
    tool_input: &serde_json::Value,
    tool_output: &str,
    is_error: bool,
    working_dir: &Path,
) {
    let registry = match GLOBAL_HOOK_REGISTRY.read().clone() {
        Some(r) => r,
        None => return,
    };

    let event_key = HookEventKind::PostToolUse.to_string();
    let hooks_for_event = match registry.get(&event_key) {
        Some(h) => h,
        None => return,
    };

    let event_json = serde_json::json!({
        "event": "PostToolUse",
        "tool_name": tool_name,
        "tool_input": tool_input,
        "tool_output": tool_output,
        "is_error": is_error,
    })
    .to_string();

    for hook in hooks_for_event {
        if let Some(ref matcher) = hook.matcher {
            if !matcher.is_empty() && !hooks::glob_match(matcher, tool_name) {
                continue;
            }
        }
        hooks::run_hook_sync(hook, &event_json, working_dir);
    }
}

// ---------------------------------------------------------------------------
// Top-level async API (called from cc-commands / cc-cli)
// ---------------------------------------------------------------------------

/// Discover and load all plugins from the standard locations.
///
/// Search order:
/// 1. `~/.coven-code/plugins/`  (user-global)
/// 2. `<project_dir>/.coven-code/plugins/`  (project-local)
/// 3. Any paths listed in `extra_paths`
///
/// Project plugins are discovered but disabled until the user grants folder
/// trust with `/plugin enable`. Only engine-global settings authorize them.
/// Returns a fully populated `PluginRegistry`.  Errors encountered during
/// loading are stored in `registry.errors` rather than propagated, so the
/// caller always gets a usable registry even when individual plugins fail.
pub async fn load_plugins(
    project_dir: &Path,
    extra_paths: &[std::path::PathBuf],
) -> PluginRegistry {
    let mut registry = PluginRegistry::new();
    registry.project_root = project_dir.canonicalize().ok();

    // User plugins.
    {
        let user_dir = default_user_plugins_dir();
        let (plugins, errors) = discover_plugins(&[user_dir], PluginSource::User).await;
        registry.extend(plugins, errors);
    }

    // Project plugins.
    let proj_dir = project_plugins_dir(project_dir);
    let (plugins, errors) = discover_plugins(&[proj_dir], PluginSource::Project).await;
    registry.extend(plugins, errors);

    // Extra paths.
    for path in extra_paths {
        let (plugins, errors) = discover_plugins(
            std::slice::from_ref(path),
            PluginSource::Extra(path.to_string_lossy().into_owned()),
        )
        .await;
        registry.extend(plugins, errors);
    }

    trust::apply_saved_state(&mut registry, project_dir);
    registry
}

/// Reload plugins: produce a new registry, compute the diff, and replace the old one.
///
/// Returns the new registry and a `ReloadDiff` describing what changed.
pub async fn reload_plugins(
    old_registry: &PluginRegistry,
    project_dir: &Path,
    extra_paths: &[std::path::PathBuf],
) -> (PluginRegistry, ReloadDiff) {
    let new_registry = load_plugins(project_dir, extra_paths).await;
    let diff = new_registry.diff_against(old_registry);
    (new_registry, diff)
}

// ---------------------------------------------------------------------------
// /plugin command definition (data-only, no SlashCommand impl here)
// ---------------------------------------------------------------------------

/// Sub-commands supported by `/plugin`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PluginSubCommand {
    /// `/plugin list` — show all installed plugins with enabled/disabled status.
    List,
    /// `/plugin enable <name>` — enable a plugin.
    Enable(String),
    /// `/plugin disable <name>` — disable a plugin.
    Disable(String),
    /// `/plugin info <name>` — show details about a plugin.
    Info(String),
    /// `/plugin install <path>` — install a plugin from a local path.
    Install(String),
    /// `/plugin reload` — reload plugins from disk.
    Reload,
    /// Show usage / help.
    Help,
}

/// Parse the arguments string for `/plugin`.
pub fn parse_plugin_args(args: &str) -> PluginSubCommand {
    let args = args.trim();
    // No args → show list
    if args.is_empty() {
        return PluginSubCommand::List;
    }
    let parts: Vec<&str> = args.splitn(3, char::is_whitespace).collect();
    match parts.first().map(|s| s.to_lowercase()).as_deref() {
        Some("list") | Some("ls") => PluginSubCommand::List,
        Some("enable") => PluginSubCommand::Enable(parts.get(1).unwrap_or(&"").to_string()),
        Some("disable") => PluginSubCommand::Disable(parts.get(1).unwrap_or(&"").to_string()),
        Some("info") | Some("show") => {
            PluginSubCommand::Info(parts.get(1).unwrap_or(&"").to_string())
        }
        Some("install") | Some("i") => {
            PluginSubCommand::Install(parts.get(1).unwrap_or(&"").to_string())
        }
        Some("reload") | Some("refresh") => PluginSubCommand::Reload,
        Some("help") | Some("--help") | Some("-h") => PluginSubCommand::Help,
        _ => PluginSubCommand::Help,
    }
}

/// Build the text output for `/plugin list`.
pub fn format_plugin_list(registry: &PluginRegistry) -> String {
    let mut out = String::new();
    let mut all: Vec<&LoadedPlugin> = registry.all();
    all.sort_by(|a, b| a.name.cmp(&b.name));

    if all.is_empty() && registry.errors.is_empty() {
        return "No plugins installed.\n\nUse `/plugin install <path>` to install a plugin from a local directory.".to_string();
    }

    let total = all.len();
    let enabled_count = all.iter().filter(|p| registry.is_enabled(&p.name)).count();
    out.push_str(&format!(
        "Installed plugins: {} ({} enabled)\n\n",
        total, enabled_count
    ));
    for p in &all {
        let status = if registry.is_enabled(&p.name) {
            "enabled"
        } else {
            "disabled"
        };
        let version = p.manifest.version.as_deref().unwrap_or("(no version)");
        let desc = p.manifest.description.as_deref().unwrap_or("");

        // Count commands and hooks for this plugin.
        let cmd_count = loader::collect_command_defs(p).len();
        let hook_count = p
            .hooks_config
            .as_ref()
            .map(|hc| hc.events.values().map(|v| v.len()).sum::<usize>())
            .unwrap_or(0);

        out.push_str(&format!("  {} [{}] v{}", p.name, status, version));
        if !desc.is_empty() {
            out.push_str(&format!(" — {}", desc));
        }
        let mut extras: Vec<String> = Vec::new();
        if cmd_count > 0 {
            extras.push(format!(
                "{} cmd{}",
                cmd_count,
                if cmd_count == 1 { "" } else { "s" }
            ));
        }
        if hook_count > 0 {
            extras.push(format!(
                "{} hook{}",
                hook_count,
                if hook_count == 1 { "" } else { "s" }
            ));
        }
        if !extras.is_empty() {
            out.push_str(&format!(" ({})", extras.join(", ")));
        }
        out.push('\n');
    }

    if all.iter().any(|p| p.source == PluginSource::Project) {
        out.push_str("\nProject plugins require `/plugin enable <name>` to trust their folder for this project, including future changes.\n");
    }

    if registry.error_count() > 0 {
        out.push_str(&format!(
            "\n{} plugin load error{}:\n",
            registry.error_count(),
            if registry.error_count() == 1 { "" } else { "s" }
        ));
        for error in &registry.errors {
            out.push_str(&format!("  {error}\n"));
        }
    }

    out
}

/// Build the text output for `/plugin info <name>`.
pub fn format_plugin_info(registry: &PluginRegistry, name: &str) -> String {
    match registry.get(name) {
        None => format!(
            "Plugin '{}' not found. Use `/plugin list` to see installed plugins.",
            name
        ),
        Some(p) => {
            let mut out = String::new();
            out.push_str(&format!("Plugin: {}\n", p.name));
            if let Some(v) = &p.manifest.version {
                out.push_str(&format!("Version: {}\n", v));
            }
            if let Some(d) = &p.manifest.description {
                out.push_str(&format!("Description: {}\n", d));
            }
            if let Some(author) = &p.manifest.author {
                out.push_str(&format!("Author: {}\n", author.name));
            }
            out.push_str(&format!(
                "Status: {}\n",
                if registry.is_enabled(name) {
                    "enabled"
                } else {
                    "disabled"
                }
            ));
            out.push_str(&format!("Source: {}\n", p.source_id));
            out.push_str(&format!("Path: {}\n", p.path.display()));
            if p.source == PluginSource::Project {
                out.push_str("Trust: `/plugin enable` authorizes this folder for this project, including future changes.\n");
            }

            // Count commands.
            let cmd_defs = loader::collect_command_defs(p);
            if !cmd_defs.is_empty() {
                out.push_str(&format!("\nCommands ({}):\n", cmd_defs.len()));
                for cmd in &cmd_defs {
                    out.push_str(&format!("  /{} — {}\n", cmd.name, cmd.description));
                }
            }

            // Hooks.
            if let Some(ref hooks_config) = p.hooks_config {
                let hook_count: usize = hooks_config.events.values().map(|v| v.len()).sum();
                if hook_count > 0 {
                    out.push_str(&format!("\nHooks ({}):\n", hook_count));
                    for (event, matchers) in &hooks_config.events {
                        for matcher in matchers {
                            for hook in &matcher.hooks {
                                let blocking = if hook.blocking { " [blocking]" } else { "" };
                                out.push_str(&format!(
                                    "  {} {}{}\n",
                                    event, hook.command, blocking
                                ));
                            }
                        }
                    }
                }
            }

            // MCP servers.
            if !p.manifest.mcp_servers.is_empty() {
                out.push_str(&format!(
                    "\nMCP servers ({}):\n",
                    p.manifest.mcp_servers.len()
                ));
                for srv in &p.manifest.mcp_servers {
                    out.push_str(&format!("  {}\n", srv.name));
                }
            }

            // LSP servers.
            if !p.manifest.lsp_servers.is_empty() {
                out.push_str(&format!(
                    "\nLSP servers ({}):\n",
                    p.manifest.lsp_servers.len()
                ));
                for srv in &p.manifest.lsp_servers {
                    out.push_str(&format!("  {}\n", srv.name));
                }
            }

            out
        }
    }
}

/// Install a plugin from a local path.
///
/// Copies the plugin directory into `~/.coven-code/plugins/` and returns the
/// loaded plugin name on success.
pub fn install_plugin_from_path(source_path: &Path) -> Result<String, PluginError> {
    // Validate that the source looks like a plugin directory.
    if !source_path.exists() {
        return Err(PluginError::Io {
            path: source_path.to_string_lossy().into_owned(),
            message: "Path does not exist".to_string(),
        });
    }

    let manifest_path = if source_path.join("plugin.json").exists() {
        source_path.join("plugin.json")
    } else if source_path.join("plugin.toml").exists() {
        source_path.join("plugin.toml")
    } else {
        return Err(PluginError::InvalidManifest {
            path: source_path.to_string_lossy().into_owned(),
            message: "No plugin.json or plugin.toml found in directory".to_string(),
        });
    };

    let bytes = std::fs::read(&manifest_path).map_err(|e| PluginError::Io {
        path: manifest_path.to_string_lossy().into_owned(),
        message: e.to_string(),
    })?;

    let manifest = if manifest_path
        .extension()
        .map(|e| e == "toml")
        .unwrap_or(false)
    {
        PluginManifest::from_toml(&bytes)
    } else {
        PluginManifest::from_json(&bytes)
    }
    .map_err(|e| PluginError::InvalidManifest {
        path: manifest_path.to_string_lossy().into_owned(),
        message: e.to_string(),
    })?;

    let plugin_name = manifest.name.clone();

    // Determine install destination.
    let plugins_root = default_user_plugins_dir();
    let dest = plugins_root.join(&plugin_name);

    // Copy source to dest.
    copy_plugin_files(source_path, &plugins_root, &plugin_name).map_err(|e| PluginError::Io {
        path: dest.to_string_lossy().into_owned(),
        message: e.to_string(),
    })?;

    tracing::info!(
        "Installed plugin '{}' from '{}' to '{}'",
        plugin_name,
        source_path.display(),
        dest.display()
    );

    Ok(plugin_name)
}

/// Copy into a trusted plugins root without following destination directory links.
/// Checks assume the directory tree is not concurrently replaced by another process.
fn copy_plugin_files(source: &Path, plugins_root: &Path, name: &str) -> std::io::Result<()> {
    use std::io::{Error, ErrorKind};
    use std::path::Component;

    // This filesystem boundary also protects callers without stricter manifest validation.
    let relative = Path::new(name);
    if relative.as_os_str().is_empty()
        || !relative
            .components()
            .all(|part| matches!(part, Component::Normal(_)))
    {
        return Err(Error::new(
            ErrorKind::InvalidInput,
            "Plugin destination must stay below the plugins directory",
        ));
    }
    let source = std::fs::canonicalize(source)?;
    let root = resolve_plugins_root(plugins_root)?;
    let destination = root.join(relative);
    let mut directory = root;
    for part in relative.components() {
        directory.push(part);
        match std::fs::symlink_metadata(&directory) {
            Ok(metadata) if metadata.is_symlink() => {
                return Err(Error::new(
                    ErrorKind::InvalidInput,
                    format!(
                        "Plugin destination directory is a symbolic link: {}",
                        directory.display()
                    ),
                ));
            }
            Ok(_) => {}
            Err(error) if error.kind() == ErrorKind::NotFound => {}
            Err(error) => return Err(error),
        }
    }

    // Compare filesystem identity, not spelling: canonical paths can still differ
    // in case on case-insensitive filesystems. Check both ancestor directions.
    let source_handle = same_file::Handle::from_path(&source)?;
    for ancestor in destination.ancestors() {
        match same_file::Handle::from_path(ancestor) {
            Ok(handle) if handle == source_handle => {
                return Err(Error::new(
                    ErrorKind::InvalidInput,
                    "Plugin source and installation destination overlap",
                ));
            }
            Ok(_) => {}
            Err(error) if error.kind() == ErrorKind::NotFound => {}
            Err(error) => return Err(error),
        }
    }
    match same_file::Handle::from_path(&destination) {
        Ok(destination_handle) => {
            for ancestor in source.ancestors() {
                if same_file::Handle::from_path(ancestor)? == destination_handle {
                    return Err(Error::new(
                        ErrorKind::InvalidInput,
                        "Plugin source and installation destination overlap",
                    ));
                }
            }
        }
        Err(error) if error.kind() == ErrorKind::NotFound => {}
        Err(error) => return Err(error),
    }
    copy_dir_all(&source, &destination)
}

/// Resolve the configured root (including intentional symlinks) without creating it.
fn resolve_plugins_root(root: &Path) -> std::io::Result<std::path::PathBuf> {
    let mut existing = root;
    let mut missing = Vec::new();
    loop {
        match std::fs::canonicalize(existing) {
            Ok(mut resolved) => {
                for part in missing.into_iter().rev() {
                    resolved.push(part);
                }
                return Ok(resolved);
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                let Some(name) = existing.file_name() else {
                    return Err(error);
                };
                missing.push(name);
                existing = existing
                    .parent()
                    .filter(|p| !p.as_os_str().is_empty())
                    .unwrap_or(Path::new("."));
            }
            Err(error) => return Err(error),
        }
    }
}

/// Recursively copy a directory.
fn copy_dir_all(src: &Path, dst: &Path) -> std::io::Result<()> {
    match std::fs::symlink_metadata(dst) {
        Ok(metadata) if metadata.is_symlink() => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                format!(
                    "Plugin destination directory is a symbolic link: {}",
                    dst.display()
                ),
            ));
        }
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Err(error),
    }
    std::fs::create_dir_all(dst)?;
    for entry in std::fs::read_dir(src)? {
        let entry = entry?;
        let ty = entry.file_type()?;
        if ty.is_dir() {
            copy_dir_all(&entry.path(), &dst.join(entry.file_name()))?;
        } else {
            // Replace the directory entry rather than writing through a symlink
            // or hardlink. A failed copy leaves the previous file intact.
            let staging = tempfile::tempdir_in(dst)?;
            let staged_file = staging.path().join("file");
            std::fs::copy(entry.path(), &staged_file)?;
            std::fs::rename(&staged_file, dst.join(entry.file_name()))?;
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// /reload-plugins summary formatting
// ---------------------------------------------------------------------------

/// Format the result of a plugin reload into a human-readable string,
/// suitable for the `/reload-plugins` command output.
pub fn format_reload_summary(registry: &PluginRegistry, diff: &ReloadDiff) -> String {
    let enabled = registry.enabled_count();
    let total = registry.plugin_count();

    let mut parts: Vec<String> = Vec::new();
    parts.push(format!(
        "{} plugin{} loaded ({} enabled)",
        total,
        if total == 1 { "" } else { "s" },
        enabled
    ));

    let cmd_count: usize = registry.all_command_defs().len();
    parts.push(format!(
        "{} command{}",
        cmd_count,
        if cmd_count == 1 { "" } else { "s" }
    ));

    let hook_count: usize = registry
        .build_hook_registry()
        .values()
        .map(|v| v.len())
        .sum();
    parts.push(format!(
        "{} hook{}",
        hook_count,
        if hook_count == 1 { "" } else { "s" }
    ));

    let mcp_count = registry.all_mcp_servers().len();
    parts.push(format!(
        "{} plugin MCP server{}",
        mcp_count,
        if mcp_count == 1 { "" } else { "s" }
    ));

    let lsp_count = registry.all_lsp_servers().len();
    parts.push(format!(
        "{} plugin LSP server{}",
        lsp_count,
        if lsp_count == 1 { "" } else { "s" }
    ));

    let mut msg = format!("Reloaded: {}", parts.join(" · "));

    if !diff.added.is_empty() {
        msg.push_str(&format!("\nAdded: {}", diff.added.join(", ")));
    }
    if !diff.removed.is_empty() {
        msg.push_str(&format!("\nRemoved: {}", diff.removed.join(", ")));
    }
    if !diff.updated.is_empty() {
        msg.push_str(&format!("\nUpdated: {}", diff.updated.join(", ")));
    }
    if diff.error_count > 0 {
        msg.push_str(&format!(
            "\n{} error{} during load.",
            diff.error_count,
            if diff.error_count == 1 { "" } else { "s" }
        ));
    }

    msg
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn write_manifest(dir: &Path, json: &serde_json::Value) {
        let path = dir.join("plugin.json");
        std::fs::write(path, serde_json::to_vec_pretty(json).unwrap()).unwrap();
    }

    #[test]
    fn parse_plugin_args_list() {
        assert_eq!(parse_plugin_args("list"), PluginSubCommand::List);
        assert_eq!(parse_plugin_args("ls"), PluginSubCommand::List);
    }

    #[test]
    fn parse_plugin_args_enable() {
        assert_eq!(
            parse_plugin_args("enable my-plugin"),
            PluginSubCommand::Enable("my-plugin".to_string())
        );
    }

    #[test]
    fn parse_plugin_args_info() {
        assert_eq!(
            parse_plugin_args("info my-plugin"),
            PluginSubCommand::Info("my-plugin".to_string())
        );
    }

    fn run_with_isolated_home(test_name: &str) -> bool {
        const CHILD_TEST: &str = "COVEN_CODE_PLUGIN_TEST_CHILD";
        if std::env::var(CHILD_TEST).ok().as_deref() == Some(test_name) {
            return true;
        }
        let home = TempDir::new().unwrap();
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", test_name])
            .env("COVEN_CODE_HOME", home.path())
            .env_remove("COVEN_CODE_TEST_HOME")
            .env(CHILD_TEST, test_name)
            .output()
            .unwrap();
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(output.status.success(), "{test_name}: {stdout}\n{stderr}");
        assert!(
            stdout.contains("test result: ok. 1 passed;"),
            "child must run exactly one test: {stdout}\n{stderr}"
        );
        false
    }

    #[tokio::test]
    async fn load_plugins_empty_dirs() {
        if !run_with_isolated_home("tests::load_plugins_empty_dirs") {
            return;
        }
        let tmp = TempDir::new().unwrap();
        let reg = load_plugins(tmp.path(), &[]).await;
        assert_eq!(reg.plugin_count(), 0);
        assert_eq!(reg.error_count(), 0);
    }

    #[tokio::test]
    async fn load_plugins_finds_project_plugin() {
        if !run_with_isolated_home("tests::load_plugins_finds_project_plugin") {
            return;
        }
        let tmp = TempDir::new().unwrap();
        let plugin_dir = tmp
            .path()
            .join(".coven-code")
            .join("plugins")
            .join("test-plugin");
        std::fs::create_dir_all(&plugin_dir).unwrap();
        write_manifest(
            &plugin_dir,
            &serde_json::json!({ "name": "test-plugin", "version": "1.0.0", "description": "A test plugin" }),
        );

        let reg = load_plugins(tmp.path(), &[]).await;
        assert_eq!(reg.plugin_count(), 1);
        assert!(reg.get("test-plugin").is_some());
        assert!(!reg.is_enabled("test-plugin"));
    }

    #[test]
    fn manifest_parse_json() {
        let json = serde_json::json!({
            "name": "my-plugin",
            "version": "0.1.0",
            "description": "Test",
            "mcpServers": {
                "my-server": { "command": "node", "args": ["server.js"] }
            }
        });
        let bytes = serde_json::to_vec(&json).unwrap();
        let manifest = PluginManifest::from_json(&bytes).unwrap();
        assert_eq!(manifest.name, "my-plugin");
        assert_eq!(manifest.mcp_servers.len(), 1);
        assert_eq!(manifest.mcp_servers[0].name, "my-server");
    }

    #[test]
    fn format_plugin_list_empty() {
        let reg = PluginRegistry::new();
        let out = format_plugin_list(&reg);
        assert_eq!(out, "No plugins installed.\n\nUse `/plugin install <path>` to install a plugin from a local directory.");
    }

    #[tokio::test]
    async fn format_plugin_list_reports_errors_without_loaded_plugins() {
        let root = TempDir::new().unwrap();
        let plugin_dir = root.path().join("broken");
        std::fs::create_dir(&plugin_dir).unwrap();
        let manifest_path = plugin_dir.join("plugin.json");
        std::fs::write(&manifest_path, "{ invalid json").unwrap();
        let (plugins, errors) =
            discover_plugins(&[root.path().to_path_buf()], PluginSource::User).await;
        assert!(plugins.is_empty());
        assert_eq!(errors.len(), 1);
        let manifest_error = errors[0].to_string();
        let mut registry = PluginRegistry::new();
        registry.extend(plugins, errors);
        let unreadable_path = root.path().join("unreadable").display().to_string();
        // Construct an IO diagnostic without relying on host permission behavior.
        registry.errors.push(PluginError::Io {
            path: unreadable_path.clone(),
            message: "fixture read failure".into(),
        });
        let output = format_plugin_list(&registry);
        assert!(output.starts_with("Installed plugins: 0 (0 enabled)\n"));
        assert!(output.contains("2 plugin load errors:"));
        assert!(output.contains(&manifest_error));
        assert!(output.contains(&manifest_path.display().to_string()));
        assert!(output.contains(&format!(
            "IO error reading '{unreadable_path}': fixture read failure"
        )));
        assert!(!output.contains("Use `/plugin info"));
    }

    #[tokio::test]
    async fn format_plugin_list_reports_duplicates_alongside_loaded_plugins() {
        let root = TempDir::new().unwrap();
        let mut registry = PluginRegistry::new();
        for directory in ["first", "second"] {
            let plugin_dir = root.path().join(directory);
            std::fs::create_dir(&plugin_dir).unwrap();
            write_manifest(
                &plugin_dir,
                &serde_json::json!({"name": "fixture", "version": "1.0.0"}),
            );
            let (plugins, errors) = discover_plugins(&[plugin_dir], PluginSource::User).await;
            registry.extend(plugins, errors);
            if directory == "first" {
                assert_eq!(
                    format_plugin_list(&registry),
                    "Installed plugins: 1 (1 enabled)\n\n  fixture [enabled] v1.0.0\n"
                );
            }
        }
        assert_eq!(registry.plugin_count(), 1);
        assert_eq!(registry.error_count(), 1);
        let output = format_plugin_list(&registry);
        assert!(output.contains("  fixture [enabled] v1.0.0\n"));
        assert!(output.contains("1 plugin load error:"));
        assert!(output.contains("Duplicate plugin name 'fixture'"));
        assert!(output.contains(&root.path().join("first").display().to_string()));
        assert!(output.contains(&root.path().join("second").display().to_string()));
        assert!(!output.contains("Use `/plugin info"));
    }

    #[test]
    fn format_reload_summary_basic() {
        let reg = PluginRegistry::new();
        let diff = ReloadDiff::default();
        let out = format_reload_summary(&reg, &diff);
        assert!(out.contains("Reloaded"));
    }
}

#[cfg(test)]
mod copy_tests {
    use super::copy_plugin_files;
    use std::fs;
    use tempfile::tempdir;

    #[test]
    fn plugin_copy_merges_and_overwrites() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        let root = temp.path().join("plugins");
        fs::create_dir_all(source.join("nested")).unwrap();
        fs::write(source.join("nested/new"), "new").unwrap();
        fs::create_dir_all(root.join("plugin/nested")).unwrap();
        fs::write(root.join("plugin/nested/new"), "old").unwrap();
        fs::write(root.join("plugin/retained"), "keep").unwrap();
        copy_plugin_files(&source, &root, "plugin").unwrap();
        assert_eq!(
            fs::read_to_string(root.join("plugin/nested/new")).unwrap(),
            "new"
        );
        assert_eq!(
            fs::read_to_string(root.join("plugin/retained")).unwrap(),
            "keep"
        );
    }

    #[test]
    fn plugin_copy_rejects_same_directory_without_truncation() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("plugin");
        fs::create_dir(&source).unwrap();
        fs::write(source.join("marker"), "preserve").unwrap();
        let result = copy_plugin_files(&source, temp.path(), "plugin");
        assert_eq!(
            fs::read_to_string(source.join("marker")).unwrap(),
            "preserve"
        );
        assert!(result.is_err());
    }

    #[test]
    fn plugin_copy_rejects_escaping_names() {
        for name in ["../outside", "absolute"] {
            let temp = tempdir().unwrap();
            let source = temp.path().join("source");
            let root = temp.path().join("plugins");
            let outside = temp.path().join("outside");
            fs::create_dir(&source).unwrap();
            fs::create_dir(&root).unwrap();
            fs::create_dir(&outside).unwrap();
            fs::write(source.join("marker"), "overwrite").unwrap();
            fs::write(outside.join("marker"), "preserve").unwrap();
            let name = if name == "absolute" {
                outside.to_str().unwrap()
            } else {
                name
            };
            let result = copy_plugin_files(&source, &root, name);
            assert_eq!(
                fs::read_to_string(outside.join("marker")).unwrap(),
                "preserve"
            );
            assert!(result.is_err());
        }
    }

    #[test]
    fn plugin_copy_replaces_hardlink_without_changing_target() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        let root = temp.path().join("plugins");
        fs::create_dir(&source).unwrap();
        fs::create_dir_all(root.join("plugin")).unwrap();
        fs::write(source.join("marker"), "new").unwrap();
        let outside = temp.path().join("outside");
        fs::write(&outside, "preserve").unwrap();
        fs::hard_link(&outside, root.join("plugin/marker")).unwrap();
        copy_plugin_files(&source, &root, "plugin").unwrap();
        assert_eq!(fs::read_to_string(&outside).unwrap(), "preserve");
        assert_eq!(
            fs::read_to_string(root.join("plugin/marker")).unwrap(),
            "new"
        );
    }

    #[cfg(unix)]
    #[test]
    fn plugin_copy_rejects_destination_directory_symlinks() {
        use std::os::unix::fs::symlink;
        for nested in [false, true] {
            let temp = tempdir().unwrap();
            let source = temp.path().join("source");
            let root = temp.path().join("plugins");
            let outside = temp.path().join("outside");
            fs::create_dir_all(source.join("nested")).unwrap();
            fs::create_dir(&root).unwrap();
            fs::create_dir(&outside).unwrap();
            let destination = if nested {
                fs::create_dir(root.join("plugin")).unwrap();
                fs::write(source.join("nested/marker"), "overwrite").unwrap();
                root.join("plugin/nested")
            } else {
                fs::write(source.join("marker"), "overwrite").unwrap();
                root.join("plugin")
            };
            fs::write(outside.join("marker"), "preserve").unwrap();
            symlink(&outside, destination).unwrap();
            let result = copy_plugin_files(&source, &root, "plugin");
            assert_eq!(
                fs::read_to_string(outside.join("marker")).unwrap(),
                "preserve"
            );
            assert!(result.is_err());
        }
    }

    #[cfg(unix)]
    #[test]
    fn plugin_copy_replaces_destination_file_symlink() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        let root = temp.path().join("plugins");
        fs::create_dir(&source).unwrap();
        fs::create_dir_all(root.join("plugin")).unwrap();
        fs::write(source.join("marker"), "new").unwrap();
        let outside = temp.path().join("outside");
        fs::write(&outside, "preserve").unwrap();
        std::os::unix::fs::symlink(&outside, root.join("plugin/marker")).unwrap();
        copy_plugin_files(&source, &root, "plugin").unwrap();
        assert_eq!(fs::read_to_string(&outside).unwrap(), "preserve");
        assert_eq!(
            fs::read_to_string(root.join("plugin/marker")).unwrap(),
            "new"
        );
        assert!(!fs::symlink_metadata(root.join("plugin/marker"))
            .unwrap()
            .is_symlink());
    }

    #[cfg(unix)]
    #[test]
    fn plugin_copy_preserves_root_alias_and_source_file_link_and_mode() {
        use std::os::unix::fs::{symlink, PermissionsExt};
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        let root = temp.path().join("plugins");
        let alias = temp.path().join("alias");
        fs::create_dir(&source).unwrap();
        fs::create_dir(&root).unwrap();
        symlink(&root, &alias).unwrap();
        let original = temp.path().join("original");
        fs::write(&original, "linked").unwrap();
        fs::set_permissions(&original, fs::Permissions::from_mode(0o751)).unwrap();
        symlink(&original, source.join("script")).unwrap();
        copy_plugin_files(&source, &alias, "plugin").unwrap();
        let destination = root.join("plugin/script");
        assert_eq!(fs::read_to_string(&destination).unwrap(), "linked");
        assert!(!fs::symlink_metadata(&destination).unwrap().is_symlink());
        assert_eq!(
            fs::metadata(destination).unwrap().permissions().mode() & 0o777,
            0o751
        );
    }
    #[test]
    fn plugin_copy_creates_missing_root_and_nested_destination() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        let root = temp.path().join("missing/plugins");
        fs::create_dir(&source).unwrap();
        fs::write(source.join("marker"), "copy").unwrap();
        copy_plugin_files(&source, &root, "nested/plugin").unwrap();
        assert_eq!(
            fs::read_to_string(root.join("nested/plugin/marker")).unwrap(),
            "copy"
        );
    }

    #[test]
    fn plugin_copy_rejects_overlapping_trees_before_creation() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        fs::create_dir_all(source.join("child")).unwrap();
        fs::write(source.join("marker"), "preserve").unwrap();
        let missing_root = source.join("missing/plugins");
        assert!(copy_plugin_files(&source, &missing_root, "plugin").is_err());
        assert!(!source.join("missing").exists());
        assert!(copy_plugin_files(&source.join("child"), temp.path(), "source").is_err());
        assert_eq!(
            fs::read_to_string(source.join("marker")).unwrap(),
            "preserve"
        );
    }

    #[test]
    fn plugin_copy_rejects_case_alias_overlap() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("Plugin");
        fs::create_dir(&source).unwrap();
        let alias = temp.path().join("plugin");
        if !alias.exists() {
            // This fixture proves the filesystem is case-sensitive.
            return;
        }
        assert!(same_file::is_same_file(&source, &alias).unwrap());
        fs::write(source.join("marker"), "preserve").unwrap();
        assert!(copy_plugin_files(&source, temp.path(), "plugin").is_err());
        assert!(copy_plugin_files(&source, &alias.join("missing"), "nested").is_err());
        assert!(!source.join("missing").exists());
        fs::create_dir(source.join("child")).unwrap();
        assert!(copy_plugin_files(&source.join("child"), temp.path(), "plugin").is_err());
        assert_eq!(
            fs::read_to_string(source.join("marker")).unwrap(),
            "preserve"
        );
    }

    #[cfg(unix)]
    #[test]
    fn plugin_copy_failure_preserves_target_and_cleans_staging() {
        let temp = tempdir().unwrap();
        let source = temp.path().join("source");
        let root = temp.path().join("plugins");
        fs::create_dir(&source).unwrap();
        fs::create_dir_all(root.join("plugin")).unwrap();
        std::os::unix::fs::symlink(temp.path().join("missing"), source.join("marker")).unwrap();
        fs::write(root.join("plugin/marker"), "preserve").unwrap();
        assert!(copy_plugin_files(&source, &root, "plugin").is_err());
        assert_eq!(
            fs::read_to_string(root.join("plugin/marker")).unwrap(),
            "preserve"
        );
        assert_eq!(fs::read_dir(root.join("plugin")).unwrap().count(), 1);
    }
}
