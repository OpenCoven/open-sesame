/// Plugin registry — holds all loaded plugins and provides queries.
///
/// Ported from the TS "enabled plugins" concept in `pluginLoader.ts` and the
/// app-state plugin arrays.
use crate::hooks::{register_plugin_hooks, HookRegistry};
use crate::plugin::{LoadedPlugin, PluginCommandDef, PluginError, ReloadDiff};
use std::collections::HashMap;

// ---------------------------------------------------------------------------
// PluginRegistry
// ---------------------------------------------------------------------------

/// Central store for all discovered plugins in a session.
///
/// Methods follow the TS pattern: `enabled()` returns only enabled plugins,
/// `all()` returns every plugin including disabled ones.
#[derive(Debug, Default, Clone)]
pub struct PluginRegistry {
    /// Canonical project identity for a discovered registry; absent on failure.
    pub(crate) project_root: Option<std::path::PathBuf>,
    /// All plugins keyed by name.
    plugins: HashMap<String, LoadedPlugin>,
    /// Accumulated load errors.
    pub errors: Vec<PluginError>,
}

impl PluginRegistry {
    // ---- Construction & population ----------------------------------------

    /// Create an empty registry.
    pub fn new() -> Self {
        Self::default()
    }

    /// Insert (or replace) a loaded plugin. Emits a duplicate error if a
    /// different path or source already holds a plugin with the same name.
    pub fn insert(&mut self, plugin: LoadedPlugin) {
        let name = plugin.name.clone();

        if let Some(existing) = self.plugins.get(&name) {
            if existing.path != plugin.path || existing.source != plugin.source {
                self.errors.push(PluginError::DuplicateName {
                    name: name.clone(),
                    first: existing.path.to_string_lossy().into_owned(),
                    second: plugin.path.to_string_lossy().into_owned(),
                });
                // Keep the first one (same behaviour as TS: first-wins).
                return;
            }
        }

        self.plugins.insert(name, plugin);
    }

    /// Append multiple plugins at once, updating errors inline.
    pub fn extend(&mut self, plugins: Vec<LoadedPlugin>, errors: Vec<PluginError>) {
        self.errors.extend(errors);
        for p in plugins {
            self.insert(p);
        }
    }

    // ---- Queries ----------------------------------------------------------

    /// All loaded plugins (enabled + disabled).
    pub fn all(&self) -> Vec<&LoadedPlugin> {
        self.plugins.values().collect()
    }

    /// Only the enabled plugins.
    pub fn enabled(&self) -> Vec<&LoadedPlugin> {
        self.plugins.values().filter(|p| p.enabled).collect()
    }

    /// Look up a plugin by name.
    pub fn get(&self, name: &str) -> Option<&LoadedPlugin> {
        self.plugins.get(name)
    }

    /// Whether a plugin is enabled.
    pub fn is_enabled(&self, name: &str) -> bool {
        self.plugins.get(name).is_some_and(|plugin| plugin.enabled)
    }

    /// Whether a cached registry belongs to this canonical project.
    pub fn matches_project(&self, project_dir: &std::path::Path) -> bool {
        match (&self.project_root, project_dir.canonicalize()) {
            (Some(loaded), Ok(current)) => *loaded == current,
            _ => false,
        }
    }

    // ---- Enable / disable -------------------------------------------------

    /// Enable a plugin by name.  Returns `false` if the plugin is not loaded.
    pub fn enable(&mut self, name: &str) -> bool {
        let Some(plugin) = self.plugins.get_mut(name) else {
            return false;
        };
        plugin.enabled = true;
        true
    }

    /// Disable a plugin by name.  Returns `false` if the plugin is not loaded.
    pub fn disable(&mut self, name: &str) -> bool {
        let Some(plugin) = self.plugins.get_mut(name) else {
            return false;
        };
        plugin.enabled = false;
        true
    }

    // ---- Derived collections from enabled plugins -------------------------

    /// Collect all `PluginCommandDef` items from enabled plugins.
    pub fn all_command_defs(&self) -> Vec<PluginCommandDef> {
        let mut defs: Vec<PluginCommandDef> = Vec::new();
        for plugin in self.enabled() {
            defs.extend(crate::loader::collect_command_defs(plugin));
        }
        defs
    }

    /// Collect paths to all `skills/` directories contributed by enabled plugins.
    pub fn all_skill_paths(&self) -> Vec<std::path::PathBuf> {
        let mut paths = Vec::new();
        for plugin in self.enabled() {
            if let Some(ref p) = plugin.skills_path {
                paths.push(p.clone());
            }
        }
        paths
    }

    /// Collect paths to all `agents/` directories contributed by enabled plugins.
    pub fn all_agent_paths(&self) -> Vec<std::path::PathBuf> {
        let mut paths = Vec::new();
        for plugin in self.enabled() {
            if let Some(ref p) = plugin.agents_path {
                paths.push(p.clone());
            }
        }
        paths
    }

    /// Collect paths to all `output-styles/` directories contributed by enabled plugins.
    pub fn all_output_style_paths(&self) -> Vec<std::path::PathBuf> {
        let mut paths = Vec::new();
        for plugin in self.enabled() {
            if let Some(ref p) = plugin.output_styles_path {
                paths.push(p.clone());
            }
        }
        paths
    }

    /// Build the `HookRegistry` from all enabled plugins.
    pub fn build_hook_registry(&self) -> HookRegistry {
        let mut registry: HookRegistry = HashMap::new();
        for plugin in self.enabled() {
            register_plugin_hooks(plugin, self.project_root.as_deref(), &mut registry);
        }
        registry
    }

    /// Collect all MCP server configs contributed by enabled plugins.
    pub fn all_mcp_servers(&self) -> Vec<claurst_core::plugin_mcp::PluginMcpContribution> {
        use claurst_core::plugin_mcp::{PluginMcpContribution, PluginMcpOrigin, PluginMcpSource};
        let mut servers = Vec::new();
        let mut plugins = self.enabled();
        plugins.sort_by(|left, right| left.name.cmp(&right.name));
        for plugin in plugins {
            let grants = plugin.manifest.capabilities.as_deref();
            if !crate::has_capability(grants, "mcp") {
                continue;
            }
            let source = match plugin.source {
                crate::PluginSource::User => PluginMcpSource::User,
                crate::PluginSource::Project => PluginMcpSource::Project,
                crate::PluginSource::Extra(_) => PluginMcpSource::Extra,
                crate::PluginSource::Inline => PluginMcpSource::Inline,
                crate::PluginSource::Builtin => PluginMcpSource::Builtin,
            };
            let origin = match PluginMcpOrigin::new(
                source,
                &plugin.path,
                self.project_root.as_deref(),
            ) {
                Ok(origin) => origin,
                Err(error) => {
                    tracing::warn!(plugin = %plugin.name, %error, "Cannot identify plugin MCP origin");
                    continue;
                }
            };
            for mcp in &plugin.manifest.mcp_servers {
                let required = match mcp.server_type.as_str() {
                    "stdio" => "shell",
                    "sse" | "http" => "network",
                    _ => continue,
                };
                // Decide eligibility while plugin origin and grants are still
                // available, before lowering into the generic core config.
                if !crate::has_capability(grants, required) {
                    continue;
                }
                servers.push(PluginMcpContribution::new(
                    origin.clone(),
                    claurst_core::config::McpServerConfig {
                        name: mcp.name.clone(),
                        command: mcp.command.clone(),
                        args: mcp.args.clone(),
                        env: mcp.env.clone(),
                        url: mcp.url.clone(),
                        server_type: mcp.server_type.clone(),
                    },
                ));
            }
        }
        servers
    }

    /// Collect all LSP server configs contributed by enabled plugins.
    pub fn all_lsp_servers(&self) -> Vec<crate::manifest::PluginLspServer> {
        let mut servers: Vec<crate::manifest::PluginLspServer> = Vec::new();
        for plugin in self.enabled() {
            if !crate::has_capability(plugin.manifest.capabilities.as_deref(), "shell") {
                continue;
            }
            for lsp in &plugin.manifest.lsp_servers {
                servers.push(lsp.clone());
            }
        }
        servers
    }

    // ---- Statistics -------------------------------------------------------

    /// Total number of plugins (enabled + disabled).
    pub fn plugin_count(&self) -> usize {
        self.plugins.len()
    }

    /// Number of enabled plugins.
    pub fn enabled_count(&self) -> usize {
        self.plugins
            .values()
            .filter(|plugin| plugin.enabled)
            .count()
    }

    /// Number of load errors.
    pub fn error_count(&self) -> usize {
        self.errors.len()
    }

    // ---- Reload diff ------------------------------------------------------

    /// Compare this registry against `old` and produce a diff report.
    pub fn diff_against(&self, old: &PluginRegistry) -> ReloadDiff {
        let old_names: std::collections::HashSet<&str> =
            old.plugins.keys().map(|s| s.as_str()).collect();
        let new_names: std::collections::HashSet<&str> =
            self.plugins.keys().map(|s| s.as_str()).collect();

        let added: Vec<String> = new_names
            .difference(&old_names)
            .map(|&s| s.to_string())
            .collect();
        let removed: Vec<String> = old_names
            .difference(&new_names)
            .map(|&s| s.to_string())
            .collect();
        let updated: Vec<String> = new_names
            .intersection(&old_names)
            .filter(|&&name| {
                let new_ver = self
                    .plugins
                    .get(name)
                    .and_then(|p| p.manifest.version.as_deref());
                let old_ver = old
                    .plugins
                    .get(name)
                    .and_then(|p| p.manifest.version.as_deref());
                new_ver != old_ver
            })
            .map(|&s| s.to_string())
            .collect();

        ReloadDiff {
            added,
            removed,
            updated,
            error_count: self.errors.len(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::manifest::PluginManifest;
    use crate::plugin::PluginSource;
    use std::path::PathBuf;

    fn make_plugin(name: &str) -> LoadedPlugin {
        LoadedPlugin {
            name: name.to_string(),
            path: PathBuf::from(format!("/tmp/{}", name)),
            source: PluginSource::User,
            source_id: format!("{}@user", name),
            manifest: PluginManifest {
                name: name.to_string(),
                ..Default::default()
            },
            enabled: true,
            commands_path: None,
            agents_path: None,
            skills_path: None,
            output_styles_path: None,
            hooks_config: None,
        }
    }

    #[test]
    fn enable_disable() {
        let mut reg = PluginRegistry::new();
        reg.insert(make_plugin("alpha"));
        assert!(reg.is_enabled("alpha"));

        reg.disable("alpha");
        assert!(!reg.is_enabled("alpha"));
        assert_eq!(reg.enabled().len(), 0);

        reg.enable("alpha");
        assert!(reg.is_enabled("alpha"));
        assert_eq!(reg.enabled().len(), 1);
    }

    #[test]
    fn duplicate_name_kept_first() {
        let mut reg = PluginRegistry::new();
        reg.insert(make_plugin("beta"));
        let mut dup = make_plugin("beta");
        dup.path = PathBuf::from("/tmp/beta2");
        reg.insert(dup);
        assert_eq!(reg.plugin_count(), 1);
        assert_eq!(reg.error_count(), 1);
    }

    #[test]
    fn replacement_uses_the_loaded_plugin_enabled_state() {
        let mut registry = PluginRegistry::new();
        let root = tempfile::tempdir().unwrap();
        let mut plugin = make_plugin("replacement");
        // MCP origins are canonical, so the contributing plugin root must exist.
        plugin.path = root.path().to_path_buf();
        plugin.manifest.capabilities = Some(vec!["mcp".into(), "shell".into()]);
        plugin
            .manifest
            .mcp_servers
            .push(crate::manifest::PluginMcpServer {
                name: "fixture-server".into(),
                server_type: "stdio".into(),
                ..Default::default()
            });
        registry.insert(plugin.clone());
        assert_eq!(registry.all_mcp_servers().len(), 1);

        plugin.enabled = false;
        registry.insert(plugin.clone());
        assert!(!registry.get("replacement").unwrap().enabled);
        assert!(!registry.is_enabled("replacement"));
        assert_eq!(registry.enabled_count(), 0);
        assert!(registry.enabled().is_empty());
        assert!(registry.all_mcp_servers().is_empty());

        plugin.enabled = true;
        registry.insert(plugin);
        assert!(registry.get("replacement").unwrap().enabled);
        assert!(registry.is_enabled("replacement"));
        assert_eq!(registry.enabled_count(), 1);
        assert_eq!(registry.enabled().len(), 1);
        assert_eq!(registry.all_mcp_servers().len(), 1);

        let mut duplicate = make_plugin("replacement");
        duplicate.path = PathBuf::from("/other/fixture/path");
        duplicate.enabled = false;
        registry.insert(duplicate);
        assert_eq!(registry.error_count(), 1);
        assert!(registry.is_enabled("replacement"));
        assert_eq!(registry.all_mcp_servers().len(), 1);
    }

    #[test]
    fn same_source_replacement_updates_enabled_membership() {
        let mut reg = PluginRegistry::new();
        reg.insert(make_plugin("alpha"));

        let mut replacement = make_plugin("alpha");
        replacement.enabled = false;
        replacement.manifest.version = Some("2.0.0".to_string());
        reg.insert(replacement);
        assert!(!reg.is_enabled("alpha"));
        assert!(!reg.get("alpha").unwrap().enabled);
        assert_eq!(
            reg.get("alpha").unwrap().manifest.version.as_deref(),
            Some("2.0.0")
        );
        assert!(reg.enabled().is_empty());
        assert_eq!(reg.enabled_count(), 0);
        assert_eq!(reg.error_count(), 0);

        reg.insert(make_plugin("alpha"));
        assert!(reg.is_enabled("alpha"));
        assert!(reg.get("alpha").unwrap().enabled);
        assert_eq!(reg.enabled_count(), 1);
        assert_eq!(reg.error_count(), 0);
    }

    #[test]
    fn diff_detects_added_removed() {
        let mut old_reg = PluginRegistry::new();
        old_reg.insert(make_plugin("kept"));
        old_reg.insert(make_plugin("gone"));

        let mut new_reg = PluginRegistry::new();
        new_reg.insert(make_plugin("kept"));
        new_reg.insert(make_plugin("new-plugin"));

        let diff = new_reg.diff_against(&old_reg);
        assert_eq!(diff.added, vec!["new-plugin"]);
        assert_eq!(diff.removed, vec!["gone"]);
        assert!(diff.updated.is_empty());
    }
}

#[cfg(test)]
mod mcp_provenance_tests {
    use super::*;
    use crate::{PluginManifest, PluginMcpServer, PluginSource};
    use claurst_core::plugin_mcp::PluginMcpSource;

    #[test]
    fn mcp_contributions_use_canonical_typed_origin_not_display_source() {
        let project = tempfile::tempdir().unwrap();
        let plugin_root = project.path().join("fixture");
        std::fs::create_dir(&plugin_root).unwrap();
        let mut registry = PluginRegistry::new();
        registry.project_root = Some(project.path().canonicalize().unwrap());
        registry.insert(LoadedPlugin {
            name: "fixture".into(),
            path: plugin_root.clone(),
            source: PluginSource::Project,
            source_id: "fixture@user".into(),
            enabled: true,
            commands_path: None,
            agents_path: None,
            skills_path: None,
            output_styles_path: None,
            hooks_config: None,
            manifest: PluginManifest {
                name: "fixture".into(),
                capabilities: Some(vec!["mcp".into(), "shell".into()]),
                mcp_servers: vec![PluginMcpServer {
                    name: "server".into(),
                    command: Some("sh".into()),
                    server_type: "stdio".into(),
                    ..Default::default()
                }],
                ..Default::default()
            },
        });
        let entries = registry.all_mcp_servers();
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].origin.source(), PluginMcpSource::Project);
        assert_eq!(
            entries[0].origin.plugin_root(),
            plugin_root.canonicalize().unwrap()
        );
        assert_eq!(
            entries[0].origin.project_root(),
            Some(project.path().canonicalize().unwrap().as_path())
        );
        registry.project_root = None;
        assert!(
            registry.all_mcp_servers().is_empty(),
            "unresolved project must not become global"
        );
        registry.project_root = Some(project.path().join("missing"));
        assert!(registry.all_mcp_servers().is_empty());
    }
}
