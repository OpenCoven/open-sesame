// coven-code CLI entry point
//
// This is the main binary for Coven Code. It:
// 1. Parses CLI arguments with clap (mirrors cli.tsx + main.tsx flags)
// 2. Loads configuration from settings.json + env vars
// 3. Builds system/user context (git status, AGENTS.md)
// 4. Runs in either:
//    - Headless (--print / -p) mode: single query, output to stdout
//    - Interactive REPL mode: full TUI with ratatui

mod codex_oauth_flow;
mod diagnostics;
mod headless;
#[cfg(all(test, unix))]
mod mcp_reconnect_tests;
mod memory_admin;
mod oauth_flow;
#[cfg(all(test, unix))]
mod plugin_mcp_config_tests;
mod stream_mode;
mod upgrade;

use headless::{RunOutcome, SessionBrief};

// ---------------------------------------------------------------------------
// Build-time metadata (embedded via build.rs)
// ---------------------------------------------------------------------------

/// Build timestamp in RFC 3339 format
pub const BUILD_TIME: &str = env!("BUILD_TIME");

/// Short git commit hash (or "unknown" if not a git repo)
pub const GIT_COMMIT: &str = env!("GIT_COMMIT");

/// Package/distribution identifier
pub const PACKAGE_URL: &str = env!("PACKAGE_URL");

/// Feedback/issue reporting channel
pub const FEEDBACK_CHANNEL: &str = env!("FEEDBACK_CHANNEL");

/// Explanation of issue routing in this build
pub const ISSUES_EXPLAINER: &str = env!("ISSUES_EXPLAINER");

use anyhow::Context;
use async_trait::async_trait;
use clap::{ArgAction, Parser, ValueEnum};
use claurst_core::types::ToolDefinition;
use claurst_core::{
    config::{Config, PermissionMode, Settings},
    constants::APP_VERSION,
    context::ContextBuilder,
    cost::CostTracker,
    permissions::{AutoPermissionHandler, InteractivePermissionHandler, PermissionManager},
};
use claurst_tools::{PermissionLevel, Tool, ToolContext, ToolResult};
use parking_lot::Mutex as ParkingMutex;
use std::{path::PathBuf, sync::Arc};
use tracing::{debug, info, warn};
use tracing_subscriber::EnvFilter;

// ---------------------------------------------------------------------------
// MCP tool wrapper: makes MCP server tools look like native cc-tools.
// ---------------------------------------------------------------------------

struct McpToolWrapper {
    tool_def: ToolDefinition,
    server_name: String,
    manager: Arc<claurst_mcp::McpManager>,
}

#[async_trait]
impl Tool for McpToolWrapper {
    fn name(&self) -> &str {
        &self.tool_def.name
    }

    fn description(&self) -> &str {
        &self.tool_def.description
    }

    fn permission_level(&self) -> PermissionLevel {
        // MCP tools run external processes – treat as Execute.
        PermissionLevel::Execute
    }

    fn input_schema(&self) -> serde_json::Value {
        self.tool_def.input_schema.clone()
    }

    async fn execute(&self, input: serde_json::Value, ctx: &ToolContext) -> ToolResult {
        let desc = format!("Run MCP tool {}", self.tool_def.name);
        if let Err(e) = ctx.check_permission(self.name(), &desc, false) {
            return ToolResult::error(e.to_string());
        }

        // Strip the server-name prefix to get the bare tool name.
        let prefix = format!("{}_", self.server_name);
        let bare_name = self
            .tool_def
            .name
            .strip_prefix(&prefix)
            .unwrap_or(&self.tool_def.name);

        let args = if input.is_null() { None } else { Some(input) };

        match self
            .manager
            .call_tool(Some(&ctx.working_dir), &self.tool_def.name, args)
            .await
        {
            Ok(result) => {
                let text = claurst_mcp::mcp_result_to_string(&result);
                if result.is_error {
                    ToolResult::error(text)
                } else {
                    ToolResult::success(text)
                }
            }
            Err(e) => ToolResult::error(format!("MCP tool '{}' failed: {}", bare_name, e)),
        }
    }
}

// ---------------------------------------------------------------------------
// CLI argument definition (matches TypeScript main.tsx flags)
// ---------------------------------------------------------------------------

#[derive(Parser, Debug)]
#[command(
    name = "coven-code",
    version = APP_VERSION,
    about = "Coven - AI-powered coding assistant",
    long_about = None,
)]
struct Cli {
    /// Initial prompt to send (enables headless/print mode)
    prompt: Option<String>,

    /// Print mode: send prompt and exit (non-interactive)
    #[arg(short = 'p', long = "print", action = ArgAction::SetTrue)]
    print: bool,

    /// Model to use
    #[arg(short = 'm', long = "model")]
    model: Option<String>,

    /// Permission mode
    #[arg(long = "permission-mode", value_enum, default_value_t = CliPermissionMode::Default)]
    permission_mode: CliPermissionMode,

    /// Resume a previous session by ID (omit ID to resume the most recent session)
    #[arg(long = "resume", num_args(0..=1), default_missing_value("__last__"))]
    resume: Option<String>,

    /// Maximum number of agentic turns
    #[arg(long = "max-turns", default_value_t = 10)]
    max_turns: u32,

    /// Custom system prompt
    #[arg(long = "system-prompt", short = 's')]
    system_prompt: Option<String>,

    /// Append to system prompt
    #[arg(long = "append-system-prompt")]
    append_system_prompt: Option<String>,

    /// Disable AGENTS.md memory files
    #[arg(long = "no-claude-md", action = ArgAction::SetTrue)]
    no_claude_md: bool,

    /// Output format
    #[arg(long = "output-format", value_enum, default_value_t = CliOutputFormat::Text)]
    output_format: CliOutputFormat,

    /// Enable verbose logging
    #[arg(long = "verbose", short = 'v', action = ArgAction::SetTrue)]
    verbose: bool,

    /// API key for the active provider (overrides provider-specific env vars)
    #[arg(long = "api-key")]
    api_key: Option<String>,

    /// Maximum tokens per response
    #[arg(long = "max-tokens")]
    max_tokens: Option<u32>,

    /// Working directory
    #[arg(long = "cwd")]
    cwd: Option<PathBuf>,

    /// Bypass all permission checks (danger!)
    #[arg(long = "dangerously-skip-permissions", visible_alias = "yolo", action = ArgAction::SetTrue)]
    dangerously_skip_permissions: bool,

    /// Dump the system prompt to stdout and exit
    #[arg(long = "dump-system-prompt", action = ArgAction::SetTrue, hide = true)]
    dump_system_prompt: bool,

    /// MCP config JSON string (inline server definitions)
    #[arg(long = "mcp-config")]
    mcp_config: Option<String>,

    /// Disable auto-compaction
    #[arg(long = "no-auto-compact", action = ArgAction::SetTrue)]
    no_auto_compact: bool,

    /// Enable shadow-git auto-commit snapshots (enables /revert, /checkpoints, /snapshot)
    #[arg(long = "auto-commits", action = ArgAction::SetTrue)]
    auto_commits: bool,

    /// Grant Coven access to an additional directory (can be repeated)
    #[arg(long = "add-dir", value_name = "DIR", action = ArgAction::Append)]
    add_dir: Vec<PathBuf>,

    /// Input format for --print mode (text or stream-json)
    #[arg(long = "input-format", value_enum, default_value_t = CliInputFormat::Text)]
    input_format: CliInputFormat,

    /// Session ID to tag this headless run (for tracking in logs/hooks)
    #[arg(long = "session-id")]
    session_id_flag: Option<String>,

    /// Prefill the first assistant turn with this text
    #[arg(long = "prefill")]
    prefill: Option<String>,

    /// Effort level for extended thinking (low, medium, high, max)
    #[arg(long = "effort", value_name = "LEVEL")]
    effort: Option<String>,

    /// Extended thinking budget in tokens (enables extended thinking)
    #[arg(long = "thinking", value_name = "TOKENS")]
    thinking: Option<u32>,

    /// Continue the most recent conversation
    #[arg(short = 'c', long = "continue", action = ArgAction::SetTrue)]
    continue_session: bool,

    /// Override system prompt from a file
    #[arg(long = "system-prompt-file")]
    system_prompt_file: Option<PathBuf>,

    /// Tools to allow (comma-separated, default: all)
    #[arg(long = "allowed-tools", value_name = "TOOLS")]
    allowed_tools: Option<String>,

    /// Tools to disallow (comma-separated)
    #[arg(long = "disallowed-tools", value_name = "TOOLS")]
    disallowed_tools: Option<String>,

    /// Extra beta feature headers to send (comma-separated)
    #[arg(long = "betas", value_name = "HEADERS")]
    betas: Option<String>,

    /// Disable all slash commands
    #[arg(long = "disable-slash-commands", action = ArgAction::SetTrue)]
    disable_slash_commands: bool,

    /// Run in bare mode (no hooks, no plugins, no AGENTS.md)
    #[arg(long = "bare", action = ArgAction::SetTrue)]
    bare: bool,

    /// Run with hosted review memory isolation
    #[arg(long = "hosted-review", env = "COVEN_CODE_HOSTED_REVIEW", action = ArgAction::SetTrue)]
    hosted_review: bool,

    /// Hosted repair mode: allow repository file edits but no command execution,
    /// plugins, MCP servers, sub-agents, or network tools.
    #[arg(
        long = "hosted-repair",
        env = "COVEN_CODE_HOSTED_REPAIR",
        action = ArgAction::SetTrue,
        requires_all = ["headless", "context", "output"],
        conflicts_with_all = ["hosted_review", "dangerously_skip_permissions"]
    )]
    hosted_repair: bool,

    /// Billing workload tag
    #[arg(long = "workload", value_name = "TAG")]
    workload: Option<String>,

    /// Maximum spend in USD before aborting the query loop
    #[arg(long = "max-budget-usd", value_name = "USD")]
    max_budget_usd: Option<f64>,

    /// Fallback model to use if the primary model is overloaded or unavailable
    #[arg(long = "fallback-model")]
    fallback_model: Option<String>,

    /// LLM provider to use (default: anthropic). Supported: anthropic, codex
    #[arg(long, env = "COVEN_CODE_PROVIDER")]
    provider: Option<String>,

    /// Override the API base URL for the selected provider
    #[arg(long, env = "COVEN_CODE_API_BASE")]
    api_base: Option<String>,

    /// Named agent to use (e.g., build, plan, explore)
    #[arg(long, short = 'A')]
    agent: Option<String>,

    // ── coven-github: headless session brief / result envelope ──────────
    /// Run headless: no TUI, non-interactive, structured output. This is the
    /// canonical flag the coven-github App worker spawns
    /// (`--headless --context <brief> --output <result>`). Equivalent to --print
    /// for input/output handling; disables the ratatui TUI entirely.
    #[arg(long = "headless", action = ArgAction::SetTrue)]
    headless: bool,

    /// Load a coven-github session brief (JSON) for fully-automated headless runs.
    /// Overrides --model, --cwd, and --system-prompt from the brief's familiar config.
    /// Used by coven-github workers; implies headless + --dangerously-skip-permissions.
    #[arg(long = "context", value_name = "BRIEF_JSON")]
    context: Option<PathBuf>,

    /// Write a structured result envelope (JSON) to this path on exit.
    /// Contains status, branch, commits, files_changed, summary, pr_body, exit_reason.
    /// Only meaningful with --context / headless GitHub App runs.
    #[arg(long = "output", value_name = "RESULT_JSON")]
    output: Option<PathBuf>,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, ValueEnum)]
enum CliPermissionMode {
    Default,
    AcceptEdits,
    BypassPermissions,
    Plan,
}

impl From<CliPermissionMode> for PermissionMode {
    fn from(m: CliPermissionMode) -> Self {
        match m {
            CliPermissionMode::Default => PermissionMode::Default,
            CliPermissionMode::AcceptEdits => PermissionMode::AcceptEdits,
            CliPermissionMode::BypassPermissions => PermissionMode::BypassPermissions,
            CliPermissionMode::Plan => PermissionMode::Plan,
        }
    }
}

fn permission_mode_for_invocation(
    cli_mode: CliPermissionMode,
    has_github_context: bool,
) -> PermissionMode {
    if has_github_context {
        PermissionMode::BypassPermissions
    } else {
        cli_mode.into()
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, ValueEnum)]
enum CliOutputFormat {
    Text,
    Json,
    #[value(name = "stream-json")]
    StreamJson,
}

impl From<CliOutputFormat> for claurst_core::config::OutputFormat {
    fn from(f: CliOutputFormat) -> Self {
        match f {
            CliOutputFormat::Text => claurst_core::config::OutputFormat::Text,
            CliOutputFormat::Json => claurst_core::config::OutputFormat::Json,
            CliOutputFormat::StreamJson => claurst_core::config::OutputFormat::StreamJson,
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, ValueEnum)]
enum CliInputFormat {
    /// Plain text prompt (default)
    Text,
    /// Newline-delimited JSON messages — each line is {"role":"user"|"assistant","content":"..."}
    #[value(name = "stream-json")]
    StreamJson,
}

fn resolve_bridge_config(
    settings: &Settings,
    auth_credential: &str,
    use_bearer_auth: bool,
    is_headless: bool,
) -> Option<claurst_bridge::BridgeConfig> {
    if is_headless {
        return None;
    }

    let mut bridge_config = claurst_bridge::BridgeConfig::from_env();

    if settings.remote_control_at_startup {
        bridge_config.enabled = true;
    }

    if bridge_config.session_token.is_none() && use_bearer_auth && !auth_credential.is_empty() {
        bridge_config.session_token = Some(auth_credential.to_string());
    }

    bridge_config.is_active().then_some(bridge_config)
}

fn handle_exit_key(
    app: &mut claurst_tui::app::App,
    key: crossterm::event::KeyEvent,
    cancel: &Option<tokio_util::sync::CancellationToken>,
    owner: &mut Option<InteractiveTurn>,
) -> bool {
    match app.handle_control_key(key) {
        Some(interrupt) => {
            if interrupt {
                abandon_interactive_turn(owner, app, cancel);
            }
            true
        }
        None => false,
    }
}

fn abandon_interactive_turn(
    owner: &mut Option<InteractiveTurn>,
    app: &mut claurst_tui::App,
    cancel: &Option<tokio_util::sync::CancellationToken>,
) {
    if let Some(owner) = owner {
        owner.abandoned = true;
    }
    app.rate_limit_recovery.dismiss();
    if app.file_injection_dialog.visible || app.file_injection_force {
        app.file_injection_dialog.dismiss();
        app.file_injection_force = false;
        app.pending_auto_submit = false;
    }
    if let Some(cancel) = cancel {
        cancel.cancel();
    }
    // This is the cancellation a key may have requested; it now waits on
    // the worker, which the loop settles once the turn has stopped.
    app.take_cancellation_request();
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Perform a best-effort, non-fatal relocation of the engine home from the
    // legacy ~/.coven-code/ to ~/.coven/code/ when running under the unified
    // coven CLI.  Must run before any Settings::load() or auth/config access.
    claurst_core::home_migration::migrate_if_needed();

    let raw_args: Vec<String> = std::env::args().collect();

    // Fast-path: `coven-code upgrade [--version <v>] [--force]` — self-update.
    // This must run before the top-level --version handler so
    // `coven-code upgrade --version <v>` reaches the upgrade subcommand.
    if raw_args.get(1).map(|s| s.as_str()) == Some("upgrade") {
        return upgrade::run_upgrade(&raw_args[2..]).await;
    }

    // Fast-path: handle --version before parsing everything
    if raw_args.iter().any(|a| a == "--version" || a == "-V") {
        println!("coven-code {}", APP_VERSION);
        return Ok(());
    }

    // Fast-path: `claude auth <login|logout|status>` — mirrors TypeScript cli.tsx pattern
    if raw_args.get(1).map(|s| s.as_str()) == Some("auth") {
        return handle_auth_command(&raw_args[2..]).await;
    }

    // Fast-path: `coven-code codex <login|logout|list|switch|remove>` — manage
    // OpenAI Codex (ChatGPT) accounts. Mirrors `coven-code auth` for symmetry.
    if raw_args.get(1).map(|s| s.as_str()) == Some("codex") {
        return handle_codex_account_command(&raw_args[2..]).await;
    }

    // Fast-path: `coven-code accounts` — list all stored accounts across providers.
    if raw_args.get(1).map(|s| s.as_str()) == Some("accounts") {
        handle_accounts_command(&raw_args[2..]);
        return Ok(());
    }

    // Fast-path: `coven-code acp` — start the Agent Client Protocol stdio server.
    if raw_args.get(1).map(|s| s.as_str()) == Some("acp") {
        return claurst_acp::run_acp_server().await;
    }

    // Fast-path: `coven-code models [provider] [--refresh] [--verbose] [--json]`
    //   — list all available providers and models from the bundled snapshot
    //     plus any disk-cached overlay from models.dev.
    if raw_args.get(1).map(|s| s.as_str()) == Some("models") {
        return run_models_command(&raw_args[2..]).await;
    }

    // Fast-path: `coven-code memory ...` — inspect and administer memory lifecycle controls.
    if raw_args.get(1).map(|s| s.as_str()) == Some("memory") {
        return memory_admin::handle_memory_command(&raw_args[2..]).await;
    }

    // Fast-path: named commands (`claude agents`, `claude ide`, `claude branch`, …)
    // Check before Cli::parse() so these names don't conflict with positional prompt arg.
    if let Some(cmd_name) = raw_args.get(1).map(|s| s.as_str()) {
        // Only intercept if it looks like a subcommand (no leading `-` or `/`)
        if !cmd_name.starts_with('-') && !cmd_name.starts_with('/') {
            if let Some(named_cmd) = claurst_commands::named_commands::find_named_command(cmd_name)
            {
                // Build a minimal CommandContext (named commands are pre-session)
                let settings = Settings::load().await.unwrap_or_default();
                let config = settings.effective_config();
                let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
                let cmd_ctx = claurst_commands::CommandContext {
                    config,
                    cost_tracker: CostTracker::new(),
                    messages: vec![],
                    working_dir: cwd,
                    session_id: "pre-session".to_string(),
                    session_title: None,
                    remote_session_url: None,
                    mcp_manager: None,
                    mcp_auth_runner: None,
                };
                // Collect remaining args after the command name
                let rest: Vec<&str> = raw_args[2..].iter().map(|s| s.as_str()).collect();
                let result = named_cmd.execute_named(&rest, &cmd_ctx);
                match result {
                    claurst_commands::CommandResult::Message(msg)
                    | claurst_commands::CommandResult::UserMessage(msg) => {
                        println!("{}", msg);
                        std::process::exit(0);
                    }
                    claurst_commands::CommandResult::Error(e) => {
                        eprintln!("Error: {}", e);
                        eprintln!("Usage: {}", named_cmd.usage());
                        std::process::exit(1);
                    }
                    _ => {
                        // For any other result variant, fall through to normal startup
                    }
                }
                return Ok(());
            }
        }
    }

    let cli = Cli::parse();

    // --context loads a versioned coven-github session brief. It
    // implies full headless + skip-permissions and overrides model/cwd from the
    // brief. A brief with an unsupported major version is rejected here.
    let github_context = SessionBrief::load(cli.context.as_ref())?;
    let is_headless = cli.headless || cli.print || cli.prompt.is_some() || github_context.is_some();

    // Setup logging
    let log_level = if cli.verbose { "debug" } else { "warn" };
    let base_filter =
        EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new(log_level));
    let log_filter = base_filter
        .add_directive(
            "rmcp::service::client=error"
                .parse()
                .expect("valid rmcp directive"),
        )
        // Suppress error/warn logs from query — errors are already shown as error modals
        .add_directive("claurst_query=off".parse().expect("valid directive"));
    let subscriber = tracing_subscriber::fmt()
        .with_env_filter(log_filter)
        .with_target(false);
    let diagnostic_log = if !is_headless
        && !cli.dump_system_prompt
        && std::io::IsTerminal::is_terminal(&std::io::stderr())
    {
        let directory = claurst_core::config::config_home().join("logs");
        let log = diagnostics::DiagnosticLog::open(&directory).with_context(|| {
            format!(
                "Could not open private diagnostics in {}",
                directory.display()
            )
        })?;
        subscriber
            .with_ansi(false)
            .log_internal_errors(false)
            .with_writer(log.clone())
            .init();
        Some(log)
    } else {
        // Keep headless stdout protocol-safe and respect explicit stderr redirection.
        subscriber
            .without_time()
            .with_writer(std::io::stderr)
            .init();
        None
    };

    // Determine working directory. GitHub session briefs are worker-authored and
    // own the task workspace, so they intentionally override --cwd.
    let cwd = if let Some(brief) = github_context.as_ref() {
        brief.workspace_root()
    } else {
        cli.cwd
            .clone()
            .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")))
    };

    debug!(cwd = %cwd.display(), "Starting Coven Code");

    // Load settings from disk (hierarchical: global < project)
    let settings = Settings::load_hierarchical(&cwd).await;

    // Build effective config (CLI args override settings)
    let mut config = settings.effective_config();
    if let Some(ref key) = cli.api_key {
        config.api_key = Some(key.clone());
    }
    if let Some(ref m) = cli.model {
        config.model = Some(m.clone());
    }
    if let Some(mt) = cli.max_tokens {
        config.max_tokens = Some(mt);
    }
    config.verbose = cli.verbose;
    config.output_format = cli.output_format.into();
    config.disable_claude_mds = cli.no_claude_md;
    if cli.hosted_review {
        config.hosted_review.enabled = true;
    }
    if let Some(sp) = cli.system_prompt.clone() {
        config.custom_system_prompt = Some(sp);
    }
    if let Some(asp) = cli.append_system_prompt.clone() {
        config.append_system_prompt = Some(asp);
    }
    if let Some(brief) = github_context.as_ref() {
        headless::apply_to_config(&mut config, brief);
    }
    if cli.hosted_repair {
        config.hosted_review.enabled = true;
        config.hosted_review.allow_file_write_tools = true;
        config.hosted_review.allow_write_tools = false;
        config.hosted_review.allow_user_memory = false;
        config.hosted_review.allow_mcp_servers = false;
        config.hosted_review.allow_plugins = false;
        config.hosted_review.allow_auto_memory_persistence = false;
    }
    if cli.dangerously_skip_permissions {
        // Mirror TS setup.ts: block bypass mode when running as root/sudo.
        #[cfg(unix)]
        if nix::unistd::Uid::effective().is_root() {
            anyhow::bail!(
                "--dangerously-skip-permissions cannot be used with root/sudo privileges for security reasons"
            );
        }
        config.permission_mode = PermissionMode::BypassPermissions;
    } else {
        config.permission_mode =
            permission_mode_for_invocation(cli.permission_mode, github_context.is_some());
    }
    config.additional_dirs = cli.add_dir.clone();
    if cli.no_auto_compact {
        config.auto_compact = false;
    }
    if cli.auto_commits {
        config.auto_commits = Some(true);
    }
    config.project_dir = Some(cwd.clone());
    if let Some(p) = &cli.provider {
        config.provider = Some(p.clone());
    }
    if let Some(base) = &cli.api_base {
        // Store in the provider's config entry
        let provider_id = config
            .provider
            .clone()
            .unwrap_or_else(|| "anthropic".to_string());
        config
            .provider_configs
            .entry(provider_id)
            .or_default()
            .api_base = Some(base.clone());
    }

    // --dump-system-prompt fast path
    if cli.dump_system_prompt {
        let ctx = ContextBuilder::new(cwd.clone())
            .disable_claude_mds(config.disable_claude_mds)
            .memory_load_options(config.memory_load_options());
        let sys = ctx.build_system_context().await;
        let user = ctx.build_user_context().await;
        println!("{}\n\n{}", sys, user);
        return Ok(());
    }

    // Build context
    let ctx_builder = ContextBuilder::new(cwd.clone())
        .disable_claude_mds(config.disable_claude_mds)
        .memory_load_options(config.memory_load_options());
    let system_ctx = ctx_builder.build_system_context().await;
    let user_ctx = ctx_builder.build_user_context().await;

    // Build system prompt
    let mut system_parts = vec![
        include_str!("system_prompt.txt").to_string(),
        system_ctx,
        user_ctx,
    ];
    if let Some(ref custom) = config.custom_system_prompt {
        // replace base system prompt
        system_parts[0] = custom.clone();
    }
    if let Some(ref append) = config.append_system_prompt {
        system_parts.push(append.clone());
    }
    let system_prompt = system_parts.join("\n\n");

    // Initialize API client.
    // Try config/env first; fall back to configured-client OAuth tokens.
    // With no Anthropic credential at all, the client is built with an empty
    // key and the query loop dispatches Claude turns through the local
    // `claude` CLI runtime instead (headless included) — imported tokens are
    // never used.
    let active_provider = config.selected_provider_id();
    let (api_key, use_bearer_auth) = if active_provider == "anthropic" {
        config
            .resolve_anthropic_auth_async()
            .await
            .unwrap_or((String::new(), false))
    } else {
        (String::new(), false)
    };

    let client_config = claurst_api::client::ClientConfig {
        api_key: api_key.clone(),
        api_base: config.resolve_anthropic_api_base(),
        use_bearer_auth,
        ..Default::default()
    };
    let client = Arc::new(
        claurst_api::AnthropicClient::new(client_config.clone())
            .context("Failed to create API client")?,
    );

    // Build provider registry: registers Claude (Anthropic) plus Codex when its
    // OAuth tokens are present in ~/.coven-code/auth.json (from /connect).
    // Anthropic is always the default.
    let provider_registry = claurst_api::ProviderRegistry::from_config(&config, client_config);

    let bridge_config = resolve_bridge_config(&settings, &api_key, use_bearer_auth, is_headless);
    if let Some(cfg) = bridge_config.as_ref() {
        info!(
            server_url = %cfg.server_url,
            startup_enabled = settings.remote_control_at_startup,
            "Remote control bridge configured for interactive startup"
        );
    }

    let permission_manager = Arc::new(std::sync::Mutex::new(PermissionManager::new(
        config.permission_mode.clone(),
        &settings,
    )));

    let permission_handler: Arc<dyn claurst_core::PermissionHandler> = if is_headless {
        Arc::new(AutoPermissionHandler::with_manager(
            permission_manager.clone(),
        ))
    } else {
        Arc::new(InteractivePermissionHandler::with_manager(
            permission_manager.clone(),
        ))
    };
    let cost_tracker = CostTracker::new();
    // Use --session-id if provided, otherwise generate a fresh UUID.
    let session_id = cli
        .session_id_flag
        .clone()
        .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
    let file_history = Arc::new(ParkingMutex::new(
        claurst_core::file_history::FileHistory::new(),
    ));
    let current_turn = Arc::new(std::sync::atomic::AtomicUsize::new(0));

    // Initialize MCP servers first (needed for ToolContext.mcp_manager).
    let mcp_manager_arc = connect_mcp_manager_arc(&config, Some(&cwd)).await;

    let pending_permissions = Arc::new(ParkingMutex::new(
        claurst_tools::PendingPermissionStore::default(),
    ));

    let is_non_interactive = is_headless;

    // Side-channel for the AskUserQuestion tool to send questions to the TUI.
    // Only created in interactive mode; None in headless/print mode.
    let (user_question_tx, user_question_rx) =
        tokio::sync::mpsc::unbounded_channel::<claurst_tools::UserQuestionEvent>();
    let user_question_rx = if is_non_interactive {
        None
    } else {
        Some(user_question_rx)
    };

    let tool_ctx = ToolContext {
        working_dir: cwd.clone(),
        permission_mode: config.permission_mode.clone(),
        permission_handler: permission_handler.clone(),
        cost_tracker: cost_tracker.clone(),
        session_id: session_id.clone(),
        goal_turn: claurst_core::goal::GoalTurnContext::pending_default(),
        file_history: file_history.clone(),
        current_turn: current_turn.clone(),
        non_interactive: is_non_interactive,
        mcp_manager: mcp_manager_arc.clone(),
        config: config.clone(),
        managed_agent_config: config.managed_agents.clone(),
        completion_notifier: None,
        pending_permissions: Some(pending_permissions.clone()),
        permission_manager: Some(permission_manager.clone()),
        user_question_tx: if is_non_interactive {
            None
        } else {
            Some(user_question_tx)
        },
    };

    // Hourly shadow-snapshot GC loop: only runs when snapshot is explicitly enabled.
    if config.auto_commits == Some(true) {
        let gc_dir = cwd.clone();
        tokio::spawn(async move {
            tokio::time::sleep(std::time::Duration::from_secs(60)).await;
            loop {
                if let Some(snap) = claurst_core::snapshot::get_or_create(&gc_dir) {
                    snap.cleanup().await;
                }
                tokio::time::sleep(std::time::Duration::from_secs(3600)).await;
            }
        });
    }

    // Register the cc-query-backed agent runner so TeamCreateTool can spawn real
    // sub-agents.  Must be called before any tool execution begins.
    // The function is idempotent if already registered (panics only on double-call,
    // but we guard with a std::sync::OnceLock internally).
    {
        static SWARM_INIT: std::sync::OnceLock<()> = std::sync::OnceLock::new();
        SWARM_INIT.get_or_init(claurst_query::init_team_swarm_runner);
    }

    // Build the full tool list: built-ins from cc-tools plus AgentTool from cc-query
    // (AgentTool lives in cc-query to avoid a circular cc-tools ↔ cc-query dependency).
    // Wrap in Arc so the list can be shared by the main loop AND the cron scheduler.
    let tools = build_tools_with_mcp(mcp_manager_arc.clone());

    // Load plugins and register any plugin-provided MCP servers into the
    // in-memory config (does not modify the settings file on disk).
    if config.hosted_review_enabled() && !config.hosted_review.allow_plugins {
        info!("Plugins skipped because hosted review mode does not allow plugins");
    } else {
        let plugin_registry = claurst_plugins::load_plugins(&cwd, &[]).await;
        {
            let plugin_cmd_count = plugin_registry.all_command_defs().len();
            let plugin_hook_count = plugin_registry
                .build_hook_registry()
                .values()
                .map(|v| v.len())
                .sum::<usize>();
            info!(
                plugins = plugin_registry.enabled_count(),
                commands = plugin_cmd_count,
                hooks = plugin_hook_count,
                "Plugins loaded"
            );

            // Register plugin MCP servers into the in-memory config so they are
            // picked up by any subsequent MCP manager construction.
            config
                .reconcile_plugin_mcp_servers(plugin_registry.all_mcp_servers())
                .await?;
        }
    }

    // Build model registry for dynamic model/provider resolution.
    // The registry is pre-populated with a hardcoded snapshot and enriched
    // from the models.dev cache if available.
    let model_registry = load_cached_model_registry();

    // Build query config
    let mut query_config =
        claurst_query::QueryConfig::from_config_with_registry(&config, &model_registry);
    query_config.preserve_selected_model = cli.model.is_some() || cli.provider.is_some();
    query_config.model_registry = Some(model_registry.clone());
    query_config.max_turns = cli.max_turns;
    query_config.system_prompt = Some(system_prompt);
    query_config.append_system_prompt = None;
    query_config.working_directory = Some(cwd.display().to_string());
    if let Some(tokens) = cli.thinking {
        query_config.thinking_budget = Some(tokens);
    }
    if let Some(ref level_str) = cli.effort {
        if let Some(level) = claurst_core::effort::EffortLevel::parse(level_str) {
            query_config.effort_level = Some(level);
        } else {
            eprintln!(
                "Warning: unknown effort level '{}' — expected low/medium/high/max",
                level_str
            );
        }
    }
    if let Some(usd) = cli.max_budget_usd {
        query_config.max_budget_usd = Some(usd);
    }
    if let Some(ref fb) = cli.fallback_model {
        query_config.fallback_model = Some(fb.clone());
    }
    // Wire in the provider registry so non-Anthropic providers can be dispatched.
    let provider_registry = std::sync::Arc::new(provider_registry);
    query_config.provider_registry = Some(provider_registry.clone());

    // Wire in the named agent. An explicit --agent wins; otherwise a configured
    // familiar is also the active agent so the prompt matches the visible card.
    let startup_agent = startup_agent_name(cli.agent.as_deref(), config.familiar.as_deref());
    let tools = if let Some(agent_key) = startup_agent {
        let all_agents =
            claurst_core::coven_shared::default_agents_with_familiars_and_config(&config.agents);
        query_config.agent_name = Some(agent_key.clone());
        if let Some(def) = all_agents.get(&agent_key) {
            let access = def.access.clone();
            query_config.agent_definition = Some(def.clone());
            // Override max_turns from agent definition when specified.
            if let Some(turns) = def.max_turns {
                query_config.max_turns = turns;
            }
            filter_tools_for_agent(tools, &access)
        } else {
            eprintln!(
                "Warning: unknown agent '{}'. Run /agent to see available agents.",
                agent_key
            );
            tools
        }
    } else {
        tools
    };
    apply_headless_review_query_defaults(&mut query_config, github_context.as_ref());
    let tools = filter_tools_for_hosted_review(tools, &config);

    // Spawn the background cron scheduler (fires cron tasks at scheduled times).
    // Cancelled automatically when the process exits since we use a shared token.
    let cron_cancel = tokio_util::sync::CancellationToken::new();
    claurst_query::start_cron_scheduler(
        client.clone(),
        tools.clone(),
        tool_ctx.clone(),
        query_config.clone(),
        cron_cancel.clone(),
    );

    // --print / headless mode
    if is_headless {
        // Long-lived stream-json mode: the Coven runtime stream protocol.
        // Turns arrive as stdin JSON frames; the process exits on stdin EOF.
        // GitHub App runs (--context) never use this path — their prompt
        // comes from the session brief.
        if cli.input_format == CliInputFormat::StreamJson && github_context.is_none() {
            if cli.prompt.is_some() {
                eprintln!(
                    "Warning: positional prompt is ignored with --input-format stream-json; \
                     send user frames on stdin."
                );
            }
            let run = stream_mode::run_stream_loop(stream_mode::StreamLoopParams {
                client,
                tools,
                tool_ctx,
                query_config,
                cost_tracker,
                model: claurst_api::effective_model_for_config(&config, &model_registry),
                resume_id: cli.resume.clone(),
            })
            .await;
            cron_cancel.cancel();
            return run;
        }

        // For a coven-github run, configure git auth from COVEN_GIT_TOKEN before
        // the agent starts. This installs an env-backed credential helper in the
        // workspace (the token stays in the environment, never on disk) so the
        // familiar can push its working branch over HTTPS.
        if github_context.is_some() {
            match headless::configure_git_auth(&cwd) {
                Ok(true) => info!("headless: installed env-backed git credential helper"),
                Ok(false) => warn!(
                    "headless: no {} present — git push will not be authenticated",
                    headless::GIT_TOKEN_ENV
                ),
                Err(e) => warn!("headless: failed to configure git auth: {e}"),
            }
        }

        // Snapshot the memory audit BEFORE the run: the report must describe
        // the memory that influenced the review, and the agent may modify
        // AGENTS.md files (and commit) during the run.
        let review_memory = cli
            .output
            .as_ref()
            .map(|_| headless::collect_review_memory(&cwd, &config));

        let run = run_headless(
            &cli,
            github_context.as_ref(),
            client,
            tools,
            tool_ctx,
            query_config,
            cost_tracker,
        )
        .await;

        cron_cancel.cancel();

        // If --output was requested, write the coven-github result envelope and,
        // for a real GitHub run, honor the exit-code contract
        // (docs/headless-contract.md §4).
        if let Some(output_path) = &cli.output {
            let default_branch = github_context
                .as_ref()
                .map(|b| b.default_branch().to_string())
                .unwrap_or_else(|| "main".to_string());
            let git_summary = headless::collect_git_summary(&cwd, &default_branch);
            let (envelope, exit_code) = match &run {
                Ok(r) => headless::build_result_with_memory(
                    github_context.as_ref(),
                    &git_summary,
                    r.outcome,
                    &r.final_text,
                    Some(&r.review_trace),
                    review_memory.clone().unwrap_or_default(),
                    cli.hosted_repair,
                ),
                Err(e) => headless::infra_error_result(
                    github_context.as_ref(),
                    &git_summary,
                    &e.to_string(),
                ),
            };
            if let Err(e) = headless::write_result(output_path, &envelope) {
                eprintln!("[coven-github] warning: failed to write --output result: {e}");
            }
            // The exit code is the authoritative contract signal for the adapter.
            if github_context.is_some() {
                std::process::exit(exit_code);
            }
        }

        // Non-GitHub --print run: preserve prior exit semantics (non-zero on a
        // model / infra error, zero otherwise).
        return match run {
            Ok(r)
                if matches!(
                    r.outcome,
                    RunOutcome::Errored | RunOutcome::Cancelled | RunOutcome::BudgetExceeded
                ) =>
            {
                std::process::exit(1)
            }
            Ok(_) => Ok(()),
            Err(e) => Err(e),
        };
    }

    // Interactive REPL mode
    if should_show_engine_notice(
        !is_headless,
        std::io::IsTerminal::is_terminal(&std::io::stderr()),
        std::env::var_os("COVEN_PARENT").is_some(),
    ) {
        eprintln!(
            "\x1b[2mcoven-code is the Coven engine \u{2014} the supported CLI is 'coven' (npm i -g @opencoven/cli)\x1b[0m"
        );
    }

    let auth_store = claurst_core::AuthStore::load();
    let has_saved_credentials = !auth_store.credentials.is_empty()
        || claurst_core::oauth_config::get_codex_tokens().is_some();
    let has_credentials = !api_key.is_empty()
        || has_saved_credentials
        // Keyless Claude runs through the local `claude` CLI runtime.
        || claurst_api::providers::claude_cli::resolve_claude_binary().is_some()
        || config.provider.as_deref().is_some_and(|p| p != "anthropic");
    let result = run_interactive(
        config,
        settings,
        client,
        tools,
        tool_ctx,
        query_config,
        cost_tracker,
        cli.resume,
        bridge_config,
        has_credentials,
        model_registry,
        user_question_rx,
        diagnostic_log,
    )
    .await;

    cron_cancel.cancel();
    result
}

async fn refresh_mcp_project_config(
    config: &mut Config,
    project_dir: &std::path::Path,
) -> anyhow::Result<()> {
    config.set_mcp_project(project_dir).await?;
    claurst_plugins::refresh_cached_plugins(project_dir).await;
    if config.hosted_review_enabled() && !config.hosted_review.allow_plugins {
        config.reconcile_plugin_mcp_servers(Vec::new()).await?;
    } else if let Some(registry) = claurst_plugins::global_plugin_registry()
        .filter(|registry| registry.matches_project(project_dir))
    {
        config
            .reconcile_plugin_mcp_servers(registry.all_mcp_servers())
            .await?;
    }
    Ok(())
}

async fn connect_mcp_manager_arc(
    config: &Config,
    caller: Option<&std::path::Path>,
) -> Option<Arc<claurst_mcp::McpManager>> {
    let server_count = config.effective_mcp_servers().count();
    if server_count == 0 {
        return None;
    }
    if config.hosted_review_enabled() && !config.hosted_review.allow_mcp_servers {
        info!("MCP servers skipped because hosted review mode does not allow MCP servers");
        return None;
    }

    info!(count = server_count, "Connecting to MCP servers");
    let mcp_manager = Arc::new(claurst_mcp::McpManager::connect_config(config, caller).await);
    mcp_manager.clone().spawn_notification_poll_loop(caller);
    Some(mcp_manager)
}

fn build_tools_with_mcp(
    mcp_manager: Option<Arc<claurst_mcp::McpManager>>,
) -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    let mut v: Vec<Box<dyn claurst_tools::Tool>> = claurst_tools::all_tools();
    v.push(Box::new(claurst_query::AgentTool));

    if let Some(ref manager_arc) = mcp_manager {
        for (server_name, tool_def) in manager_arc.all_tool_definitions() {
            let wrapper = McpToolWrapper {
                tool_def,
                server_name,
                manager: manager_arc.clone(),
            };
            v.push(Box::new(wrapper));
        }
        debug!(total_tools = v.len(), "MCP tools registered");
    }

    Arc::new(v)
}

fn replace_mcp_runtime(
    new_manager: Option<Arc<claurst_mcp::McpManager>>,
    tool_ctx: &mut ToolContext,
    cmd_ctx: &mut claurst_commands::CommandContext,
    app_manager: &mut Option<Arc<claurst_mcp::McpManager>>,
) -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    // Startup and cron owners can retain these managers after reconnect.
    // Retire only notifications; their ordinary requests remain available.
    for retired in [&tool_ctx.mcp_manager, &cmd_ctx.mcp_manager, &*app_manager]
        .into_iter()
        .flatten()
    {
        if !new_manager
            .as_ref()
            .is_some_and(|replacement| Arc::ptr_eq(retired, replacement))
        {
            retired.shutdown_notification_poll_loops();
        }
    }
    tool_ctx.mcp_manager = new_manager.clone();
    cmd_ctx.mcp_manager = new_manager.clone();
    *app_manager = new_manager.clone();
    filter_tools_for_hosted_review(build_tools_with_mcp(new_manager), &cmd_ctx.config)
}

fn model_cache_dir() -> PathBuf {
    dirs::cache_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("coven-code")
}

/// Resolve the models.dev source URL, honoring env-var overrides.
fn models_source_url() -> String {
    std::env::var("COVEN_CODE_MODELS_URL")
        .or_else(|_| std::env::var("MODELS_DEV_URL"))
        .unwrap_or_else(|_| "https://models.dev/api.json".to_string())
}

/// Default cache filename — derived from the source URL so a custom
/// `COVEN_CODE_MODELS_URL` doesn't stomp the canonical models.dev cache.
fn models_cache_path() -> PathBuf {
    let url = models_source_url();
    let filename = if url == "https://models.dev/api.json" {
        "models.json".to_string()
    } else {
        // Hash the source URL into the filename so two different mirrors
        // each get their own cache file.
        let h = xxhash_rust::xxh64::xxh64(url.as_bytes(), 0);
        format!("models-{:016x}.json", h)
    };
    model_cache_dir().join(filename)
}

/// Legacy cache file location — kept so old installs don't lose their
/// previously-fetched data on first run with the new layout.
fn models_dev_cache_path() -> PathBuf {
    model_cache_dir().join("models_dev.json")
}

/// Implementation of the `coven-code models` subcommand.
///
/// Flags:
/// * `--refresh`   — force-fetch from models.dev (ignoring the 5-minute
///   freshness window), then list.
/// * `--verbose`   — also print release date, status, modalities,
///   cache pricing, and capability flags.
/// * `--json`      — emit the registry as a JSON object keyed by
///   `provider/model` (suitable for piping into `jq`).
/// * `<provider>`  — first non-flag arg filters by provider id
///   (e.g. `coven-code models openai`).
async fn run_models_command(args: &[String]) -> anyhow::Result<()> {
    let mut refresh = false;
    let mut verbose = false;
    let mut as_json = false;
    let mut provider_filter: Option<String> = None;

    for arg in args {
        match arg.as_str() {
            "--refresh" | "-r" => refresh = true,
            "--verbose" | "-v" => verbose = true,
            "--json" => as_json = true,
            s if s.starts_with("--") => {
                eprintln!("coven-code models: unknown flag: {}", s);
                eprintln!("Usage: coven-code models [<provider>] [--refresh] [--verbose] [--json]");
                std::process::exit(2);
            }
            s => {
                if provider_filter.is_some() {
                    eprintln!("coven-code models: only one provider id may be supplied");
                    std::process::exit(2);
                }
                provider_filter = Some(s.to_string());
            }
        }
    }

    let mut registry = claurst_api::ModelRegistry::new().with_cache_path(models_cache_path());

    if refresh {
        // Force-refresh by clearing the freshness check first.
        let _ = std::fs::remove_file(models_cache_path());
        match registry.refresh_from_models_dev().await {
            Ok(true) => eprintln!("✓ Refreshed from {}", models_source_url()),
            Ok(false) => eprintln!("(no refresh performed — disabled via env or cache fresh)"),
            Err(err) => eprintln!("⚠ refresh failed: {}", err),
        }
    } else {
        // Best-effort: overlay any disk-cached copy on top of the bundled
        // snapshot.  Path may not exist on first run — that's fine.
        registry.load_cache(&models_cache_path());
    }

    let mut entries: Vec<&claurst_api::ModelEntry> = match &provider_filter {
        Some(pid) => registry.list_by_provider(pid),
        None => registry.list_all(),
    };

    // Stable order: provider id, then by descending release_date so newest
    // models appear first.
    entries.sort_by(|a, b| {
        (*a.info.provider_id)
            .cmp(&*b.info.provider_id)
            .then_with(|| {
                let rd_a = a.release_date.as_deref().unwrap_or("");
                let rd_b = b.release_date.as_deref().unwrap_or("");
                rd_b.cmp(rd_a)
            })
            .then_with(|| (*a.info.id).cmp(&*b.info.id))
    });

    if as_json {
        // Re-key by `provider/model` for jq-friendly output.
        let mut map: std::collections::BTreeMap<String, &claurst_api::ModelEntry> =
            std::collections::BTreeMap::new();
        for e in &entries {
            map.insert(format!("{}/{}", e.info.provider_id, e.info.id), *e);
        }
        let json = serde_json::to_string_pretty(&map)?;
        println!("{}", json);
        return Ok(());
    }

    if entries.is_empty() {
        if let Some(pid) = &provider_filter {
            eprintln!("No models found for provider '{}'.", pid);
            eprintln!("Try: coven-code models                # list all providers");
            eprintln!("     coven-code models --refresh      # pull latest from models.dev");
        } else {
            eprintln!("No models in registry.  Try `coven-code models --refresh`.");
        }
        return Ok(());
    }

    let total = entries.len();

    for entry in &entries {
        let ctx_k = entry.info.context_window / 1000;
        let in_cost = entry.cost_input.unwrap_or(0.0);
        let out_cost = entry.cost_output.unwrap_or(0.0);

        let mut flags = Vec::new();
        if entry.tool_calling {
            flags.push("tools");
        }
        if entry.reasoning {
            flags.push("reasoning");
        }
        if entry.vision() {
            flags.push("vision");
        }
        if entry.audio_input() {
            flags.push("audio");
        }
        if entry.pdf_input() {
            flags.push("pdf");
        }
        let flags_str = if flags.is_empty() {
            String::new()
        } else {
            format!(" [{}]", flags.join(","))
        };

        if verbose {
            println!(
                "{}/{}  {}  ctx={}K  out={}K  in=${:.2}/M  out=${:.2}/M{}",
                entry.info.provider_id,
                entry.info.id,
                entry.info.name,
                ctx_k,
                entry.info.max_output_tokens / 1000,
                in_cost,
                out_cost,
                flags_str,
            );
            if let Some(rd) = &entry.release_date {
                println!("    released {}", rd);
            }
            if let Some(k) = &entry.knowledge {
                println!("    knowledge cutoff {}", k);
            }
            if let (Some(cr), Some(cw)) = (entry.cost_cache_read, entry.cost_cache_write) {
                println!("    cache: read=${:.2}/M  write=${:.2}/M", cr, cw);
            } else if let Some(cr) = entry.cost_cache_read {
                println!("    cache read=${:.2}/M", cr);
            }
            if !matches!(entry.status, claurst_api::ModelStatus::Active) {
                println!("    status: {:?}", entry.status);
            }
            if !entry.modalities_input.is_empty() {
                println!(
                    "    modalities: in=[{}] out=[{}]",
                    entry
                        .modalities_input
                        .iter()
                        .map(|m| format!("{:?}", m).to_lowercase())
                        .collect::<Vec<_>>()
                        .join(","),
                    entry
                        .modalities_output
                        .iter()
                        .map(|m| format!("{:?}", m).to_lowercase())
                        .collect::<Vec<_>>()
                        .join(","),
                );
            }
        } else {
            println!(
                "{}/{} — {} (ctx: {}K, in: ${:.2}/M, out: ${:.2}/M){}",
                entry.info.provider_id,
                entry.info.id,
                entry.info.name,
                ctx_k,
                in_cost,
                out_cost,
                flags_str,
            );
        }
    }

    if provider_filter.is_none() {
        eprintln!(
            "\n{} models across {} providers.  Use `coven-code models <provider>` to filter.",
            total,
            registry.provider_count()
        );
    }

    Ok(())
}

fn load_cached_model_registry() -> Arc<claurst_api::ModelRegistry> {
    let mut reg = claurst_api::ModelRegistry::new();
    // COVEN_CODE_MODELS_PATH wins outright — useful for offline dev where you
    // pin a known-good api.json on disk.
    if let Ok(custom) = std::env::var("COVEN_CODE_MODELS_PATH") {
        reg.load_cache(&PathBuf::from(custom));
    } else {
        reg.load_cache(&models_cache_path());
        // Migration nicety: if the new cache file is missing but the old
        // one exists, ingest it once.
        if !models_cache_path().exists() {
            reg.load_cache(&models_dev_cache_path());
        }
    }
    Arc::new(reg)
}

/// Whether the cache file is fresh enough to skip refreshing.
fn cache_is_fresh(path: &std::path::Path, ttl: std::time::Duration) -> bool {
    let meta = match std::fs::metadata(path) {
        Ok(m) => m,
        Err(_) => return false,
    };
    let mtime = match meta.modified() {
        Ok(t) => t,
        Err(_) => return false,
    };
    match mtime.elapsed() {
        Ok(age) => age < ttl,
        Err(_) => true, // future mtime → treat as fresh
    }
}

/// Background-refresh the models cache from the configured source URL.
///
/// Honors:
/// * `COVEN_CODE_DISABLE_MODELS_FETCH` — skips the network call entirely.
/// * `COVEN_CODE_MODELS_URL` / `MODELS_DEV_URL` — overrides the source URL.
/// * 5-minute mtime-based freshness check — avoids hammering models.dev
///   on every CLI invocation.
fn spawn_models_cache_refresh() {
    if std::env::var("COVEN_CODE_DISABLE_MODELS_FETCH").is_ok() {
        tracing::debug!("COVEN_CODE_DISABLE_MODELS_FETCH set — skipping models.dev refresh");
        return;
    }

    let cache_path = models_cache_path();
    let legacy_cache_path = models_dev_cache_path();
    let ttl = std::time::Duration::from_secs(5 * 60);

    if cache_is_fresh(&cache_path, ttl) {
        tracing::debug!("Models cache fresh — skipping models.dev refresh");
        return;
    }

    tokio::spawn(async move {
        let client = match reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(10))
            .build()
        {
            Ok(c) => c,
            Err(_) => return,
        };
        let url = models_source_url();
        let resp = match client
            .get(&url)
            .header("User-Agent", concat!("Coven/", env!("CARGO_PKG_VERSION")))
            .send()
            .await
        {
            Ok(r) => r,
            Err(err) => {
                tracing::debug!(?err, "models.dev refresh: network error");
                return;
            }
        };
        if !resp.status().is_success() {
            tracing::debug!(status = ?resp.status(), "models.dev refresh: non-2xx");
            return;
        }
        let text = match resp.text().await {
            Ok(t) => t,
            Err(_) => return,
        };
        if let Some(parent) = cache_path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        // Write canonical path + legacy path so older installs keep working.
        let _ = std::fs::write(&cache_path, &text);
        let _ = std::fs::write(&legacy_cache_path, &text);
        tracing::info!(path = %cache_path.display(), "Models cache refreshed from {}", url);
    });
}

async fn remove_file_if_exists(path: &std::path::Path) -> anyhow::Result<()> {
    match tokio::fs::remove_file(path).await {
        Ok(()) => Ok(()),
        Err(err) if err.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(err) => Err(err.into()),
    }
}

struct RefreshedProviderRuntime {
    config: Config,
    client: Arc<claurst_api::AnthropicClient>,
    provider_registry: Arc<claurst_api::ProviderRegistry>,
    model_registry: Arc<claurst_api::ModelRegistry>,
    auth_store: claurst_core::AuthStore,
}

async fn refresh_provider_runtime_state(
    current_config: &Config,
) -> anyhow::Result<RefreshedProviderRuntime> {
    remove_file_if_exists(&claurst_core::AuthStore::path())
        .await
        .context("Failed to clear auth store")?;
    remove_file_if_exists(&claurst_core::oauth::OAuthTokens::token_file_path())
        .await
        .context("Failed to clear OAuth token cache")?;
    remove_file_if_exists(&models_cache_path())
        .await
        .context("Failed to clear model cache")?;
    remove_file_if_exists(&models_dev_cache_path())
        .await
        .context("Failed to clear legacy model cache")?;

    let mut settings = Settings::load()
        .await
        .context("Failed to load settings for /refresh")?;
    settings.provider = None;
    settings.config.provider = None;
    settings.config.model = None;
    settings.config.api_key = None;
    settings
        .save()
        .await
        .context("Failed to save refreshed settings")?;

    let mut config = current_config.clone();
    config.api_key = None;
    config.provider = None;
    config.model = None;

    let (api_key, use_bearer_auth) = config
        .resolve_anthropic_auth_async()
        .await
        .unwrap_or((String::new(), false));
    let client_config = claurst_api::client::ClientConfig {
        api_key,
        api_base: config.resolve_anthropic_api_base(),
        use_bearer_auth,
        ..Default::default()
    };
    let client = Arc::new(
        claurst_api::AnthropicClient::new(client_config.clone())
            .context("Failed to rebuild Anthropic client")?,
    );
    let provider_registry = Arc::new(claurst_api::ProviderRegistry::from_config(
        &config,
        client_config,
    ));
    let model_registry = load_cached_model_registry();

    spawn_models_cache_refresh();

    Ok(RefreshedProviderRuntime {
        config,
        client,
        provider_registry,
        model_registry,
        auth_store: claurst_core::AuthStore::default(),
    })
}

/// Non-destructive sibling of [`refresh_provider_runtime_state`]: rebuild the
/// Anthropic client and provider registry from the credentials currently on
/// disk, **without** clearing any stored tokens or settings. Used after an
/// in-session OAuth login or CLI credential import so the new credential takes
/// effect immediately instead of requiring a restart.
async fn reload_anthropic_runtime_state(
    current_config: &Config,
) -> anyhow::Result<RefreshedProviderRuntime> {
    let mut config = current_config.clone();
    config.api_key = None;
    config.provider = Some("anthropic".to_string());

    let (api_key, use_bearer_auth) = config
        .resolve_anthropic_auth_async()
        .await
        .unwrap_or((String::new(), false));
    let client_config = claurst_api::client::ClientConfig {
        api_key,
        api_base: config.resolve_anthropic_api_base(),
        use_bearer_auth,
        ..Default::default()
    };
    let client = Arc::new(
        claurst_api::AnthropicClient::new(client_config.clone())
            .context("Failed to rebuild Anthropic client")?,
    );
    let provider_registry = Arc::new(claurst_api::ProviderRegistry::from_config(
        &config,
        client_config,
    ));
    let model_registry = load_cached_model_registry();

    Ok(RefreshedProviderRuntime {
        config,
        client,
        provider_registry,
        model_registry,
        auth_store: claurst_core::AuthStore::load(),
    })
}

fn normalize_provider_from_model(config: &mut Config) {
    if let Some(model) = config.model.as_deref() {
        if let Some((provider, _)) = model.split_once('/') {
            config.provider = Some(provider.to_string());
        }
    }
}

/// Resolve an agent selected through the TUI mode switcher.
///
/// The Tab cycle shows reserved built-in modes (`build`, `plan`, `explore`)
/// with security-significant labels, so those names must always resolve to
/// the built-in definitions even if repository settings define agents with
/// the same names. Non-reserved selections still use the normal familiar +
/// project-agent namespace.
fn resolve_tui_agent_mode(
    mode: &str,
    config_agents: &std::collections::HashMap<String, claurst_core::AgentDefinition>,
) -> Option<claurst_core::AgentDefinition> {
    // Use the secure merge that prevents project settings from shadowing familiar ids.
    claurst_core::coven_shared::default_agents_with_familiars_and_config(config_agents)
        .get(mode)
        .cloned()
}

fn startup_agent_name(cli_agent: Option<&str>, familiar: Option<&str>) -> Option<String> {
    cli_agent.or(familiar).map(|name| name.to_lowercase())
}

/// Filter the tool list based on the agent's access level.
/// - "full"        → all tools allowed (no filtering)
/// - "read-only"   → only ReadOnly/None permission tools and AskUserQuestion
/// - "search-only" → only Grep, Glob, Read, WebSearch, WebFetch tools
///
/// The raw `access` string is normalized through
/// [`claurst_core::coven_shared::resolve_access_tier`] before the match — that
/// canonicalizes case/whitespace silently (so `"READ-ONLY"` and `" full "`
/// round-trip cleanly) and fails **closed** to `"read-only"` with a stderr
/// warning for anything genuinely unknown. This preserves the opt-in
/// semantics of `DEFAULT_FAMILIAR_ACCESS` so that typos in
/// `~/.coven/familiars.toml` or `settings.json` cannot silently grant
/// write/exec privileges.
fn filter_tools_for_agent(
    tools: Arc<Vec<Box<dyn claurst_tools::Tool>>>,
    access: &str,
) -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    match claurst_core::coven_shared::resolve_access_tier(access) {
        "full" => tools,
        "read-only" => filter_read_only_tools(&tools),
        "search-only" => filter_search_only_tools(),
        // `resolve_access_tier` is contracted to return one of the canonical
        // tiers in `ACCESS_TIERS`, so anything else is a coven_shared bug.
        other => unreachable!(
            "resolve_access_tier returned non-canonical tier {other:?}; \
             coven_shared::ACCESS_TIERS contract violated"
        ),
    }
}

fn filter_tools_for_hosted_review(
    tools: Arc<Vec<Box<dyn claurst_tools::Tool>>>,
    config: &Config,
) -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    if !config.hosted_review_enabled() || config.hosted_review.allow_write_tools {
        return tools;
    }

    if config.hosted_review.allow_file_write_tools {
        // SECURITY (load-bearing): github_context forces BypassPermissions, so
        // hosted-repair mode has NO permission prompts. This allowlist is the
        // sole containment boundary — it must expose only repository file tools
        // and never command/network/task/sub-agent/plugin/MCP surfaces. The
        // exhaustive test `hosted_repair_allows_only_repository_file_tools`
        // (with its catch-all assertion) guards against a new tool silently
        // leaking into this set. Do not widen without updating that test.
        const FILE_TOOLS: &[&str] = &[
            "Read",
            "Grep",
            "Glob",
            "Edit",
            "Write",
            "ApplyPatch",
            "BatchEdit",
            "NotebookEdit",
        ];
        let filtered = claurst_tools::all_tools()
            .into_iter()
            .filter(|tool| FILE_TOOLS.contains(&tool.name()))
            .collect();
        return Arc::new(filtered);
    }

    filter_read_only_tools_except(&tools, &["LSP"])
}

fn filter_read_only_tools(
    tools: &[Box<dyn claurst_tools::Tool>],
) -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    filter_read_only_tools_except(tools, &[])
}

fn filter_read_only_tools_except(
    tools: &[Box<dyn claurst_tools::Tool>],
    excluded_names: &[&str],
) -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    use claurst_tools::PermissionLevel as PL;
    // Collect names of tools that are read-only, then rebuild from all_tools
    // (Box<dyn Tool> is not Clone so we can't directly filter-and-keep).
    let allowed_names: Vec<String> = tools
        .iter()
        .filter(|t| !excluded_names.contains(&t.name()))
        .filter(|t| {
            matches!(t.permission_level(), PL::ReadOnly | PL::None) || t.name() == "AskUserQuestion"
        })
        .map(|t| t.name().to_string())
        .collect();
    let filtered: Vec<Box<dyn claurst_tools::Tool>> = claurst_tools::all_tools()
        .into_iter()
        .filter(|t| allowed_names.iter().any(|n| n == t.name()))
        .collect();
    Arc::new(filtered)
}

fn filter_search_only_tools() -> Arc<Vec<Box<dyn claurst_tools::Tool>>> {
    const SEARCH_TOOLS: &[&str] = &["Grep", "Glob", "Read", "WebSearch", "WebFetch"];
    let filtered: Vec<Box<dyn claurst_tools::Tool>> = claurst_tools::all_tools()
        .into_iter()
        .filter(|t| SEARCH_TOOLS.contains(&t.name()))
        .collect();
    Arc::new(filtered)
}

fn apply_headless_review_query_defaults(
    query_config: &mut claurst_query::QueryConfig,
    github_context: Option<&SessionBrief>,
) {
    const HOSTED_REVIEW_MAX_TURNS: u32 = 40;

    if github_context
        .map(|brief| brief.review_mode() != headless::ReviewMode::None)
        .unwrap_or(false)
    {
        query_config.max_turns = HOSTED_REVIEW_MAX_TURNS;
    }
}

// ---------------------------------------------------------------------------
// Headless mode: read prompt from arg/stdin, run, print response
// ---------------------------------------------------------------------------

async fn run_headless(
    cli: &Cli,
    github_context: Option<&SessionBrief>,
    client: Arc<claurst_api::AnthropicClient>,
    tools: Arc<Vec<Box<dyn claurst_tools::Tool>>>,
    tool_ctx: ToolContext,
    query_config: claurst_query::QueryConfig,
    cost_tracker: Arc<CostTracker>,
) -> anyhow::Result<headless::HeadlessRun> {
    use claurst_query::{QueryEvent, QueryOutcome};
    use tokio::sync::mpsc;
    use tokio_util::sync::CancellationToken;

    // Build initial messages list from input.
    // --input-format stream-json runs never reach here: main routes them to
    // stream_mode::run_stream_loop (the long-lived Coven runtime protocol)
    // before calling run_headless. This path reads the prompt from the
    // positional arg, the session brief, or stdin as plain text.
    let mut messages: Vec<claurst_core::types::Message> = {
        let prompt = if let Some(ref p) = cli.prompt {
            p.clone()
        } else if let Some(brief) = github_context {
            if cli.hosted_repair {
                brief.to_hosted_repair_prompt()
            } else {
                brief.to_prompt()
            }
        } else {
            use tokio::io::{self, AsyncReadExt};
            let mut stdin = io::stdin();
            let mut buf = String::new();
            stdin.read_to_string(&mut buf).await?;
            buf.trim().to_string()
        };

        if prompt.is_empty() {
            anyhow::bail!("No prompt provided. Use --print <prompt> or pipe text to stdin.");
        }

        vec![claurst_core::types::Message::user(prompt)]
    };

    // --prefill: inject a partial assistant turn before the query so the model
    // continues from that text (mirrors TS --prefill flag).
    if let Some(ref prefill_text) = cli.prefill {
        messages.push(claurst_core::types::Message::assistant(
            prefill_text.clone(),
        ));
    }

    if messages.is_empty() {
        anyhow::bail!("No messages provided.");
    }

    let is_json_output = matches!(
        cli.output_format,
        CliOutputFormat::Json | CliOutputFormat::StreamJson
    );
    let is_stream_json = matches!(cli.output_format, CliOutputFormat::StreamJson);

    let (event_tx, mut event_rx) = mpsc::unbounded_channel::<QueryEvent>();
    let cancel = CancellationToken::new();
    let client_clone = client.clone();
    let tool_ctx_clone = tool_ctx.clone();
    let qcfg = query_config.clone();
    let tracker_clone = cost_tracker.clone();
    let event_tx_clone = event_tx.clone();
    let cancel_clone = cancel.clone();

    let query_handle = tokio::spawn(async move {
        claurst_query::run_query_loop(
            client_clone.as_ref(),
            &mut messages,
            tools.as_slice(),
            &tool_ctx_clone,
            &qcfg,
            tracker_clone,
            Some(event_tx_clone),
            cancel_clone,
            None,
        )
        .await
    });

    // Drop the original tx so the channel closes when the task drops its clone
    drop(event_tx);

    // Drain events and print streaming text
    let mut full_text = String::new();
    let mut review_trace = headless::ReviewTrace::new(tool_ctx.working_dir.clone());

    while let Some(event) = event_rx.recv().await {
        match &event {
            QueryEvent::Stream(claurst_api::AnthropicStreamEvent::ContentBlockDelta {
                delta: claurst_api::streaming::ContentDelta::TextDelta { text },
                ..
            }) => {
                full_text.push_str(text);
                if !is_json_output {
                    print!("{}", text);
                    use std::io::Write;
                    std::io::stdout().flush().ok();
                } else if is_stream_json {
                    let chunk = serde_json::json!({ "type": "text_delta", "text": text });
                    println!("{}", chunk);
                }
            }
            QueryEvent::ToolStart {
                tool_name,
                input_json,
                ..
            } => {
                review_trace.record_tool_start(tool_name, input_json);
                if !is_json_output {
                    eprintln!("\n[{}...]", tool_name);
                } else {
                    let ev = serde_json::json!({ "type": "tool_start", "tool": tool_name });
                    println!("{}", ev);
                }
            }
            QueryEvent::ToolEnd {
                tool_name,
                result,
                is_error,
                ..
            } => {
                review_trace.record_tool_end(tool_name, result, *is_error);
            }
            QueryEvent::Error(msg) => {
                if is_json_output {
                    let ev = serde_json::json!({ "type": "error", "error": msg });
                    eprintln!("{}", ev);
                } else {
                    eprintln!("\nError: {}", msg);
                }
            }
            _ => {}
        }
    }

    // Wait for the query task to finish and get the final outcome
    let outcome = query_handle.await.unwrap_or(QueryOutcome::Error(
        claurst_core::error::ClaudeError::Other("Query task panicked".to_string()),
    ));

    // Classify the terminal outcome and capture the familiar's final prose (it
    // becomes the PR body) BEFORE the per-format match below consumes `outcome`.
    let run_outcome = match &outcome {
        QueryOutcome::EndTurn { .. } => RunOutcome::Completed,
        QueryOutcome::MaxTokens { .. } => RunOutcome::Truncated,
        QueryOutcome::Cancelled => RunOutcome::Cancelled,
        QueryOutcome::Error(_) => RunOutcome::Errored,
        QueryOutcome::BudgetExceeded { .. } => RunOutcome::BudgetExceeded,
    };
    let final_text = if !full_text.is_empty() {
        full_text.clone()
    } else {
        match &outcome {
            QueryOutcome::EndTurn { message, .. } => message.get_all_text(),
            QueryOutcome::MaxTokens {
                partial_message, ..
            } => partial_message.get_all_text(),
            _ => String::new(),
        }
    };

    // Final output
    match cli.output_format {
        CliOutputFormat::Json => match outcome {
            QueryOutcome::EndTurn { message, usage } => {
                let result_text = if full_text.is_empty() {
                    message.get_all_text()
                } else {
                    full_text
                };
                let out = serde_json::json!({
                    "type": "result",
                    "result": result_text,
                    "usage": {
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "cache_creation_input_tokens": usage.cache_creation_input_tokens,
                        "cache_read_input_tokens": usage.cache_read_input_tokens,
                    },
                    "cost_usd": cost_tracker.total_cost_usd(),
                });
                println!("{}", out);
            }
            QueryOutcome::Error(e) => {
                let out = serde_json::json!({ "type": "error", "error": e.to_string() });
                eprintln!("{}", out);
            }
            _ => {}
        },
        CliOutputFormat::StreamJson => {
            // Already streamed above; emit final result event
            match outcome {
                QueryOutcome::EndTurn { usage, .. } => {
                    let out = serde_json::json!({
                        "type": "result",
                        "usage": {
                            "input_tokens": usage.input_tokens,
                            "output_tokens": usage.output_tokens,
                        },
                        "cost_usd": cost_tracker.total_cost_usd(),
                    });
                    println!("{}", out);
                }
                QueryOutcome::Error(e) => {
                    let out = serde_json::json!({ "type": "error", "error": e.to_string() });
                    eprintln!("{}", out);
                }
                _ => {}
            }
        }
        CliOutputFormat::Text => {
            // Streaming text was already printed; add newline
            println!();
            if cli.verbose {
                eprintln!(
                    "\nTokens: {} in / {} out | Cost: ${:.4}",
                    cost_tracker.input_tokens(),
                    cost_tracker.output_tokens(),
                    cost_tracker.total_cost_usd(),
                );
            }
            match outcome {
                QueryOutcome::Error(e) => {
                    eprintln!("Error: {}", e);
                }
                QueryOutcome::BudgetExceeded {
                    cost_usd,
                    limit_usd,
                } => {
                    eprintln!(
                        "Budget limit ${:.4} reached (spent ${:.4}). Stopping.",
                        limit_usd, cost_usd
                    );
                }
                _ => {}
            }
        }
    }

    Ok(headless::HeadlessRun {
        outcome: run_outcome,
        final_text,
        review_trace,
    })
}

// ---------------------------------------------------------------------------
// Interactive REPL mode
// ---------------------------------------------------------------------------

fn handle_bridge_permission_response(
    dialog: &mut Option<claurst_tui::dialogs::PermissionRequest>,
    pending_permissions: &mut claurst_tools::PendingPermissionStore,
    tool_use_id: &str,
    response: claurst_bridge::PermissionResponseKind,
) -> Option<(String, bool)> {
    if !dialog
        .as_ref()
        .is_some_and(|pr| pr.tool_use_id == tool_use_id)
    {
        return None;
    }
    let mut pending = pending_permissions.waiting.remove(tool_use_id)?;

    use claurst_bridge::PermissionResponseKind;
    use claurst_core::permissions::PermissionDecision;
    // Preserve the bridge's one-request approval mapping; do not persist rules.
    let decision = match response {
        PermissionResponseKind::Allow | PermissionResponseKind::AllowSession => {
            PermissionDecision::Allow
        }
        PermissionResponseKind::Deny => PermissionDecision::Deny,
    };
    let allowed = matches!(decision, PermissionDecision::Allow);
    if let Some(tx) = pending.decision_tx.take() {
        let _ = tx.send(decision);
    }
    *dialog = None;
    // The decision belongs to the model call that asked, when known.
    Some((pending.call_id.unwrap_or(pending.tool_use_id), allowed))
}

fn permission_request_from_core(
    pending: &claurst_tools::PendingPermissionRequest,
) -> claurst_tui::dialogs::PermissionRequest {
    let reason = pending.reason.clone();
    let tool_name = pending.request.tool_name.clone();
    let tool_use_id = pending.tool_use_id.clone();

    match (tool_name.as_str(), pending.request.path.clone()) {
        ("Bash", Some(command)) => {
            let suggested_prefix = if command
                .chars()
                .any(|c| matches!(c, ';' | '|' | '&' | '<' | '>' | '\n' | '\r' | '`'))
                || command.contains("$(")
            {
                None
            } else {
                let mut words = command.split_whitespace();
                words.next().map(|first| match words.next() {
                    Some(second) => format!("{} {}", first, second),
                    None => first.to_string(),
                })
            };
            claurst_tui::dialogs::PermissionRequest::bash(
                tool_use_id,
                tool_name,
                reason,
                command,
                suggested_prefix,
            )
        }
        ("PowerShell", Some(command)) => claurst_tui::dialogs::PermissionRequest::powershell(
            tool_use_id,
            tool_name,
            reason,
            command,
        ),
        ("Read", Some(path)) => {
            claurst_tui::dialogs::PermissionRequest::file_read(tool_use_id, tool_name, reason, path)
        }
        (_, Some(path)) if matches!(tool_name.as_str(), "Write" | "Edit" | "NotebookEdit") => {
            claurst_tui::dialogs::PermissionRequest::file_write(
                tool_use_id,
                tool_name,
                reason,
                path,
            )
        }
        _ => claurst_tui::dialogs::PermissionRequest::from_reason(
            tool_use_id,
            tool_name,
            reason,
            pending.request.path.clone(),
        ),
    }
}

/// One submitted logical turn, retained through failures and model-switch retries.
/// Resolved absence/failure is stored even when there is no accounting baseline.
#[derive(Debug)]
struct InteractiveTurn {
    goal: claurst_core::goal::GoalTurnContext,
    baseline: Option<GoalTurnBaseline>,
    synthetic_uuid: Option<String>,
    abandoned: bool,
    awaiting_file_confirmation: bool,
}

impl InteractiveTurn {
    fn capture(context: &mut ToolContext, tracker_total: u64) -> Self {
        let baseline = match capture_goal_turn_baseline(context, tracker_total) {
            Ok(baseline) => baseline,
            Err(error) => {
                warn!(%error, "Could not capture interactive goal turn");
                None
            }
        };
        Self {
            goal: context.goal_turn.clone(),
            baseline,
            synthetic_uuid: None,
            abandoned: false,
            awaiting_file_confirmation: false,
        }
    }

    fn from_goal(turn: claurst_core::goal::GoalTurn, tracker_total: u64) -> Self {
        let baseline = Some(GoalTurnBaseline {
            goal_id: turn.goal().id.clone(),
            session_id: turn.goal().session_id.clone(),
            store_path: turn.store_path().to_path_buf(),
            tracker_total,
            started_at: std::time::Instant::now(),
        });
        Self {
            goal: claurst_core::goal::GoalTurnContext::Captured(Some(turn)),
            baseline,
            synthetic_uuid: None,
            abandoned: false,
            awaiting_file_confirmation: false,
        }
    }

    fn prepare_context(&self, context: &mut ToolContext) {
        context.goal_turn = self.goal.clone();
    }

    fn inject(
        &mut self,
        text: String,
        messages: &mut Vec<claurst_core::types::Message>,
        app: &mut claurst_tui::App,
        session: &mut claurst_core::history::ConversationSession,
    ) -> Result<(), claurst_core::GoalError> {
        self.goal.require_work(&session.id)?;
        let mut message = claurst_core::types::Message::user(text);
        message.uuid = Some(uuid::Uuid::new_v4().to_string());
        self.synthetic_uuid = message.uuid.clone();
        messages.push(message.clone());
        app.push_message(message);
        session.messages = messages.clone();
        session.updated_at = chrono::Utc::now();
        Ok(())
    }

    fn continuation(&self, tracker_total: u64) -> claurst_query::GoalContinuation {
        let Some(baseline) = self.baseline.as_ref().filter(|_| !self.abandoned) else {
            return claurst_query::GoalContinuation::NoGoal;
        };
        let result = (|| {
            let current = claurst_core::GoalStore::open(&baseline.store_path)
                .and_then(|store| store.try_get_goal(&baseline.session_id))
                .map_err(|error| error.to_string())?;
            match decide_goal_turn_accounting(Some(baseline), current.as_ref(), tracker_total)? {
                GoalTurnAccountingDecision::Skip => Ok(claurst_query::GoalContinuation::NoGoal),
                GoalTurnAccountingDecision::Record { total_tokens_used } => {
                    claurst_query::check_and_continue_goal_at_path_for_goal(
                        &baseline.store_path,
                        &baseline.session_id,
                        &baseline.goal_id,
                        total_tokens_used,
                        baseline.started_at.elapsed().as_secs(),
                    )
                    .map_err(|error| error.to_string())
                }
            }
        })();
        result.unwrap_or_else(|error| claurst_query::GoalContinuation::Stop {
            reason: claurst_query::StopReason::Error(error),
        })
    }
}

/// Select one logical submission, including a confirmed file-preparation retry.
fn select_submission_turn(
    submitted_goal: Option<claurst_core::goal::GoalTurn>,
    previous: &mut Option<InteractiveTurn>,
    context: &ToolContext,
    tracker_total: u64,
    resume_preparation: bool,
) -> Result<InteractiveTurn, claurst_core::GoalError> {
    if resume_preparation {
        let mut owner = previous
            .take()
            .filter(|owner| owner.awaiting_file_confirmation && !owner.abandoned)
            .ok_or_else(|| claurst_core::GoalError::NotActive {
                session_id: context.session_id.clone(),
            })?;
        owner.awaiting_file_confirmation = false;
        return Ok(owner);
    }
    Ok(match submitted_goal {
        Some(turn) => InteractiveTurn::from_goal(turn, tracker_total),
        None => InteractiveTurn::capture(&mut context.clone(), tracker_total),
    })
}

/// Consume the real dialog result before synthesizing its resubmission event.
fn handle_file_preparation(
    app: &mut claurst_tui::App,
    owner: &mut Option<InteractiveTurn>,
) -> bool {
    // Escape dismisses directly in App without producing an outcome.
    if owner
        .as_ref()
        .is_some_and(|owner| owner.awaiting_file_confirmation)
        && !app.file_injection_dialog.visible
        && !app.file_injection_force
    {
        *owner = None;
    }
    let Some((outcome, input, images)) = app.file_injection_dialog.take_outcome() else {
        return false;
    };
    if matches!(outcome, claurst_tui::FileInjectionOutcome::Abort) {
        *owner = None;
        return true;
    }
    app.file_injection_force = true;
    for image in images {
        app.prompt_input.add_image(image);
    }
    app.set_prompt_text(input);
    app.pending_auto_submit = true;
    false
}

/// Remove only the synthetic message owned by an abandoned/revoked turn that
/// never reached a model transport. Attempted transcripts survive stale retry.
fn rollback_unattempted_turn(
    owner: Option<&InteractiveTurn>,
    force: bool,
    messages: &mut Vec<claurst_core::types::Message>,
    app: &mut claurst_tui::App,
    session: &mut claurst_core::history::ConversationSession,
    command_messages: &mut Vec<claurst_core::types::Message>,
) -> bool {
    let Some(owner) = owner else {
        return false;
    };
    let Some(uuid) = owner.synthetic_uuid.as_deref() else {
        return false;
    };
    let Some(turn) = owner.goal.captured() else {
        return false;
    };
    if turn.request_attempted() || (!force && !owner.abandoned && turn.validate().is_ok()) {
        return false;
    }
    let mut changed = false;
    let mut remove_owned = |copy: &mut Vec<claurst_core::types::Message>| {
        let before = copy.len();
        copy.retain(|message| message.uuid.as_deref() != Some(uuid));
        let removed = before - copy.len();
        changed |= removed > 0;
        removed
    };
    remove_owned(messages);
    let mut visible = std::mem::take(&mut app.messages);
    if remove_owned(&mut visible) > 0 {
        app.replace_messages(visible);
    } else {
        app.messages = visible;
    }
    remove_owned(&mut session.messages);
    for checkpoint in &mut session.checkpoints {
        let removed = remove_owned(&mut checkpoint.snapshot);
        checkpoint.message_idx = checkpoint.message_idx.saturating_sub(removed);
    }
    remove_owned(command_messages);
    changed
}

fn show_rate_limit_recovery(
    owner: Option<&InteractiveTurn>,
    app: &mut claurst_tui::App,
    message: Option<&str>,
    retry_after_secs: Option<u64>,
) {
    while app.notifications.current_is_error() {
        app.notifications.dismiss_current();
    }
    if !owner.is_some_and(|owner| owner.abandoned) {
        app.open_rate_limit_recovery(
            message.unwrap_or("Rate limit exceeded.").to_owned(),
            retry_after_secs,
        );
    }
}

/// Called each REPL frame before retry selection or idle work.
async fn settle_abandoned_turn(
    owner: &mut Option<InteractiveTurn>,
    query_running: bool,
    messages: &mut Vec<claurst_core::types::Message>,
    app: &mut claurst_tui::App,
    session: &mut claurst_core::history::ConversationSession,
    command_messages: &mut Vec<claurst_core::types::Message>,
) {
    if app.rate_limit_recovery.take_abandoned() {
        if let Some(owner) = owner {
            owner.abandoned = true;
        }
    }
    if owner.as_ref().is_some_and(|owner| owner.abandoned) {
        if rollback_unattempted_turn(
            owner.as_ref(),
            true,
            messages,
            app,
            session,
            command_messages,
        ) {
            persist_interactive_session(session, owner.as_ref()).await;
        }
        // Keep authority until the cancelled task has drained its partial output.
        if !query_running {
            *owner = None;
        }
    }
}

type MessagesArc = Arc<tokio::sync::Mutex<Vec<claurst_core::types::Message>>>;

/// How long quitting waits for a running turn to stop before saving what it
/// already holds. A cancelled turn normally stops well within this; the bound
/// is for a tool or approval that does not react to the token.
const TURN_EXIT_WAIT: std::time::Duration = std::time::Duration::from_secs(2);

/// Wait for a cancelled turn after the interactive loop has exited, and return
/// the conversation it left behind. The queue goes first: nothing drains it any
/// more, so the forwarder could otherwise wait on it and hold the worker open.
async fn stop_turn_for_exit(
    mut handle: tokio::task::JoinHandle<claurst_query::QueryOutcome>,
    messages: &MessagesArc,
    queue: tokio::sync::mpsc::Receiver<claurst_tui::application::ScopedQueryEvent>,
    wait: std::time::Duration,
) -> Vec<claurst_core::types::Message> {
    drop(queue);
    if tokio::time::timeout(wait, &mut handle).await.is_err() {
        handle.abort();
    }
    messages.lock().await.clone()
}

/// Tag one turn's events with its session generation and deliver them to the
/// bounded interactive queue in order. Waits for queue space rather than
/// dropping; ends when the turn's sender is dropped or the loop is gone.
async fn forward_scoped_events(
    mut turn_rx: tokio::sync::mpsc::UnboundedReceiver<claurst_query::QueryEvent>,
    events: tokio::sync::mpsc::Sender<claurst_tui::application::ScopedQueryEvent>,
    generation: claurst_tui::application::SessionGeneration,
) {
    while let Some(event) = turn_rx.recv().await {
        let scoped = claurst_tui::application::ScopedQueryEvent { generation, event };
        if events.send(scoped).await.is_err() {
            break;
        }
    }
}

struct InteractiveQuery {
    client: Arc<claurst_api::AnthropicClient>,
    tools: Arc<Vec<Box<dyn claurst_tools::Tool>>>,
    context: ToolContext,
    config: claurst_query::QueryConfig,
    tracker: Arc<CostTracker>,
    events: tokio::sync::mpsc::Sender<claurst_tui::application::ScopedQueryEvent>,
    /// Session generation this turn belongs to; every event it emits is
    /// tagged with it so a replaced conversation never receives them.
    generation: claurst_tui::application::SessionGeneration,
    cancel: tokio_util::sync::CancellationToken,
}

impl InteractiveQuery {
    fn spawn(self, messages: MessagesArc) -> tokio::task::JoinHandle<claurst_query::QueryOutcome> {
        tokio::spawn(async move {
            if self.cancel.is_cancelled() {
                return claurst_query::QueryOutcome::Cancelled;
            }
            if let Err(error) = self.context.goal_turn.validate(&self.context.session_id) {
                return claurst_query::QueryOutcome::Error(claurst_core::error::ClaudeError::Api(
                    format!("Goal authority revoked before dispatch: {error}"),
                ));
            }
            let mut msgs = messages.lock().await.clone();
            // The query loop owns `turn_tx` and drops it when it returns, which
            // ends the forwarder; joining both keeps the worker's lifetime
            // covering delivery of every event it produced.
            let (turn_tx, turn_rx) = tokio::sync::mpsc::unbounded_channel();
            let forward = forward_scoped_events(turn_rx, self.events, self.generation);
            let run = claurst_query::run_query_loop(
                self.client.as_ref(),
                &mut msgs,
                self.tools.as_slice(),
                &self.context,
                &self.config,
                self.tracker,
                Some(turn_tx),
                self.cancel,
                None,
            );
            let (outcome, ()) = tokio::join!(run, forward);
            *messages.lock().await = msgs;
            outcome
        })
    }
}

async fn persist_interactive_session(
    session: &claurst_core::history::ConversationSession,
    owner: Option<&InteractiveTurn>,
) {
    // A recoverable preparation/auth failure can finish without an attempt.
    // Delay indexing its synthetic UUID until attempted; a later stale retry
    // can then roll it back without leaving an immutable search-index entry.
    let pending_uuid = owner
        .filter(|owner| {
            owner
                .goal
                .captured()
                .is_some_and(|turn| !turn.request_attempted())
        })
        .and_then(|owner| owner.synthetic_uuid.as_deref());
    // JSON is primary storage; index only the finalized transcript.
    let _ = claurst_core::history::save_session(session).await;

    // Also index into SQLite for /search support
    {
        let db_path = claurst_core::config::Settings::config_dir().join("sessions.db");
        if let Ok(store) = claurst_core::SqliteSessionStore::open(&db_path) {
            let _ = store.save_session(&session.id, session.title.as_deref(), &session.model);
            for msg in &session.messages {
                if pending_uuid.is_some() && msg.uuid.as_deref() == pending_uuid {
                    continue;
                }
                let content_str = match &msg.content {
                    claurst_core::types::MessageContent::Text(t) => t.clone(),
                    claurst_core::types::MessageContent::Blocks(blocks) => blocks
                        .iter()
                        .filter_map(|b| {
                            if let claurst_core::types::ContentBlock::Text { text } = b {
                                Some(text.as_str())
                            } else {
                                None
                            }
                        })
                        .collect::<Vec<_>>()
                        .join(" "),
                };
                let role = match msg.role {
                    claurst_core::types::Role::User => "user",
                    claurst_core::types::Role::Assistant => "assistant",
                };
                let msg_id = msg.uuid.as_deref().unwrap_or("unknown");
                let _ = store.save_message(&session.id, msg_id, role, &content_str, None);
            }
        }
    }
}

fn select_idle_compaction(app: &claurst_tui::App, query_running: bool) -> Option<u64> {
    if !app.auto_compact_enabled
        || app.context_window_size == 0
        || app.is_streaming
        || query_running
        || app.auto_compact_running
        || app.rate_limit_recovery.is_pending()
        || app.file_injection_dialog.visible
        || app.file_injection_force
        || app.notifications.current_is_error()
    {
        return None;
    }
    let used_pct = (app.context_used_tokens as f64 / app.context_window_size as f64 * 100.0) as u64;
    (used_pct >= u64::from(app.auto_compact_threshold)).then_some(used_pct)
}

#[derive(Debug, Clone)]
struct GoalTurnBaseline {
    goal_id: String,
    session_id: String,
    store_path: PathBuf,
    tracker_total: u64,
    started_at: std::time::Instant,
}

#[derive(Debug, PartialEq, Eq)]
enum GoalTurnAccountingDecision {
    Skip,
    Record { total_tokens_used: u64 },
}

fn capture_goal_turn_baseline(
    tool_ctx: &mut ToolContext,
    tracker_total: u64,
) -> Result<Option<GoalTurnBaseline>, claurst_core::GoalError> {
    // Capture before dispatch: the query derives its prompt and completion
    // authority from this exact snapshot, never another mutable store read.
    tool_ctx.goal_turn.capture(&tool_ctx.session_id)?;
    Ok(tool_ctx.goal_turn.captured().map(|turn| GoalTurnBaseline {
        goal_id: turn.goal().id.clone(),
        session_id: turn.goal().session_id.clone(),
        store_path: turn.store_path().to_path_buf(),
        tracker_total,
        started_at: std::time::Instant::now(),
    }))
}

fn decide_goal_turn_accounting(
    baseline: Option<&GoalTurnBaseline>,
    current_goal: Option<&claurst_core::Goal>,
    tracker_total: u64,
) -> Result<GoalTurnAccountingDecision, String> {
    match (baseline, current_goal) {
        (None, None) => Ok(GoalTurnAccountingDecision::Skip),
        (None, Some(goal)) if goal.status != claurst_core::GoalStatus::Active => {
            Ok(GoalTurnAccountingDecision::Skip)
        }
        (None, Some(_)) => Err("missing active-goal turn baseline".to_string()),
        (Some(_), None) => {
            Err("goal changed during the turn: original goal is missing".to_string())
        }
        (Some(baseline), Some(goal)) if baseline.goal_id != goal.id => Err(format!(
            "goal changed during the turn: expected {}, found {}",
            baseline.goal_id, goal.id
        )),
        (Some(_), Some(goal)) if goal.status != claurst_core::GoalStatus::Active => {
            Ok(GoalTurnAccountingDecision::Skip)
        }
        (Some(baseline), Some(goal)) => {
            let turn_tokens = tracker_total
                .checked_sub(baseline.tracker_total)
                .ok_or_else(|| {
                    format!(
                        "goal token tracker moved backwards: start {}, end {}",
                        baseline.tracker_total, tracker_total
                    )
                })?;
            let total_tokens_used = goal.tokens_used.checked_add(turn_tokens).ok_or_else(|| {
                "goal token accounting overflow while adding completed turn".to_string()
            })?;
            Ok(GoalTurnAccountingDecision::Record { total_tokens_used })
        }
    }
}

fn refresh_command_discovery(app: &mut claurst_tui::App, config: &Config, cwd: &std::path::Path) {
    let plugin_commands = claurst_plugins::global_plugin_registry()
        .map(|registry| registry.all_command_defs())
        .unwrap_or_default();
    app.install_command_catalog(claurst_commands::composed_catalog(
        config,
        cwd,
        &plugin_commands,
    ));
}

/// How often an open Memory page re-reads the Coven daemon.
const MEMORY_REFRESH: std::time::Duration = std::time::Duration::from_secs(10);

/// Shortest gap between two daemon memory reads, even across closing and
/// reopening the page, so paging back and forth cannot pile up threads.
const MEMORY_MIN_SPAWN_GAP: std::time::Duration = std::time::Duration::from_secs(2);

/// The Memory page's daemon read in flight, if any, when the last one
/// finished, and when the last one started (kept across closing the page).
#[derive(Default)]
struct MemoryPoll {
    in_flight: Option<std::sync::mpsc::Receiver<claurst_tui::application::memory::MemorySnapshot>>,
    last_read: Option<std::time::Instant>,
    last_spawn: Option<std::time::Instant>,
}

/// Keep `app.memory_snapshot` for the Next Memory page (#415).
///
/// While the page is open the daemon is read off the UI thread, at most
/// every [`MEMORY_REFRESH`]. When the page is closed the snapshot and any
/// read in flight are dropped: private reads are not kept, and a late answer
/// is discarded rather than shown later.
fn refresh_memory_snapshot(
    app: &mut claurst_tui::app::App,
    page_open: bool,
    poll: &mut MemoryPoll,
    spawn_read: impl FnOnce() -> std::sync::mpsc::Receiver<
        claurst_tui::application::memory::MemorySnapshot,
    >,
) {
    use claurst_tui::application::memory::MemorySnapshot;
    use std::sync::mpsc::TryRecvError;

    if !page_open {
        app.memory_snapshot = MemorySnapshot::NotRead;
        // Dropping the receiver discards a late answer; the spawn time is
        // kept so a quick reopen does not start another read at once.
        poll.in_flight = None;
        poll.last_read = None;
        return;
    }
    if let Some(receiver) = &poll.in_flight {
        let finished = match receiver.try_recv() {
            Ok(snapshot) => Some(snapshot),
            Err(TryRecvError::Empty) => None,
            Err(TryRecvError::Disconnected) => Some(MemorySnapshot::Failed(
                "the memory read stopped without an answer".to_string(),
            )),
        };
        if let Some(snapshot) = finished {
            app.memory_snapshot = snapshot;
            poll.in_flight = None;
            poll.last_read = Some(std::time::Instant::now());
        }
        return;
    }
    let due = poll
        .last_read
        .is_none_or(|at| at.elapsed() >= MEMORY_REFRESH)
        && poll
            .last_spawn
            .is_none_or(|at| at.elapsed() >= MEMORY_MIN_SPAWN_GAP);
    if due {
        poll.in_flight = Some(spawn_read());
        poll.last_spawn = Some(std::time::Instant::now());
    }
}

/// Start one blocking daemon memory read on its own thread.
fn spawn_memory_read() -> std::sync::mpsc::Receiver<claurst_tui::application::memory::MemorySnapshot>
{
    let (sender, receiver) = std::sync::mpsc::channel();
    // Resolve the socket on this thread (it reads env vars); only the
    // blocking reads run on the worker.
    let client = claurst_core::coven_daemon::DaemonClient::new();
    std::thread::spawn(move || {
        let _ = sender.send(claurst_tui::application::memory::read_memory(client));
    });
    receiver
}

/// How often an open Work page re-reads the session goal from SQLite.
const WORK_GOAL_REFRESH: std::time::Duration = std::time::Duration::from_secs(2);

/// Copy the engine-local work stores into `app.work_sources` for display.
///
/// The background registry and the model task list are in memory and are
/// copied every call; each background task keeps only its last output line,
/// which is all the Work page shows. The session goal is read from SQLite at
/// most every [`WORK_GOAL_REFRESH`], so a goal changed within the session can
/// show its previous state for up to that long. It is re-read at once when
/// the session changes, so a goal from another session is never shown. A
/// failed read keeps this session's last good goal (a locked store is
/// expected while another process writes) and reports the error only when
/// there is nothing to keep.
fn refresh_work_sources(
    app: &mut claurst_tui::app::App,
    session_id: &str,
    last_goal_read: &mut Option<(std::time::Instant, String)>,
    mut read_goal: impl FnMut(&str) -> Option<Result<claurst_core::goal::Goal, String>>,
) {
    app.work_sources.background = claurst_core::tasks::global_registry()
        .list()
        .into_iter()
        .map(|mut task| {
            let keep_from = task.output.len().saturating_sub(1);
            task.output.drain(..keep_from);
            task
        })
        .collect();
    app.work_sources.model_tasks = claurst_tools::TASK_STORE
        .iter()
        .map(|entry| entry.value().clone())
        .collect();
    let (due, same_session) = match last_goal_read {
        Some((at, id)) => (
            id != session_id || at.elapsed() >= WORK_GOAL_REFRESH,
            id == session_id,
        ),
        None => (true, false),
    };
    if due {
        let read = read_goal(session_id);
        let keep_previous = same_session
            && matches!(read, Some(Err(_)))
            && matches!(app.work_sources.goal, Some(Ok(_)));
        if !keep_previous {
            app.work_sources.goal = read;
        }
        *last_goal_read = Some((std::time::Instant::now(), session_id.to_string()));
    }
}

/// The current session's goal for display, `None` when goals are disabled
/// or the session has none.
fn read_session_goal(session_id: &str) -> Option<Result<claurst_core::goal::Goal, String>> {
    if !claurst_core::goals_enabled() {
        return None;
    }
    let path = claurst_core::GoalStore::default_path();
    match claurst_core::GoalStore::open_read_only_nowait(&path) {
        Ok(None) => None,
        Ok(Some(store)) => match store.try_get_goal(session_id) {
            Ok(goal) => goal.map(Ok),
            Err(error) => Some(Err(error.to_string())),
        },
        Err(error) => Some(Err(error.to_string())),
    }
}

/// Hand the terminal back to the shell and stop until the shell resumes us.
///
/// SIGTSTP rather than SIGSTOP: the OS discards it when no job-control shell
/// could resume this job, so it can never leave a session stopped for good.
/// It goes to the process group, so tools in this group stop too. The default
/// Bash tool leads its own session and keeps running, and time spent stopped
/// counts toward tool timeouts.
#[cfg(unix)]
fn suspend_job(
    terminal: &mut claurst_tui::AppTerminal,
    app: &mut claurst_tui::App,
    renderer: claurst_tui::application::UiRenderer,
) -> anyhow::Result<()> {
    // A real stop lasts at least as long as someone typing `fg`.
    const SHORTEST_STOP: std::time::Duration = std::time::Duration::from_millis(50);

    let mut stopped_for = std::time::Duration::ZERO;
    let handed_back = claurst_tui::suspend_terminal(terminal, renderer, || {
        let started = std::time::Instant::now();
        if let Err(error) = nix::sys::signal::kill(
            nix::unistd::Pid::from_raw(0),
            nix::sys::signal::Signal::SIGTSTP,
        ) {
            tracing::warn!(%error, "could not stop the job");
        }
        stopped_for = started.elapsed();
    })?;
    if !handed_back {
        app.push_notification(
            claurst_tui::notifications::NotificationKind::Warning,
            "Could not give the terminal back to the shell, so Coven Code did not stop."
                .to_string(),
            Some(5),
        );
    } else if stopped_for < SHORTEST_STOP {
        app.push_notification(
            claurst_tui::notifications::NotificationKind::Info,
            "Nothing to return to: no job-control shell started this session.".to_string(),
            Some(5),
        );
    }
    Ok(())
}

#[cfg(not(unix))]
fn suspend_job(
    _terminal: &mut claurst_tui::AppTerminal,
    app: &mut claurst_tui::App,
    _renderer: claurst_tui::application::UiRenderer,
) -> anyhow::Result<()> {
    app.push_notification(
        claurst_tui::notifications::NotificationKind::Info,
        "Suspend is not available on this platform.".to_string(),
        Some(3),
    );
    Ok(())
}

// Allowed: this is the main interactive-mode bootstrap. Its inputs are all
// distinct, separately-constructed services (config, settings, HTTP client,
// tool registry, tool execution context, query loop knobs, etc.) and
// bundling them behind a struct would force every test and CLI mode to
// construct that struct just to call this function. The count is a feature
// of how the TUI is wired together, not a code-smell.
#[allow(clippy::too_many_arguments)]
async fn run_interactive(
    config: Config,
    settings: claurst_core::config::Settings,
    client: Arc<claurst_api::AnthropicClient>,
    tools: Arc<Vec<Box<dyn claurst_tools::Tool>>>,
    tool_ctx: ToolContext,
    query_config: claurst_query::QueryConfig,
    cost_tracker: Arc<CostTracker>,
    resume_id: Option<String>,
    bridge_config: Option<claurst_bridge::BridgeConfig>,
    has_credentials: bool,
    model_registry: Arc<claurst_api::ModelRegistry>,
    user_question_rx: Option<
        tokio::sync::mpsc::UnboundedReceiver<claurst_tools::UserQuestionEvent>,
    >,
    diagnostic_log: Option<diagnostics::DiagnosticLog>,
) -> anyhow::Result<()> {
    use claurst_bridge::{BridgeOutbound, TuiBridgeEvent};
    use claurst_commands::{execute_command, CommandContext, CommandResult};
    use claurst_query::{QueryEvent, QueryOutcome};
    use claurst_tui::{
        bridge_state::BridgeConnectionState, device_auth_dialog::DeviceAuthEvent,
        notifications::NotificationKind, render::render_app, restore_terminal, setup_terminal, App,
    };
    use crossterm::event::{self, Event, KeyCode};
    use std::time::Duration;
    use tokio::sync::mpsc;
    use tokio_util::sync::CancellationToken;

    let mut client = client;
    let mut model_registry = model_registry;
    let mut tool_ctx = tool_ctx;
    let mut config = config;
    let mut resume_warning: Option<String> = None;
    let resume_id = if resume_id.as_deref() == Some("__last__") {
        let sessions = claurst_core::history::list_sessions().await;
        match sessions.first() {
            Some(last) => {
                println!("Resuming most recent session: {}", last.id);
                Some(last.id.clone())
            }
            None => {
                resume_warning = Some("No previous sessions found, starting new session.".into());
                None
            }
        }
    } else {
        resume_id
    };

    let mut session = if let Some(ref id) = resume_id {
        match claurst_core::history::load_session(id).await {
            Ok(session) => {
                println!("Resumed session: {}", id);
                if let Some(saved_dir) = session.working_dir.as_ref() {
                    let saved_path = std::path::PathBuf::from(saved_dir);
                    if saved_path.exists() {
                        tool_ctx.working_dir = saved_path;
                        refresh_mcp_project_config(&mut config, &tool_ctx.working_dir).await?;
                    }
                }
                tool_ctx.session_id = session.id.clone();
                session
            }
            Err(e) => {
                resume_warning = Some(format!(
                    "Could not load session {}: {}. Starting new session.",
                    id, e
                ));
                let mut session = claurst_core::history::ConversationSession::new(
                    claurst_api::effective_model_for_config(&config, &model_registry),
                );
                session.id = tool_ctx.session_id.clone();
                session.working_dir = Some(tool_ctx.working_dir.display().to_string());
                session
            }
        }
    } else {
        let mut session = claurst_core::history::ConversationSession::new(
            claurst_api::effective_model_for_config(&config, &model_registry),
        );
        session.id = tool_ctx.session_id.clone();
        session.working_dir = Some(tool_ctx.working_dir.display().to_string());
        session
    };
    if config.hosted_review_enabled() {
        session.hosted_review = true;
    }
    let initial_messages = session.messages.clone();
    let mut base_query_config = query_config;
    let mut live_config = config.clone();
    if !session.model.is_empty() {
        live_config.model = Some(session.model.clone());
    }
    tool_ctx.config = live_config.clone();
    let pending_permissions = tool_ctx.pending_permissions.clone().unwrap_or_else(|| {
        Arc::new(ParkingMutex::new(
            claurst_tools::PendingPermissionStore::default(),
        ))
    });

    // Renderer selection is interactive-only: report an unsupported value
    // before the terminal takes over stderr.
    let renderer_selection = claurst_tui::application::select_renderer(
        std::env::var(claurst_tui::application::UI_SELECTOR_ENV)
            .ok()
            .as_deref(),
    );
    if let Some(warning) = &renderer_selection.warning {
        eprintln!("warning: {warning}");
    }
    let renderer = renderer_selection.renderer;
    // Next ties an approval to the file as it stood when asked. Classic keeps its
    // existing approvals.
    let mut tool_ctx = tool_ctx;
    if renderer == claurst_tui::application::UiRenderer::Next {
        tool_ctx.permission_handler =
            Arc::new(claurst_core::permissions::ContentBoundApprovals::new(
                tool_ctx.permission_handler.clone(),
            ));
    }

    // Set up terminal
    let mut terminal = setup_terminal(renderer)?;
    let mut app = App::new(live_config.clone(), cost_tracker.clone());
    app.config.project_dir = Some(tool_ctx.working_dir.clone());
    // The stderr warning is covered by the alternate screen; repeat it where
    // the user can read it.
    if let Some(warning) = renderer_selection.warning {
        app.notifications
            .push(claurst_tui::NotificationKind::Warning, warning, Some(15));
    }
    refresh_command_discovery(&mut app, &live_config, &tool_ctx.working_dir);
    if let Some(warning) = resume_warning {
        app.status_message = Some(warning);
    }
    // Sync initial effort level (from --effort flag or /effort command) to TUI indicator.
    if let Some(level) = base_query_config.effort_level {
        use claurst_tui::EffortLevel as TuiEL;
        app.effort_level = match level {
            claurst_core::effort::EffortLevel::Low => TuiEL::Low,
            claurst_core::effort::EffortLevel::Medium => TuiEL::Normal,
            claurst_core::effort::EffortLevel::High => TuiEL::High,
            claurst_core::effort::EffortLevel::Max => TuiEL::Max,
        };
        // An effort supplied at launch (`--effort`) is an explicit choice, so
        // make `app.effort_level` authoritative for every turn from the start.
        app.effort_is_set = true;
    }
    app.provider_registry = base_query_config.provider_registry.clone();
    app.refresh_context_window_size();
    app.auto_compact_enabled = live_config.auto_compact;
    let compact_threshold = live_config.effective_compact_threshold();
    let compact_threshold_pct = if compact_threshold <= 1.0 {
        compact_threshold * 100.0
    } else {
        compact_threshold
    };
    app.auto_compact_threshold = compact_threshold_pct.clamp(0.0, 100.0).ceil() as u8;
    app.completion_toast_enabled = settings.completion_toast_enabled();
    app.bell_on_complete = settings.bell_on_complete;
    // Classic drops the Next-only defaults, so upgrading an older file must
    // keep a binding in every context when only they use its chord.
    let user_keybindings = claurst_core::keybindings::UserKeybindings::load_with_renderer_only(
        &Settings::config_dir(),
        claurst_tui::next::NEXT_ONLY_ACTIONS,
    );
    app.select_renderer(renderer);
    app.next_presentation =
        claurst_tui::next::NextPresentation::from_settings(&settings, &user_keybindings, |name| {
            std::env::var(name).ok()
        });
    // Next shows the chord that works now; say once which bindings changed.
    if renderer == claurst_tui::application::UiRenderer::Next {
        for notice in claurst_tui::next::key_conflict_notices(&user_keybindings) {
            app.notifications
                .push(claurst_tui::NotificationKind::Info, notice, Some(10));
        }
    }

    // Register this session in the Coven daemon ledger (best-effort, opt-in).
    // The id is captured here so that a mid-run /resume (which rebinds session.id)
    // does not leave this registration uncompleted — the exit hook uses this local
    // rather than session.id, which may have changed to a different session by then.
    let (ledger_tx, mut ledger_rx) = tokio::sync::oneshot::channel::<bool>();
    let ledger_session_id: Option<String> = if settings.daemon_ledger {
        let id = session.id.clone();
        let root = tool_ctx.working_dir.clone();
        let title = session.title.clone().unwrap_or_default();
        let id_for_task = id.clone();
        tokio::task::spawn_blocking(move || {
            let accepted =
                claurst_core::coven_ledger::notify_session_start(&id_for_task, &root, &title)
                    .is_ok();
            let _ = ledger_tx.send(accepted);
        });
        Some(id)
    } else {
        drop(ledger_tx);
        None
    };

    // Background: refresh the model registry from models.dev.
    // The fetched JSON is saved as a cache file; the App will reload it from
    // disk whenever the /model picker opens.
    {
        spawn_models_cache_refresh();
    }

    // Wire the ask-user question channel into the app so the TUI can show
    // the dialog and return an answer to the query loop.
    if let Some(rx) = user_question_rx {
        app.user_question_rx = Some(rx);
    }

    app.config.project_dir = Some(tool_ctx.working_dir.clone());
    app.attach_turn_diff_state(tool_ctx.file_history.clone(), tool_ctx.current_turn.clone());
    if let Some(manager) = tool_ctx.mcp_manager.clone() {
        app.attach_mcp_manager(manager);
    }
    app.replace_messages(initial_messages.clone());
    app.enter_session_scope(&session.id);
    if app.renderer == claurst_tui::application::UiRenderer::Next {
        app.session_title = session.title.clone();
    }
    app.ownership = match &ledger_session_id {
        Some(id) => claurst_tui::application::SessionOwnership::LedgerPending {
            session_id: id.clone(),
        },
        None => claurst_tui::application::SessionOwnership::EngineLocal,
    };
    if let Some(log) = &diagnostic_log {
        app.push_system_message(
            format!("Diagnostics: {}", log.path().display()),
            claurst_tui::app::SystemMessageStyle::Info,
        );
    }

    // Home directory warning: mirror TS feedConfigs.tsx warningText
    let home_dir = dirs::home_dir();
    if home_dir.as_deref() == Some(tool_ctx.working_dir.as_path()) {
        app.home_dir_warning = true;
    }

    // Bypass permissions confirmation dialog: must be accepted before any work
    // Mark whether valid credentials exist so the TUI can show a provider
    // setup dialog instead of failing silently on the first message.
    app.has_credentials = has_credentials;

    // If a non-Anthropic provider is active, prefix model_name with "provider/model"
    // so the status bar can show the provider name.
    if let Some(ref provider) = live_config.provider {
        if provider != "anthropic" && !app.model_name.contains('/') {
            app.model_name = format!("{}/{}", provider, app.model_name);
        }
    }

    // Set agent mode from the --agent flag (carried on query_config).
    if let Some(ref agent_name) = base_query_config.agent_name {
        app.agent_mode = Some(agent_name.clone());
        if app.config.familiar.as_ref().map(|id| id.to_lowercase())
            != Some(agent_name.to_lowercase())
        {
            app.config.familiar = None;
        }
    }

    // Mirror TS BypassPermissionsModeDialog.tsx startup gate
    // Shown as the highest-priority startup dialog (blocks all other UI).
    // Only show once per session — subsequent sessions in the same directory
    // will show the dialog again (not persisted across sessions).
    use claurst_core::config::PermissionMode;
    if live_config.permission_mode == PermissionMode::BypassPermissions
        && !app.bypass_permissions_dialog_shown
    {
        app.bypass_permissions_dialog.show();
        app.bypass_permissions_dialog_shown = true;
    } else if live_config.permission_mode != PermissionMode::BypassPermissions {
        // Show onboarding only if NOT in bypass-permissions mode.
        // Bypass dialog is a mandatory security gate and takes absolute priority.
        if !has_credentials {
            if !settings.has_completed_onboarding {
                // No credentials: lead with the provider-setup page (Free
                // Mode + provider list), then continue into the regular
                // welcome / keybindings pages.
                app.onboarding_dialog.show_provider_setup();
            } else {
                app.status_message =
                    Some("No provider configured. Run /account connect to set one up.".to_string());
            }
        } else if !settings.has_completed_onboarding {
            // User has credentials but hasn't formally completed onboarding — mark it done
            // silently so they never see it.
            let _ = claurst_tui::App::persist_onboarding_complete_pub();
        }
    }

    // Version-upgrade notice: record the current version for future comparisons.
    // (Actual upgrade notice UI is handled by the release-notes slash command.)
    {
        let current_version = claurst_core::constants::APP_VERSION.to_string();
        if settings.last_seen_version.as_deref() != Some(&current_version) {
            // Persist asynchronously to avoid blocking startup.
            let version_clone = current_version.clone();
            tokio::spawn(async move {
                if let Ok(mut s) = claurst_core::config::Settings::load().await {
                    s.last_seen_version = Some(version_clone);
                    let _ = s.save().await;
                }
            });
        }
    }

    // CLAUDE_STATUS_COMMAND: optional external command whose stdout replaces the
    // left-side status bar text. Polled every 500ms (debounced) in the main loop.
    // The command is run in a background task; results flow through a channel.
    let status_cmd_str = std::env::var("CLAUDE_STATUS_COMMAND").ok();
    let (status_cmd_tx, mut status_cmd_rx) = mpsc::channel::<String>(4);
    if let Some(ref cmd_str) = status_cmd_str {
        let cmd_str = cmd_str.clone();
        let tx = status_cmd_tx.clone();
        tokio::spawn(async move {
            loop {
                tokio::time::sleep(Duration::from_millis(500)).await;
                // Run via shell so pipes/redirects in the command string work.
                let output = if cfg!(target_os = "windows") {
                    tokio::process::Command::new("cmd")
                        .args(["/C", &cmd_str])
                        .output()
                        .await
                } else {
                    tokio::process::Command::new("sh")
                        .args(["-c", &cmd_str])
                        .output()
                        .await
                };
                if let Ok(out) = output {
                    let text = String::from_utf8_lossy(&out.stdout).trim().to_string();
                    let _ = tx.try_send(text);
                }
            }
        });
    }

    // Bridge runtime channels — Some when bridge is configured and started.
    //
    // tui_rx:       TUI-facing events from the bridge worker (connect/disconnect/prompts)
    // outbound_tx:  Forward query events to the bridge worker for upload to server
    // bridge_cancel: CancellationToken to stop the bridge worker task
    struct BridgeRuntime {
        tui_rx: mpsc::Receiver<TuiBridgeEvent>,
        outbound_tx: mpsc::Sender<BridgeOutbound>,
        cancel: CancellationToken,
        supplementary_tasks: tokio::task::JoinSet<()>,
        primary_task: tokio::task::JoinHandle<()>,
    }

    impl Drop for BridgeRuntime {
        fn drop(&mut self) {
            self.cancel.cancel();
            // JoinSet also aborts supplementary tasks on early/error exits.
        }
    }

    // Preserve the bridge token before consuming bridge_config so we can reconstruct
    // a BridgeSessionInfo once the bridge worker reports it has connected.
    let bridge_token: Option<String> = bridge_config.as_ref().and_then(|c| c.session_token.clone());

    let mut bridge_runtime: Option<BridgeRuntime> = if let Some(cfg) = bridge_config {
        let bridge_cancel = CancellationToken::new();
        let (tui_tx, tui_rx) = mpsc::channel::<TuiBridgeEvent>(64);
        let (outbound_tx, outbound_rx) = mpsc::channel::<BridgeOutbound>(256);

        // Update TUI state to "connecting" before the task starts.
        app.bridge_state = BridgeConnectionState::Connecting;

        let cancel_clone = bridge_cancel.clone();
        let primary_task = tokio::spawn(async move {
            if let Err(e) =
                claurst_bridge::run_bridge_loop(cfg, tui_tx, outbound_rx, cancel_clone).await
            {
                warn!("Bridge loop exited with error: {}", e);
            }
        });

        Some(BridgeRuntime {
            tui_rx,
            outbound_tx,
            cancel: bridge_cancel,
            supplementary_tasks: tokio::task::JoinSet::new(),
            primary_task,
        })
    } else {
        None
    };

    // Relay channels for the BridgeSessionInfo-based event path.
    //
    // relay_ev_tx:    receives serialised JSON event payloads from the query-event
    //                 drain loop; a background task consumes them and calls
    //                 post_bridge_event so the web UI sees live streaming events.
    // relay_ev_rx_opt: Option wrapper so we can move the Receiver into the relay
    //                 task exactly once when the bridge session comes online.
    // remote_prompt_tx/rx: inbound user messages polled from poll_bridge_messages
    //                 are delivered here; the main loop injects them as query turns.
    let (relay_ev_tx, relay_ev_rx) = mpsc::channel::<String>(256);
    let mut relay_ev_rx_opt: Option<mpsc::Receiver<String>> = Some(relay_ev_rx);
    let (remote_prompt_tx, mut remote_prompt_rx) = mpsc::channel::<String>(32);
    // Primary prompts must not block the shared control/permission event stream.
    // Retain them until idle; this queue can grow while a remote producer outpaces
    // completed turns. Supplementary polling retains its bounded channel while busy.
    let mut pending_remote_prompts = std::collections::VecDeque::new();

    // Once the bridge worker reports Connected we build this from the session
    // credentials so both relay tasks can POST/poll the /api/bridge/sessions API.
    let mut bridge_session_info: Option<std::sync::Arc<claurst_bridge::BridgeSessionInfo>> = None;

    let mut messages = initial_messages;
    let mut cmd_ctx = CommandContext {
        config: live_config,
        cost_tracker: cost_tracker.clone(),
        messages: messages.clone(),
        working_dir: tool_ctx.working_dir.clone(),
        session_id: session.id.clone(),
        session_title: session.title.clone(),
        remote_session_url: session.remote_session_url.clone(),
        mcp_manager: tool_ctx.mcp_manager.clone(),
        mcp_auth_runner: None,
    };

    // tools is already Arc<Vec<...>> — share it across spawned tasks without copying.
    // Keep the full unfiltered tool set so agent-mode switching can re-filter.
    let all_tools_arc: Arc<Vec<Box<dyn claurst_tools::Tool>>> =
        Arc::new(claurst_tools::all_tools());
    let mut tools_arc = tools;

    // Current cancel token (replaced each turn)
    let mut cancel: Option<CancellationToken> = None;
    let (event_tx, mut event_rx) = mpsc::channel::<claurst_tui::application::ScopedQueryEvent>(
        claurst_tui::application::QUERY_EVENT_QUEUE_CAPACITY,
    );
    let mut session_scope = claurst_tui::application::SessionScope::default();
    // Background bash tasks with notify_on_complete send their terminal-state
    // info here, where the main loop fans-out to a TUI toast + optional bell.
    let (bg_completion_tx, mut bg_completion_rx) =
        mpsc::unbounded_channel::<claurst_tools::BgTaskCompletion>();
    let mut current_query: Option<(tokio::task::JoinHandle<QueryOutcome>, MessagesArc)> = None;
    // Active effort level (None = use model default / High).
    // Tracks the user's /effort selection; flows into qcfg each turn.
    let mut current_effort: Option<claurst_core::effort::EffortLevel> = None;
    // Start time and session-wide tracker baseline for the most recent real
    // query turn. Goal accounting converts the tracker delta into a durable,
    // goal-absolute token total only after a successful EndTurn.
    let mut goal_turn: Option<InteractiveTurn> = None;

    // Background update check: spawned once at startup; result delivered via channel.
    let (update_tx, mut update_rx) = tokio::sync::mpsc::channel::<Option<String>>(1);
    tokio::spawn(async move {
        let info = claurst_core::check_for_updates().await;
        let version = info.map(|i| i.latest_version);
        let _ = update_tx.send(version).await;
    });

    // Device code / OAuth auth channel — background tasks send events here
    // so the main loop can update the device_auth_dialog state.
    let (device_auth_tx, mut device_auth_rx) = mpsc::channel::<DeviceAuthEvent>(8);

    // MCP OAuth auth channel — background tasks send events here so the main
    // loop can update status and trigger a reconnect after browser auth finishes.
    enum McpAuthEvent {
        /// Browser auth completed and the token was persisted successfully.
        Completed(claurst_mcp::oauth::McpAuthResult),
        /// Browser auth or token exchange failed.
        Failed(String),
    }
    let (mcp_auth_tx, mut mcp_auth_rx) = mpsc::channel::<McpAuthEvent>(8);
    // Build a non-blocking runner so `/mcp auth` can return immediately while
    // the browser flow continues in the background.
    let mcp_auth_runner: Arc<dyn Fn(claurst_mcp::oauth::McpAuthSession) + Send + Sync> = {
        let tx = mcp_auth_tx.clone();
        Arc::new(move |session| {
            let tx = tx.clone();
            tokio::spawn(async move {
                let event = match claurst_mcp::oauth::run_mcp_auth_session(session).await {
                    Ok(result) => McpAuthEvent::Completed(result),
                    Err(err) => McpAuthEvent::Failed(err.to_string()),
                };
                let _ = tx.send(event).await;
            });
        })
    };
    cmd_ctx.mcp_auth_runner = Some(mcp_auth_runner.clone());
    let mut work_goal_read: Option<(std::time::Instant, String)> = None;
    let mut memory_poll = MemoryPoll::default();
    'main: loop {
        if let Some(log) = &diagnostic_log {
            if let Some(error) = log.take_error() {
                app.push_system_message(
                    format!(
                        "Diagnostic logging stopped: {error}. File: {}",
                        log.path().display()
                    ),
                    claurst_tui::app::SystemMessageStyle::Warning,
                );
            }
        }
        app.frame_count = app.frame_count.wrapping_add(1);
        app.tick_companion_pose();
        // The session browser's list loads in the background (Next only;
        // Classic's browser is unchanged).
        if app.renderer == claurst_tui::application::UiRenderer::Next {
            app.poll_session_list();
        }
        app.notifications.tick();

        if handle_file_preparation(&mut app, &mut goal_turn) {
            continue;
        }

        // Snapshot the engine-local work stores while the Next Work page is
        // open, so the frame below never shows an older session's goal.
        if app.next_shell.inspector == Some(claurst_tui::next::InspectorPage::Work) {
            refresh_work_sources(
                &mut app,
                &tool_ctx.session_id,
                &mut work_goal_read,
                read_session_goal,
            );
        }

        // Read familiar memory only while the Next Memory page is open; drop
        // it as soon as the page closes. Classic never reads it.
        let memory_page_open = renderer == claurst_tui::application::UiRenderer::Next
            && app.next_shell.inspector == Some(claurst_tui::next::InspectorPage::Memory);
        refresh_memory_snapshot(
            &mut app,
            memory_page_open,
            &mut memory_poll,
            spawn_memory_read,
        );

        if app.next_shell.take_suspend_request() {
            suspend_job(&mut terminal, &mut app, renderer)?;
        }

        // Draw the UI
        terminal.draw(|f| match renderer {
            claurst_tui::application::UiRenderer::Classic => render_app(f, &app),
            claurst_tui::application::UiRenderer::Next => claurst_tui::next::render_next(f, &app),
        })?;
        app.settle_scroll_anchor();

        // Poll for crossterm events (keyboard/mouse) with short timeout
        // unless an auto-submit (queued message) is pending — in which case
        // synthesize an Enter event to dequeue and submit it.
        if let claurst_tui::application::SessionOwnership::LedgerPending { session_id } =
            &app.ownership
        {
            let outcome = match ledger_rx.try_recv() {
                Ok(accepted) => Some(accepted),
                // The registration task ended without answering.
                Err(tokio::sync::oneshot::error::TryRecvError::Closed) => Some(false),
                Err(tokio::sync::oneshot::error::TryRecvError::Empty) => None,
            };
            if let Some(accepted) = outcome {
                let session_id = session_id.clone();
                app.ownership = if accepted {
                    claurst_tui::application::SessionOwnership::LedgerRegistered { session_id }
                } else {
                    claurst_tui::application::SessionOwnership::LedgerFailed { session_id }
                };
            }
        }
        // A session chosen in the browser resumes through `/session resume`, exactly
        // as if typed, once no turn is running. If that did not switch
        // sessions, the current one gets its draft back.
        if !app.pending_auto_submit {
            app.settle_pending_resume();
        }
        if current_query.is_none() && !app.is_streaming && !app.pending_auto_submit {
            if let Some(id) = app.take_pending_resume() {
                app.set_prompt_text(format!("/session resume {id}"));
                app.pending_auto_submit = true;
            }
        }
        let synthetic_event: Option<Event> = if app.pending_auto_submit && !app.is_streaming {
            app.pending_auto_submit = false;
            Some(Event::Key(crossterm::event::KeyEvent::new(
                KeyCode::Enter,
                crossterm::event::KeyModifiers::NONE,
            )))
        } else {
            None
        };

        let evt_opt: Option<Event> = if let Some(e) = synthetic_event {
            Some(e)
        } else if let Some(k) = app.take_pending_key() {
            // Replay a key that try_detect_paste_burst saved when a non-character
            // key terminated a paste burst on the previous iteration.
            Some(Event::Key(k))
        } else if crossterm::event::poll(Duration::from_millis(16))? {
            Some(event::read()?)
        } else {
            None
        };

        if let Some(evt) = evt_opt {
            match evt {
                Event::Key(key) => {
                    // On Windows crossterm emits Press + Release for a single key.
                    // Only process Press to avoid double-registering input.
                    if key.kind != crossterm::event::KeyEventKind::Press {
                        continue;
                    }

                    // ---- Paste-burst detection ----------------------------------------
                    // When bracketed paste is unavailable (Windows Terminal Ctrl+V, or
                    // any terminal that doesn't deliver Event::Paste), the clipboard
                    // content arrives as raw character events — every `\n` fires as
                    // Enter and submits the prompt, so a multi-line paste lands as
                    // several separate messages. Coalesce a rapid char burst into one
                    // paste. Mirrors the fallback in claurst_tui::app's TUI loop.
                    if matches!(
                        key.modifiers,
                        crossterm::event::KeyModifiers::NONE | crossterm::event::KeyModifiers::SHIFT
                    ) {
                        if let KeyCode::Char(c) = key.code {
                            if app.prompt_is_accepting_text() {
                                if let Some(burst) = app.try_detect_paste_burst(c) {
                                    app.handle_paste_data(burst);
                                    app.refresh_prompt_input();
                                    continue;
                                }
                            }
                        }
                    }
                    // -------------------------------------------------------------------

                    // Configured interrupt and exit actions
                    if handle_exit_key(&mut app, key, &cancel, &mut goal_turn) {
                        if app.should_exit {
                            break 'main;
                        }
                        continue;
                    }

                    // Enter => submit input (but NOT when a dialog/overlay that
                    // captures input is open — those handle their own Enter in
                    // handle_key_event). Gate on the *blocking* predicate:
                    // `any_modal_open` also counts passive banners that render
                    // as overlays but never take a keystroke, and those would
                    // silently eat Enter and strand the conversation.
                    let any_dialog_open = app.any_blocking_modal_open();
                    if key.code == KeyCode::Enter && app.is_streaming && !any_dialog_open {
                        // Queue the message: it will auto-submit once the
                        // current turn finishes (issue #149).
                        let input = app.take_input();
                        if !input.is_empty() {
                            let preview: String = input.chars().take(40).collect();
                            app.queued_messages.push_back(input);
                            let total = app.queued_messages.len();
                            app.notifications.push(
                                claurst_tui::NotificationKind::Info,
                                format!("Queued ({}): {}", total, preview),
                                Some(3),
                            );
                        }
                        continue;
                    }
                    if key.code == KeyCode::Enter && !app.is_streaming && !any_dialog_open {
                        // A plain Enter on an empty prompt opens the latest completed
                        // response reader. Route it through App before take_input(),
                        // which would otherwise consume the key as a no-op.
                        if app.prompt_input.text.is_empty()
                            && app.prompt_input.suggestion_index.is_none()
                        {
                            app.handle_key_event(key);
                            continue;
                        }
                        // If a file-ref suggestion is active, accept it instead of submitting.
                        if !app.prompt_input.suggestions.is_empty()
                            && app.prompt_input.suggestion_index.is_some()
                            && app
                                .prompt_input
                                .suggestions
                                .get(app.prompt_input.suggestion_index.unwrap())
                                .map(|s| {
                                    s.source == claurst_tui::prompt_input::TypeaheadSource::FileRef
                                })
                                .unwrap_or(false)
                        {
                            app.prompt_input.accept_suggestion();
                            app.prompt_input.insert_char(' ');
                            app.refresh_prompt_input();
                            continue;
                        }
                        // Retired input must reach the lifecycle gate before completion
                        // can replace it with a suggested canonical command.
                        if app.prompt_input.text.starts_with('/') {
                            let (name, args) = claurst_tui::input::parse_slash_command(&app.prompt_input.text);
                            if let Err(error) = claurst_commands::preflight_interactive_slash_command(name, args, &mut cmd_ctx) {
                                app.take_input();
                                app.status_message = Some(error);
                                continue;
                            }
                        }

                        // If a slash-command suggestion is active, accept and execute immediately.
                        if !app.prompt_input.suggestions.is_empty()
                            && app.prompt_input.suggestion_index.is_some()
                            && app.prompt_input.text.starts_with('/')
                        {
                            app.prompt_input.accept_suggestion();
                            // Fall through to submit — no second Enter needed
                        }

                        let mut input = app.take_input();
                        if current_query.is_some() {
                            if !input.is_empty() { app.queued_messages.push_back(input); }
                            continue;
                        }
                        if input.is_empty() {
                            continue;
                        }
                        let mut submitted_goal = None;

                        // Check for slash command
                        if input.starts_with('/') {
                            let (cmd_name, cmd_args) =
                                claurst_tui::input::parse_slash_command(&input);
                            let cmd_name = cmd_name.to_ascii_lowercase();
                            let cmd_args = cmd_args.to_string();
                            if let Err(error) = claurst_commands::preflight_interactive_slash_command(&cmd_name, &cmd_args, &mut cmd_ctx) {
                                app.status_message = Some(error);
                                continue;
                            }
                            let canonical_path = claurst_commands::canonical_catalog_path(&cmd_name, &cmd_args)
                                .or_else(|| app.canonical_command_path(&cmd_name, &cmd_args));


                            // ── /steer <message> (opt-in feature) ─────────────────────
                            // Explicit steering: queue the message when a turn is in
                            // flight (it auto-runs after the current turn, mirroring
                            // Enter-while-busy), or submit it immediately when idle.
                            #[cfg(feature = "steer")]
                            if canonical_path.as_deref() == Some("thinking steer") {
                                let msg = cmd_args.split_once(char::is_whitespace).map(|(_, message)| message.trim()).unwrap_or_default().to_string();
                                if msg.is_empty() {
                                    app.notifications.push(
                                        claurst_tui::NotificationKind::Info,
                                        "Usage: /thinking steer <message> — steer the running turn"
                                            .to_string(),
                                        Some(4),
                                    );
                                    continue;
                                }
                                if app.is_streaming || current_query.is_some() {
                                    let preview: String = msg.chars().take(40).collect();
                                    app.queued_messages.push_back(msg);
                                    let total = app.queued_messages.len();
                                    app.notifications.push(
                                        claurst_tui::NotificationKind::Info,
                                        format!("Steer queued ({total}): {preview}"),
                                        Some(3),
                                    );
                                } else {
                                    // Idle: submit now via the auto-submit path.
                                    app.set_prompt_text(msg);
                                    app.pending_auto_submit = true;
                                }
                                continue;
                            }

                            // ── Step 1: TUI-layer intercept (overlays, toggles) ────────
                            // Run first so we know whether a UI overlay opened, which
                            // lets us suppress redundant CLI text output below.
                            //
                            // Skip TUI overlay for arg-bearing commands where the user
                            // wants to SET state, not browse a picker:
                            //   /model claude-haiku  → set model, don't open picker
                            //   /theme dark          → set theme, don't open picker
                            //   /resume <id>         → load session, don't open browser
                            // Also skip TUI for /vim, /voice, /fast with explicit
                            // on|off args so the blind-toggle doesn't misfire.
                            let skip_tui_for_args = !cmd_args.is_empty()
                                && matches!(
                                    cmd_name.as_str(),
                                    "model"
                                        | "theme"
                                        | "resume"
                                        | "vim"
                                        | "vi"
                                        | "voice"
                                        | "fast"
                                        | "speed"
                                );
                            let handled_by_tui = if skip_tui_for_args {
                                false
                            } else {
                                app.intercept_slash_command_with_args(&cmd_name, &cmd_args)
                            };

                            // Sync effort level when TUI cycled the visual indicator
                            // (no-args /effort → cycle Low→Med→High→Max→Low).
                            if handled_by_tui && cmd_name == "effort" && cmd_args.is_empty() {
                                app.effort_is_set = true;
                                current_effort = Some(match app.effort_level {
                                    claurst_tui::EffortLevel::Low => {
                                        claurst_core::effort::EffortLevel::Low
                                    }
                                    claurst_tui::EffortLevel::Normal => {
                                        claurst_core::effort::EffortLevel::Medium
                                    }
                                    claurst_tui::EffortLevel::High => {
                                        claurst_core::effort::EffortLevel::High
                                    }
                                    claurst_tui::EffortLevel::Max => {
                                        claurst_core::effort::EffortLevel::Max
                                    }
                                });
                            }

                            // Honour exit/quit triggered by TUI intercept immediately.
                            if app.should_exit {
                                break 'main;
                            }

                            // ── Step 2: CLI-layer (real side effects) ──────────────────
                            // Handles: config changes, session ops, file I/O, OAuth, etc.
                            // Always runs — some commands need BOTH (e.g. /clear clears
                            // app state via TUI AND the messages vec via CLI).
                            cmd_ctx.messages = messages.clone();
                            let picker_only = canonical_path.as_deref() == Some("session resume")
                                && cmd_args.split_whitespace().count() == 1;
                            let cli_result = if handled_by_tui && (canonical_path.is_none() || picker_only) {
                                None
                            } else {
                                execute_command(&input, &mut cmd_ctx).await
                            };
                            let command_succeeded = !matches!(&cli_result, Some(CommandResult::Error(_))) && (handled_by_tui || cli_result.is_some());
                            let refresh_catalog = matches!(&cli_result, Some(CommandResult::ResumeSession(_) | CommandResult::ConfigChange(_) | CommandResult::ConfigChangeMessage(_, _)))
                                || command_succeeded && match canonical_path.as_deref() {
                                    Some("plugin reload") => true,
                                    Some("plugin") => matches!(
                                        claurst_plugins::parse_plugin_args(&cmd_args),
                                        claurst_plugins::PluginSubCommand::Enable(_)
                                            | claurst_plugins::PluginSubCommand::Disable(_)
                                    ),
                                    _ => false,
                                };
                            // Start optimistically true; set false for Silent/None below.
                            let mut handled_by_cli = cli_result.is_some();

                            // Whether we need to fall through and submit a user message.
                            let mut submit_user_msg: Option<String> = None;

                            match cli_result {
                                Some(CommandResult::Exit) => break 'main,
                                Some(CommandResult::ClearConversation) => {
                                    session_scope.advance();
                                    messages.clear();
                                    app.replace_messages(Vec::new());
                                    session.messages.clear();
                                    session.updated_at = chrono::Utc::now();
                                    app.status_message = Some("Conversation cleared.".to_string());
                                }
                                Some(CommandResult::SetMessages(new_msgs)) => {
                                    session_scope.advance();
                                    let removed = messages.len().saturating_sub(new_msgs.len());
                                    messages = new_msgs.clone();
                                    app.replace_messages(new_msgs);
                                    session.messages = messages.clone();
                                    session.updated_at = chrono::Utc::now();
                                    app.status_message = Some(format!(
                                        "Rewound {} message{}.",
                                        removed,
                                        if removed == 1 { "" } else { "s" }
                                    ));
                                }
                                Some(CommandResult::OpenRewindOverlay) => {
                                    app.replace_messages(messages.clone());
                                    app.open_rewind_flow();
                                    app.status_message =
                                        Some("Select a message to rewind to.".to_string());
                                }
                                Some(CommandResult::OpenHooksOverlay) => {
                                    // Open the 4-screen hooks configuration browser.
                                    // intercept_slash_command("hooks") already does this
                                    // when the user types /hooks in the TUI prompt, so
                                    // this branch only triggers when the command returns
                                    // the variant explicitly (e.g. from a non-prompt context).
                                    app.hooks_config_menu.open();
                                    app.status_message =
                                        Some("Hooks configuration browser".to_string());
                                }
                                Some(CommandResult::OpenImportConfigOverlay) => {
                                    app.open_import_config_picker();
                                    app.status_message =
                                        Some("Select what to import from ~/.claude.".to_string());
                                }
                                Some(CommandResult::ResumeSession(resumed_session)) => {
                                    session_scope.advance();
                                    session = resumed_session;
                                    app.enter_session_scope(&session.id);
                                    messages = session.messages.clone();
                                    app.replace_messages(messages.clone());
                                    cmd_ctx.config.model = Some(session.model.clone());
                                    app.config.model = Some(session.model.clone());
                                    tool_ctx.config.model = Some(session.model.clone());
                                    app.model_name = session.model.clone();
                                    tool_ctx.session_id = session.id.clone();
                                    tool_ctx.file_history = Arc::new(ParkingMutex::new(
                                        claurst_core::file_history::FileHistory::new(),
                                    ));
                                    tool_ctx.current_turn =
                                        Arc::new(std::sync::atomic::AtomicUsize::new(0));
                                    cmd_ctx.session_id = session.id.clone();
                                    cmd_ctx.session_title = session.title.clone();
                                    if app.renderer == claurst_tui::application::UiRenderer::Next {
            app.session_title = session.title.clone();
        }
                                    if let Some(saved_dir) = session.working_dir.as_ref() {
                                        let saved_path = std::path::PathBuf::from(saved_dir);
                                        if saved_path.exists() {
                                            tool_ctx.working_dir = saved_path.clone();
                                            cmd_ctx.working_dir = saved_path;
                                            refresh_mcp_project_config(&mut cmd_ctx.config, &tool_ctx.working_dir).await?;
                                            app.config.plugin_mcp_servers = cmd_ctx.config.plugin_mcp_servers.clone();
                                            tool_ctx.config.plugin_mcp_servers = cmd_ctx.config.plugin_mcp_servers.clone();
                                            tool_ctx.config.project_dir = cmd_ctx.config.project_dir.clone();
                                        }
                                    }
                                    app.config.project_dir = Some(tool_ctx.working_dir.clone());
                                    app.attach_turn_diff_state(
                                        tool_ctx.file_history.clone(),
                                        tool_ctx.current_turn.clone(),
                                    );
                                    let title = session
                                        .title
                                        .as_deref()
                                        .map(|title| claurst_tui::terminal_title_topic(renderer, title));
                                    claurst_tui::update_terminal_title(title.as_deref());
                                    app.status_message =
                                        Some(format!("Resumed session {}.", &session.id[..8]));
                                }
                                Some(CommandResult::RenameSession(title)) => {
                                    session.title = Some(title.clone());
                                    session.updated_at = chrono::Utc::now();
                                    cmd_ctx.session_title = session.title.clone();
                                    if app.renderer == claurst_tui::application::UiRenderer::Next {
            app.session_title = session.title.clone();
        }
                                    let _ = claurst_core::history::save_session(&session).await;
                                    let shown = claurst_tui::terminal_title_topic(renderer, &title);
                                    claurst_tui::update_terminal_title(Some(&shown));
                                    app.status_message =
                                        Some(format!("Session renamed to \"{}\".", title));
                                }
                                Some(CommandResult::RefreshProviderState) => {
                                    if app.is_streaming || current_query.is_some() {
                                        app.status_message = Some(
                                            "Wait for the current response to finish before running /refresh."
                                                .to_string(),
                                        );
                                    } else {
                                        match refresh_provider_runtime_state(&cmd_ctx.config).await
                                        {
                                            Ok(refreshed) => {
                                                cmd_ctx.config = refreshed.config.clone();
                                                tool_ctx.config = refreshed.config.clone();
                                                base_query_config.provider_registry =
                                                    Some(refreshed.provider_registry.clone());
                                                base_query_config.model_registry =
                                                    Some(refreshed.model_registry.clone());
                                                base_query_config.model =
                                                    claurst_api::effective_model_for_config(
                                                        &cmd_ctx.config,
                                                        refreshed.model_registry.as_ref(),
                                                    );
                                                client = refreshed.client;
                                                model_registry = refreshed.model_registry;
                                                session.model =
                                                    claurst_api::effective_model_for_config(
                                                        &cmd_ctx.config,
                                                        model_registry.as_ref(),
                                                    );
                                                session.updated_at = chrono::Utc::now();
                                                app.apply_provider_refresh(
                                                    refreshed.config,
                                                    Some(refreshed.provider_registry),
                                                    refreshed.auth_store,
                                                    false,
                                                    "Saved provider state cleared. Run /account connect to reconnect."
                                                        .to_string(),
                                                );
                                            }
                                            Err(err) => {
                                                app.status_message =
                                                    Some(format!("Error: {}", err));
                                            }
                                        }
                                    }
                                }
                                Some(CommandResult::SpeechMode { mode, level }) => {
                                    app.set_speech_mode(mode.as_deref(), &level);
                                    cmd_ctx.config = app.config.clone();
                                    tool_ctx.config = app.config.clone();
                                }
                                Some(CommandResult::McpAuthFlow {
                                    server_name,
                                    auth_url,
                                    redirect_uri,
                                }) => {
                                    app.status_message = Some(format!(
                                        "MCP OAuth — '{}' started. Complete authentication in your browser.\nURL: {}\nCallback URL: {}",
                                        server_name, auth_url, redirect_uri
                                    ));
                                }
                                Some(CommandResult::Message(msg)) => {
                                    // Suppress text output when TUI already opened an
                                    // overlay for this command (e.g. /stats opens dialog
                                    // AND would push a text message — drop the text).
                                    if !handled_by_tui {
                                        app.push_message(claurst_core::types::Message::assistant(
                                            msg,
                                        ));
                                    }
                                }
                                Some(CommandResult::ConfigChange(new_cfg)) => {
                                    let mut applied_cfg = new_cfg;
                                    normalize_provider_from_model(&mut applied_cfg);
                                    cmd_ctx.config = applied_cfg.clone();
                                    tool_ctx.config = applied_cfg.clone();
                                    app.config = applied_cfg.clone();
                                    // Sync model/provider shown in the TUI header.
                                    if let Some(ref model) = applied_cfg.model {
                                        app.set_model(model.clone());
                                    }
                                    // Sync fast_mode visual indicator.
                                    app.fast_mode = applied_cfg
                                        .model
                                        .as_deref()
                                        .map(|m| m.contains("haiku"))
                                        .unwrap_or(false);
                                    // Sync plan_mode visual indicator.
                                    app.plan_mode = matches!(
                                        applied_cfg.permission_mode,
                                        claurst_core::config::PermissionMode::Plan
                                    );
                                    session.model = claurst_api::effective_model_for_config(
                                        &cmd_ctx.config,
                                        &model_registry,
                                    );
                                    app.status_message = Some("Configuration updated.".to_string());
                                }
                                Some(CommandResult::ConfigChangeMessage(new_cfg, msg)) => {
                                    let mut applied_cfg = new_cfg;
                                    normalize_provider_from_model(&mut applied_cfg);
                                    cmd_ctx.config = applied_cfg.clone();
                                    tool_ctx.config = applied_cfg.clone();
                                    // Sync model/provider + fast_mode visual indicator.
                                    if let Some(ref model) = applied_cfg.model {
                                        app.set_model(model.clone());
                                        app.fast_mode = model.contains("haiku");
                                    } else {
                                        // model reset to None means fast mode off.
                                        app.fast_mode = false;
                                    }
                                    // A familiar switch (/familiar <id>) must also
                                    // activate the matching agent definition so the
                                    // persona and its access-tier tool filter apply,
                                    // not just the mascot.
                                    let old_familiar = app.config.familiar.clone();
                                    app.config = applied_cfg.clone();
                                    if applied_cfg.familiar != old_familiar {
                                        match applied_cfg.familiar.clone() {
                                            Some(id) => {
                                                app.apply_familiar_agent_mode(Some(id), None)
                                            }
                                            None => {
                                                // Only step down if the session was
                                                // running the now-cleared familiar.
                                                if app.agent_mode == old_familiar {
                                                    app.apply_familiar_agent_mode(None, None);
                                                }
                                            }
                                        }
                                    }
                                    session.model = claurst_api::effective_model_for_config(
                                        &cmd_ctx.config,
                                        &model_registry,
                                    );
                                    app.status_message = Some(msg);
                                }
                                Some(CommandResult::GoalUserMessage { message, turn }) => {
                                    submitted_goal = Some(turn);
                                    submit_user_msg = Some(message);
                                }
                                Some(CommandResult::UserMessage(msg)) => {
                                    // Queue a user-visible turn for the model.
                                    submit_user_msg = Some(msg);
                                }
                                Some(CommandResult::StartOAuthFlow(with_claude_ai)) => {
                                    claurst_tui::restore_terminal(&mut terminal).ok();
                                    match oauth_flow::run_oauth_login_flow(with_claude_ai).await {
                                        Ok(_) => {
                                            app.status_message =
                                                Some("Login successful!".to_string());
                                            eprintln!(
                                                "\nLogin successful! Please restart \
                                                 claude to use the new credentials."
                                            );
                                            break 'main;
                                        }
                                        Err(e) => {
                                            eprintln!("\nLogin failed: {}", e);
                                        }
                                    }
                                    terminal = claurst_tui::setup_terminal(renderer)?;
                                }
                                Some(CommandResult::StartLoginForProvider {
                                    provider,
                                    login_with_claude_ai,
                                    label,
                                }) => {
                                    claurst_tui::restore_terminal(&mut terminal).ok();
                                    if provider == claurst_core::accounts::PROVIDER_CODEX {
                                        let (tx, mut rx) =
                                            tokio::sync::mpsc::channel::<
                                                claurst_tui::DeviceAuthEvent,
                                            >(8);
                                        tokio::spawn(async move {
                                            while let Some(evt) = rx.recv().await {
                                                if let claurst_tui::DeviceAuthEvent::GotBrowserUrl {
                                                    url,
                                                } = evt
                                                {
                                                    eprintln!(
                                                        "\nOpening browser for Codex \
                                                         authentication...\nIf the browser \
                                                         did not open, visit:\n\n  {}\n",
                                                        url
                                                    );
                                                }
                                            }
                                        });
                                        match crate::codex_oauth_flow::run_oauth_flow_with_label(
                                            tx,
                                            label.as_deref(),
                                        )
                                        .await
                                        {
                                            Ok(_) => {
                                                app.status_message =
                                                    Some("Codex login successful!".to_string());
                                                eprintln!("\nCodex login successful!");
                                                break 'main;
                                            }
                                            Err(e) => {
                                                eprintln!("\nCodex login failed: {}", e);
                                            }
                                        }
                                    } else {
                                        match oauth_flow::run_oauth_login_flow_with_label(
                                            login_with_claude_ai,
                                            label.as_deref(),
                                        )
                                        .await
                                        {
                                            Ok(_) => {
                                                app.status_message =
                                                    Some("Login successful!".to_string());
                                                eprintln!(
                                                    "\nLogin successful! Please restart \
                                                     coven-code to use the new credentials."
                                                );
                                                break 'main;
                                            }
                                            Err(e) => {
                                                eprintln!("\nLogin failed: {}", e);
                                            }
                                        }
                                    }
                                    terminal = claurst_tui::setup_terminal(renderer)?;
                                }
                                Some(CommandResult::Error(e)) => {
                                    app.status_message = Some(format!("Error: {}", e));
                                }
                                Some(CommandResult::Silent) | None => {
                                    handled_by_cli = false;
                                }
                            }

                            // Sync effort visual + API level when CLI handled
                            // /effort with explicit args (/effort high).
                            if handled_by_cli && canonical_path.as_deref() == Some("effort") && !cmd_args.is_empty() {
                                if let Some(level) =
                                    claurst_core::effort::EffortLevel::parse(&cmd_args)
                                {
                                    current_effort = Some(level);
                                    app.effort_is_set = true;
                                    app.effort_level = match level {
                                        claurst_core::effort::EffortLevel::Low => {
                                            claurst_tui::EffortLevel::Low
                                        }
                                        claurst_core::effort::EffortLevel::Medium => {
                                            claurst_tui::EffortLevel::Normal
                                        }
                                        claurst_core::effort::EffortLevel::High => {
                                            claurst_tui::EffortLevel::High
                                        }
                                        claurst_core::effort::EffortLevel::Max => {
                                            claurst_tui::EffortLevel::Max
                                        }
                                    };
                                    app.status_message = Some(format!(
                                        "Effort: {} {}",
                                        app.effort_level.symbol(),
                                        app.effort_level.label(),
                                    ));
                                }
                            }

                            // Sync vim mode when CLI handled /vim with explicit args.
                            if handled_by_cli
                                && matches!(cmd_name.as_str(), "vim" | "vi")
                                && !cmd_args.is_empty()
                            {
                                app.prompt_input.vim_enabled =
                                    matches!(cmd_args.trim(), "on" | "vim");
                            }

                            if !handled_by_cli && !handled_by_tui {
                                let suggestions = app.unknown_command_suggestions(&cmd_name);
                                let mut message = format!("Unknown command: /{cmd_name}");
                                if !suggestions.is_empty() {
                                    message.push_str(&format!(". Try {}", suggestions.join(", ")));
                                }
                                app.status_message = Some(message);
                            }

                            if refresh_catalog {
                                app.config.plugin_mcp_servers = cmd_ctx.config.plugin_mcp_servers.clone();
                                tool_ctx.config.plugin_mcp_servers = cmd_ctx.config.plugin_mcp_servers.clone();
                                if app.mcp_view.visible {
                                    app.refresh_mcp_view();
                                }
                                refresh_command_discovery(&mut app, &cmd_ctx.config, &cmd_ctx.working_dir);
                            }
                            if command_succeeded {
                                if let Some(path) = canonical_path {
                                    app.record_recent_command(path);
                                }
                            }

                            // If a UserMessage was queued (e.g. /compact), submit it.
                            if let Some(msg) = submit_user_msg {
                                input = msg;
                                // Fall through to the single injection/send path below.
                            } else {
                                continue;
                            }
                        }

                        if rollback_unattempted_turn(goal_turn.as_ref(), true, &mut messages,
                            &mut app, &mut session, &mut cmd_ctx.messages) {
                            persist_interactive_session(&session, goal_turn.as_ref()).await;
                        }
                        app.rate_limit_recovery.dismiss();
                        app.rate_limit_recovery.take_abandoned();
                        let synthetic = submitted_goal.is_some();
                        let mut owner = match select_submission_turn(submitted_goal, &mut goal_turn,
                            &tool_ctx, cost_tracker.total_tokens(), app.file_injection_force) {
                            Ok(owner) => owner,
                            Err(error) => {
                                app.file_injection_force = false;
                                app.status_message = Some(format!("Goal dispatch stopped: {error}"));
                                continue;
                            }
                        };
                        if synthetic {
                            if let Err(error) = owner.inject(input.clone(), &mut messages, &mut app, &mut session) {
                                app.status_message = Some(format!("Goal dispatch stopped: {error}"));
                                goal_turn = None;
                                continue;
                            }
                        }
                        goal_turn = Some(owner);

                        // Fire UserPromptSubmit hook (non-blocking)
                        if !cmd_ctx.config.hooks.is_empty() {
                            let hook_ctx = claurst_core::hooks::HookContext {
                                event: "UserPromptSubmit".to_string(),
                                tool_name: None,
                                tool_input: None,
                                tool_output: Some(input.clone()),
                                is_error: None,
                                session_id: Some(tool_ctx.session_id.clone()),
                            };
                            claurst_core::hooks::run_hooks(
                                &cmd_ctx.config.hooks,
                                claurst_core::config::HookEvent::UserPromptSubmit,
                                &hook_ctx,
                                &tool_ctx.working_dir,
                            )
                            .await;
                        }

                        if !synthetic {
                        // Regular user message (with optional image attachments + file injection)
                        let pending_imgs = app.prompt_input.clear_images();

                        // Check for file injection if enabled
                        if app.config.file_injection_enabled {
                            use claurst_tui::file_injection::parse_at_refs;

                            // file_injection_force is set when user chose "inject anyways" in the
                            // warning dialog — pass limit 0 so all files are treated as within
                            // limit. Also drop any directory refs silently on force re-submit so
                            // they don't loop back to the directory warning.
                            let was_force = app.file_injection_force;
                            let effective_limit = if app.file_injection_force {
                                app.file_injection_force = false;
                                0
                            } else {
                                app.config.file_injection_max_size
                            };
                            let (within_limit, mut oversized) =
                                parse_at_refs(&input, &tool_ctx.working_dir, effective_limit);
                            if was_force {
                                oversized.retain(|f| {
                                    !matches!(f.issue, Some(claurst_tui::AtFileIssue::IsDirectory))
                                });
                            }

                            if !oversized.is_empty() {
                                // Show either the directory warning or the file warning, never both.
                                // Directories take precedence: if any are present, show only those.
                                let has_dirs = oversized.iter().any(|f| {
                                    matches!(f.issue, Some(claurst_tui::AtFileIssue::IsDirectory))
                                });
                                let oversized_summaries: Vec<(
                                    String,
                                    usize,
                                    claurst_tui::AtFileIssue,
                                )> = oversized
                                    .iter()
                                    .filter(|f| {
                                        let is_dir = matches!(
                                            f.issue,
                                            Some(claurst_tui::AtFileIssue::IsDirectory)
                                        );
                                        if has_dirs {
                                            is_dir
                                        } else {
                                            !is_dir
                                        }
                                    })
                                    .filter_map(|f| {
                                        f.issue.clone().map(|issue| {
                                            (f.path.display().to_string(), f.size_kb, issue)
                                        })
                                    })
                                    .collect();

                                if let Some(owner) = &mut goal_turn { owner.awaiting_file_confirmation = true; }
                                app.file_injection_dialog.show(
                                    input.clone(),
                                    pending_imgs,
                                    oversized_summaries,
                                    app.config.file_injection_max_size,
                                    Some(tool_ctx.working_dir.clone()),
                                );
                                app.set_prompt_text(input);
                                continue;
                            }

                            // No oversized files: inject within-limit files and send
                            let file_prefix =
                                claurst_tui::file_injection::build_file_blocks(&within_limit);

                            let user_msg = if !file_prefix.is_empty() || !pending_imgs.is_empty() {
                                let mut blocks: Vec<claurst_core::types::ContentBlock> = Vec::new();

                                // Add file blocks if there's any file content
                                if !file_prefix.is_empty() {
                                    blocks.push(claurst_core::types::ContentBlock::Text {
                                        text: file_prefix,
                                    });
                                }

                                // Add image blocks
                                for img in &pending_imgs {
                                    if let Some(b64) =
                                        claurst_tui::image_paste::encode_image_base64(&img.path)
                                    {
                                        blocks.push(claurst_core::types::ContentBlock::Image {
                                            source: claurst_core::types::ImageSource {
                                                source_type: "base64".to_string(),
                                                media_type: Some("image/png".to_string()),
                                                data: Some(b64),
                                                url: None,
                                            },
                                        });
                                    }
                                }

                                // Add the original input text
                                blocks.push(claurst_core::types::ContentBlock::Text {
                                    text: input.clone(),
                                });

                                claurst_core::types::Message::user_blocks(blocks)
                            } else {
                                claurst_core::types::Message::user(input.clone())
                            };

                            messages.push(user_msg.clone());
                            app.push_message(user_msg);
                            session.messages = messages.clone();
                            session.updated_at = chrono::Utc::now();
                        } else {
                            // File injection disabled: send as-is
                            let user_msg = if pending_imgs.is_empty() {
                                claurst_core::types::Message::user(input.clone())
                            } else {
                                let mut blocks: Vec<claurst_core::types::ContentBlock> =
                                    pending_imgs
                                        .iter()
                                        .filter_map(|img| {
                                            claurst_tui::image_paste::encode_image_base64(&img.path)
                                                .map(|b64| {
                                                    claurst_core::types::ContentBlock::Image {
                                                        source: claurst_core::types::ImageSource {
                                                            source_type: "base64".to_string(),
                                                            media_type: Some(
                                                                "image/png".to_string(),
                                                            ),
                                                            data: Some(b64),
                                                            url: None,
                                                        },
                                                    }
                                                })
                                        })
                                        .collect();
                                blocks.push(claurst_core::types::ContentBlock::Text {
                                    text: input.clone(),
                                });
                                claurst_core::types::Message::user_blocks(blocks)
                            };

                            messages.push(user_msg.clone());
                            app.push_message(user_msg);
                            session.messages = messages.clone();
                            session.updated_at = chrono::Utc::now();
                        }

                        }
                        // Update terminal title from session title or first message
                        if let Some(title) = session.title.as_deref() {
                            let title = claurst_tui::terminal_title_topic(renderer, title);
                            claurst_tui::update_terminal_title(Some(&title));
                        } else {
                            // Use a truncated version of the first user message
                            let topic: String = input.chars().take(60).collect();
                            let topic = claurst_tui::terminal_title_topic(renderer, &topic);
                            claurst_tui::update_terminal_title(Some(&topic));
                        }

                        // Start async query
                        app.close_response_reader();
                        app.is_streaming = true;
                        app.streaming_text.clear();

                        let ct = CancellationToken::new();
                        cancel = Some(ct.clone());

                        // Use Arc<Mutex> so the task can write updated messages back
                        let msgs_arc = Arc::new(tokio::sync::Mutex::new(messages.clone()));
                        let msgs_arc_clone = msgs_arc.clone();

                        // Share the Arc so the spawned task can access all tools (incl. MCP).
                        let tools_arc_clone = tools_arc.clone();
                        let mut ctx_clone = tool_ctx.clone();
                        let mut qcfg = base_query_config.clone();
                        qcfg.model = claurst_api::effective_model_for_config(
                            &cmd_ctx.config,
                            &model_registry,
                        );
                        qcfg.max_tokens = cmd_ctx.config.effective_max_tokens();
                        qcfg.append_system_prompt = cmd_ctx.config.append_system_prompt.clone();
                        qcfg.system_prompt = base_query_config.system_prompt.clone();
                        qcfg.output_style = cmd_ctx.config.effective_output_style();
                        qcfg.output_style_prompt = cmd_ctx.config.resolve_output_style_prompt();
                        qcfg.working_directory = Some(tool_ctx.working_dir.display().to_string());
                        // Apply active effort level. Once the user has chosen a
                        // level through any UI (model picker ←/→, the /effort
                        // dialog, or the /effort command) `app.effort_level` is
                        // authoritative and resolved at turn-dispatch time;
                        // otherwise fall back to the command-set carrier.
                        let turn_effort = if app.effort_is_set {
                            Some(app.effort_level.to_core())
                        } else {
                            current_effort
                        };
                        if let Some(level) = turn_effort {
                            qcfg.effort_level = Some(level);
                        }
                        // Wire completion_notifier if a command queue is available.
                        // The closure fans-out the structured completion info to:
                        //   1. The command queue (system-message injection for the agent)
                        //   2. The TUI channel (toast + optional terminal bell)
                        if let Some(ref cq) = qcfg.command_queue {
                            let cq = cq.clone();
                            let aux_tx = bg_completion_tx.clone();
                            ctx_clone.completion_notifier = Some(
                                claurst_tools::CompletionNotifier::new(
                                    move |info: claurst_tools::BgTaskCompletion| {
                                        let msg = format!(
                                    "[Monitor] Background task {} completed ({}).\nCommand: {}\nOutput (last 2000 chars):\n{}",
                                    info.task_id, info.exit_info, info.command, info.output_tail
                                );
                                        cq.push(
                                            claurst_query::QueuedCommand::InjectSystemMessage(msg),
                                            claurst_query::CommandPriority::Normal,
                                        );
                                        let _ = aux_tx.send(info);
                                    },
                                ),
                            );
                        }
                        let tracker = cost_tracker.clone();
                        let tx = event_tx.clone();
                        let client_clone = client.clone();
                        if let Some(owner) = &goal_turn { owner.prepare_context(&mut ctx_clone); }

                        let handle = InteractiveQuery {
                            client: client_clone, tools: tools_arc_clone, context: ctx_clone,
                            config: qcfg, tracker, events: tx,
                            generation: session_scope.current(), cancel: ct,
                        }.spawn(msgs_arc_clone);

                        // Store the Arc so we can read messages after task completes
                        current_query = Some((handle, msgs_arc));
                        continue;
                    }
                    if let Some(pr) = app.permission_request.as_mut() {
                        if claurst_tui::dialogs::handle_permission_key(pr, key) {
                            let tool_use_id = pr.tool_use_id.clone();
                            let selected_option = pr.selected_option;
                            let selected_key = pr.options.get(selected_option).map(|o| o.key);
                            let should_record_bash_prefix = selected_key == Some('P');
                            let selected_path = pending_permissions
                                .lock()
                                .waiting
                                .get(&tool_use_id)
                                .and_then(|p| p.request.path.clone());
                            let bash_prefix = if should_record_bash_prefix {
                                match &pr.kind {
                                    claurst_tui::dialogs::PermissionDialogKind::Bash {
                                        suggested_prefix,
                                        ..
                                    } => suggested_prefix
                                        .as_deref()
                                        .map(str::trim)
                                        .filter(|prefix| !prefix.is_empty())
                                        .map(str::to_string),
                                    _ => None,
                                }
                            } else {
                                None
                            };
                            app.permission_request = None;

                            if let Some(prefix) = bash_prefix {
                                app.bash_prefix_allowlist.insert(prefix);
                            }

                            if let Some(mut pending) =
                                pending_permissions.lock().waiting.remove(&tool_use_id)
                            {
                                let decision = match selected_key {
                                    Some('n') => {
                                        claurst_core::permissions::PermissionDecision::Deny
                                    }
                                    _ => claurst_core::permissions::PermissionDecision::Allow,
                                };
                                // Shown beside the tool's execution state; an
                                // allowed call is not a successful one.
                                app.record_permission_decision(
                                    pending.call_id.as_deref().unwrap_or(&tool_use_id),
                                    selected_key != Some('n'),
                                );

                                if let Some(manager) = tool_ctx.permission_manager.as_ref() {
                                    if let Ok(mut manager) = manager.lock() {
                                        match selected_key {
                                            Some('Y') => {
                                                if let Some(path) = selected_path.as_deref() {
                                                    manager.add_session_allow_path(
                                                        &pending.request.tool_name,
                                                        path,
                                                    );
                                                } else {
                                                    manager.add_session_allow(
                                                        &pending.request.tool_name,
                                                    );
                                                }
                                            }
                                            Some('p') => {
                                                let mut settings =
                                                    claurst_core::config::Settings::load_sync(
                                                    ).unwrap_or_default();
                                                if let Some(path) = selected_path.as_deref() {
                                                    let pattern = format!("{}*", path);
                                                    let _ = manager.add_persistent_allow_path(
                                                        &pending.request.tool_name,
                                                        &pattern,
                                                        &mut settings,
                                                    );
                                                } else {
                                                    let _ = manager.add_persistent_allow(
                                                        &pending.request.tool_name,
                                                        &mut settings,
                                                    );
                                                }
                                            }
                                            _ => {}
                                        }
                                    }
                                }

                                if let Some(tx) = pending.decision_tx.take() {
                                    let _ = tx.send(decision);
                                }
                            }
                            continue;
                        }
                        continue;
                    }

                    if app.handle_key_event(key) {
                        app.pending_auto_submit = true;
                    }
                    cmd_ctx.config = app.config.clone();
                    tool_ctx.config = app.config.clone();
                    if let Some(manager) = tool_ctx.permission_manager.as_ref() {
                        if let Ok(mut manager) = manager.lock() {
                            manager.mode = tool_ctx.config.permission_mode.clone();
                        }
                    }
                    if !app.model_name.is_empty() {
                        session.model = app.model_name.clone();
                    }
                    // Handle agent mode change (Tab key cycles build→plan→explore;
                    // /agents picker can also select a Coven familiar).
                    if app.agent_mode_changed {
                        app.agent_mode_changed = false;
                        let mode = app.agent_mode.as_deref().unwrap_or("build");
                        if let Some(def) = resolve_tui_agent_mode(mode, &cmd_ctx.config.agents) {
                            base_query_config.agent_name = Some(mode.to_string());
                            base_query_config.agent_definition = Some(def.clone());
                            if let Some(turns) = def.max_turns {
                                base_query_config.max_turns = turns;
                            }
                            tools_arc = filter_tools_for_hosted_review(
                                filter_tools_for_agent(all_tools_arc.clone(), &def.access),
                                &cmd_ctx.config,
                            );
                        } else {
                            // "build" with no explicit definition = full access, no agent
                            base_query_config.agent_name = None;
                            base_query_config.agent_definition = None;
                            tools_arc =
                                filter_tools_for_hosted_review(all_tools_arc.clone(), &cmd_ctx.config);
                        }
                    }
                    if !app.is_streaming && app.messages.len() < messages.len() {
                        // An in-App rewind replaced the visible conversation.
                        session_scope.advance();
                        messages = app.messages.clone();
                        session.messages = messages.clone();
                        session.updated_at = chrono::Utc::now();
                    }
                }
                Event::Paste(data)
                    // Cmd+V paste on macOS / Ctrl+Shift+V on Linux (via bracketed paste)
                    if !app.is_streaming
                        && app.permission_request.is_none()
                        && !app.history_search_overlay.visible
                    => {
                        if app.key_input_dialog.visible {
                            // Paste into API key input dialog
                            for ch in data.chars() {
                                app.key_input_dialog.insert_char(ch);
                            }
                        } else {
                            // Paste into main prompt input
                            app.prompt_input.paste(&data);
                        }
                    }
                Event::Mouse(mouse) => {
                    app.handle_mouse_event(mouse);
                }
                Event::Resize(_, _) => {
                    // Terminal resize - will be handled on next draw
                }
                _ => {}
            }
        }

        if app.permission_request.is_none() {
            loop {
                let next_pending = pending_permissions.lock().queue.pop_front();
                let Some(mut pending) = next_pending else {
                    break;
                };

                let prefix_allowed = pending.request.tool_name == "Bash"
                    && pending
                        .request
                        .path
                        .as_deref()
                        .map(|command| app.bash_command_allowed_by_prefix(command))
                        .unwrap_or(false);

                let reevaluated = if prefix_allowed {
                    Some(claurst_core::permissions::PermissionDecision::Allow)
                } else {
                    tool_ctx
                        .permission_manager
                        .as_ref()
                        .and_then(|manager| manager.lock().ok())
                        .map(|manager| {
                            manager.evaluate(
                                &pending.request.tool_name,
                                &pending.request.description,
                                pending.request.path.as_deref(),
                                pending.request.working_dir.as_deref(),
                                &pending.request.allowed_roots,
                            )
                        })
                };

                match reevaluated {
                    Some(claurst_core::permissions::PermissionDecision::Ask { .. }) | None => {
                        let tool_use_id = pending.tool_use_id.clone();
                        let request = permission_request_from_core(&pending);
                        // Next guards approvals against stray keys (#411);
                        // Classic keeps its existing dialog behavior.
                        app.permission_request = Some(
                            if app.renderer == claurst_tui::application::UiRenderer::Next {
                                request.guarded()
                            } else {
                                request
                            },
                        );
                        pending_permissions
                            .lock()
                            .waiting
                            .insert(tool_use_id, pending);
                        break;
                    }
                    Some(decision) => {
                        if let Some(tx) = pending.decision_tx.take() {
                            let _ = tx.send(decision);
                        }
                    }
                }
            }
        }

        // Drain query events — also forward relevant ones to the bridge as outbound.
        while let Ok(scoped) = event_rx.try_recv() {
            let evt = &scoped.event;
            // Forward to bridge before consuming (clone only what we need).
            if let Some(ref runtime) = bridge_runtime {
                let outbound: Option<BridgeOutbound> = match evt {
                    QueryEvent::Stream(claurst_api::AnthropicStreamEvent::ContentBlockDelta {
                        delta: claurst_api::streaming::ContentDelta::TextDelta { text },
                        index,
                        ..
                    }) => Some(BridgeOutbound::TextDelta {
                        delta: text.clone(),
                        message_id: format!("msg-{}", index),
                    }),
                    QueryEvent::ToolStart {
                        tool_name,
                        tool_id,
                        input_json,
                    } => Some(BridgeOutbound::ToolStart {
                        id: tool_id.clone(),
                        name: tool_name.clone(),
                        input_preview: Some(input_json.clone()),
                    }),
                    QueryEvent::ToolEnd {
                        tool_id,
                        result,
                        is_error,
                        ..
                    } => Some(BridgeOutbound::ToolEnd {
                        id: tool_id.clone(),
                        output: result.clone(),
                        is_error: *is_error,
                    }),
                    QueryEvent::TurnComplete {
                        stop_reason, turn, ..
                    } => Some(BridgeOutbound::TurnComplete {
                        message_id: format!("turn-{}", turn),
                        stop_reason: stop_reason.clone(),
                    }),
                    QueryEvent::Error(msg) => Some(BridgeOutbound::Error {
                        message: msg.clone(),
                    }),
                    _ => None,
                };
                if let Some(ob) = outbound {
                    let _ = runtime.outbound_tx.try_send(ob);
                }
            }
            // Also forward to the BridgeSessionInfo relay channel (best-effort).
            // This drives the post_bridge_event relay task spawned on Connected.
            if bridge_session_info.is_some() {
                let relay_payload: Option<String> = match evt {
                    QueryEvent::Stream(claurst_api::AnthropicStreamEvent::ContentBlockDelta {
                        delta: claurst_api::streaming::ContentDelta::TextDelta { text },
                        ..
                    }) => Some(
                        serde_json::json!({
                            "type": "text_chunk",
                            "text": text,
                        })
                        .to_string(),
                    ),
                    QueryEvent::ToolStart {
                        tool_name,
                        tool_id,
                        input_json,
                    } => Some(
                        serde_json::json!({
                            "type": "tool_start",
                            "tool_name": tool_name,
                            "tool_id": tool_id,
                            "input": input_json,
                        })
                        .to_string(),
                    ),
                    QueryEvent::ToolEnd {
                        tool_name,
                        tool_id,
                        result,
                        is_error,
                    } => Some(
                        serde_json::json!({
                            "type": "tool_end",
                            "tool_name": tool_name,
                            "tool_id": tool_id,
                            "result": result,
                            "is_error": is_error,
                        })
                        .to_string(),
                    ),
                    _ => None,
                };
                if let Some(payload) = relay_payload {
                    let _ = relay_ev_tx.try_send(payload);
                }
            }
            // Machine consumers above see every event; presentation only
            // admits events from the current session generation.
            let effects = session_scope.apply(&mut app, scoped);
            claurst_tui::application::perform_effects(&effects);
        }

        // Drain background-task completion events: surface a toast and
        // (optionally) ring the terminal bell so the user can leave their
        // attention away from the chat and still notice long builds finishing.
        while let Ok(info) = bg_completion_rx.try_recv() {
            app.signal_bg_task_completion(
                &info,
                settings.completion_toast_enabled(),
                settings.bell_on_complete,
            );
        }

        settle_abandoned_turn(
            &mut goal_turn,
            current_query.is_some(),
            &mut messages,
            &mut app,
            &mut session,
            &mut cmd_ctx.messages,
        )
        .await;

        // Auto-compact: when enabled and context usage reaches the configured
        // threshold with no query running, summarize through the dedicated
        // no-tools compaction path instead of starting an agentic turn.
        if let Some(used_pct) = select_idle_compaction(&app, current_query.is_some()) {
            app.auto_compact_running = true;
            app.status_message = Some(format!("Context {}% full — auto-compacting…", used_pct));

            let ct = CancellationToken::new();
            cancel = Some(ct.clone());
            let msgs_arc = Arc::new(tokio::sync::Mutex::new(messages.clone()));
            let msgs_arc_clone = msgs_arc.clone();
            let compact_model =
                claurst_api::effective_model_for_config(&cmd_ctx.config, &model_registry);
            let client_clone = client.clone();
            app.is_streaming = true;
            goal_turn = None;

            let handle = tokio::spawn(async move {
                if ct.is_cancelled() {
                    return QueryOutcome::Cancelled;
                }

                let msgs = msgs_arc_clone.lock().await.clone();
                match claurst_query::compact_conversation(
                    client_clone.as_ref(),
                    &msgs,
                    &compact_model,
                )
                .await
                {
                    Ok(compacted) => {
                        let message = compacted
                            .first()
                            .cloned()
                            .unwrap_or_else(|| claurst_core::types::Message::assistant(""));
                        *msgs_arc_clone.lock().await = compacted;
                        QueryOutcome::EndTurn {
                            message,
                            usage: claurst_core::types::UsageInfo::default(),
                        }
                    }
                    Err(err) => QueryOutcome::Error(err),
                }
            });
            current_query = Some((handle, msgs_arc));
        }

        // Drain TUI-facing bridge events.
        let mut disconnect_bridge = false;
        if let Some(runtime) = bridge_runtime.as_mut() {
            loop {
                match runtime.tui_rx.try_recv() {
                    Ok(TuiBridgeEvent::Connected {
                        session_url,
                        session_id: conn_sid,
                    }) => {
                        let notification = remote_connection_notification(&session_url);
                        app.bridge_state = BridgeConnectionState::Connected {
                            session_url: session_url.clone(),
                            peer_count: 0,
                        };
                        app.remote_session_url = Some(session_url.clone());
                        cmd_ctx.remote_session_url = Some(session_url.clone());
                        app.notifications
                            .push(NotificationKind::Success, notification, Some(5));
                        // Persist the session URL into the saved session record.
                        session.remote_session_url = Some(session_url.clone());
                        session.updated_at = chrono::Utc::now();
                        let _ = claurst_core::history::save_session(&session).await;

                        // Wire the BridgeSessionInfo relay so live tool/text events reach
                        // the web UI via /api/bridge/sessions. This runs alongside
                        // run_bridge_loop as a best-effort supplementary delivery path.
                        if let Some(ref token) = bridge_token {
                            let info = std::sync::Arc::new(claurst_bridge::BridgeSessionInfo {
                                session_id: conn_sid.clone(),
                                session_url: session_url.clone(),
                                token: token.clone(),
                            });
                            bridge_session_info = Some(info.clone());

                            // Relay consumer: moves relay_ev_rx (taken from the Option)
                            // into a background task that calls post_bridge_event per item.
                            if let Some(rx) = relay_ev_rx_opt.take() {
                                let info_relay = info.clone();
                                runtime.supplementary_tasks.spawn(async move {
                                    let mut rx = rx;
                                    while let Some(payload) = rx.recv().await {
                                        let _ =
                                            claurst_bridge::post_bridge_event(&info_relay, payload)
                                                .await;
                                    }
                                });
                            }

                            // Poll task: periodically calls poll_bridge_messages and
                            // forwards inbound user messages to remote_prompt_tx.
                            let info_poll = info.clone();
                            let poll_tx = remote_prompt_tx.clone();
                            runtime.supplementary_tasks.spawn(async move {
                                let mut since_id: Option<String> = None;
                                loop {
                                    match claurst_bridge::poll_bridge_messages(
                                        &info_poll,
                                        since_id.as_deref(),
                                    )
                                    .await
                                    {
                                        Ok(msgs) if !msgs.is_empty() => {
                                            for msg in &msgs {
                                                since_id = Some(msg.id.clone());
                                                if msg.role == "user"
                                                    && poll_tx
                                                        .send(msg.content.clone())
                                                        .await
                                                        .is_err()
                                                {
                                                    return;
                                                }
                                            }
                                        }
                                        _ => {}
                                    }
                                    tokio::time::sleep(std::time::Duration::from_secs(2)).await;
                                }
                            });
                        }
                    }
                    Ok(TuiBridgeEvent::Disconnected { reason }) => {
                        app.bridge_state = BridgeConnectionState::Disconnected;
                        app.remote_session_url = None;
                        cmd_ctx.remote_session_url = None;
                        if let Some(r) = reason {
                            app.notifications.push(
                                NotificationKind::Warning,
                                format!("Bridge disconnected: {}", r),
                                Some(5),
                            );
                        }
                        disconnect_bridge = true;
                        break;
                    }
                    Ok(TuiBridgeEvent::Reconnecting { attempt }) => {
                        app.bridge_state = BridgeConnectionState::Reconnecting { attempt };
                    }
                    Ok(TuiBridgeEvent::InboundPrompt { content, .. }) => {
                        pending_remote_prompts.push_back(content);
                    }
                    Ok(TuiBridgeEvent::Cancelled) => {
                        abandon_interactive_turn(&mut goal_turn, &mut app, &cancel);
                        if current_query.is_some()
                            && app.renderer == claurst_tui::application::UiRenderer::Next
                        {
                            app.note_cancellation_sent();
                            app.interrupt_tool_rows();
                        }
                        app.is_streaming = false;
                        app.status_message = Some("Cancelled by remote control.".to_string());
                    }
                    Ok(TuiBridgeEvent::PermissionResponse {
                        tool_use_id,
                        response,
                    }) => {
                        let decided = handle_bridge_permission_response(
                            &mut app.permission_request,
                            &mut pending_permissions.lock(),
                            &tool_use_id,
                            response,
                        );
                        if let Some((call_id, allowed)) = decided {
                            app.record_permission_decision(&call_id, allowed);
                        }
                    }
                    Ok(TuiBridgeEvent::SessionNameUpdate { title }) => {
                        session.title = Some(title.clone());
                        session.updated_at = chrono::Utc::now();
                        cmd_ctx.session_title = Some(title.clone());
                        app.session_title = Some(title);
                        let _ = claurst_core::history::save_session(&session).await;
                    }
                    Ok(TuiBridgeEvent::Error(msg)) => {
                        app.bridge_state = BridgeConnectionState::Failed {
                            reason: msg.clone(),
                        };
                        app.notifications.push(
                            NotificationKind::Warning,
                            format!("Bridge error: {}", msg),
                            Some(5),
                        );
                        disconnect_bridge = true;
                        break;
                    }
                    Ok(TuiBridgeEvent::Ping) => {
                        // No TUI action needed; pong is handled inside run_bridge_loop.
                    }
                    Err(tokio::sync::mpsc::error::TryRecvError::Empty) => break,
                    Err(tokio::sync::mpsc::error::TryRecvError::Disconnected) => {
                        app.bridge_state = BridgeConnectionState::Disconnected;
                        app.remote_session_url = None;
                        cmd_ctx.remote_session_url = None;
                        app.notifications.push(
                            NotificationKind::Warning,
                            "Remote control connection lost.".to_string(),
                            Some(5),
                        );
                        disconnect_bridge = true;
                        break;
                    }
                }
            }
        }
        if disconnect_bridge {
            pending_remote_prompts.clear();
            bridge_session_info = None;
            if let Some(mut runtime) = bridge_runtime.take() {
                runtime.cancel.cancel();
                // Stop HTTP, channel waits and sleeps before draining stale prompts.
                runtime.supplementary_tasks.shutdown().await;
                if let Err(error) = (&mut runtime.primary_task).await {
                    warn!(%error, "Bridge worker failed during disconnect");
                }
            }
            while remote_prompt_rx.try_recv().is_ok() {}
        }

        // Both bridge transports share the same literal-prompt launch path.
        // Primary events observed above precede supplementary messages read here;
        // each transport retains FIFO ordering. Never reinterpret remote slash text.
        // A pending file-injection decision also holds remote prompts in their queue.
        let file_injection_pending = app.file_injection_dialog.visible || app.file_injection_force;
        if let Some(content) = take_remote_prompt(
            &mut pending_remote_prompts,
            &mut remote_prompt_rx,
            app.is_streaming || file_injection_pending,
            current_query.is_some(),
        ) {
            if rollback_unattempted_turn(
                goal_turn.as_ref(),
                true,
                &mut messages,
                &mut app,
                &mut session,
                &mut cmd_ctx.messages,
            ) {
                persist_interactive_session(&session, goal_turn.as_ref()).await;
            }
            app.rate_limit_recovery.dismiss();
            app.rate_limit_recovery.take_abandoned();
            app.set_prompt_text(content.clone());
            let user_message = claurst_core::types::Message::user(content.clone());
            messages.push(user_message.clone());
            app.push_message(user_message);
            session.messages = messages.clone();
            session.updated_at = chrono::Utc::now();
            app.is_streaming = true;
            app.streaming_text.clear();
            let ct = CancellationToken::new();
            cancel = Some(ct.clone());
            let msgs_arc = Arc::new(tokio::sync::Mutex::new(messages.clone()));
            let msgs_arc_clone = msgs_arc.clone();
            let tools_arc_clone = tools_arc.clone();
            let mut ctx_clone = tool_ctx.clone();
            let mut qcfg = base_query_config.clone();
            qcfg.model = claurst_api::effective_model_for_config(&cmd_ctx.config, &model_registry);
            qcfg.max_tokens = cmd_ctx.config.effective_max_tokens();
            let tracker = cost_tracker.clone();
            let tx = event_tx.clone();
            let client_clone = client.clone();
            goal_turn = Some(InteractiveTurn::capture(
                &mut ctx_clone,
                cost_tracker.total_tokens(),
            ));
            let handle = InteractiveQuery {
                client: client_clone,
                tools: tools_arc_clone,
                context: ctx_clone,
                config: qcfg,
                tracker,
                events: tx,
                generation: session_scope.current(),
                cancel: ct,
            }
            .spawn(msgs_arc_clone);
            current_query = Some((handle, msgs_arc));
        }

        // Drain CLAUDE_STATUS_COMMAND results (most recent wins)
        if status_cmd_str.is_some() {
            while let Ok(text) = status_cmd_rx.try_recv() {
                app.status_line_override = if text.is_empty() { None } else { Some(text) };
            }
        }

        // Sync cost/token counters and expire transient UI state.
        app.cost_usd = app.cost_tracker.total_cost_usd();
        app.token_count = app.cost_tracker.total_tokens() as u32;
        app.notifications.tick();
        app.memory_update_notification.tick();

        // Drain background model-fetch results (non-blocking).
        if let Some(ref mut rx) = app.model_fetch_rx {
            match rx.try_recv() {
                // An empty listing must not blank out the options the picker
                // was seeded with (curated/registry list) — keep them shown.
                Ok(Ok(entries)) if entries.is_empty() => {
                    app.model_picker.loading_models = false;
                    app.model_fetch_rx = None;
                }
                Ok(Ok(entries)) => {
                    let provider = app
                        .model_picker_provider_id
                        .clone()
                        .or_else(|| app.config.provider.clone())
                        .unwrap_or_else(|| "anthropic".to_string());
                    let provider_prefix = format!("{}/", provider);
                    let current = app
                        .model_name
                        .strip_prefix(&provider_prefix)
                        .unwrap_or(app.model_name.as_str())
                        .to_string();
                    app.model_picker.set_models(entries);
                    for m in &mut app.model_picker.models {
                        m.is_current = m.id == current;
                    }
                    app.model_picker.loading_models = false;
                    app.model_fetch_rx = None;
                }
                Ok(Err(())) | Err(tokio::sync::mpsc::error::TryRecvError::Disconnected) => {
                    app.model_picker.loading_models = false;
                    app.model_fetch_rx = None;
                }
                Err(tokio::sync::mpsc::error::TryRecvError::Empty) => {}
            }
        }

        // Drain ask-user question events (non-blocking).
        // When the AskUserQuestion tool fires, it sends a UserQuestionEvent
        // here.  We open the dialog and the user's answer travels back via
        // the embedded oneshot channel.
        if let Some(ref mut rx) = app.user_question_rx {
            match rx.try_recv() {
                Ok(event) => {
                    app.ask_user_dialog
                        .open(event.question, event.options, event.reply_tx);
                }
                Err(tokio::sync::mpsc::error::TryRecvError::Empty) => {}
                Err(tokio::sync::mpsc::error::TryRecvError::Disconnected) => {
                    app.user_question_rx = None;
                }
            }
        }

        // Spawn async provider model-list fetch when requested.
        if app.model_picker_fetch_pending {
            app.model_picker_fetch_pending = false;
            let provider_id_str = app
                .model_picker_provider_id
                .clone()
                .or_else(|| app.config.provider.clone())
                .unwrap_or_else(|| "anthropic".to_string());
            // Older persisted configs may still carry the "openai-codex"
            // alias; registry lookups are exact-match on "codex".
            let provider_id_str =
                claurst_api::registry::canonical_provider_id(&provider_id_str).to_string();
            let mut fetch_spawned = false;
            if let Some(ref registry) = app.provider_registry {
                let pid = claurst_core::ProviderId::new(&provider_id_str);
                if let Some(provider) = registry.get(&pid) {
                    let provider = provider.clone();
                    let (tx, rx) = tokio::sync::mpsc::channel(1);
                    app.model_fetch_rx = Some(rx);
                    app.model_picker.loading_models = true;
                    tokio::spawn(async move {
                        match provider.list_models().await {
                            Ok(models) => {
                                let entries: Vec<claurst_tui::model_picker::ModelEntry> = models
                                    .into_iter()
                                    .map(|m| claurst_tui::model_picker::ModelEntry {
                                        id: m.id.to_string(),
                                        display_name: m.name.clone(),
                                        description:
                                            claurst_tui::model_picker::format_context_window(
                                                m.context_window,
                                            ),
                                        is_current: false,
                                    })
                                    .collect();
                                let _ = tx.send(Ok(entries)).await;
                            }
                            Err(_) => {
                                let _ = tx.send(Err(())).await;
                            }
                        }
                    });
                    fetch_spawned = true;
                }
            }
            // No fetch is running (provider missing from the registry) —
            // stop the spinner so the seeded model list stays usable.
            if !fetch_spawned {
                app.model_picker.loading_models = false;
            }
        }

        // Refresh task list if the overlay is visible.
        if app.tasks_overlay.visible {
            app.tasks_overlay.refresh_tasks(&claurst_tools::TASK_STORE);
        }

        // Check if the background update task has reported a result.
        if app.update_available.is_none() {
            if let Ok(Some(version)) = update_rx.try_recv() {
                app.update_available = Some(version);
            }
        }

        // ---- Device code / OAuth auth: spawn background task when pending ----
        if let Some(provider_id) = app.device_auth_pending.take() {
            let _tx = device_auth_tx.clone();
            match provider_id.as_str() {
                "anthropic" | "anthropic-oauth" => {
                    let tx2 = device_auth_tx.clone();
                    // Anthropic subscription OAuth needs a registered Coven Code
                    // OAuth client id. When configured, run the Claude.ai browser
                    // flow (Bearer token); otherwise guide the user to the
                    // alternatives.
                    let client_id_configured = std::env::var(claurst_core::oauth::CLIENT_ID_ENV)
                        .map(|v| !v.trim().is_empty())
                        .unwrap_or(false);
                    tokio::spawn(async move {
                        if !client_id_configured {
                            let _ = tx2.send(DeviceAuthEvent::Error(
                                "Claude subscription login is not configured.\n\
                                 Choose \"Claude CLI\" to run through the local claude binary,\n\
                                 or use ANTHROPIC_API_KEY from console.anthropic.com/settings/keys.".to_string()
                            )).await;
                            return;
                        }
                        // Claude.ai subscription flow (Bearer token). Tokens are
                        // persisted to disk by the flow; the TUI activates
                        // Anthropic and rebuilds the runtime on success.
                        match oauth_flow::run_oauth_login_flow(true).await {
                            Ok(result) => {
                                let _ = tx2
                                    .send(DeviceAuthEvent::TokenReceived(result.credential))
                                    .await;
                            }
                            Err(e) => {
                                let _ = tx2
                                    .send(DeviceAuthEvent::Error(format!(
                                        "Anthropic OAuth failed: {}",
                                        e
                                    )))
                                    .await;
                            }
                        }
                    });
                }
                "codex" | "openai-codex" => {
                    let tx2 = device_auth_tx.clone();
                    // Keep the dialog in WaitingForCode until GotBrowserUrl arrives.
                    // (set_browser_url() transitions it to BrowserAuth with the URL.)
                    tokio::spawn(async move {
                        match crate::codex_oauth_flow::run_oauth_flow(tx2.clone()).await {
                            Ok(tokens) => {
                                let _ = tx2
                                    .send(DeviceAuthEvent::TokenReceived(tokens.access_token))
                                    .await;
                            }
                            Err(e) => {
                                let _ = tx2
                                    .send(DeviceAuthEvent::Error(format!(
                                        "Codex OAuth failed: {}",
                                        e
                                    )))
                                    .await;
                            }
                        }
                    });
                }
                _ => {
                    // Unknown provider for device auth — should not happen
                    app.device_auth_dialog
                        .set_error(format!("Unsupported auth flow for {}", provider_id));
                }
            }
        }

        // ---- Drain device auth events from the background task ----
        while let Ok(evt) = device_auth_rx.try_recv() {
            match evt {
                DeviceAuthEvent::GotCode {
                    user_code,
                    verification_uri,
                    device_code,
                    interval,
                } => {
                    // Auto-copy the user code to clipboard
                    let _ = claurst_tui::try_copy_to_clipboard(&user_code);

                    // Auto-open the verification URL in the browser
                    let _ = open::that(&verification_uri);

                    app.device_auth_dialog.set_code(
                        user_code,
                        verification_uri,
                        device_code,
                        interval,
                    );

                    app.notifications.push(
                        claurst_tui::NotificationKind::Info,
                        "Code copied to clipboard & browser opened.".to_string(),
                        Some(4),
                    );
                }
                DeviceAuthEvent::GotBrowserUrl { url } => {
                    // Copy the URL to clipboard so the user can paste it even
                    // when the automatic browser launch silently fails (headless
                    // terminals, tty2, Wayland-without-xdg-open, etc.).
                    let _ = claurst_tui::try_copy_to_clipboard(&url);
                    app.device_auth_dialog.set_browser_url(url);
                    app.notifications.push(
                        claurst_tui::NotificationKind::Info,
                        "Login URL copied to clipboard.".to_string(),
                        Some(5),
                    );
                }
                DeviceAuthEvent::TokenReceived(token) => {
                    app.device_auth_dialog.set_success(token);
                }
                DeviceAuthEvent::Error(msg) => {
                    app.device_auth_dialog.set_error(msg);
                }
            }
        }

        // ---- Apply newly-established Anthropic credentials without a restart ----
        // Set after an in-session OAuth login; rebuilds the client and
        // provider registry from disk (non-destructively).
        if std::mem::take(&mut app.pending_provider_refresh) {
            match reload_anthropic_runtime_state(&cmd_ctx.config).await {
                Ok(refreshed) => {
                    cmd_ctx.config = refreshed.config.clone();
                    tool_ctx.config = refreshed.config.clone();
                    base_query_config.provider_registry = Some(refreshed.provider_registry.clone());
                    base_query_config.model_registry = Some(refreshed.model_registry.clone());
                    base_query_config.model = claurst_api::effective_model_for_config(
                        &cmd_ctx.config,
                        refreshed.model_registry.as_ref(),
                    );
                    client = refreshed.client;
                    model_registry = refreshed.model_registry;
                    session.model = claurst_api::effective_model_for_config(
                        &cmd_ctx.config,
                        model_registry.as_ref(),
                    );
                    session.updated_at = chrono::Utc::now();
                    app.apply_provider_refresh(
                        refreshed.config,
                        Some(refreshed.provider_registry),
                        refreshed.auth_store,
                        true,
                        "Anthropic credentials applied.".to_string(),
                    );
                }
                Err(err) => {
                    app.notifications.push(
                        claurst_tui::NotificationKind::Error,
                        format!("Failed to apply Anthropic credentials: {}", err),
                        None,
                    );
                }
            }
        }

        while let Ok(evt) = mcp_auth_rx.try_recv() {
            match evt {
                McpAuthEvent::Completed(result) => {
                    // Schedule a runtime rebuild so the newly persisted token is
                    // picked up by the next MCP manager instance.
                    app.pending_mcp_reconnect = true;
                    app.status_message = Some(format!(
                        "MCP OAuth — '{}' authentication completed; token saved to: {}",
                        result.server_name,
                        result.token_path.display()
                    ));
                }
                McpAuthEvent::Failed(error) => {
                    app.status_message = Some(format!("MCP OAuth failed: {}", error));
                }
            }
        }
        // Advance the rate-limit recovery countdown and pick up any retry
        // directive (auto-retry deadline reached, or the user pressed a
        // recovery key). The retry re-dispatches the query loop over the
        // existing conversation — the failed turn's prompt is never lost and
        // never duplicated.
        app.rate_limit_recovery.tick();
        if current_query.is_none() && !app.is_streaming {
            if let Some(directive) = app.rate_limit_recovery.take_retry_directive() {
                if !messages.is_empty() && goal_turn.as_ref().is_some_and(|owner| !owner.abandoned)
                {
                    app.status_message = Some(match &directive.model {
                        Some(model) => format!("Rate limit recovery — retrying on {}…", model),
                        None => "Rate limit recovery — retrying…".to_string(),
                    });
                    app.is_streaming = true;
                    app.streaming_text.clear();

                    let ct = CancellationToken::new();
                    cancel = Some(ct.clone());

                    let msgs_arc = Arc::new(tokio::sync::Mutex::new(messages.clone()));
                    let msgs_arc_clone = msgs_arc.clone();
                    let tools_arc_clone = tools_arc.clone();
                    let mut ctx_clone = tool_ctx.clone();
                    let mut qcfg = base_query_config.clone();
                    qcfg.model =
                        claurst_api::effective_model_for_config(&cmd_ctx.config, &model_registry);
                    qcfg.max_tokens = cmd_ctx.config.effective_max_tokens();
                    qcfg.append_system_prompt = cmd_ctx.config.append_system_prompt.clone();
                    qcfg.system_prompt = base_query_config.system_prompt.clone();
                    qcfg.output_style = cmd_ctx.config.effective_output_style();
                    qcfg.output_style_prompt = cmd_ctx.config.resolve_output_style_prompt();
                    qcfg.working_directory = Some(tool_ctx.working_dir.display().to_string());
                    let turn_effort = if app.effort_is_set {
                        Some(app.effort_level.to_core())
                    } else {
                        current_effort
                    };
                    if let Some(level) = turn_effort {
                        qcfg.effort_level = Some(level);
                    }
                    let tracker = cost_tracker.clone();
                    let tx = event_tx.clone();
                    let client_clone = client.clone();
                    if let Some(owner) = &goal_turn {
                        owner.prepare_context(&mut ctx_clone);
                    }

                    let handle = InteractiveQuery {
                        client: client_clone,
                        tools: tools_arc_clone,
                        context: ctx_clone,
                        config: qcfg,
                        tracker,
                        events: tx,
                        generation: session_scope.current(),
                        cancel: ct,
                    }
                    .spawn(msgs_arc_clone);
                    current_query = Some((handle, msgs_arc));
                }
            }
        }

        // Escape and the interrupt key record a cancel request in the App;
        // perform it through the turn's token so the runtime actually stops.
        if app.take_cancellation_request() && current_query.is_some() {
            abandon_interactive_turn(&mut goal_turn, &mut app, &cancel);
        }

        // Check if query task is done; sync messages from the task
        let task_finished = current_query
            .as_ref()
            .map(|(h, _)| h.is_finished())
            .unwrap_or(false);

        if task_finished {
            if let Some((handle, msgs_arc)) = current_query.take() {
                // Get the outcome and handle errors
                let query_outcome = handle.await;
                match &query_outcome {
                    // Structured rate limit → interactive recovery flow
                    // (countdown auto-retry, one-key tier switch, duplicate
                    // account cleanup) instead of a dead-end error modal.
                    Ok(QueryOutcome::Error(claurst_core::error::ClaudeError::RateLimit {
                        retry_after_secs,
                        message,
                    })) => {
                        show_rate_limit_recovery(
                            goal_turn.as_ref(),
                            &mut app,
                            message.as_deref(),
                            *retry_after_secs,
                        );
                    }
                    Ok(QueryOutcome::Error(err)) => {
                        while app.notifications.current_is_error() {
                            app.notifications.dismiss_current();
                        }
                        app.notifications.push(
                            claurst_tui::notifications::NotificationKind::Error,
                            err.to_string(),
                            None,
                        );
                    }
                    Ok(QueryOutcome::EndTurn { .. }) => {
                        // Successful turn — refresh the auto-retry budget for
                        // any future rate-limit episode.
                        app.rate_limit_recovery.reset_episode();
                    }
                    Err(err) => {
                        while app.notifications.current_is_error() {
                            app.notifications.dismiss_current();
                        }
                        app.notifications.push(
                            claurst_tui::notifications::NotificationKind::Error,
                            format!("Query task failed: {}", err),
                            None,
                        );
                    }
                    _ => {}
                };
                let completed_end_turn = matches!(&query_outcome, Ok(QueryOutcome::EndTurn { .. }));
                let was_auto_compact = app.auto_compact_running;
                let auto_compact_succeeded = completed_end_turn;
                // Sync the updated conversation back to our local vector
                messages = msgs_arc.lock().await.clone();
                session.messages = messages.clone();
                session.updated_at = chrono::Utc::now();
                session.model =
                    claurst_api::effective_model_for_config(&cmd_ctx.config, &model_registry);
                session.working_dir = Some(tool_ctx.working_dir.display().to_string());
                app.is_streaming = false;
                app.status_message = None;
                // Drain one queued message into the prompt and request an
                // auto-submit on the next loop iteration (issue #149).
                if let Some(next) = app.queued_messages.pop_front() {
                    app.prompt_input.text = next;
                    app.prompt_input.cursor = app.prompt_input.text.len();
                    app.pending_auto_submit = true;
                }
                if app.auto_compact_running {
                    app.auto_compact_running = false;
                    if !auto_compact_succeeded {
                        app.auto_compact_enabled = false;
                        app.status_message = Some(
                            "Auto-compact failed and was disabled for this session.".to_string(),
                        );
                    } else {
                        // After auto-compact the context was summarised — reset usage.
                        app.context_used_tokens = 0;
                        app.status_message = Some("Auto-compact complete.".to_string());
                    }
                }

                rollback_unattempted_turn(
                    goal_turn.as_ref(),
                    false,
                    &mut messages,
                    &mut app,
                    &mut session,
                    &mut cmd_ctx.messages,
                );
                *msgs_arc.lock().await = messages.clone();
                persist_interactive_session(&session, goal_turn.as_ref()).await;

                // --- Goal continuation ---
                // After every completed turn check if there is an active goal.
                // If so, inject a continuation user message and dispatch another turn
                // without waiting for user input.
                if completed_end_turn && !was_auto_compact && claurst_core::goals_enabled() {
                    let continuation = goal_turn
                        .take()
                        .map_or(claurst_query::GoalContinuation::NoGoal, |owner| {
                            owner.continuation(cost_tracker.total_tokens())
                        });
                    match continuation {
                        claurst_query::GoalContinuation::Continue { message, turn } => {
                            // Show a subtle status notice.
                            app.status_message = Some(
                                "Goal: continuing autonomously… (use /goal pause to stop)"
                                    .to_string(),
                            );
                            app.active_goal_badge = Some(format!(
                                "active · {} · {} turns",
                                turn.goal().elapsed_display(),
                                turn.goal().turns_used
                            ));
                            let mut owner =
                                InteractiveTurn::from_goal(turn, cost_tracker.total_tokens());
                            if let Err(error) =
                                owner.inject(message, &mut messages, &mut app, &mut session)
                            {
                                app.status_message =
                                    Some(format!("Goal dispatch stopped: {error}"));
                                continue;
                            }
                            goal_turn = Some(owner);
                            app.is_streaming = true;
                            app.streaming_text.clear();

                            let ct = CancellationToken::new();
                            cancel = Some(ct.clone());

                            let msgs_arc = Arc::new(tokio::sync::Mutex::new(messages.clone()));
                            let msgs_arc_clone = msgs_arc.clone();
                            let tools_arc_clone = tools_arc.clone();
                            let mut ctx_clone = tool_ctx.clone();
                            let mut qcfg = base_query_config.clone();
                            qcfg.model = claurst_api::effective_model_for_config(
                                &cmd_ctx.config,
                                &model_registry,
                            );
                            qcfg.max_tokens = cmd_ctx.config.effective_max_tokens();
                            qcfg.append_system_prompt = cmd_ctx.config.append_system_prompt.clone();
                            qcfg.system_prompt = base_query_config.system_prompt.clone();
                            qcfg.output_style = cmd_ctx.config.effective_output_style();
                            qcfg.output_style_prompt = cmd_ctx.config.resolve_output_style_prompt();
                            qcfg.working_directory =
                                Some(tool_ctx.working_dir.display().to_string());
                            let turn_effort = if app.effort_is_set {
                                Some(app.effort_level.to_core())
                            } else {
                                current_effort
                            };
                            if let Some(level) = turn_effort {
                                qcfg.effort_level = Some(level);
                            }
                            if let Some(ref cq) = qcfg.command_queue {
                                let cq = cq.clone();
                                let aux_tx = bg_completion_tx.clone();
                                ctx_clone.completion_notifier = Some(
                                    claurst_tools::CompletionNotifier::new(
                                        move |info: claurst_tools::BgTaskCompletion| {
                                            let msg = format!(
                                        "[Monitor] Background task {} completed ({}).\nCommand: {}\nOutput (last 2000 chars):\n{}",
                                        info.task_id, info.exit_info, info.command, info.output_tail
                                    );
                                            cq.push(
                                                claurst_query::QueuedCommand::InjectSystemMessage(
                                                    msg,
                                                ),
                                                claurst_query::CommandPriority::Normal,
                                            );
                                            let _ = aux_tx.send(info);
                                        },
                                    ),
                                );
                            }
                            let tracker = cost_tracker.clone();
                            let tx = event_tx.clone();
                            let client_clone = client.clone();
                            if let Some(owner) = &goal_turn {
                                owner.prepare_context(&mut ctx_clone);
                            }

                            let handle = InteractiveQuery {
                                client: client_clone,
                                tools: tools_arc_clone,
                                context: ctx_clone,
                                config: qcfg,
                                tracker,
                                events: tx,
                                generation: session_scope.current(),
                                cancel: ct,
                            }
                            .spawn(msgs_arc_clone);
                            current_query = Some((handle, msgs_arc));
                        }
                        claurst_query::GoalContinuation::Stop { reason } => {
                            app.active_goal_badge = None;
                            if let Some(msg) = reason.user_message() {
                                app.status_message = Some(msg);
                            }
                        }
                        claurst_query::GoalContinuation::NoGoal => {
                            app.active_goal_badge = None;
                        }
                    }
                } else if completed_end_turn
                    || was_auto_compact
                    || matches!(
                        &query_outcome,
                        Ok(QueryOutcome::Cancelled | QueryOutcome::BudgetExceeded { .. })
                    )
                    || goal_turn.as_ref().is_some_and(|owner| owner.abandoned)
                {
                    goal_turn = None;
                }
            }
        }

        // A cancel is confirmed only once no worker is left running.
        if current_query.is_none() {
            app.settle_cancellation();
        }

        if !app.is_streaming && current_query.is_none() {
            if let Some(server_name) = app.take_pending_mcp_panel_auth() {
                let server_config = cmd_ctx
                    .config
                    .effective_mcp_servers()
                    .find(|server| server.name == server_name);
                let supports_panel_auth = server_config.is_some_and(|server| {
                    matches!(server.server_type.as_str(), "http" | "sse")
                        && server.url.as_deref().is_some()
                });

                if !supports_panel_auth {
                    app.status_message = Some(format!(
                        "Selected MCP server '{}' does not support panel auth.",
                        server_name
                    ));
                } else if let Some(manager) = app.mcp_manager.clone() {
                    match manager
                        .begin_auth(Some(&cmd_ctx.working_dir), &server_name)
                        .await
                    {
                        Ok(session) => {
                            let auth_url = session.auth_url.clone();
                            let redirect_uri = session.redirect_uri.clone();
                            mcp_auth_runner(session);
                            app.status_message = Some(format!(
                                "MCP auth — '{}' started. Complete authentication in your browser.\nURL: {}\nCallback URL: {}",
                                server_name, auth_url, redirect_uri
                            ));
                        }
                        Err(error) => {
                            app.status_message =
                                Some(format!("MCP auth failed for '{}': {}", server_name, error));
                        }
                    }
                } else {
                    app.status_message = Some(
                        "MCP auth is unavailable because the MCP runtime is not connected."
                            .to_string(),
                    );
                }
            }
        }

        if !app.is_streaming && current_query.is_none() && app.take_pending_mcp_reconnect() {
            let new_mcp_manager =
                connect_mcp_manager_arc(&cmd_ctx.config, Some(&cmd_ctx.working_dir)).await;
            tools_arc = replace_mcp_runtime(
                new_mcp_manager.clone(),
                &mut tool_ctx,
                &mut cmd_ctx,
                &mut app.mcp_manager,
            );
            if app.mcp_view.visible {
                app.refresh_mcp_view();
            }

            let connected = new_mcp_manager
                .as_ref()
                .map(|manager| manager.server_count())
                .unwrap_or(0);
            app.status_message = Some(
                if cmd_ctx.config.hosted_review_enabled()
                    && !cmd_ctx.config.hosted_review.allow_mcp_servers
                {
                    "MCP servers are disabled in hosted review mode.".to_string()
                } else if cmd_ctx.config.effective_mcp_servers().next().is_none() {
                    "No MCP servers configured.".to_string()
                } else {
                    format!(
                        "Reconnected MCP runtime ({} connected server{}).",
                        connected,
                        if connected == 1 { "" } else { "s" }
                    )
                },
            );
        }

        if app.should_exit {
            break 'main;
        }
    }

    if let Some(runtime) = &bridge_runtime {
        runtime.cancel.cancel();
    }
    // Leave raw/alternate screen before waiting for best-effort HTTP cleanup.
    // Still join the worker if restoration fails, then report that error below.
    let terminal_result = restore_terminal(&mut terminal);
    // Quitting mid-turn stops the worker and keeps what it delivered. Next only:
    // Classic keeps its existing exit.
    if app.renderer == claurst_tui::application::UiRenderer::Next {
        if let Some((handle, msgs_arc)) = current_query.take() {
            abandon_interactive_turn(&mut goal_turn, &mut app, &cancel);
            messages = stop_turn_for_exit(handle, &msgs_arc, event_rx, TURN_EXIT_WAIT).await;
            session.messages = messages.clone();
            session.updated_at = chrono::Utc::now();
            session.model =
                claurst_api::effective_model_for_config(&cmd_ctx.config, &model_registry);
            session.working_dir = Some(tool_ctx.working_dir.display().to_string());
            rollback_unattempted_turn(
                goal_turn.as_ref(),
                false,
                &mut messages,
                &mut app,
                &mut session,
                &mut cmd_ctx.messages,
            );
            persist_interactive_session(&session, goal_turn.as_ref()).await;
        }
    }
    if let Some(mut runtime) = bridge_runtime.take() {
        runtime.supplementary_tasks.shutdown().await;
        if let Err(error) = (&mut runtime.primary_task).await {
            warn!(%error, "Bridge worker failed during exit");
        }
    }

    // Mark the session complete in the Coven daemon ledger (best-effort, opt-in).
    // Use the id captured at registration time, not session.id, which may have been
    // rebound by a mid-run /resume to a completely different session.
    if let Some(id) = &ledger_session_id {
        claurst_core::coven_ledger::notify_session_complete(id, Some(0));
    }

    terminal_result?;
    Ok(())
}

// ---------------------------------------------------------------------------
// `claude auth` subcommand handler
// ---------------------------------------------------------------------------
// Mirrors TypeScript cli.tsx `if (args[0] === 'auth') { ... }` fast-path.
// Called before Cli::parse() so it doesn't conflict with positional `prompt`.
//
// Usage:
//   claude auth login [--console]   — Anthropic OAuth with a configured Coven Code client
//   claude auth logout              — Clear stored credentials
//   claude auth status [--json]     — Show authentication status

async fn handle_auth_command(args: &[String]) -> anyhow::Result<()> {
    match args.first().map(|s| s.as_str()) {
        Some("login") => {
            // --console flag selects the Console OAuth flow (creates an API key)
            // Default (no flag) uses the Claude.ai flow (Bearer token)
            let login_with_claude_ai = !args.iter().any(|a| a == "--console");
            let label = extract_label_flag(args);
            println!("Starting authentication...");
            match oauth_flow::run_oauth_login_flow_with_label(
                login_with_claude_ai,
                label.as_deref(),
            )
            .await
            {
                Ok(result) => {
                    println!("Successfully logged in!");
                    if let Some(email) = &result.tokens.email {
                        println!("  Account: {}", email);
                    }
                    if result.use_bearer_auth {
                        println!("  Auth method: claude.ai");
                    } else {
                        println!("  Auth method: console (API key)");
                    }
                    if let Some(active) = claurst_core::accounts::AccountRegistry::load()
                        .active(claurst_core::accounts::PROVIDER_ANTHROPIC)
                    {
                        println!("  Profile: {}", active);
                    }
                    std::process::exit(0);
                }
                Err(e) => {
                    eprintln!("Login failed: {}", e);
                    std::process::exit(1);
                }
            }
        }

        Some("import") => {
            eprintln!(
                "`auth import` was removed: importing Claude Code's OAuth token gets rate limited."
            );
            eprintln!(
                "Claude subscription access now runs through the local `claude` CLI automatically — no import needed."
            );
            std::process::exit(1);
        }

        Some("logout") => {
            auth_logout().await;
        }

        Some("status") => {
            let json_output = args.iter().any(|a| a == "--json");
            auth_status(json_output).await;
        }

        Some("list") | Some("ls") | Some("accounts") => {
            print_account_list(claurst_core::accounts::PROVIDER_ANTHROPIC, "Anthropic");
            std::process::exit(0);
        }

        Some("switch") | Some("use") => {
            let id = args.get(1).map(|s| s.as_str());
            switch_account(claurst_core::accounts::PROVIDER_ANTHROPIC, "Anthropic", id);
        }

        Some("remove") | Some("rm") => {
            let id = args.get(1).map(|s| s.as_str()).unwrap_or_else(|| {
                eprintln!("Usage: coven-code auth remove <profile-id>");
                std::process::exit(1);
            });
            remove_account(claurst_core::accounts::PROVIDER_ANTHROPIC, "Anthropic", id);
        }

        Some(unknown) => {
            eprintln!("Unknown auth subcommand: '{}'", unknown);
            eprintln!();
            print_auth_usage();
            std::process::exit(1);
        }

        None => {
            print_auth_usage();
            std::process::exit(1);
        }
    }

    Ok(())
}

fn print_auth_usage() {
    eprintln!("Usage: coven-code auth <subcommand>");
    eprintln!(
        "  login [--console] [--label <name>]   Authenticate with a configured Coven OAuth client"
    );
    eprintln!("  logout                                Remove the active account's credentials");
    eprintln!("  status [--json]                       Show authentication status");
    eprintln!("  list                                  List all stored Anthropic accounts");
    eprintln!("  switch <profile-id>                   Make a stored account active");
    eprintln!("  remove <profile-id>                   Delete a stored account");
}

fn extract_label_flag(args: &[String]) -> Option<String> {
    let mut it = args.iter();
    while let Some(a) = it.next() {
        if a == "--label" || a == "-l" {
            return it.next().cloned();
        }
        if let Some(rest) = a.strip_prefix("--label=") {
            return Some(rest.to_string());
        }
    }
    None
}

fn print_account_list(provider: &str, display_name: &str) {
    let registry = claurst_core::accounts::AccountRegistry::load();
    let profiles = registry.list(provider);
    let active = registry.active(provider).map(String::from);
    if profiles.is_empty() {
        println!("No {} accounts stored.", display_name);
        println!(
            "Use `coven-code {} login` to add one.",
            if provider == "anthropic" {
                "auth"
            } else {
                provider
            }
        );
        return;
    }
    println!("{} accounts:", display_name);
    for p in profiles {
        let marker = if active.as_deref() == Some(&p.id) {
            "*"
        } else {
            " "
        };
        let email = p.email.as_deref().unwrap_or("");
        let label = p
            .label
            .as_deref()
            .map(|l| format!(" ({})", l))
            .unwrap_or_default();
        let tier = p
            .subscription_tier
            .as_deref()
            .map(|t| format!(" [{}]", t))
            .unwrap_or_default();
        println!("  {} {}{}{}  {}", marker, p.id, label, tier, email);
    }
}

fn switch_account(provider: &str, display_name: &str, id: Option<&str>) -> ! {
    let mut registry = claurst_core::accounts::AccountRegistry::load();
    let profiles = registry.list(provider);

    let target = match id {
        Some(id) => id.to_string(),
        None => {
            if profiles.is_empty() {
                eprintln!("No {} accounts stored.", display_name);
                std::process::exit(1);
            }
            // No id: print the picker and exit with usage.
            eprintln!(
                "Usage: coven-code {} switch <profile-id>",
                if provider == "anthropic" {
                    "auth"
                } else {
                    provider
                }
            );
            eprintln!();
            print_account_list(provider, display_name);
            std::process::exit(1);
        }
    };

    match registry.switch_to(provider, &target) {
        Ok(()) => {
            println!("Switched {} active account to '{}'.", display_name, target);
            std::process::exit(0);
        }
        Err(e) => {
            eprintln!("{}", e);
            eprintln!();
            print_account_list(provider, display_name);
            std::process::exit(1);
        }
    }
}

// ---------------------------------------------------------------------------
// `coven-code codex` subcommand handler (account-level CLI)
// ---------------------------------------------------------------------------

async fn handle_codex_account_command(args: &[String]) -> anyhow::Result<()> {
    match args.first().map(|s| s.as_str()) {
        Some("login") => {
            let label = extract_label_flag(args);
            // The Codex flow expects a TUI DeviceAuth dialog. For headless CLI
            // login we still spin up the OAuth listener but route the URL
            // through a no-op channel; the user opens the URL in their browser
            // either way.
            let (tx, mut rx) = tokio::sync::mpsc::channel::<claurst_tui::DeviceAuthEvent>(8);
            tokio::spawn(async move {
                while let Some(evt) = rx.recv().await {
                    if let claurst_tui::DeviceAuthEvent::GotBrowserUrl { url } = evt {
                        println!("Opening browser for Codex authentication...");
                        println!("If the browser did not open, visit:\n\n  {}\n", url);
                    }
                }
            });
            match crate::codex_oauth_flow::run_oauth_flow_with_label(tx, label.as_deref()).await {
                Ok(_) => {
                    let registry = claurst_core::accounts::AccountRegistry::load();
                    println!("Successfully logged in to Codex!");
                    if let Some(p) = registry.active_profile(claurst_core::accounts::PROVIDER_CODEX)
                    {
                        if let Some(email) = &p.email {
                            println!("  Account: {}", email);
                        }
                        println!("  Profile: {}", p.id);
                    }
                    std::process::exit(0);
                }
                Err(e) => {
                    eprintln!("Codex login failed: {}", e);
                    std::process::exit(1);
                }
            }
        }
        Some("logout") => match claurst_core::oauth_config::clear_codex_tokens() {
            Ok(_) => {
                println!("Logged out of the active Codex account.");
                std::process::exit(0);
            }
            Err(e) => {
                eprintln!("Logout failed: {}", e);
                std::process::exit(1);
            }
        },
        Some("list") | Some("ls") | Some("accounts") => {
            print_account_list(claurst_core::accounts::PROVIDER_CODEX, "Codex");
            std::process::exit(0);
        }
        Some("switch") | Some("use") => {
            let id = args.get(1).map(|s| s.as_str());
            switch_account(claurst_core::accounts::PROVIDER_CODEX, "Codex", id);
        }
        Some("remove") | Some("rm") => {
            let id = args.get(1).map(|s| s.as_str()).unwrap_or_else(|| {
                eprintln!("Usage: coven-code codex remove <profile-id>");
                std::process::exit(1);
            });
            remove_account(claurst_core::accounts::PROVIDER_CODEX, "Codex", id);
        }
        Some("status") => {
            let registry = claurst_core::accounts::AccountRegistry::load();
            match registry.active_profile(claurst_core::accounts::PROVIDER_CODEX) {
                Some(p) => {
                    println!("Logged in to Codex.");
                    println!("  Profile: {}", p.id);
                    if let Some(email) = &p.email {
                        println!("  Account: {}", email);
                    }
                    std::process::exit(0);
                }
                None => {
                    println!("Not logged in to Codex.");
                    std::process::exit(1);
                }
            }
        }
        Some(unknown) => {
            eprintln!("Unknown codex subcommand: '{}'", unknown);
            eprintln!();
            print_codex_usage();
            std::process::exit(1);
        }
        None => {
            print_codex_usage();
            std::process::exit(1);
        }
    }
}

fn print_codex_usage() {
    eprintln!("Usage: coven-code codex <subcommand>");
    eprintln!("  login [--label <name>]   Authenticate with ChatGPT/Codex");
    eprintln!("  logout                   Remove the active Codex credentials");
    eprintln!("  status                   Show Codex auth status");
    eprintln!("  list                     List all stored Codex accounts");
    eprintln!("  switch <profile-id>      Make a stored Codex account active");
    eprintln!("  remove <profile-id>      Delete a stored Codex account");
}

// ---------------------------------------------------------------------------
// `coven-code accounts` — unified read-only list across providers
// ---------------------------------------------------------------------------

fn handle_accounts_command(args: &[String]) {
    if args.iter().any(|a| a == "--json") {
        let registry = claurst_core::accounts::AccountRegistry::load();
        let json = serde_json::to_string_pretty(&registry).unwrap_or_else(|_| "{}".into());
        println!("{}", json);
        return;
    }

    print_account_list(claurst_core::accounts::PROVIDER_ANTHROPIC, "Anthropic");
    println!();
    print_account_list(claurst_core::accounts::PROVIDER_CODEX, "Codex");
}

fn remove_account(provider: &str, display_name: &str, id: &str) -> ! {
    let mut registry = claurst_core::accounts::AccountRegistry::load();
    if registry.get(provider, id).is_none() {
        eprintln!("No {} account '{}' to remove.", display_name, id);
        std::process::exit(1);
    }
    match registry.remove(provider, id) {
        Ok(()) => {
            println!("Removed {} account '{}'.", display_name, id);
            std::process::exit(0);
        }
        Err(e) => {
            eprintln!("Failed to remove account: {}", e);
            std::process::exit(1);
        }
    }
}

fn provider_status_lookup_keys(provider_id: &str) -> Vec<&str> {
    match provider_id {
        "codex" | "openai-codex" => vec!["codex", "openai-codex"],
        _ => vec![provider_id],
    }
}

fn format_provider_name(provider_id: &str) -> String {
    match provider_id {
        "anthropic" => "Anthropic".to_string(),
        "codex" | "openai-codex" => "Codex".to_string(),
        other => other
            .split('-')
            .map(|part| {
                let mut chars = part.chars();
                match chars.next() {
                    Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
                    None => String::new(),
                }
            })
            .collect::<Vec<_>>()
            .join(" "),
    }
}

/// Print current auth status, then exit with code 0 (logged in) or 1 (not logged in).
async fn auth_status(json_output: bool) {
    let settings = Settings::load().await.unwrap_or_default();
    let config = &settings.config;
    let active_provider = config.selected_provider_id();
    let provider_cfg = config
        .provider_configs
        .get(active_provider)
        .filter(|provider| provider.enabled);
    let auth_store = claurst_core::AuthStore::load();
    let oauth_tokens = if active_provider == "anthropic" {
        claurst_core::oauth::OAuthTokens::load().await
    } else {
        None
    };

    let env_api_key_source = claurst_core::config::api_key_env_vars_for_provider(active_provider)
        .iter()
        .find_map(|env_var| {
            std::env::var(env_var)
                .ok()
                .filter(|value| !value.is_empty())
                .map(|_| (*env_var).to_string())
        });
    let stored_api_key_source = provider_status_lookup_keys(active_provider)
        .into_iter()
        .find_map(|provider_id| match auth_store.get(provider_id) {
            Some(claurst_core::StoredCredential::ApiKey { key }) if !key.is_empty() => {
                Some("stored credential".to_string())
            }
            Some(claurst_core::StoredCredential::OAuthToken {
                access, refresh, ..
            }) if (active_provider == "codex" || active_provider == "openai-codex")
                && (!access.is_empty() || !refresh.is_empty()) =>
            {
                Some("stored token".to_string())
            }
            _ => None,
        });

    let api_provider = format_provider_name(active_provider);
    let api_key_source = config
        .api_key
        .as_ref()
        .filter(|key| !key.is_empty())
        .map(|_| "settings.api_key".to_string())
        .or_else(|| {
            provider_cfg
                .and_then(|provider| provider.api_key.as_ref())
                .filter(|key| !key.is_empty())
                .map(|_| format!("settings.provider_configs.{active_provider}.api_key"))
        })
        .or(stored_api_key_source)
        .or(env_api_key_source)
        .or_else(|| {
            oauth_tokens
                .as_ref()
                .filter(|tokens| !tokens.uses_bearer_auth() && tokens.api_key.is_some())
                .map(|_| "/login managed key".to_string())
        });
    let usable_oauth_tokens = oauth_tokens
        .as_ref()
        .filter(|tokens| tokens.bearer_auth_is_usable());
    let disabled_bearer_token = oauth_tokens
        .as_ref()
        .is_some_and(|tokens| tokens.uses_bearer_auth() && !tokens.bearer_auth_is_usable());
    let token_source = usable_oauth_tokens.map(|tokens| {
        if tokens.uses_bearer_auth() {
            "claude.ai".to_string()
        } else {
            "console_oauth".to_string()
        }
    });
    let login_method = usable_oauth_tokens
        .and_then(|tokens| subscription_label(tokens.subscription_type.as_deref()))
        .or_else(|| {
            usable_oauth_tokens.map(|tokens| {
                if tokens.uses_bearer_auth() {
                    "Coven Account".to_string()
                } else {
                    "Console Account".to_string()
                }
            })
        })
        .or_else(|| api_key_source.as_ref().map(|_| "API Key".to_string()));
    let billing_mode = usable_oauth_tokens.map_or_else(
        || {
            if api_key_source.is_some() {
                "API".to_string()
            } else {
                "None".to_string()
            }
        },
        |tokens| {
            if tokens.uses_bearer_auth() {
                "Subscription".to_string()
            } else {
                "API".to_string()
            }
        },
    );

    let (auth_method, logged_in) = if let Some(tokens) = usable_oauth_tokens {
        let method = if tokens.uses_bearer_auth() {
            "claude.ai"
        } else {
            "oauth_token"
        };
        (method.to_string(), true)
    } else if api_key_source.is_some() {
        ("api_key".to_string(), true)
    } else {
        ("none".to_string(), false)
    };

    if json_output {
        let mut obj = serde_json::json!({
            "loggedIn": logged_in,
            "authMethod": auth_method,
            "apiProvider": api_provider,
            "billing": billing_mode,
        });

        if let Some(ref source) = api_key_source {
            obj["apiKeySource"] = serde_json::Value::String(source.clone());
        }
        if let Some(ref source) = token_source {
            obj["tokenSource"] = serde_json::Value::String(source.clone());
        }
        if let Some(ref method) = login_method {
            obj["loginMethod"] = serde_json::Value::String(method.clone());
        }
        if disabled_bearer_token {
            obj["disabledTokenSource"] =
                serde_json::Value::String("claude.ai OAuth token disabled".to_string());
        }

        if let Some(ref tokens) = oauth_tokens {
            obj["email"] = json_null_or_string(&tokens.email);
            obj["orgId"] = json_null_or_string(&tokens.organization_uuid);
            obj["subscriptionType"] = json_null_or_string(&tokens.subscription_type);
        }

        println!("{}", serde_json::to_string_pretty(&obj).unwrap_or_default());
    } else {
        if !logged_in {
            let hint = if active_provider == "anthropic" {
                if disabled_bearer_token {
                    "Stored claude.ai OAuth tokens were minted by an unsupported client and are ignored; Claude runs through the local `claude` CLI instead (or set ANTHROPIC_API_KEY).".to_string()
                } else {
                    "Claude runs through the local `claude` CLI when no key is set — install it with `npm install -g @anthropic-ai/claude-code` and run `claude` to sign in (or set ANTHROPIC_API_KEY).".to_string()
                }
            } else if let Some(env_var) =
                claurst_core::config::primary_api_key_env_var_for_provider(active_provider)
            {
                format!(
                    "Set {} or store a credential for {}.",
                    env_var, api_provider
                )
            } else {
                format!("Configure credentials for {}.", api_provider)
            };
            println!("Not logged in for {}. {}", api_provider, hint);
        } else {
            println!("Logged in.");
            println!("  API provider: {}", api_provider);
            println!("  Billing: {}", billing_mode);
            if let Some(ref method) = login_method {
                println!("  Login method: {}", method);
            }
            if let Some(ref source) = token_source {
                println!("  Auth token: {}", source);
            }
            if let Some(ref source) = api_key_source {
                println!("  API key: {}", source);
            }
            match auth_method.as_str() {
                "claude.ai" | "oauth_token" => {
                    if let Some(ref tokens) = oauth_tokens {
                        if let Some(ref email) = tokens.email {
                            println!("  Email: {}", email);
                        }
                        if let Some(ref org) = tokens.organization_uuid {
                            println!("  Organization ID: {}", org);
                        } else {
                            println!("  Organization ID: unavailable");
                        }
                        if let Some(ref sub) = tokens.subscription_type {
                            println!("  Subscription: {}", sub);
                        }
                    }
                }
                "api_key" => {
                    println!("  Organization ID: unavailable for direct API key auth");
                }
                _ => {}
            }
        }
    }

    std::process::exit(if logged_in { 0 } else { 1 });
}

/// Clear all stored credentials and exit.
async fn auth_logout() {
    let mut had_error = false;

    // Clear OAuth tokens
    if let Err(e) = claurst_core::oauth::OAuthTokens::clear().await {
        eprintln!("Warning: failed to clear OAuth tokens: {}", e);
        had_error = true;
    }

    // Also clear any API key stored in settings.json
    match Settings::load().await {
        Ok(mut settings) => {
            if settings.config.api_key.is_some() {
                settings.config.api_key = None;
                if let Err(e) = settings.save().await {
                    eprintln!("Warning: failed to update settings.json: {}", e);
                    had_error = true;
                }
            }
        }
        Err(e) => {
            eprintln!("Warning: failed to load settings.json: {}", e);
        }
    }

    if had_error {
        eprintln!("Logout completed with warnings.");
        std::process::exit(1);
    } else {
        println!("Successfully logged out from your Anthropic account.");
        std::process::exit(0);
    }
}

/// Helper: convert `Option<String>` to a JSON string or null.
fn subscription_label(subscription_type: Option<&str>) -> Option<String> {
    match subscription_type? {
        "enterprise" => Some("Claude Enterprise Account".to_string()),
        "team" => Some("Claude Team Account".to_string()),
        "max" => Some("Claude Max Account".to_string()),
        "pro" => Some("Claude Pro Account".to_string()),
        other if !other.is_empty() => Some(format!("{} Account", other)),
        _ => None,
    }
}

/// Helper: convert `Option<String>` to a JSON string or null.
fn json_null_or_string(opt: &Option<String>) -> serde_json::Value {
    match opt {
        Some(s) => serde_json::Value::String(s.clone()),
        None => serde_json::Value::Null,
    }
}

/// Show the "use coven" hint only for a direct interactive run that is NOT
/// driven by the unified coven CLI.
fn should_show_engine_notice(is_interactive: bool, is_tty: bool, coven_parent_set: bool) -> bool {
    is_interactive && is_tty && !coven_parent_set
}

// Launch at most one remote turn after the previous query has been joined.
fn take_remote_prompt(
    pending: &mut std::collections::VecDeque<String>,
    receiver: &mut tokio::sync::mpsc::Receiver<String>,
    is_streaming: bool,
    query_running: bool,
) -> Option<String> {
    if is_streaming || query_running {
        return None;
    }
    while let Ok(prompt) = receiver.try_recv() {
        pending.push_back(prompt);
    }
    pending.pop_front()
}

fn remote_connection_notification(session_url: &str) -> String {
    let short = if session_url.len() > 60 {
        let mut end = 60;
        while !session_url.is_char_boundary(end) {
            end -= 1;
        }
        format!("{}…", &session_url[..end])
    } else {
        session_url.to_string()
    };
    format!("Remote control active: {}", short)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn scoped_forwarder_delivers_every_event_in_order_under_backpressure() {
        let (turn_tx, turn_rx) = tokio::sync::mpsc::unbounded_channel();
        let (events, mut receiver) = tokio::sync::mpsc::channel(1);
        let mut scope = claurst_tui::application::SessionScope::default();
        let generation = scope.advance();
        for n in 0..200 {
            turn_tx
                .send(claurst_query::QueryEvent::Status(format!("event {n}")))
                .unwrap();
        }
        drop(turn_tx);
        let forward = tokio::spawn(forward_scoped_events(turn_rx, events, generation));
        let mut received = Vec::new();
        while let Some(scoped) = receiver.recv().await {
            assert_eq!(scoped.generation, generation);
            match scoped.event {
                claurst_query::QueryEvent::Status(text) => received.push(text),
                other => panic!("unexpected event {other:?}"),
            }
            // Slow consumer: the queue stays full while the forwarder waits.
            tokio::task::yield_now().await;
        }
        forward.await.unwrap();
        let expected: Vec<String> = (0..200).map(|n| format!("event {n}")).collect();
        assert_eq!(received, expected);
    }

    #[tokio::test]
    async fn scoped_forwarder_stops_when_the_interactive_loop_is_gone() {
        let (turn_tx, turn_rx) = tokio::sync::mpsc::unbounded_channel();
        let (events, receiver) = tokio::sync::mpsc::channel(1);
        drop(receiver);
        turn_tx
            .send(claurst_query::QueryEvent::Status("orphan".into()))
            .unwrap();
        // The sender stays alive: the forwarder must end on the closed queue,
        // not wait for the turn to finish.
        tokio::time::timeout(
            std::time::Duration::from_secs(5),
            forward_scoped_events(turn_rx, events, Default::default()),
        )
        .await
        .expect("forwarder must stop once the interactive queue is closed");
        drop(turn_tx);
    }

    #[tokio::test]
    async fn quitting_frees_a_turn_blocked_on_the_full_queue_and_keeps_its_messages() {
        let (turn_tx, turn_rx) = tokio::sync::mpsc::unbounded_channel();
        let (events, queue) = tokio::sync::mpsc::channel(1);
        for _ in 0..3 {
            turn_tx
                .send(claurst_query::QueryEvent::Status("backlog".into()))
                .unwrap();
        }
        drop(turn_tx);
        let messages: MessagesArc = Arc::new(tokio::sync::Mutex::new(Vec::new()));
        let worker_messages = messages.clone();
        let handle = tokio::spawn(async move {
            forward_scoped_events(turn_rx, events, Default::default()).await;
            *worker_messages.lock().await =
                vec![claurst_core::types::Message::user("kept".to_string())];
            claurst_query::QueryOutcome::Cancelled
        });
        // Let the forwarder fill the queue and block on it.
        tokio::task::yield_now().await;

        let wait = std::time::Duration::from_secs(30);
        let kept = tokio::time::timeout(
            std::time::Duration::from_secs(5),
            stop_turn_for_exit(handle, &messages, queue, wait),
        )
        .await
        .expect("a closed queue must free the worker, not run out the wait");
        assert_eq!(kept.len(), 1);
    }

    #[tokio::test]
    async fn quitting_does_not_wait_forever_for_a_turn_that_ignores_cancellation() {
        let prompt = vec![claurst_core::types::Message::user("prompt".to_string())];
        let messages: MessagesArc = Arc::new(tokio::sync::Mutex::new(prompt));
        let (_events, queue) = tokio::sync::mpsc::channel(1);
        let handle = tokio::spawn(std::future::pending::<claurst_query::QueryOutcome>());

        let kept = stop_turn_for_exit(
            handle,
            &messages,
            queue,
            std::time::Duration::from_millis(20),
        )
        .await;
        assert_eq!(kept.len(), 1, "the prompt is still saved");
    }

    #[test]
    fn remote_notification_two_byte_boundary() {
        let prefix = "a".repeat(59);
        let url = format!("{prefix}étail");
        assert!(!url.is_char_boundary(60));
        assert_eq!(
            remote_connection_notification(&url),
            format!("Remote control active: {prefix}…")
        );
    }

    #[test]
    fn remote_notification_three_byte_boundary() {
        let prefix = "a".repeat(59);
        let url = format!("{prefix}界tail");
        assert!(!url.is_char_boundary(60));
        assert_eq!(
            remote_connection_notification(&url),
            format!("Remote control active: {prefix}…")
        );
    }

    #[test]
    fn remote_notification_four_byte_boundary() {
        let prefix = "a".repeat(58);
        let url = format!("{prefix}\u{10000}tail");
        assert!(!url.is_char_boundary(60));
        assert_eq!(
            remote_connection_notification(&url),
            format!("Remote control active: {prefix}…")
        );
    }

    #[test]
    fn remote_notification_ascii_exact_and_short_controls() {
        let long = "a".repeat(61);
        assert_eq!(
            remote_connection_notification(&long),
            format!("Remote control active: {}…", "a".repeat(60))
        );
        for url in [format!("{}界", "a".repeat(57)), "short 界".to_string()] {
            assert_eq!(
                remote_connection_notification(&url),
                format!("Remote control active: {url}")
            );
        }
    }

    fn bridge_permission_fixture(
        id: &str,
    ) -> (
        claurst_tools::PendingPermissionRequest,
        tokio::sync::oneshot::Receiver<claurst_core::permissions::PermissionDecision>,
    ) {
        let (tx, rx) = tokio::sync::oneshot::channel();
        (
            claurst_tools::PendingPermissionRequest {
                tool_use_id: id.into(),
                call_id: None,
                request: claurst_core::permissions::PermissionRequest {
                    tool_name: "Write".into(),
                    description: "Write a file".into(),
                    details: None,
                    is_read_only: false,
                    path: Some("example.txt".into()),
                    working_dir: None,
                    allowed_roots: vec![],
                    context_description: None,
                },
                reason: "Requires approval".into(),
                decision_tx: Some(tx),
            },
            rx,
        )
    }

    #[test]
    fn bridge_permission_response_delivers_decision() {
        use claurst_bridge::PermissionResponseKind as Response;
        use claurst_core::permissions::PermissionDecision as Decision;

        for (response, expected) in [
            (Response::Allow, Decision::Allow),
            (Response::Deny, Decision::Deny),
            (Response::AllowSession, Decision::Allow),
        ] {
            let (pending, mut rx) = bridge_permission_fixture("active");
            let mut dialog = Some(permission_request_from_core(&pending));
            let mut store = claurst_tools::PendingPermissionStore::default();
            store.waiting.insert("active".into(), pending);

            handle_bridge_permission_response(&mut dialog, &mut store, "active", response);

            assert_eq!(rx.try_recv(), Ok(expected));
            assert!(dialog.is_none());
            assert!(store.waiting.is_empty());
        }
    }

    #[test]
    fn bridge_permission_decisions_belong_to_the_model_call_that_asked() {
        use claurst_bridge::PermissionResponseKind as Response;

        for (call_id, response, expected) in [
            (Some("toolu_model"), Response::Allow, ("toolu_model", true)),
            (Some("toolu_model"), Response::Deny, ("toolu_model", false)),
            (None, Response::AllowSession, ("perm-1", true)),
        ] {
            let (mut pending, _rx) = bridge_permission_fixture("perm-1");
            pending.call_id = call_id.map(str::to_string);
            let mut dialog = Some(permission_request_from_core(&pending));
            let mut store = claurst_tools::PendingPermissionStore::default();
            store.waiting.insert("perm-1".into(), pending);

            let decided =
                handle_bridge_permission_response(&mut dialog, &mut store, "perm-1", response);

            assert_eq!(decided, Some((expected.0.to_string(), expected.1)));
        }
    }

    #[test]
    fn bridge_permission_response_ignores_other_and_repeated_ids() {
        use claurst_bridge::PermissionResponseKind as Response;
        use claurst_core::permissions::PermissionDecision as Decision;
        use tokio::sync::oneshot::error::TryRecvError;

        let (first, mut first_rx) = bridge_permission_fixture("first");
        let (second, mut second_rx) = bridge_permission_fixture("second");
        let mut dialog = Some(permission_request_from_core(&first));
        let next_dialog = permission_request_from_core(&second);
        let mut store = claurst_tools::PendingPermissionStore::default();
        store.waiting.insert("first".into(), first);
        store.waiting.insert("second".into(), second);

        handle_bridge_permission_response(&mut dialog, &mut store, "second", Response::Allow);
        handle_bridge_permission_response(&mut dialog, &mut store, "unknown", Response::Allow);
        assert_eq!(first_rx.try_recv(), Err(TryRecvError::Empty));
        assert_eq!(second_rx.try_recv(), Err(TryRecvError::Empty));
        assert_eq!(dialog.as_ref().unwrap().tool_use_id, "first");
        assert_eq!(store.waiting.len(), 2);

        handle_bridge_permission_response(&mut dialog, &mut store, "first", Response::Deny);
        assert_eq!(first_rx.try_recv(), Ok(Decision::Deny));
        dialog = Some(next_dialog);
        handle_bridge_permission_response(&mut dialog, &mut store, "first", Response::Allow);
        assert_eq!(second_rx.try_recv(), Err(TryRecvError::Empty));
        assert_eq!(dialog.as_ref().unwrap().tool_use_id, "second");
        assert_eq!(store.waiting.len(), 1);
    }

    #[test]
    fn bridge_permission_response_requires_displayed_pending_request() {
        use claurst_bridge::PermissionResponseKind as Response;
        use tokio::sync::oneshot::error::TryRecvError;

        let (pending, mut rx) = bridge_permission_fixture("active");
        let mut dialog = Some(permission_request_from_core(&pending));
        let mut store = claurst_tools::PendingPermissionStore::default();
        handle_bridge_permission_response(&mut dialog, &mut store, "active", Response::Allow);
        assert!(
            dialog.is_some(),
            "missing pending decision must not hide the dialog"
        );
        assert_eq!(rx.try_recv(), Err(TryRecvError::Empty));

        store.waiting.insert("active".into(), pending);
        dialog = None;
        handle_bridge_permission_response(&mut dialog, &mut store, "active", Response::Allow);
        assert_eq!(rx.try_recv(), Err(TryRecvError::Empty));
        assert_eq!(store.waiting.len(), 1);
    }

    #[test]
    fn remote_prompt_waits_while_streaming() {
        let mut pending = std::collections::VecDeque::new();
        let (tx, mut rx) = tokio::sync::mpsc::channel(2);
        tx.try_send("first".to_owned()).unwrap();
        tx.try_send("second".to_owned()).unwrap();
        assert_eq!(take_remote_prompt(&mut pending, &mut rx, true, false), None);
        assert_eq!(rx.len(), 2);
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false).as_deref(),
            Some("first")
        );
    }

    #[test]
    fn remote_prompt_waits_for_query_completion() {
        let mut pending = std::collections::VecDeque::new();
        let (tx, mut rx) = tokio::sync::mpsc::channel(1);
        tx.try_send("pending".to_owned()).unwrap();
        assert_eq!(take_remote_prompt(&mut pending, &mut rx, false, true), None);
        assert_eq!(rx.len(), 1);
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false).as_deref(),
            Some("pending")
        );
    }

    #[test]
    fn remote_prompt_dequeues_one_at_a_time_in_order() {
        let mut pending = std::collections::VecDeque::new();
        let (tx, mut rx) = tokio::sync::mpsc::channel(2);
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false),
            None
        );
        tx.try_send("first".to_owned()).unwrap();
        tx.try_send("second".to_owned()).unwrap();
        drop(tx);
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false).as_deref(),
            Some("first")
        );
        assert_eq!(pending.len(), 1);
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false).as_deref(),
            Some("second")
        );
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false),
            None
        );
    }

    #[test]
    fn remote_prompt_preserves_primary_and_supplementary_observed_order() {
        let mut pending =
            std::collections::VecDeque::from(["primary first".to_owned(), "/exit".to_owned()]);
        let (tx, mut rx) = tokio::sync::mpsc::channel(2);
        tx.try_send("secondary first".to_owned()).unwrap();
        tx.try_send("secondary second".to_owned()).unwrap();
        for (streaming, running) in [(true, false), (false, true), (true, true)] {
            assert_eq!(
                take_remote_prompt(&mut pending, &mut rx, streaming, running),
                None
            );
            assert_eq!(pending.len(), 2);
            assert_eq!(rx.len(), 2);
        }
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false).as_deref(),
            Some("primary first")
        );
        pending.push_back("primary later".to_owned());
        for expected in [
            "/exit",
            "secondary first",
            "secondary second",
            "primary later",
        ] {
            assert_eq!(
                take_remote_prompt(&mut pending, &mut rx, false, false).as_deref(),
                Some(expected)
            );
        }
        assert_eq!(
            take_remote_prompt(&mut pending, &mut rx, false, false),
            None
        );
    }

    fn tool_names(tools: &[Box<dyn claurst_tools::Tool>]) -> Vec<String> {
        let mut names: Vec<String> = tools.iter().map(|t| t.name().to_string()).collect();
        names.sort();
        names
    }

    fn test_agent(access: &str, prompt: &str) -> claurst_core::AgentDefinition {
        claurst_core::AgentDefinition {
            description: None,
            model: None,
            temperature: None,
            prompt: Some(prompt.to_string()),
            access: access.to_string(),
            visible: true,
            max_turns: None,
            color: None,
        }
    }

    #[test]
    fn tui_reserved_modes_ignore_project_agent_overrides() {
        let mut config_agents = std::collections::HashMap::new();
        config_agents.insert(
            "plan".to_string(),
            test_agent("full", "malicious project plan prompt"),
        );

        let def = resolve_tui_agent_mode("plan", &config_agents)
            .expect("built-in plan mode should resolve");
        assert_eq!(def.access, "read-only");
        assert_ne!(def.prompt.as_deref(), Some("malicious project plan prompt"));
    }

    #[test]
    fn tui_non_reserved_modes_can_use_project_agents() {
        let mut config_agents = std::collections::HashMap::new();
        config_agents.insert("custom".to_string(), test_agent("full", "custom prompt"));

        let def = resolve_tui_agent_mode("custom", &config_agents)
            .expect("custom project agent should resolve");
        assert_eq!(def.access, "full");
        assert_eq!(def.prompt.as_deref(), Some("custom prompt"));
    }

    #[test]
    fn startup_agent_defaults_to_configured_familiar() {
        assert_eq!(
            startup_agent_name(None, Some("Wisp")),
            Some("wisp".to_string())
        );
    }

    #[test]
    fn startup_agent_prefers_explicit_agent_over_familiar() {
        assert_eq!(
            startup_agent_name(Some("Explore"), Some("Wisp")),
            Some("explore".to_string())
        );
    }

    #[test]
    fn filter_full_returns_input_unchanged() {
        let all = Arc::new(claurst_tools::all_tools());
        let before = tool_names(&all);
        let filtered = filter_tools_for_agent(all.clone(), "full");
        assert_eq!(tool_names(&filtered), before);
    }

    #[test]
    fn filter_read_only_excludes_write_and_exec_tools() {
        let all = Arc::new(claurst_tools::all_tools());
        let filtered = filter_tools_for_agent(all, "read-only");
        let names = tool_names(&filtered);
        // Write/exec tools must not appear.
        for forbidden in ["Bash", "Edit", "Write", "NotebookEdit"] {
            assert!(
                !names.contains(&forbidden.to_string()),
                "read-only must not include {forbidden}, got {names:?}"
            );
        }
    }

    #[test]
    fn filter_unknown_access_falls_back_to_read_only() {
        let all = Arc::new(claurst_tools::all_tools());
        let read_only = tool_names(&filter_tools_for_agent(all.clone(), "read-only"));
        // Genuinely unknown tiers must fail closed to read-only — they trip
        // the warning path inside `resolve_access_tier`, not the silent
        // case/whitespace canonicalization.
        for unknown in ["readonly", "i-am-evil", "", "writeable", "full-access"] {
            let got = tool_names(&filter_tools_for_agent(all.clone(), unknown));
            assert_eq!(
                got, read_only,
                "unknown access {unknown:?} must fail closed to read-only"
            );
        }
    }

    #[test]
    fn filter_case_and_whitespace_canonicalize_silently() {
        let all = Arc::new(claurst_tools::all_tools());
        let full = tool_names(&filter_tools_for_agent(all.clone(), "full"));
        let read_only = tool_names(&filter_tools_for_agent(all.clone(), "read-only"));
        let search_only = tool_names(&filter_tools_for_agent(all.clone(), "search-only"));
        // Common surface variants should match their canonical tier rather
        // than fail closed — typos warn, case/whitespace do not.
        for (variant, expected) in [
            ("FULL", &full),
            (" full ", &full),
            ("READ-ONLY", &read_only),
            ("Read-Only", &read_only),
            ("  search-only\n", &search_only),
        ] {
            let got = tool_names(&filter_tools_for_agent(all.clone(), variant));
            assert_eq!(&got, expected, "variant {variant:?} should canonicalize");
        }
    }

    #[test]
    fn filter_search_only_limits_to_known_search_tools() {
        let all = Arc::new(claurst_tools::all_tools());
        let names = tool_names(&filter_tools_for_agent(all, "search-only"));
        // Must be a subset of the documented search-tool whitelist.
        const ALLOWED: &[&str] = &["Grep", "Glob", "Read", "WebSearch", "WebFetch"];
        for name in &names {
            assert!(
                ALLOWED.contains(&name.as_str()),
                "search-only emitted disallowed tool {name}, expected subset of {ALLOWED:?}"
            );
        }
    }

    #[test]
    fn hosted_review_headless_gets_extra_turn_budget() {
        let raw = r#"{
            "contract_version": "3",
            "trigger": "issue_mention",
            "repo": { "owner": "o", "name": "r", "clone_url": "https://github.com/o/r.git", "default_branch": "main" },
            "task": { "kind": "respond_to_mention", "issue_number": 7, "comment_body": "review this" },
            "familiar": { "id": "cody", "display_name": "Cody", "skills": [] },
            "workspace": { "root": "/tmp/ws" },
            "review_context": { "kind": "pull_request", "files": [{ "filename": "src/lib.rs" }] }
        }"#;
        let brief: SessionBrief = serde_json::from_str(raw).expect("brief parses");
        let mut query_config = claurst_query::QueryConfig {
            max_turns: 10,
            ..Default::default()
        };

        apply_headless_review_query_defaults(&mut query_config, Some(&brief));

        assert_eq!(query_config.max_turns, 40);
    }

    #[test]
    fn hosted_review_headless_caps_existing_turn_budget() {
        let raw = r#"{
            "contract_version": "3",
            "trigger": "issue_mention",
            "repo": { "owner": "o", "name": "r", "clone_url": "https://github.com/o/r.git", "default_branch": "main" },
            "task": { "kind": "respond_to_mention", "issue_number": 7, "comment_body": "review this" },
            "familiar": { "id": "cody", "display_name": "Cody", "skills": [] },
            "workspace": { "root": "/tmp/ws" },
            "review_context": { "kind": "pull_request", "files": [{ "filename": "src/lib.rs" }] }
        }"#;
        let brief: SessionBrief = serde_json::from_str(raw).expect("brief parses");
        let mut query_config = claurst_query::QueryConfig {
            max_turns: 99,
            ..Default::default()
        };

        apply_headless_review_query_defaults(&mut query_config, Some(&brief));

        assert_eq!(query_config.max_turns, 40);
    }

    #[test]
    fn non_review_headless_keeps_turn_budget() {
        let raw = r#"{
            "contract_version": "3",
            "trigger": "issue_mention",
            "repo": { "owner": "o", "name": "r", "clone_url": "https://github.com/o/r.git", "default_branch": "main" },
            "task": { "kind": "respond_to_mention", "issue_number": 7, "comment_body": "answer this" },
            "familiar": { "id": "cody", "display_name": "Cody", "skills": [] },
            "workspace": { "root": "/tmp/ws" }
        }"#;
        let brief: SessionBrief = serde_json::from_str(raw).expect("brief parses");
        let mut query_config = claurst_query::QueryConfig {
            max_turns: 10,
            ..Default::default()
        };

        apply_headless_review_query_defaults(&mut query_config, Some(&brief));

        assert_eq!(query_config.max_turns, 10);
    }

    #[test]
    fn hosted_review_filters_write_and_execute_tools_by_default() {
        let all = Arc::new(claurst_tools::all_tools());
        let config = Config {
            hosted_review: claurst_core::hosted_review::HostedReviewConfig {
                enabled: true,
                ..Default::default()
            },
            ..Default::default()
        };

        let names = tool_names(&filter_tools_for_hosted_review(all, &config));

        assert!(names.contains(&"Read".to_string()));
        for forbidden in ["Bash", "Edit", "Write", "NotebookEdit", "ApplyPatch", "LSP"] {
            assert!(
                !names.contains(&forbidden.to_string()),
                "hosted review default tools must not include {forbidden}, got {names:?}"
            );
        }
    }

    #[test]
    fn hosted_review_trusted_policy_can_keep_write_tools() {
        let all = Arc::new(claurst_tools::all_tools());
        let before = tool_names(&all);
        let config = Config {
            hosted_review: claurst_core::hosted_review::HostedReviewConfig {
                enabled: true,
                allow_write_tools: true,
                ..Default::default()
            },
            ..Default::default()
        };

        assert_eq!(
            tool_names(&filter_tools_for_hosted_review(all, &config)),
            before
        );
    }

    #[test]
    fn hosted_repair_allows_only_repository_file_tools() {
        let all = Arc::new(claurst_tools::all_tools());
        let config = Config {
            hosted_review: claurst_core::hosted_review::HostedReviewConfig {
                enabled: true,
                allow_file_write_tools: true,
                ..Default::default()
            },
            ..Default::default()
        };

        let names = tool_names(&filter_tools_for_hosted_review(all, &config));
        for required in ["Read", "Grep", "Glob", "Edit", "Write", "ApplyPatch"] {
            assert!(
                names.contains(&required.to_string()),
                "hosted repair missing {required}: {names:?}"
            );
        }
        for forbidden in [
            "Bash",
            "PtyBash",
            "PowerShell",
            "WebSearch",
            "WebFetch",
            "Agent",
            "TeamCreate",
            "Skill",
            "ToolSearch",
            "ListMcpResources",
            "ReadMcpResource",
        ] {
            assert!(
                !names.contains(&forbidden.to_string()),
                "hosted repair must not include {forbidden}: {names:?}"
            );
        }
        assert!(
            names.iter().all(|name| [
                "Read",
                "Grep",
                "Glob",
                "Edit",
                "Write",
                "ApplyPatch",
                "BatchEdit",
                "NotebookEdit",
            ]
            .contains(&name.as_str())),
            "hosted repair exposed an unexpected tool: {names:?}"
        );
    }

    #[test]
    fn hosted_repair_cli_requires_the_structured_headless_contract() {
        assert!(Cli::try_parse_from(["coven-code", "--hosted-repair"]).is_err());
        assert!(Cli::try_parse_from([
            "coven-code",
            "--headless",
            "--hosted-repair",
            "--context",
            "brief.json",
            "--output",
            "result.json",
        ])
        .is_ok());
        assert!(Cli::try_parse_from([
            "coven-code",
            "--headless",
            "--hosted-review",
            "--hosted-repair",
            "--context",
            "brief.json",
            "--output",
            "result.json",
        ])
        .is_err());
        assert!(Cli::try_parse_from([
            "coven-code",
            "--headless",
            "--hosted-repair",
            "--dangerously-skip-permissions",
            "--context",
            "brief.json",
            "--output",
            "result.json",
        ])
        .is_err());
    }

    #[test]
    fn github_context_forces_noninteractive_permission_bypass() {
        assert_eq!(
            permission_mode_for_invocation(CliPermissionMode::Default, true),
            PermissionMode::BypassPermissions
        );
        assert_eq!(
            permission_mode_for_invocation(CliPermissionMode::Plan, true),
            PermissionMode::BypassPermissions
        );
        assert_eq!(
            permission_mode_for_invocation(CliPermissionMode::AcceptEdits, false),
            PermissionMode::AcceptEdits
        );
    }

    // NOTE: the coven-github headless-contract types + behavior moved to the
    // `headless` module; their conformance tests live in `headless.rs`
    // (`#[cfg(test)] mod tests`), pinned to the vendored golden fixtures.

    // ── coven-runtimes manifest drift guard ─────────────────────────────────
    //
    // `spec/runtime-manifest/coven-code.json` is the runtime adapter manifest
    // accepted into the OpenCoven/coven-runtimes canonical registry. Registry
    // versions are immutable: if one of these tests fails, a CLI flag the
    // manifest depends on drifted. Fix the flag or publish a new manifest
    // version and re-accept it in coven-runtimes (`conjure registry add`) —
    // do not silently edit the shipped 1.0.0 definition.

    const RUNTIME_MANIFEST: &str =
        include_str!("../../../../spec/runtime-manifest/coven-code.json");

    fn runtime_adapter() -> coven_runtime_spec::RuntimeAdapter {
        let manifest = coven_runtime_spec::AdapterManifest::from_json(RUNTIME_MANIFEST)
            .expect("runtime manifest parses");
        assert_eq!(manifest.adapters.len(), 1, "exactly one adapter expected");
        manifest.adapters.into_iter().next().expect("one adapter")
    }

    #[test]
    fn runtime_manifest_passes_spec_validation() {
        let adapter = runtime_adapter();
        let errors = coven_runtime_spec::validate_adapter(&adapter);
        assert!(errors.is_empty(), "spec violations: {errors:?}");
        assert_eq!(adapter.id, "coven-code");
        assert_eq!(adapter.executable, "coven-code");
    }

    #[test]
    fn runtime_manifest_declares_full_stream_capabilities() {
        let caps = runtime_adapter().capabilities;
        assert!(caps.stream, "stream mode is implemented in stream_mode.rs");
        assert!(caps.preassigned_session_id);
        assert!(caps.think, "think maps to --thinking");
        assert!(caps.speed, "speed maps to --effort");
    }

    #[test]
    fn runtime_manifest_stream_launch_args_parse() {
        let adapter = runtime_adapter();
        let stream = adapter.stream_args.as_ref().expect("stream_args declared");

        let mut argv: Vec<String> = vec!["coven-code".into()];
        argv.extend(stream.prefix_args.iter().cloned());
        let session_flag = stream
            .session_id_flag
            .as_deref()
            .expect("session_id_flag declared");
        argv.push(session_flag.to_string());
        argv.push("00000000-0000-0000-0000-000000000000".into());
        argv.push(adapter.model_flag.clone().expect("model_flag declared"));
        argv.push("claude-sonnet-4-5".into());
        argv.push(
            adapter
                .system_prompt_flag
                .clone()
                .expect("system_prompt_flag declared"),
        );
        argv.push("identity preamble".into());

        let cli = Cli::try_parse_from(&argv).expect("stream launch argv parses");
        assert!(cli.print);
        assert_eq!(cli.input_format, CliInputFormat::StreamJson);
        assert_eq!(cli.output_format, CliOutputFormat::StreamJson);
        assert_eq!(
            cli.session_id_flag.as_deref(),
            Some("00000000-0000-0000-0000-000000000000")
        );
    }

    #[test]
    fn runtime_manifest_resume_flag_parses() {
        let adapter = runtime_adapter();
        let stream = adapter.stream_args.as_ref().expect("stream_args declared");
        let resume_flag = stream.resume_flag.as_deref().expect("resume_flag declared");

        let mut argv: Vec<String> = vec!["coven-code".into()];
        argv.extend(stream.prefix_args.iter().cloned());
        argv.push(resume_flag.to_string());
        argv.push("11111111-1111-1111-1111-111111111111".into());

        let cli = Cli::try_parse_from(&argv).expect("resume argv parses");
        assert_eq!(
            cli.resume.as_deref(),
            Some("11111111-1111-1111-1111-111111111111")
        );
    }

    #[test]
    fn runtime_manifest_sandbox_mapping_parses_for_both_policies() {
        let adapter = runtime_adapter();
        let sandbox = adapter.sandbox.as_ref().expect("sandbox declared");

        for (permission, expected) in [
            (
                coven_runtime_spec::Permission::Full,
                CliPermissionMode::BypassPermissions,
            ),
            (
                coven_runtime_spec::Permission::ReadOnly,
                CliPermissionMode::Plan,
            ),
        ] {
            let mut argv: Vec<String> = vec!["coven-code".into()];
            argv.extend(adapter.non_interactive_prompt_prefix_args.iter().cloned());
            argv.extend(sandbox.args(permission));
            argv.push("do the thing".into());

            let cli = Cli::try_parse_from(&argv)
                .unwrap_or_else(|e| panic!("{permission:?} sandbox argv rejected: {e}"));
            assert_eq!(cli.permission_mode, expected);
        }
    }

    #[test]
    fn runtime_manifest_one_shot_launch_parses() {
        let adapter = runtime_adapter();
        let mut argv: Vec<String> = vec!["coven-code".into()];
        argv.extend(adapter.non_interactive_prompt_prefix_args.iter().cloned());
        argv.push("hello".into());

        let cli = Cli::try_parse_from(&argv).expect("one-shot argv parses");
        assert!(cli.print);
        assert_eq!(cli.prompt.as_deref(), Some("hello"));
    }

    // --- should_show_engine_notice truth table ---

    #[test]
    fn engine_notice_shown_for_direct_interactive_tty() {
        // All three conditions met: interactive + TTY + no COVEN_PARENT
        assert!(should_show_engine_notice(true, true, false));
    }

    #[test]
    fn engine_notice_suppressed_when_coven_parent_set() {
        // Driven by the unified coven CLI
        assert!(!should_show_engine_notice(true, true, true));
    }

    #[test]
    fn engine_notice_suppressed_when_non_interactive() {
        // Headless/print/prompt mode
        assert!(!should_show_engine_notice(false, true, false));
    }

    #[test]
    fn engine_notice_suppressed_when_not_a_tty() {
        // Piped stdout/stderr (e.g. CI, script)
        assert!(!should_show_engine_notice(true, false, false));
    }

    fn accounting_goal(
        id: &str,
        status: claurst_core::GoalStatus,
        tokens_used: u64,
    ) -> claurst_core::Goal {
        claurst_core::Goal {
            id: id.to_string(),
            session_id: "session".to_string(),
            objective: "finish".to_string(),
            status,
            token_budget: None,
            tokens_used,
            time_used_secs: 0,
            turns_used: 0,
            created_at_ms: 1,
            updated_at_ms: 1,
        }
    }

    fn accounting_baseline(id: &str, tracker_total: u64) -> GoalTurnBaseline {
        GoalTurnBaseline {
            goal_id: id.to_string(),
            session_id: "session".to_string(),
            store_path: PathBuf::from("unused-accounting-fixture.sqlite"),
            tracker_total,
            started_at: std::time::Instant::now(),
        }
    }

    #[test]
    fn goal_accounting_excludes_pre_goal_tracker_usage() {
        let baseline = accounting_baseline("goal-1", 1_000);
        let goal = accounting_goal("goal-1", claurst_core::GoalStatus::Active, 30);

        assert_eq!(
            decide_goal_turn_accounting(Some(&baseline), Some(&goal), 1_025).unwrap(),
            GoalTurnAccountingDecision::Record {
                total_tokens_used: 55
            }
        );
    }

    #[test]
    fn goal_accounting_skips_goal_that_became_terminal_during_turn() {
        let baseline = accounting_baseline("goal-1", 100);
        let goal = accounting_goal("goal-1", claurst_core::GoalStatus::Complete, 9);

        assert_eq!(
            decide_goal_turn_accounting(Some(&baseline), Some(&goal), 110).unwrap(),
            GoalTurnAccountingDecision::Skip
        );
    }

    #[test]
    fn goal_accounting_skips_terminal_goal_without_active_baseline() {
        let goal = accounting_goal("goal-1", claurst_core::GoalStatus::Paused, 9);

        assert_eq!(
            decide_goal_turn_accounting(None, Some(&goal), 110).unwrap(),
            GoalTurnAccountingDecision::Skip
        );
    }

    #[test]
    fn goal_accounting_rejects_active_goal_without_baseline() {
        let goal = accounting_goal("goal-1", claurst_core::GoalStatus::Active, 0);

        let error = decide_goal_turn_accounting(None, Some(&goal), 110).unwrap_err();

        assert!(error.contains("missing active-goal turn baseline"));
    }

    #[test]
    fn goal_accounting_rejects_replacement_goal_identity() {
        let baseline = accounting_baseline("old-goal", 100);
        let replacement = accounting_goal("new-goal", claurst_core::GoalStatus::Active, 0);

        let error =
            decide_goal_turn_accounting(Some(&baseline), Some(&replacement), 110).unwrap_err();

        assert!(error.contains("goal changed during the turn"));
    }

    #[test]
    fn goal_accounting_reports_tracker_underflow() {
        let baseline = accounting_baseline("goal-1", 100);
        let goal = accounting_goal("goal-1", claurst_core::GoalStatus::Active, 0);

        let error = decide_goal_turn_accounting(Some(&baseline), Some(&goal), 99).unwrap_err();

        assert!(error.contains("tracker moved backwards"));
    }

    fn goal_capture_context(path: PathBuf) -> ToolContext {
        ToolContext {
            working_dir: path.parent().unwrap().to_path_buf(),
            permission_mode: PermissionMode::Default,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::Default,
            }),
            cost_tracker: CostTracker::new(),
            session_id: "session".to_string(),
            goal_turn: claurst_core::goal::GoalTurnContext::Pending(path),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        }
    }

    #[test]
    fn goal_baseline_and_query_context_share_one_snapshot() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("goals.sqlite");
        let store = claurst_core::GoalStore::open(&path).unwrap();
        let original = store
            .set_goal("session", "original prompt A", None)
            .unwrap();
        let mut ctx = goal_capture_context(path.clone());
        let baseline = capture_goal_turn_baseline(&mut ctx, 17).unwrap().unwrap();
        store
            .set_goal("session", "replacement prompt B", None)
            .unwrap();
        let again = capture_goal_turn_baseline(&mut ctx, 21).unwrap().unwrap();
        let captured = ctx.goal_turn.captured().unwrap();
        assert_eq!(captured.goal(), &original);
        assert_eq!(baseline.goal_id, original.id);
        assert_eq!(again.goal_id, baseline.goal_id);
        assert_eq!(baseline.session_id, captured.goal().session_id);
        assert_eq!(baseline.store_path, captured.store_path());
        assert_eq!(baseline.store_path, std::fs::canonicalize(path).unwrap());
        assert_eq!(baseline.tracker_total, 17);
        assert!(claurst_core::goal_system_prompt_addendum(captured.goal())
            .contains("original prompt A"));
    }

    #[test]
    fn goal_baseline_empty_or_failed_capture_cannot_adopt_later_goal() {
        let dir = tempfile::tempdir().unwrap();
        for initially_fails in [false, true] {
            let parent = dir
                .path()
                .join(if initially_fails { "failed" } else { "empty" });
            if initially_fails {
                std::fs::write(&parent, "not a directory").unwrap();
            } else {
                std::fs::create_dir(&parent).unwrap();
            }
            let path = parent.join("goals.sqlite");
            let mut ctx = goal_capture_context(path.clone());
            let first = capture_goal_turn_baseline(&mut ctx, 10);
            if initially_fails {
                assert!(first.is_err());
                std::fs::remove_file(&parent).unwrap();
                std::fs::create_dir(&parent).unwrap();
            } else {
                assert!(first.unwrap().is_none());
            }
            let store = claurst_core::GoalStore::open(&path).unwrap();
            let later = store.set_goal("session", "later B", None).unwrap();
            let retry = capture_goal_turn_baseline(&mut ctx, 20);
            if initially_fails {
                assert!(retry.is_err());
            } else {
                assert!(retry.unwrap().is_none());
            }
            assert!(ctx.goal_turn.captured().is_none());
            assert_eq!(store.try_get_goal("session").unwrap().unwrap(), later);
        }
    }

    fn work_goal(session_id: &str) -> claurst_core::goal::Goal {
        claurst_core::goal::Goal {
            id: format!("goal-{session_id}"),
            session_id: session_id.to_string(),
            objective: format!("objective of {session_id}"),
            status: claurst_core::goal::GoalStatus::Active,
            token_budget: None,
            tokens_used: 0,
            time_used_secs: 0,
            turns_used: 0,
            created_at_ms: 0,
            updated_at_ms: 0,
        }
    }

    #[test]
    fn an_open_memory_page_reads_off_thread_once_per_refresh() {
        use claurst_tui::application::memory::MemorySnapshot;
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        let mut poll = MemoryPoll::default();
        let (sender, receiver) = std::sync::mpsc::channel();
        let mut receiver = Some(receiver);
        refresh_memory_snapshot(&mut app, true, &mut poll, || receiver.take().unwrap());
        assert!(poll.in_flight.is_some(), "a read started");
        assert_eq!(app.memory_snapshot, MemorySnapshot::NotRead);
        // Still in flight: no second read is started.
        refresh_memory_snapshot(&mut app, true, &mut poll, || panic!("second read"));
        sender.send(MemorySnapshot::Offline).unwrap();
        refresh_memory_snapshot(&mut app, true, &mut poll, || panic!("second read"));
        assert_eq!(app.memory_snapshot, MemorySnapshot::Offline);
        // Fresh: no new read until the refresh interval passes.
        refresh_memory_snapshot(&mut app, true, &mut poll, || panic!("too soon"));
        poll.last_read = Some(std::time::Instant::now() - MEMORY_REFRESH * 2);
        poll.last_spawn = Some(std::time::Instant::now() - MEMORY_REFRESH * 2);
        let (_again, again_rx) = std::sync::mpsc::channel();
        let mut again_rx = Some(again_rx);
        refresh_memory_snapshot(&mut app, true, &mut poll, || again_rx.take().unwrap());
        assert!(poll.in_flight.is_some(), "re-read after the interval");
    }

    #[test]
    fn closing_the_memory_page_drops_the_snapshot_and_a_late_answer() {
        use claurst_tui::application::memory::MemorySnapshot;
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        let mut poll = MemoryPoll::default();
        let (sender, receiver) = std::sync::mpsc::channel();
        let mut receiver = Some(receiver);
        refresh_memory_snapshot(&mut app, true, &mut poll, || receiver.take().unwrap());
        app.memory_snapshot = MemorySnapshot::UpdateRequired;
        refresh_memory_snapshot(&mut app, false, &mut poll, || panic!("closed"));
        assert_eq!(app.memory_snapshot, MemorySnapshot::NotRead);
        assert!(poll.in_flight.is_none() && poll.last_read.is_none());
        assert!(poll.last_spawn.is_some(), "spawn time survives the close");
        assert!(
            sender.send(MemorySnapshot::Offline).is_err(),
            "late answer has nowhere to land"
        );
    }

    #[test]
    fn a_memory_read_that_dies_is_reported_not_left_reading() {
        use claurst_tui::application::memory::MemorySnapshot;
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        let mut poll = MemoryPoll::default();
        let (sender, receiver) = std::sync::mpsc::channel::<MemorySnapshot>();
        let mut receiver = Some(receiver);
        refresh_memory_snapshot(&mut app, true, &mut poll, || receiver.take().unwrap());
        drop(sender);
        refresh_memory_snapshot(&mut app, true, &mut poll, || panic!("retry storm"));
        assert!(matches!(app.memory_snapshot, MemorySnapshot::Failed(_)));
        // The failure counts as a read: no immediate respawn.
        refresh_memory_snapshot(&mut app, true, &mut poll, || panic!("retry storm"));
        assert!(poll.in_flight.is_none());
    }

    #[test]
    fn reopening_the_memory_page_quickly_does_not_start_a_new_read_at_once() {
        use claurst_tui::application::memory::MemorySnapshot;
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        let mut poll = MemoryPoll::default();
        let (_sender, receiver) = std::sync::mpsc::channel();
        let mut receiver = Some(receiver);
        refresh_memory_snapshot(&mut app, true, &mut poll, || receiver.take().unwrap());
        // Tab past the page and straight back.
        refresh_memory_snapshot(&mut app, false, &mut poll, || panic!("closed"));
        refresh_memory_snapshot(&mut app, true, &mut poll, || panic!("spawned on reopen"));
        assert_eq!(
            app.memory_snapshot,
            MemorySnapshot::NotRead,
            "no old snapshot"
        );
        // After the minimum gap a reopened page reads again.
        poll.last_spawn = Some(std::time::Instant::now() - MEMORY_MIN_SPAWN_GAP * 2);
        let (_again, again_rx) = std::sync::mpsc::channel();
        let mut again_rx = Some(again_rx);
        refresh_memory_snapshot(&mut app, true, &mut poll, || again_rx.take().unwrap());
        assert!(poll.in_flight.is_some());
    }

    #[test]
    fn the_work_snapshot_rereads_the_goal_at_once_on_a_session_switch_and_throttles_otherwise() {
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        let mut last = None;
        let mut reads = Vec::new();
        {
            let mut reader = |id: &str| {
                reads.push(id.to_string());
                (id == "session-a").then(|| Ok(work_goal(id)))
            };
            refresh_work_sources(&mut app, "session-a", &mut last, &mut reader);
            refresh_work_sources(&mut app, "session-a", &mut last, &mut reader);
            assert_eq!(
                app.work_sources
                    .goal
                    .as_ref()
                    .map(|goal| goal.as_ref().unwrap().id.clone()),
                Some("goal-session-a".to_string())
            );
            refresh_work_sources(&mut app, "session-b", &mut last, &mut reader);
        }
        assert_eq!(
            reads,
            ["session-a", "session-b"],
            "throttled within a session"
        );
        assert!(
            app.work_sources.goal.is_none(),
            "session-a's goal is not shown in session-b"
        );
    }

    #[test]
    fn a_failed_goal_read_keeps_this_sessions_last_goal_but_not_another_sessions() {
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        let mut last = None;
        refresh_work_sources(&mut app, "session-a", &mut last, |id| {
            Some(Ok(work_goal(id)))
        });
        let expired = std::time::Instant::now() - WORK_GOAL_REFRESH * 2;
        last = Some((expired, "session-a".to_string()));
        refresh_work_sources(&mut app, "session-a", &mut last, |_| {
            Some(Err("database is locked".to_string()))
        });
        assert!(
            matches!(&app.work_sources.goal, Some(Ok(goal)) if goal.id == "goal-session-a"),
            "a locked store keeps the last goal"
        );
        refresh_work_sources(&mut app, "session-b", &mut last, |_| {
            Some(Err("database is locked".to_string()))
        });
        assert!(
            matches!(&app.work_sources.goal, Some(Err(_))),
            "session-a's goal is not kept for session-b"
        );
    }

    #[test]
    fn the_work_snapshot_keeps_only_the_last_background_output_line() {
        let registry = claurst_core::tasks::global_registry();
        let task = claurst_core::tasks::BackgroundTask::new("chatty");
        let id = task.id.clone();
        registry.register(task);
        for n in 0..5 {
            registry.append_output(&id, &format!("line {n}"));
        }
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        refresh_work_sources(&mut app, "session-a", &mut None, |_| None);
        registry.complete(&id);
        let snapshot = app
            .work_sources
            .background
            .iter()
            .find(|task| task.id == id)
            .expect("snapshot");
        assert_eq!(snapshot.output, ["line 4"]);
    }

    #[test]
    fn the_work_snapshot_copies_the_in_memory_stores() {
        let id = format!("work-snapshot-{}", std::process::id());
        let now = chrono::Utc::now();
        claurst_tools::TASK_STORE.insert(
            id.clone(),
            claurst_tools::Task {
                id: id.clone(),
                subject: "snapshot me".to_string(),
                description: String::new(),
                status: claurst_tools::TaskStatus::Pending,
                owner: None,
                blocks: Vec::new(),
                blocked_by: Vec::new(),
                metadata: None,
                output: None,
                created_at: now,
                updated_at: now,
            },
        );
        let mut app = claurst_tui::app::App::new(
            claurst_core::config::Config::default(),
            claurst_core::cost::CostTracker::new(),
        );
        refresh_work_sources(&mut app, "session-a", &mut None, |_| None);
        claurst_tools::TASK_STORE.remove(&id);
        assert!(app
            .work_sources
            .model_tasks
            .iter()
            .any(|task| task.id == id));
    }
}

#[cfg(test)]
mod goal_dispatch_tests;
