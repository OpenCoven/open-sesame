// claurst-tui: Terminal UI using ratatui + crossterm for Coven Code.
//
// This crate provides the interactive terminal interface including:
// - Message display with syntax highlighting
// - Input prompt with history
// - Streaming response rendering
// - Tool execution progress display
// - Permission dialogs
// - Cost/token tracking display
// - Notification banners
// - Help, history-search, message-selector, and rewind overlays
// - Bridge connection status badge
// - Plugin hint banners

use crossterm::event::{
    DisableMouseCapture, EnableMouseCapture, KeyboardEnhancementFlags, PopKeyboardEnhancementFlags,
    PushKeyboardEnhancementFlags,
};
// EnableBracketedPaste is enabled on macOS and Linux only. On Windows, it causes
// Windows Terminal to wrap Ctrl+V content in VT escape sequences that crossterm's
// Windows Console API backend doesn't decode as `Event::Paste` — the bytes land as
// raw key events, turning every `\n` into a prompt submit. Unix terminals (macOS/Linux)
// handle bracketed paste correctly, allowing multi-line pastes to preserve newlines.
#[cfg(not(target_os = "windows"))]
use crossterm::event::{DisableBracketedPaste, EnableBracketedPaste};
use crossterm::execute;
use crossterm::terminal::{
    disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen,
};
use quiet_backend::QuietBackend;
use ratatui::backend::CrosstermBackend;
use ratatui::Terminal;
use std::io::{self, Stdout};

fn env_flag_is_enabled(value: &str) -> bool {
    !matches!(
        value.trim().to_ascii_lowercase().as_str(),
        "" | "0" | "false" | "off" | "no"
    )
}

fn should_push_keyboard_enhancement<I, K, V>(env: I) -> bool
where
    I: IntoIterator<Item = (K, V)>,
    K: AsRef<str>,
    V: AsRef<str>,
{
    // Cave embeds us in xterm.js. Its normal key input works, but the kitty
    // "report all keys as escape codes" mode can make printable keys vanish.
    let mut explicit = None;
    let mut in_cave = false;
    for (key, value) in env {
        let key = key.as_ref();
        let value = value.as_ref();
        if key == "COVEN_CODE_KEYBOARD_ENHANCEMENT" {
            explicit = Some(env_flag_is_enabled(value));
        }
        if key == "COVENCAVE" && env_flag_is_enabled(value) {
            in_cave = true;
        }
    }
    explicit.unwrap_or(!in_cave)
}

fn should_push_keyboard_enhancement_for_process() -> bool {
    should_push_keyboard_enhancement(std::env::vars())
}

// ---------------------------------------------------------------------------
// Sub-modules
// ---------------------------------------------------------------------------

/// Agent definitions list and coordinator progress view.
pub mod agents_view;
/// Application state and main event loop.
pub mod app;
/// Typed presentation seam shared by the Classic and Next renderers.
pub mod application;
/// Model-initiated question dialog (AskUserQuestion tool).
pub mod ask_user_dialog;
/// Bridge connection state and status badge.
pub mod bridge_state;
/// Startup confirmation dialog for --dangerously-skip-permissions mode.
pub mod bypass_permissions_dialog;
/// Presentation-only metadata for command discovery surfaces.
pub mod command_palette;
/// Context window and rate-limit visualization overlay (/context).
pub mod context_viz;

pub mod coven_status;
/// Device code / browser-based auth overlay (Claude OAuth, Codex login).
pub mod device_auth_dialog;
/// Reusable fuzzy-search selection dialog widget.
pub mod dialog_select;
/// Permission dialogs and confirmation dialogs.
pub mod dialogs;
/// Diff viewer dialog (two-pane: file list + unified diff detail).
pub mod diff_viewer;
/// Effort-level picker dialog (/effort).
pub mod effort_picker;
/// MCP elicitation dialog (form-based user input requested by MCP servers).
pub mod elicitation_dialog;
/// Export format picker dialog (/export).
pub mod export_dialog;
/// Static themed familiar card composer (welcome panel, F2 switcher, /agents).
pub mod familiar_card;
/// Familiar card image lookup and terminal escape rendering.
pub mod familiar_image;
/// Familiar theming: palettes + archetypes per familiar id.
pub mod familiar_theme;
/// Session quality feedback survey overlay.
pub mod feedback_survey;
/// Figure/icon constants matching src/constants/figures.ts
pub mod figures;
/// File injection utilities for parsing @file references.
pub mod file_injection;
/// File injection warning dialog (shown when oversized files detected).
pub mod file_injection_dialog;
/// Coven familiar handoff command support.
pub mod handoff;
/// Read-only hooks configuration browser.
pub mod hooks_config_menu;
/// Clipboard image paste and Ctrl+V text paste.
pub mod image_paste;
/// Import-config preview and confirmation dialog.
pub mod import_config_dialog;
/// Input helpers: slash command parsing.
pub mod input;
/// Startup dialog for malformed settings.json or AGENTS.md.
pub mod invalid_config_dialog;
/// Masked text input overlay for entering API keys.
pub mod key_input_dialog;
/// Inline image rendering via the Kitty graphics protocol (with text fallback).
pub mod kitty_image;
/// Rune mascot rendering.
pub mod mascot;
/// MCP server management UI.
pub mod mcp_view;
/// Memory file selector overlay (AGENTS.md browser).
pub mod memory_file_selector;
/// Memory update notification banner (shown after Coven Code updates a AGENTS.md file).
pub mod memory_update_notification;
/// Message copy utilities for different formatting options (markdown, plaintext, code, JSON).
pub mod message_copy;
/// Message type renderers (assistant, user, tool use, etc.).
pub mod messages;
/// Model picker overlay (/model command).
pub mod model_picker;
/// Opt-in Next renderer (`COVEN_CODE_UI=next`).
pub mod next;
/// Notification / banner system.
pub mod notifications;
/// First-launch onboarding / welcome dialog.
pub mod onboarding_dialog;
/// Post-paint OSC 8 hyperlink emission — makes URLs Ctrl/Cmd-clickable.
pub mod osc8;
/// Overage credit upsell banner (shown when user exceeds free-tier limit).
pub mod overage_upsell;
/// Help overlay, history search, message selector, rewind flow.
pub mod overlays;
/// Plugin hint/recommendation UI.
pub mod plugin_views;
/// Complete prompt input with vim mode, history, typeahead, and paste handling.
pub mod prompt_input;
pub mod quiet_backend;
pub mod rate_limit_recovery;
/// All ratatui rendering logic.
pub mod render;
/// Full-response reader for completed assistant messages.
pub mod response_reader;
/// Session branching overlay (Ctrl+B) — create and switch between conversation branches.
pub mod session_branching;
/// Session browser overlay (/session, /resume, /rename, /export).
pub mod session_browser;
/// Full-screen tabbed settings interface.
pub mod settings_screen;
/// Interactive skills picker dialog (/skills).
pub mod skills_picker;
/// Stats dialog with token usage and cost charts.
pub mod stats_dialog;
/// Task progress overlay (Ctrl+T) — shows task status with inline toggle.
pub mod tasks_overlay;
/// Color palette management for different themes and accessibility support.
pub mod theme_colors;
/// Theme picker overlay.
pub mod theme_screen;
/// Turn-aware transcript grouping and metadata helpers.
pub mod transcript_turn;
/// Virtual scrollable list for efficient message rendering.
pub mod virtual_list;
/// Push-to-talk voice capture and Whisper transcription.
pub mod voice_capture;
/// Voice mode availability notice (shown when voice is available but not enabled).
pub mod voice_mode_notice;

// ---------------------------------------------------------------------------
// Public re-exports
// ---------------------------------------------------------------------------

pub use agents_view::{
    load_agent_definitions, render_agents_menu, render_coordinator_status, AgentDefinition,
    AgentInfo, AgentStatus, AgentsMenuState,
};
pub use app::{try_copy_to_clipboard, App};
pub use bypass_permissions_dialog::{
    render_bypass_permissions_dialog, BypassPermissionsDialogState,
};
pub use command_palette::{
    command_category_order, flatten_command_catalog, rank_commands, CommandPaletteContext,
    CommandPaletteEntry,
};
pub use dialog_select::{render_dialog_select, DialogSelectState, SelectItem, SelectItemKind};
pub use diff_viewer::{
    load_git_diff, parse_unified_diff, render_diff_dialog, DiffPane, DiffType, DiffViewerState,
};
pub use elicitation_dialog::{
    render_elicitation_dialog, ElicitationDialogState, ElicitationField, ElicitationFieldKind,
    ElicitationResult,
};
pub use feedback_survey::{FeedbackResponse, FeedbackSurveyStage, FeedbackSurveyState};
pub use hooks_config_menu::{HookEntry, HooksConfigMenuState};
pub use import_config_dialog::{render_import_config_dialog, ImportConfigDialogState};
pub use input::{is_slash_command, parse_slash_command};
pub use invalid_config_dialog::{
    render_invalid_config_dialog, InvalidConfigDialogState, InvalidConfigKind,
};
pub use key_input_dialog::{render_key_input_dialog, KeyInputDialogState};
pub use mcp_view::{render_mcp_view, McpServerView, McpToolView, McpViewState, McpViewStatus};
pub use memory_file_selector::{MemoryFile, MemoryFileSelectorState, MemoryFileType};
pub use memory_update_notification::{
    get_relative_memory_path, render_memory_update_notification, MemoryUpdateNotificationState,
};
pub use model_picker::{
    model_supports_effort, render_model_picker, EffortLevel, ModelEntry, ModelPickerState,
};
pub use notifications::NotificationKind;
pub use onboarding_dialog::{render_onboarding_dialog, OnboardingDialogState};
pub use overage_upsell::{render_overage_upsell, OverageCreditUpsellState};
pub use prompt_input::{
    compute_typeahead, handle_paste, render_prompt_input, InputMode, PromptInputState, VimFindKind,
    VimMode, VimOperator, VimPendingState,
};
pub use session_branching::{
    render_session_branching, BranchBrowserMode, BranchInfo, SessionBranchingState,
};
pub use session_browser::{
    render_session_browser, SessionBrowserMode, SessionBrowserState, SessionEntry,
};
pub use stats_dialog::{load_stats, render_stats_dialog, StatsDialogState, StatsTab};
pub use voice_mode_notice::{render_voice_mode_notice, VoiceModeNoticeState};
// (FreeModeField type is now per-provider; legacy callers may still import both names.)
pub use device_auth_dialog::{
    render_device_auth_dialog, DeviceAuthDialogState, DeviceAuthEvent, DeviceAuthStatus,
};
pub use file_injection::{build_file_blocks, parse_at_refs, AtFileIssue, AtFileRef};
pub use file_injection_dialog::{
    render_file_injection_dialog, FileInjectionDialogState, FileInjectionOutcome,
};

// ---------------------------------------------------------------------------
// Terminal initialization / teardown helpers (public API)
// ---------------------------------------------------------------------------

/// Restore terminal capabilities (alternate screen, mouse capture, bracketed paste, keyboard enhancement).
/// Used by both restore_terminal and the panic hook.
fn restore_terminal_cleanup() -> io::Result<()> {
    #[cfg(not(target_os = "windows"))]
    execute!(
        io::stdout(),
        LeaveAlternateScreen,
        DisableMouseCapture,
        DisableBracketedPaste,
        PopKeyboardEnhancementFlags,
    )?;

    // On Windows, KeyboardEnhancementFlags may not have been pushed
    // (conhost / older terminals reject the escape).  Pop is harmless
    // whether it succeeded or not — ignore errors on restore.
    #[cfg(target_os = "windows")]
    {
        // Pop may fail on legacy Windows conhost where the push was a no-op;
        // do it best-effort so cleanup never errors out the process.
        let _ = execute!(io::stdout(), PopKeyboardEnhancementFlags);
        execute!(io::stdout(), LeaveAlternateScreen, DisableMouseCapture)?;
    }

    Ok(())
}

/// Set up the terminal for TUI mode (raw mode + alternate screen + mouse capture).
///
/// Also installs a panic hook that restores the terminal before printing the
/// panic message.  Without this, any panic in rendering code leaves the
/// terminal in raw mode with mouse capture enabled — the user sees garbage
/// input until they run `reset`.
pub fn setup_terminal(renderer: application::UiRenderer) -> io::Result<AppTerminal> {
    // Chain on top of any existing hook (e.g. from a previous call or test harness).
    // Only restore the terminal when the panic originates on the main thread.
    // Tokio worker threads also trigger this process-wide hook (Tokio catches
    // the panic internally but the hook still fires), so without this guard any
    // panicking background task would destroy the live TUI display while the
    // main render loop is still running.
    let main_thread_id = std::thread::current().id();
    let original_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |panic_info| {
        if std::thread::current().id() == main_thread_id {
            // Best-effort restore — ignore errors, we're already unwinding.
            let _ = disable_raw_mode();
            let _ = restore_terminal_cleanup();
            let _ = execute!(io::stdout(), crossterm::cursor::Show);
        }
        original_hook(panic_info);
    }));

    enable_raw_mode()?;
    let mut stdout = io::stdout();

    #[cfg(not(target_os = "windows"))]
    {
        execute!(
            stdout,
            EnterAlternateScreen,
            EnableMouseCapture,
            EnableBracketedPaste,
        )?;
        if should_push_keyboard_enhancement_for_process() {
            execute!(
                stdout,
                PushKeyboardEnhancementFlags(
                    KeyboardEnhancementFlags::DISAMBIGUATE_ESCAPE_CODES
                        | KeyboardEnhancementFlags::REPORT_ALL_KEYS_AS_ESCAPE_CODES,
                ),
            )?;
        }
    }

    // On Windows, keyboard enhancement is best-effort: conhost and older
    // terminal builds do not support the kitty keyboard protocol.
    // crossterm 0.29 improved detection but may still reject in some
    // configurations.  Warn the user when it fails, then continue.
    #[cfg(target_os = "windows")]
    {
        execute!(stdout, EnterAlternateScreen, EnableMouseCapture)?;
        // Kitty keyboard protocol is unsupported on legacy Windows conhost;
        // best-effort — modern Windows Terminal accepts it, conhost returns
        // "Keyboard progressive enhancement not implemented for the legacy
        // Windows API" which we ignore so the TUI can still start.
        if should_push_keyboard_enhancement_for_process() {
            let _ = execute!(
                stdout,
                PushKeyboardEnhancementFlags(
                    KeyboardEnhancementFlags::DISAMBIGUATE_ESCAPE_CODES
                        | KeyboardEnhancementFlags::REPORT_ALL_KEYS_AS_ESCAPE_CODES,
                ),
            );
        }
    }

    set_terminal_title("\u{2728} Coven");
    // Only Next keeps unchanged frames off the wire; Classic's bytes are unchanged.
    let quiet = renderer == application::UiRenderer::Next;
    let backend = QuietBackend::new(CrosstermBackend::new(stdout), quiet);
    let terminal = Terminal::new(backend)?;
    Ok(terminal)
}

/// Restore the terminal to its original state.
pub fn restore_terminal(terminal: &mut AppTerminal) -> io::Result<()> {
    disable_raw_mode()?;
    // Restore the original title by clearing it (terminals fall back to default).
    let _ = execute!(terminal.backend_mut(), crossterm::terminal::SetTitle(""),);
    restore_terminal_cleanup()?;
    // Never skip this as "already shown": the user keeps this cursor.
    terminal.backend_mut().forget_terminal_state();
    terminal.show_cursor()?;
    Ok(())
}

/// The interactive terminal handed to the event loops.
pub type AppTerminal = Terminal<QuietBackend<CrosstermBackend<Stdout>>>;

/// The title most recently set, so it can be restored after a suspend.
static LAST_TERMINAL_TITLE: std::sync::Mutex<Option<String>> = std::sync::Mutex::new(None);

#[cfg(unix)]
fn last_terminal_title() -> Option<String> {
    LAST_TERMINAL_TITLE.lock().ok()?.clone()
}

/// Set the terminal window title via OSC escape sequence.
pub fn set_terminal_title(title: &str) {
    if let Ok(mut last) = LAST_TERMINAL_TITLE.lock() {
        *last = Some(title.to_string());
    }
    let _ = execute!(io::stdout(), crossterm::terminal::SetTitle(title));
}

/// The topic text for the terminal title. The title is written raw inside an
/// OSC sequence, so in Next every control character and bidirectional
/// override is dropped and newlines become spaces: a prompt or session title
/// can never end the sequence early and emit its own. Classic is unchanged.
pub fn terminal_title_topic(renderer: application::UiRenderer, topic: &str) -> String {
    match renderer {
        application::UiRenderer::Classic => topic.to_string(),
        application::UiRenderer::Next => topic
            .chars()
            .filter_map(|ch| match ch {
                '\n' | '\r' | '\t' => Some(' '),
                '\u{0}'..='\u{1f}'
                | '\u{7f}'..='\u{9f}'
                | '\u{202a}'..='\u{202e}'
                | '\u{2066}'..='\u{2069}' => None,
                _ => Some(ch),
            })
            .collect(),
    }
}

/// Give the terminal back to the shell, run `stop`, then take it back.
/// Returns whether `stop` ran: it does not if the terminal could not be
/// handed back, and the terminal is set up again either way.
///
/// The new terminal has no previous frame, so the next draw repaints it all.
#[cfg(unix)]
pub fn suspend_terminal(
    terminal: &mut AppTerminal,
    renderer: application::UiRenderer,
    stop: impl FnOnce(),
) -> io::Result<bool> {
    let title = last_terminal_title();
    // Keyboard flags have one stack per screen and setup pushed on the
    // alternate one, but restore pops after leaving it. Pop here too, or that
    // stack grows on every suspend and programs run from the shell inherit it.
    if should_push_keyboard_enhancement_for_process() {
        let _ = execute!(io::stdout(), PopKeyboardEnhancementFlags);
    }
    let stopped = stop_if_restored(restore_terminal(terminal), stop);
    *terminal = setup_terminal(renderer)?;
    terminal.clear()?;
    if let Some(title) = title {
        set_terminal_title(&title);
    }
    Ok(stopped)
}

/// Run `stop` only if the terminal was handed back to the shell. Restoring
/// stops at its first error, and stopping then would leave the shell in raw
/// mode, on the alternate screen or with mouse capture on. Returns whether
/// it ran.
#[cfg(unix)]
fn stop_if_restored(restored: io::Result<()>, stop: impl FnOnce()) -> bool {
    match restored {
        Ok(()) => {
            stop();
            true
        }
        Err(error) => {
            tracing::warn!(%error, "could not hand the terminal back; not suspending");
            false
        }
    }
}

/// Update the terminal title to reflect the current session context.
/// Format: "✨ | <topic>" or just "✨ Coven" when no topic is set.
pub fn update_terminal_title(topic: Option<&str>) {
    match topic {
        Some(t) if !t.is_empty() => set_terminal_title(&format!("\u{2728} | {}", t)),
        _ => set_terminal_title("\u{2728} Coven"),
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use app::{App, ToolStatus, ToolUseBlock};
    use claurst_core::config::Config;
    use claurst_core::cost::CostTracker;
    use claurst_core::file_history::FileHistory;
    use claurst_core::types::{ContentBlock, Role, ToolResultContent};
    use dialogs::PermissionRequest;
    use notifications::NotificationKind;
    use ratatui::{backend::TestBackend, buffer::Buffer, layout::Rect, Terminal};
    use std::path::PathBuf;
    use std::sync::Arc;
    use tempfile::tempdir;

    fn make_app() -> App {
        let mut app = App::new(Config::default(), CostTracker::new());
        app.install_command_catalog(
            ["account", "clear", "help", "model"]
                .into_iter()
                .map(|path| CommandPaletteEntry {
                    path: path.to_string(),
                    aliases: Vec::new(),
                    summary: format!("{path} summary"),
                    usage: format!("/{path}"),
                    category: "Test".to_string(),
                    keywords: vec![path.to_string()],
                    source: "test".to_string(),
                    suggest_when: Vec::new(),
                    children: Vec::new(),
                })
                .collect(),
        );
        app
    }

    // ---- terminal capability policy --------------------------------------

    #[test]
    fn cave_embedded_terminal_disables_keyboard_enhancement() {
        let env = [("COVENCAVE", "1")];

        assert!(!should_push_keyboard_enhancement(env));
    }

    #[test]
    fn regular_terminal_enables_keyboard_enhancement() {
        let env: [(&str, &str); 0] = [];

        assert!(should_push_keyboard_enhancement(env));
    }

    #[test]
    fn explicit_opt_out_disables_keyboard_enhancement() {
        let env = [("COVEN_CODE_KEYBOARD_ENHANCEMENT", "0")];

        assert!(!should_push_keyboard_enhancement(env));
    }

    #[test]
    fn explicit_opt_in_overrides_cave_embedded_terminal() {
        let env = [("COVENCAVE", "1"), ("COVEN_CODE_KEYBOARD_ENHANCEMENT", "1")];

        assert!(should_push_keyboard_enhancement(env));
    }

    // ---- input helpers ---------------------------------------------------

    #[test]
    fn test_is_slash_command() {
        assert!(input::is_slash_command("/help"));
        assert!(input::is_slash_command("/compact args"));
        assert!(!input::is_slash_command("//comment"));
        assert!(!input::is_slash_command("hello"));
        assert!(!input::is_slash_command(""));
    }

    #[test]
    fn test_parse_slash_command_no_args() {
        let (cmd, args) = input::parse_slash_command("/help");
        assert_eq!(cmd, "help");
        assert_eq!(args, "");
    }

    #[test]
    fn test_parse_slash_command_with_args() {
        let (cmd, args) = input::parse_slash_command("/compact  --force ");
        assert_eq!(cmd, "compact");
        assert_eq!(args, "--force");
    }

    #[test]
    fn test_parse_slash_command_non_slash() {
        let (cmd, args) = input::parse_slash_command("hello world");
        assert_eq!(cmd, "");
        assert_eq!(args, "");
    }

    // ---- App::take_input ------------------------------------------------

    #[test]
    fn test_take_input_pushes_history() {
        let mut app = make_app();
        app.set_prompt_text("hello".to_string());
        let result = app.take_input();
        assert_eq!(result, "hello");
        assert_eq!(app.input, "");
        assert_eq!(app.prompt_input.text, "");
        assert_eq!(app.input_history, vec!["hello"]);
        assert_eq!(app.prompt_input.history, vec!["hello"]);
        assert_eq!(app.cursor_pos, 0);
    }

    #[test]
    fn test_take_input_empty_does_not_push_history() {
        let mut app = make_app();
        let result = app.take_input();
        assert_eq!(result, "");
        assert!(app.input_history.is_empty());
    }

    // ---- add_message / set_model ----------------------------------------

    #[test]
    fn test_add_message() {
        let mut app = make_app();
        app.add_message(Role::User, "hi".to_string());
        assert_eq!(app.messages.len(), 1);
        assert_eq!(app.messages[0].role, Role::User);
    }

    #[test]
    fn test_set_model() {
        let mut app = make_app();
        app.set_model("claude-opus-4-5".to_string());
        assert_eq!(app.model_name, "claude-opus-4-5");
    }

    #[test]
    fn test_stats_slash_command_opens_dialog_and_closes_other_views() {
        let mut app = make_app();
        app.mcp_view.open(vec![]);
        app.agents_menu.visible = true;

        assert!(app.intercept_slash_command("stats"));
        assert!(app.stats_dialog.visible);
        assert!(!app.mcp_view.visible);
        assert!(!app.agents_menu.visible);
        assert!(!app.diff_viewer.visible);
    }

    #[test]
    fn test_familiar_slash_command_populates_active_agents() {
        let mut app = make_app();
        app.agent_status = vec![
            ("Mendel".to_string(), "running".to_string()),
            ("Aristotle".to_string(), "waiting".to_string()),
            ("Plato".to_string(), "done".to_string()),
        ];

        assert!(app.intercept_slash_command("familiar"));
        assert!(app.agents_menu.visible);
        assert_eq!(app.agents_menu.active_agents.len(), 3);
        assert_eq!(
            app.agents_menu.active_agents[0].status,
            AgentStatus::Running
        );
        assert_eq!(
            app.agents_menu.active_agents[1].status,
            AgentStatus::WaitingForTool
        );
        assert_eq!(
            app.agents_menu.active_agents[2].status,
            AgentStatus::Complete
        );
    }

    #[test]
    fn test_agents_editor_ctrl_s_saves_new_agent() {
        let temp = tempdir().unwrap();
        let mut app = make_app();
        app.agents_menu.open(temp.path());
        app.agents_menu.open_editor(None);
        app.agents_menu.editor.name = "Planner".to_string();
        app.agents_menu.editor.description = "Plans complex work".to_string();
        app.agents_menu.editor.prompt = "Help break work into steps.".to_string();

        app.handle_key_event(ctrl(KeyCode::Char('s')));

        let saved = temp
            .path()
            .join(".coven-code")
            .join("agents")
            .join("planner.md");
        assert!(saved.exists());
        let content = std::fs::read_to_string(saved).unwrap();
        assert!(content.contains("name: Planner"));
        assert!(content.contains("Help break work into steps."));
        assert!(matches!(
            app.agents_menu.route,
            agents_view::AgentsRoute::Detail(_)
        ));
    }

    #[test]
    fn test_agents_editor_render_uses_live_editor_state() {
        let temp = tempdir().unwrap();
        let mut state = AgentsMenuState::new();
        state.open(temp.path());
        state.open_editor(None);
        state.editor.name = "Builder".to_string();
        state.editor.description = "Builds code".to_string();
        state.editor.prompt = "Ship the feature.".to_string();

        let area = Rect {
            x: 0,
            y: 0,
            width: 90,
            height: 24,
        };
        let mut buf = Buffer::empty(area);
        agents_view::render_agents_menu(&state, area, &mut buf);

        let rendered = buf
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");
        assert!(rendered.contains("Builder"));
        assert!(rendered.contains("Ship the feature."));
        assert!(!rendered.contains("Edit the agent file directly"));
    }

    #[test]
    fn test_changes_slash_command_opens_turn_diff_mode() {
        let mut app = make_app();

        assert!(app.intercept_slash_command("changes"));
        assert!(app.diff_viewer.visible);
        assert_eq!(app.diff_viewer.diff_type, DiffType::TurnDiff);
    }

    // ---- key handling ----------------------------------------------------

    use crossterm::event::{KeyCode, KeyEvent, KeyEventKind, KeyEventState, KeyModifiers};

    fn key(code: KeyCode) -> KeyEvent {
        KeyEvent {
            code,
            modifiers: KeyModifiers::NONE,
            kind: KeyEventKind::Press,
            state: KeyEventState::NONE,
        }
    }

    fn ctrl(code: KeyCode) -> KeyEvent {
        KeyEvent {
            code,
            modifiers: KeyModifiers::CONTROL,
            kind: KeyEventKind::Press,
            state: KeyEventState::NONE,
        }
    }

    #[test]
    fn test_agents_menu_d_removes_selected_workspace_agent() {
        let temp = tempdir().unwrap();
        let agents_dir = temp.path().join(".coven-code").join("agents");
        std::fs::create_dir_all(&agents_dir).unwrap();
        let agent_path = agents_dir.join("reviewer.md");
        std::fs::write(
            &agent_path,
            "---\nname: Reviewer\nmodel: claude-sonnet-4-6\ndescription: Reviews code\n---\n\nReview code.",
        )
        .unwrap();

        let mut app = make_app();
        app.config.project_dir = Some(temp.path().to_path_buf());
        assert!(app.intercept_slash_command("familiar"));
        app.agents_menu.selected_row = 2;

        app.handle_key_event(key(KeyCode::Char('d')));

        assert!(!agent_path.exists());
        assert_eq!(
            app.status_message.as_deref(),
            Some("Removed agent Reviewer.")
        );
        assert!(matches!(
            app.agents_menu.route,
            agents_view::AgentsRoute::List
        ));
    }

    #[test]
    fn test_ctrl_c_requires_two_presses_to_exit() {
        let mut app = make_app();
        // First Ctrl+C: shows warning, doesn't exit
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(!app.should_exit);
        assert!(app.last_exit_key_warning.is_some());

        // Second Ctrl+C within 1 second: exits
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(app.should_exit);
    }

    #[test]
    fn test_ctrl_c_clears_input_first_press() {
        let mut app = make_app();
        app.set_prompt_text("some text".to_string());
        // First Ctrl+C: clears input
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(app.prompt_input.is_empty());
        assert!(!app.should_exit);
        assert!(app.last_exit_key_warning.is_some());
    }

    #[test]
    fn test_other_key_resets_exit_warning() {
        let mut app = make_app();
        // First Ctrl+C: shows warning
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(app.last_exit_key_warning.is_some());

        // Press a different key: resets warning
        app.handle_key_event(key(KeyCode::Char('a')));
        assert!(app.last_exit_key_warning.is_none());

        // Now Ctrl+C starts over (doesn't exit)
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(!app.should_exit);
        assert!(app.last_exit_key_warning.is_some());
    }

    #[test]
    fn test_ctrl_c_timeout_resets_after_two_seconds() {
        let mut app = make_app();
        // First Ctrl+C: shows warning
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(app.last_exit_key_warning.is_some());

        // Manually expire the timer by setting it to >2 seconds ago
        app.last_exit_key_warning =
            Some(std::time::Instant::now() - std::time::Duration::from_millis(2100));

        // Second Ctrl+C after timeout: should show warning again, not exit
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(!app.should_exit);
        assert!(app.last_exit_key_warning.is_some());
    }

    #[test]
    fn test_ctrl_c_cancels_streaming() {
        let mut app = make_app();
        app.is_streaming = true;
        app.streaming_text = "partial".to_string();
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(!app.is_streaming);
        assert!(!app.should_exit);
        assert!(app.streaming_text.is_empty());
    }

    #[test]
    fn test_ctrl_d_requires_two_presses_to_exit() {
        let mut app = make_app();
        // First Ctrl+D: shows warning, doesn't exit
        app.handle_key_event(ctrl(KeyCode::Char('d')));
        assert!(!app.should_exit);
        assert!(app.last_exit_key_warning.is_some());

        // Second Ctrl+D within 2 seconds: exits
        app.handle_key_event(ctrl(KeyCode::Char('d')));
        assert!(app.should_exit);
    }

    #[test]
    fn test_ctrl_d_does_not_quit_with_input() {
        let mut app = make_app();
        app.set_prompt_text("abc".to_string());
        app.handle_key_event(ctrl(KeyCode::Char('d')));
        assert!(!app.should_exit);
    }

    #[test]
    fn test_ctrl_c_then_ctrl_d_then_ctrl_c_exits() {
        let mut app = make_app();
        // First Ctrl+C: shows warning, sets start_key = 'c'
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(!app.should_exit);
        assert_eq!(app.exit_key_sequence_start, Some('c'));

        // Ctrl+D (wrong key): resets timer but keeps waiting for Ctrl+C
        app.handle_key_event(ctrl(KeyCode::Char('d')));
        assert!(!app.should_exit);
        assert_eq!(app.exit_key_sequence_start, Some('c')); // Still waiting for Ctrl+C

        // Ctrl+C again: exits
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(app.should_exit);
    }

    #[test]
    fn test_ctrl_d_then_ctrl_c_then_ctrl_d_exits() {
        let mut app = make_app();
        // First Ctrl+D: shows warning, sets start_key = 'd'
        app.handle_key_event(ctrl(KeyCode::Char('d')));
        assert!(!app.should_exit);
        assert_eq!(app.exit_key_sequence_start, Some('d'));

        // Ctrl+C (wrong key): resets timer but keeps waiting for Ctrl+D
        app.handle_key_event(ctrl(KeyCode::Char('c')));
        assert!(!app.should_exit);
        assert_eq!(app.exit_key_sequence_start, Some('d')); // Still waiting for Ctrl+D

        // Ctrl+D again: exits
        app.handle_key_event(ctrl(KeyCode::Char('d')));
        assert!(app.should_exit);
    }

    #[test]
    fn test_enter_returns_true() {
        let mut app = make_app();
        let submit = app.handle_key_event(key(KeyCode::Enter));
        assert!(submit);
    }

    #[test]
    fn test_enter_blocked_while_streaming() {
        let mut app = make_app();
        app.is_streaming = true;
        let submit = app.handle_key_event(key(KeyCode::Enter));
        assert!(!submit);
    }

    #[test]
    fn test_char_input_appends() {
        let mut app = make_app();
        app.handle_key_event(key(KeyCode::Char('h')));
        app.handle_key_event(key(KeyCode::Char('i')));
        assert_eq!(app.input, "hi");
        assert_eq!(app.prompt_input.text, "hi");
    }

    #[test]
    fn test_backspace_removes_char() {
        let mut app = make_app();
        app.set_prompt_text("hello".to_string());
        app.handle_key_event(key(KeyCode::Backspace));
        assert_eq!(app.input, "hell");
        assert_eq!(app.prompt_input.text, "hell");
    }

    #[test]
    fn test_history_navigation() {
        let mut app = make_app();
        app.prompt_input.history = vec!["first".to_string(), "second".to_string()];
        app.input_history = app.prompt_input.history.clone();
        app.handle_key_event(key(KeyCode::Up));
        assert_eq!(app.input, "second");
        app.handle_key_event(key(KeyCode::Up));
        assert_eq!(app.input, "first");
        app.handle_key_event(key(KeyCode::Down));
        assert_eq!(app.input, "second");
        app.handle_key_event(key(KeyCode::Down));
        assert_eq!(app.input, "");
        assert!(app.history_index.is_none());
    }

    #[test]
    fn test_history_navigation_restores_draft() {
        let mut app = make_app();
        app.prompt_input.history = vec!["first".to_string(), "second".to_string()];
        app.input_history = app.prompt_input.history.clone();
        app.set_prompt_text("draft".to_string());

        app.handle_key_event(key(KeyCode::Up));
        assert_eq!(app.input, "second");

        app.handle_key_event(key(KeyCode::Down));
        assert_eq!(app.input, "draft");
        assert_eq!(app.prompt_input.text, "draft");
        assert!(app.history_index.is_none());
    }

    #[test]
    fn test_tab_accepts_slash_suggestion() {
        let mut app = make_app();
        app.handle_key_event(key(KeyCode::Char('/')));
        app.handle_key_event(key(KeyCode::Char('a')));
        app.handle_key_event(key(KeyCode::Tab));

        assert_eq!(app.input, "/account");
        assert_eq!(app.input, app.prompt_input.text);
        assert_eq!(app.cursor_pos, app.input.len());
    }

    #[test]
    fn test_ctrl_p_opens_global_search() {
        let mut app = make_app();
        app.handle_key_event(ctrl(KeyCode::Char('p')));
        assert!(app.global_search.visible);
    }

    #[test]
    fn test_global_search_enter_inserts_selected_ref() {
        let mut app = make_app();
        app.global_search.open();
        app.global_search.results = vec![overlays::SearchResult {
            file: "src/main.rs".to_string(),
            line: 42,
            col: 1,
            text: "fn main() {}".to_string(),
            context_before: Vec::new(),
            context_after: Vec::new(),
        }];
        app.handle_key_event(key(KeyCode::Enter));

        assert!(!app.global_search.visible);
        assert_eq!(app.input, "src/main.rs:42");
        assert_eq!(app.prompt_input.text, "src/main.rs:42");
    }

    /// Welcome-panel affordance snapshot test. The two-column welcome box
    /// surfaces — at a glance, in under a second — the active model, the
    /// provider, and daemon reachability. This guards those first-screen
    /// affordances against regressions in the redesigned layout. (The
    /// familiar is shown as an avatar in the full box and as a "Familiar:"
    /// label in the narrow fallback, which is covered separately by
    /// `welcome_small_terminal_fallback_carries_status_signals`.)
    #[test]
    fn welcome_screen_renders_status_block_with_key_affordances() {
        let backend = TestBackend::new(120, 24);
        let mut terminal = Terminal::new(backend).unwrap();
        // Fresh app, no transcript — the welcome box owns the top of
        // the screen.
        let app = make_app();
        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();
        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");
        // Header.
        assert!(
            rendered.contains("Coven"),
            "welcome box is missing the Coven header.\n--- rendered buffer ---\n{rendered}"
        );
        // Provider (a fresh app defaults to Claude / Anthropic).
        assert!(
            rendered.contains("Anthropic"),
            "welcome box is missing the provider label.\n--- rendered buffer ---\n{rendered}"
        );
        // Active model family (default model is a Claude Opus variant).
        assert!(
            rendered.contains("Opus"),
            "welcome box is missing the model label.\n--- rendered buffer ---\n{rendered}"
        );
        // Daemon reachability, shown as the online/offline state on the
        // provider line.
        assert!(
            rendered.contains("online") || rendered.contains("offline"),
            "welcome box is missing daemon reachability.\n--- rendered buffer ---\n{rendered}"
        );
    }

    /// Small-terminal fallback: when the welcome area is too short for
    /// the full box, the single-line fallback still includes the model,
    /// daemon, and familiar context strip. We test with a "wide-but-
    /// short" geometry (100 cols × 8 rows) so the fallback row has room
    /// to render every segment rather than truncating on width.
    #[test]
    fn welcome_small_terminal_fallback_carries_status_signals() {
        let backend = TestBackend::new(100, 8);
        let mut terminal = Terminal::new(backend).unwrap();
        let app = make_app();
        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();
        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");
        assert!(
            rendered.contains("Coven"),
            "fallback should include Coven header. buffer: {rendered}"
        );
        assert!(
            rendered.contains("Daemon"),
            "fallback should include daemon hint. buffer: {rendered}"
        );
        assert!(
            rendered.contains("Familiar"),
            "fallback should include familiar hint. buffer: {rendered}"
        );
    }

    #[test]
    fn test_render_app_keeps_logo_header_after_first_message() {
        let backend = TestBackend::new(120, 40);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.push_message(claurst_core::types::Message::user("hello".to_string()));

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(rendered.contains("Coven"));
        assert!(rendered.contains("hello"));
    }

    #[test]
    fn test_render_app_uses_true_rgb_shell_background() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let app = make_app();

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let buffer = terminal.backend().buffer();
        let bg = crate::overlays::COVEN_CODE_APP_BG;

        assert_eq!(buffer[(0, 12)].bg, bg);
        assert_eq!(buffer[(119, 12)].bg, bg);
    }

    #[test]
    fn test_render_app_keeps_footer_visible_with_slash_suggestions() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.handle_key_event(key(KeyCode::Char('/')));
        app.handle_key_event(key(KeyCode::Char('c')));

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(rendered.contains("/clear"));
        assert!(rendered.contains("[cmd]"));
    }

    #[test]
    fn test_render_app_hides_generic_thinking_status_row() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.is_streaming = true;

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(!rendered.contains("Thinking..."));
    }

    #[test]
    fn test_render_app_shows_footer_notification_instead_of_effort() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.notifications.push(
            NotificationKind::Warning,
            "Update available! Run upgrade".to_string(),
            Some(30),
        );

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(rendered.contains("Update available! Run upgrade"));
        assert!(!rendered.contains("/effort"));
    }

    #[test]
    fn test_render_app_keeps_permission_dialog_above_error_modal() {
        let backend = TestBackend::new(100, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.permission_request = Some(PermissionRequest::standard(
            "tu1".to_string(),
            "Bash".to_string(),
            "Run a shell command".to_string(),
        ));
        app.notifications.push(
            NotificationKind::Error,
            "dangerous command failed with a long error message".to_string(),
            None,
        );

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(rendered.contains("Permission Required"));
        assert!(rendered.contains("Yes, allow once"));
        assert!(rendered.contains("No, deny"));
    }

    #[test]
    fn test_render_app_hides_shortcuts_hint_when_prompt_has_text() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.set_prompt_text("hello".to_string());

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(!rendered.contains("? shortcuts"));
    }

    #[test]
    fn test_render_app_shows_startup_notices_below_logo_header() {
        let backend = TestBackend::new(120, 40);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.away_summary = Some("2 agent updates while you were away".to_string());
        app.remote_session_url = Some("https://example.com/session/123".to_string());
        app.bridge_state = crate::bridge_state::BridgeConnectionState::Connected {
            session_url: "https://example.com/session/123".to_string(),
            peer_count: 2,
        };

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(rendered.contains("2 agent updates while you were away"));
        assert!(rendered.contains("Remote session active"));
        assert!(rendered.contains("https://example.com/session/123"));
    }

    #[test]
    fn test_turn_diff_toggle_uses_cached_turn_files() {
        let mut state = DiffViewerState::new();
        state.set_turn_diff(vec![diff_viewer::FileDiffStats {
            path: "src/lib.rs".to_string(),
            added: 2,
            removed: 1,
            binary: false,
            is_new_file: false,
            hunks: vec![diff_viewer::DiffHunk {
                old_range: (1, 1),
                new_range: (1, 2),
                lines: vec![diff_viewer::DiffLine {
                    kind: diff_viewer::DiffLineKind::Header,
                    content: "@@ -1,1 +1,2 @@".to_string(),
                    old_line_no: None,
                    new_line_no: None,
                }],
            }],
        }]);

        state.toggle_diff_type(std::path::Path::new("."));

        assert_eq!(state.diff_type, DiffType::TurnDiff);
        assert_eq!(state.files.len(), 1);
        assert_eq!(state.files[0].path, "src/lib.rs");
    }

    #[test]
    fn test_build_turn_diff_from_history_snapshots() {
        let mut history = FileHistory::new();
        history.record_modification(
            PathBuf::from("/workspace/src/lib.rs"),
            b"fn old() {}\n",
            b"fn new() {}\n",
            3,
            "FileEdit",
        );

        let files = diff_viewer::build_turn_diff(&history, 3, std::path::Path::new("/workspace"));

        assert_eq!(files.len(), 1);
        assert_eq!(files[0].path, "src/lib.rs");
        assert_eq!(files[0].added, 1);
        assert_eq!(files[0].removed, 1);
        assert!(!files[0].hunks.is_empty());
    }

    #[test]
    fn test_changes_slash_command_refreshes_turn_history() {
        let mut app = make_app();
        let file_history = Arc::new(parking_lot::Mutex::new(FileHistory::new()));
        let current_turn = Arc::new(std::sync::atomic::AtomicUsize::new(1));
        file_history.lock().record_modification(
            PathBuf::from("src/lib.rs"),
            b"fn before() {}\n",
            b"fn after() {}\n",
            1,
            "FileEdit",
        );
        app.attach_turn_diff_state(file_history, current_turn);

        assert!(app.intercept_slash_command("changes"));
        assert_eq!(app.diff_viewer.diff_type, DiffType::TurnDiff);
        assert_eq!(app.diff_viewer.files.len(), 1);
        assert_eq!(app.diff_viewer.files[0].path, "src/lib.rs");
    }

    #[test]
    fn test_render_diff_dialog_shows_turn_empty_state() {
        let mut state = DiffViewerState::new();
        state.visible = true;
        state.diff_type = DiffType::TurnDiff;
        let area = Rect {
            x: 0,
            y: 0,
            width: 80,
            height: 20,
        };
        let mut buf = Buffer::empty(area);

        diff_viewer::render_diff_dialog(&state, area, &mut buf);

        let rendered = buf
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");
        assert!(rendered.contains("No changes were captured for this turn."));
    }

    #[test]
    fn test_page_scroll() {
        let mut app = make_app();
        app.handle_key_event(key(KeyCode::PageUp));
        assert_eq!(app.scroll_offset, 10);
        app.handle_key_event(key(KeyCode::PageDown));
        assert_eq!(app.scroll_offset, 0);
    }

    #[test]
    fn test_f1_toggles_help() {
        let mut app = make_app();
        assert!(!app.help_overlay.visible);
        app.handle_key_event(key(KeyCode::F(1)));
        assert!(app.help_overlay.visible);
        app.handle_key_event(key(KeyCode::F(1)));
        assert!(!app.help_overlay.visible);
    }

    #[test]
    fn test_stats_dialog_keys_switch_tab_and_close() {
        let mut app = make_app();
        app.stats_dialog.visible = true;

        app.handle_key_event(key(KeyCode::Right));
        assert_eq!(app.stats_dialog.tab, StatsTab::DailyTokens);

        app.handle_key_event(key(KeyCode::Esc));
        assert!(!app.stats_dialog.visible);
    }

    #[test]
    fn test_mcp_view_keys_search_and_close() {
        let mut app = make_app();
        app.mcp_view.open(vec![McpServerView {
            name: "filesystem".to_string(),
            transport: "stdio".to_string(),
            status: McpViewStatus::Connected,
            tool_count: 1,
            resource_count: 0,
            prompt_count: 0,
            resources: vec![],
            prompts: vec![],
            error_message: None,
            tools: vec![McpToolView {
                name: "read_file".to_string(),
                server: "filesystem".to_string(),
                description: "Read a file".to_string(),
                input_schema: None,
            }],
        }]);
        app.mcp_view.switch_pane();

        app.handle_key_event(key(KeyCode::Char('r')));
        assert_eq!(app.mcp_view.tool_search, "");
        assert_eq!(
            app.status_message.as_deref(),
            Some("Reconnecting MCP runtime...")
        );
        app.handle_key_event(key(KeyCode::Char('f')));
        assert_eq!(app.mcp_view.tool_search, "f");

        app.handle_key_event(key(KeyCode::Backspace));
        assert_eq!(app.mcp_view.tool_search, "");

        app.handle_key_event(key(KeyCode::Esc));
        assert!(!app.mcp_view.visible);
    }

    #[test]
    fn test_mcp_view_render_shows_resources_and_prompts() {
        let mut state = McpViewState::new();
        state.open(vec![McpServerView {
            name: "filesystem".to_string(),
            transport: "stdio".to_string(),
            status: McpViewStatus::Connected,
            tool_count: 1,
            resource_count: 2,
            prompt_count: 1,
            resources: vec!["workspace-root".to_string(), "project-config".to_string()],
            prompts: vec!["summarize-workspace".to_string()],
            error_message: None,
            tools: vec![McpToolView {
                name: "read_file".to_string(),
                server: "filesystem".to_string(),
                description: "Read a file".to_string(),
                input_schema: None,
            }],
        }]);
        state.switch_pane();
        state.switch_pane();

        let area = Rect {
            x: 0,
            y: 0,
            width: 120,
            height: 30,
        };
        let mut buf = Buffer::empty(area);
        mcp_view::render_mcp_view(&state, area, &mut buf);
        let rendered = buf
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(rendered.contains("2 res"));
        assert!(rendered.contains("1 prompts"));
    }

    #[test]
    fn test_mcp_view_auth_key_queues_selected_server_panel_auth() {
        let mut app = make_app();
        app.mcp_view.open(vec![McpServerView {
            name: "mcphub".to_string(),
            transport: "http".to_string(),
            status: McpViewStatus::Connected,
            tool_count: 1,
            resource_count: 0,
            prompt_count: 0,
            resources: vec![],
            prompts: vec![],
            error_message: None,
            tools: vec![McpToolView {
                name: "read_file".to_string(),
                server: "mcphub".to_string(),
                description: "Read a file".to_string(),
                input_schema: None,
            }],
        }]);

        let submit = app.handle_key_event(key(KeyCode::Char('a')));
        assert!(!submit);
        assert_eq!(app.prompt_input.text, "");
        assert_eq!(app.take_pending_mcp_panel_auth().as_deref(), Some("mcphub"));
        assert!(!app.mcp_view.visible);
        assert_eq!(app.mcp_view.tool_search, "");
    }

    #[test]
    fn test_mcp_view_auth_key_with_no_servers_is_safe_noop() {
        let mut app = make_app();
        app.mcp_view.open(vec![]);

        let submit = app.handle_key_event(key(KeyCode::Char('a')));
        assert!(!submit);
        assert!(app.mcp_view.visible);
        assert_eq!(app.prompt_input.text, "");
        assert!(app.take_pending_mcp_panel_auth().is_none());
    }

    #[test]
    fn test_mcp_view_auth_key_only_works_in_servers_pane() {
        let mut app = make_app();
        app.mcp_view.open(vec![McpServerView {
            name: "mcphub".to_string(),
            transport: "http".to_string(),
            status: McpViewStatus::Connected,
            tool_count: 1,
            resource_count: 0,
            prompt_count: 0,
            resources: vec![],
            prompts: vec![],
            error_message: None,
            tools: vec![McpToolView {
                name: "read_file".to_string(),
                server: "mcphub".to_string(),
                description: "Read a file".to_string(),
                input_schema: None,
            }],
        }]);
        app.mcp_view.switch_pane();

        let submit = app.handle_key_event(key(KeyCode::Char('a')));
        assert!(!submit);
        assert!(app.mcp_view.visible);
        assert_eq!(app.mcp_view.tool_search, "a");
        assert!(app.take_pending_mcp_panel_auth().is_none());
    }

    #[test]
    fn test_take_pending_mcp_panel_auth_clears_after_read() {
        let mut app = make_app();
        app.pending_mcp_panel_auth = Some("mcphub".to_string());

        assert_eq!(app.take_pending_mcp_panel_auth().as_deref(), Some("mcphub"));
        assert!(app.take_pending_mcp_panel_auth().is_none());
    }

    #[test]
    fn test_message_renderer_includes_tool_use_and_thinking_blocks() {
        let msg = claurst_core::types::Message::assistant_blocks(vec![
            ContentBlock::Thinking {
                thinking: "reasoning".to_string(),
                signature: "sig".to_string(),
            },
            ContentBlock::ToolUse {
                id: "toolu_1".to_string(),
                name: "read_file".to_string(),
                input: serde_json::json!({ "path": "README.md" }),
            },
            ContentBlock::Text {
                text: "Done".to_string(),
            },
        ]);

        let rendered = messages::render_message(&msg, &messages::RenderContext::default());
        let text = rendered
            .iter()
            .map(|line| {
                line.spans
                    .iter()
                    .map(|span| span.content.clone())
                    .collect::<String>()
            })
            .collect::<Vec<_>>()
            .join("\n");

        assert!(text.contains("Thinking"));
        assert!(text.contains("read_file"));
        assert!(text.contains("Done"));
    }

    #[test]
    fn test_message_renderer_includes_tool_result_errors() {
        let msg = claurst_core::types::Message::user_blocks(vec![ContentBlock::ToolResult {
            tool_use_id: "toolu_1".to_string(),
            content: ToolResultContent::Text("boom".to_string()),
            is_error: Some(true),
        }]);

        let rendered = messages::render_message(&msg, &messages::RenderContext::default());
        let text = rendered
            .iter()
            .map(|line| {
                line.spans
                    .iter()
                    .map(|span| span.content.clone())
                    .collect::<String>()
            })
            .collect::<Vec<_>>()
            .join("\n");

        assert!(text.contains("Error"));
        assert!(text.contains("boom"));
    }

    // ---- QueryEvent handling --------------------------------------------

    #[test]
    fn test_handle_status_event() {
        let mut app = make_app();
        app.handle_query_event(claurst_query::QueryEvent::Status("working".to_string()));
        assert_eq!(app.status_message.as_deref(), Some("working"));
    }

    #[test]
    fn test_handle_error_event() {
        let mut app = make_app();
        app.is_streaming = true;
        app.handle_query_event(claurst_query::QueryEvent::Error("oops".to_string()));
        assert!(!app.is_streaming);
        assert_eq!(app.messages.len(), 1);
        assert!(app.messages[0].get_all_text().contains("oops"));
    }

    #[test]
    fn test_handle_tool_start_and_end() {
        let mut app = make_app();
        app.handle_query_event(claurst_query::QueryEvent::ToolStart {
            tool_name: "Bash".to_string(),
            tool_id: "t1".to_string(),
            input_json: r#"{"command":"ls -la"}"#.to_string(),
        });
        assert_eq!(app.tool_use_blocks.len(), 1);
        assert_eq!(app.tool_use_blocks[0].turn_index, None);
        assert_eq!(app.tool_use_blocks[0].status, ToolStatus::Running);

        app.handle_query_event(claurst_query::QueryEvent::ToolEnd {
            tool_name: "Bash".to_string(),
            tool_id: "t1".to_string(),
            result: "output".to_string(),
            is_error: false,
        });
        assert_eq!(app.tool_use_blocks[0].status, ToolStatus::Done);
    }

    #[test]
    fn test_handle_tool_end_error() {
        let mut app = make_app();
        app.tool_use_blocks.push(ToolUseBlock {
            id: "t2".to_string(),
            name: "Read".to_string(),
            turn_index: None,
            status: ToolStatus::Running,
            output_preview: None,
            input_json: r#"{"file_path":"foo.rs"}"#.to_string(),
        });
        app.handle_query_event(claurst_query::QueryEvent::ToolEnd {
            tool_name: "Read".to_string(),
            tool_id: "t2".to_string(),
            result: "file not found".to_string(),
            is_error: true,
        });
        assert_eq!(app.tool_use_blocks[0].status, ToolStatus::Error);
        assert!(app.status_message.is_some());
    }

    #[test]
    fn test_turn_complete_flushes_streaming_text() {
        let mut app = make_app();
        app.is_streaming = true;
        app.streaming_text = "partial response".to_string();
        app.handle_query_event(claurst_query::QueryEvent::TurnComplete {
            turn: 1,
            stop_reason: "end_turn".to_string(),
            usage: None,
        });
        assert!(!app.is_streaming);
        assert!(app.streaming_text.is_empty());
        assert_eq!(app.messages.len(), 1);
        assert_eq!(app.messages[0].get_all_text(), "partial response");
    }

    #[test]
    fn test_turn_complete_flushes_streaming_thinking_into_blocks() {
        let mut app = make_app();
        app.is_streaming = true;
        app.streaming_thinking = "outline the fix".to_string();
        app.handle_query_event(claurst_query::QueryEvent::TurnComplete {
            turn: 1,
            stop_reason: "end_turn".to_string(),
            usage: None,
        });

        let blocks = app.messages[0].content_blocks();
        assert!(matches!(
            blocks.first(),
            Some(ContentBlock::Thinking { thinking, .. }) if thinking == "outline the fix"
        ));
    }

    #[test]
    fn test_render_app_transcript_uses_turn_metadata_without_legacy_glyph() {
        let backend = TestBackend::new(120, 30);
        let mut terminal = Terminal::new(backend).unwrap();
        let mut app = make_app();
        app.push_message(claurst_core::types::Message::user("hello".to_string()));
        app.push_message(claurst_core::types::Message::assistant(
            "hi there".to_string(),
        ));
        app.turn_metadata[0].interrupted = true;

        terminal
            .draw(|frame| crate::render::render_app(frame, &app))
            .unwrap();

        let rendered = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect::<Vec<_>>()
            .join("");

        assert!(!rendered.contains("◆"));
        assert!(rendered.contains("▣"));
    }

    // ---- PermissionRequest --------------------------------------------

    #[test]
    fn test_permission_request_standard() {
        let pr = PermissionRequest::standard(
            "tu1".to_string(),
            "Bash".to_string(),
            "Run a shell command".to_string(),
        );
        assert_eq!(pr.options.len(), 4);
        assert_eq!(pr.options[0].key, 'y');
        assert_eq!(pr.options[1].key, 'Y');
        assert_eq!(pr.options[2].key, 'p');
        assert_eq!(pr.options[3].key, 'n');
    }

    /// Regression: the audit flagged a double-unwrap in
    /// `handle_permission_key`'s Up/Down arms. If the dialog was cleared
    /// between the outer `as_mut()` bind and the inner `.as_mut().unwrap()`
    /// (e.g. a tool result resolved the request), the second unwrap would
    /// panic the TUI. Now those branches pattern-match and silently no-op.
    /// This test pins the no-panic contract by handling Up/Down with no
    /// active permission dialog.
    #[test]
    fn arrow_keys_do_not_panic_without_permission_dialog() {
        let mut app = make_app();
        assert!(app.permission_request.is_none());
        // Either branch could have panicked before the fix.
        app.handle_key_event(key(KeyCode::Up));
        app.handle_key_event(key(KeyCode::Down));
        // No assertion needed — surviving these calls is the assertion.
    }

    /// Up/Down with an active dialog adjusts `selected_option` correctly
    /// and saturates at the bounds.
    #[test]
    fn arrow_keys_navigate_permission_dialog_selection() {
        let mut app = make_app();
        let mut pr = PermissionRequest::standard(
            "tu_test".to_string(),
            "Bash".to_string(),
            "Run a command".to_string(),
        );
        pr.selected_option = 0;
        app.permission_request = Some(pr);

        app.handle_key_event(key(KeyCode::Down));
        assert_eq!(app.permission_request.as_ref().unwrap().selected_option, 1);
        app.handle_key_event(key(KeyCode::Down));
        assert_eq!(app.permission_request.as_ref().unwrap().selected_option, 2);
        app.handle_key_event(key(KeyCode::Up));
        assert_eq!(app.permission_request.as_ref().unwrap().selected_option, 1);

        // Saturation: walking past index 0 should stay at 0.
        app.handle_key_event(key(KeyCode::Up));
        app.handle_key_event(key(KeyCode::Up));
        app.handle_key_event(key(KeyCode::Up));
        assert_eq!(app.permission_request.as_ref().unwrap().selected_option, 0);

        // Saturation at the end too — 4 options, max index 3.
        for _ in 0..10 {
            app.handle_key_event(key(KeyCode::Down));
        }
        assert_eq!(app.permission_request.as_ref().unwrap().selected_option, 3);
    }

    /// Regression for issue #49: with a voice recorder attached, pressing
    /// plain `v` must NOT start recording. Plain-V used to be a broken
    /// hold-to-talk that ate every literal `v` character (typing
    /// "/coven", "review", etc.). Recording now toggles exclusively
    /// through Alt+V.
    #[test]
    fn issue_49_plain_v_does_not_start_voice_recording() {
        let mut app = make_app();
        assert!(
            !app.voice_recording,
            "fresh app must not be recording at startup"
        );

        // Simulate a voice recorder being attached as if voice_enabled were
        // true in ui-settings.json. The previous behaviour was to start
        // recording on the first plain-`v` keystroke once voice_recorder
        // was Some — we override the field directly to isolate the input
        // path from the env-var/file resolution.
        app.voice_recorder = Some(std::sync::Arc::new(std::sync::Mutex::new(
            claurst_core::voice::VoiceRecorder::new(claurst_core::voice::VoiceConfig {
                enabled: true,
                ..Default::default()
            }),
        )));

        // Type "voice" — every plain `v` press must hit the prompt buffer
        // instead of starting a recording.
        app.handle_key_event(key(KeyCode::Char('v')));
        app.handle_key_event(key(KeyCode::Char('o')));
        app.handle_key_event(key(KeyCode::Char('i')));
        app.handle_key_event(key(KeyCode::Char('c')));
        app.handle_key_event(key(KeyCode::Char('e')));

        assert!(
            !app.voice_recording,
            "plain `v` must not trigger voice recording (issue #49)"
        );
        assert!(
            app.prompt_input.text.contains("voice"),
            "plain `v` must reach the prompt buffer, got: {:?}",
            app.prompt_input.text
        );
    }

    /// Regression for issue #49: `COVEN_CODE_VOICE=0` (or `=false`) must
    /// be a hard opt-out that ignores `voice_enabled: true` in
    /// ui-settings.json.
    #[test]
    fn issue_49_coven_code_voice_env_opt_out_is_respected() {
        // SAFETY: env vars are process-global; the surrounding test
        // suite is single-threaded by default for this binary.
        let prev = std::env::var("COVEN_CODE_VOICE").ok();

        std::env::set_var("COVEN_CODE_VOICE", "0");
        assert!(crate::app::voice_explicitly_disabled());
        std::env::set_var("COVEN_CODE_VOICE", "false");
        assert!(crate::app::voice_explicitly_disabled());
        std::env::set_var("COVEN_CODE_VOICE", "1");
        assert!(!crate::app::voice_explicitly_disabled());
        std::env::remove_var("COVEN_CODE_VOICE");
        assert!(!crate::app::voice_explicitly_disabled());

        if let Some(v) = prev {
            std::env::set_var("COVEN_CODE_VOICE", v);
        }
    }
}

#[cfg(all(test, unix))]
mod terminal_title_tests {
    use super::*;

    #[test]
    fn the_last_title_is_remembered_for_a_resume() {
        set_terminal_title("title before suspending");
        assert_eq!(
            last_terminal_title().as_deref(),
            Some("title before suspending")
        );
    }

    #[test]
    fn a_terminal_that_was_not_handed_back_is_not_stopped() {
        let mut stopped = false;
        let failed = Err(io::Error::other("raw mode stayed on"));
        assert!(!stop_if_restored(failed, || stopped = true));
        assert!(!stopped, "the shell would get a half-restored terminal");

        assert!(stop_if_restored(Ok(()), || stopped = true));
        assert!(stopped);
    }
}
