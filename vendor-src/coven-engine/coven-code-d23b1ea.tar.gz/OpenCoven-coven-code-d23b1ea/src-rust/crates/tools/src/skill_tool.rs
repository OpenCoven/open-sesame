// SkillTool: execute user-defined skill (prompt template) files programmatically.
//
// Skills are Markdown files stored in:
//   <project>/.coven-code/commands/<name>.md
//   ~/.coven-code/commands/<name>.md
//
// Bundled skills (defined in bundled_skills.rs) are checked first before the
// disk directories, so they take precedence over same-named .md files.
//
// The model invokes this tool to expand a skill's prompt inline.
// Supports $ARGUMENTS placeholder substitution.
// Use skill="list" to discover available skills.

use crate::bundled_skills::{expand_prompt, find_bundled_skill, user_invocable_skills};
use crate::{PermissionLevel, Tool, ToolContext, ToolResult};
use async_trait::async_trait;
use serde::Deserialize;
use serde_json::{json, Value};
use std::path::PathBuf;
use tracing::debug;

pub struct SkillTool;

#[derive(Debug, Deserialize)]
struct SkillInput {
    skill: String,
    #[serde(default)]
    args: Option<String>,
}

#[async_trait]
impl Tool for SkillTool {
    fn name(&self) -> &str {
        "Skill"
    }

    fn description(&self) -> &str {
        "Execute a skill (custom prompt template) by name. \
         Skills are .md files in .coven-code/commands/ or ~/.coven-code/commands/. \
         Use skill=\"list\" to discover available skills. \
         The expanded skill prompt is returned for you to act on."
    }

    fn permission_level(&self) -> PermissionLevel {
        PermissionLevel::ReadOnly
    }

    fn input_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "skill": {
                    "type": "string",
                    "description": "Skill name (without .md extension), or \"list\" to enumerate skills"
                },
                "args": {
                    "type": "string",
                    "description": "Arguments passed to the skill — replaces $ARGUMENTS in the template"
                }
            },
            "required": ["skill"]
        })
    }

    async fn execute(&self, input: Value, ctx: &ToolContext) -> ToolResult {
        let params: SkillInput = match serde_json::from_value(input) {
            Ok(p) => p,
            Err(e) => return ToolResult::error(format!("Invalid input: {}", e)),
        };

        let dirs = skill_search_dirs(ctx);
        if params.skill == "list" {
            return list_skills(&dirs).await;
        }
        let skill_name = params.skill.trim_end_matches(".md");
        debug!(skill = skill_name, "Loading skill");

        // Check bundled skills first — they take precedence over disk files.
        if let Some(bundled) = find_bundled_skill(skill_name) {
            let args = params.args.as_deref().unwrap_or("");
            let prompt = expand_prompt(bundled, args);
            let prompt = prompt.trim().to_string();
            if prompt.is_empty() {
                return ToolResult::error(format!(
                    "Bundled skill '{}' expanded to empty content.",
                    skill_name
                ));
            }
            return ToolResult::success(prompt);
        }

        let (skill_path, raw) = match find_and_read_skill(skill_name, &dirs).await {
            Some(found) => found,
            None => {
                // Distinguish "registered with Coven daemon but unsupported"
                // from "actually missing" so the user gets actionable feedback.
                let is_daemon = claurst_core::coven_shared::list_daemon_skills()
                    .iter()
                    .any(|s| s.id == skill_name);
                if is_daemon {
                    return ToolResult::error(format!(
                        "Skill '{}' is registered with the Coven daemon \
                         (~/.coven/skills/{}/metadata.json) but cannot be \
                         expanded from coven-code — daemon skills use a \
                         manifest-only format. Invoke it via the daemon directly.",
                        skill_name, skill_name
                    ));
                }
                return ToolResult::error(format!(
                    "Skill '{}' not found. Use skill=\"list\" to see available skills.",
                    skill_name
                ));
            }
        };

        if let Err(e) = ctx.check_permission_for_path(
            self.name(),
            &format!("Load skill {}", params.skill),
            skill_path,
            true,
        ) {
            return ToolResult::error(e.to_string());
        }

        // Strip YAML frontmatter if present (--- ... ---)
        let content = strip_frontmatter(&raw);

        // Substitute $ARGUMENTS
        let prompt = if let Some(args) = &params.args {
            content.replace("$ARGUMENTS", args)
        } else {
            content.replace("$ARGUMENTS", "")
        };

        let prompt = prompt.trim().to_string();
        if prompt.is_empty() {
            return ToolResult::error(format!("Skill '{}' expanded to empty content.", skill_name));
        }

        ToolResult::success(prompt)
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn skill_search_dirs(ctx: &ToolContext) -> Vec<PathBuf> {
    let mut dirs = vec![ctx.working_dir.join(".coven-code").join("commands")];
    dirs.push(claurst_core::config::config_home().join("commands"));
    dirs
}

async fn list_skills(dirs: &[PathBuf]) -> ToolResult {
    // Skills toggled off in the `/skills` picker are hidden from the model.
    // Use the async loader so we don't block the runtime from this async fn.
    let disabled = claurst_core::config::Settings::load()
        .await
        .map(|s| s.disabled_skills)
        .unwrap_or_default();

    // Start with the bundled skills (minus any the user disabled).
    let mut lines: Vec<String> = Vec::new();
    let bundled: Vec<(&str, &str)> = user_invocable_skills()
        .into_iter()
        .filter(|(name, _)| !disabled.contains(*name))
        .collect();
    for (name, desc) in &bundled {
        lines.push(format!("  {} — {} [bundled]", name, desc));
    }
    let bundled_names: Vec<&str> = bundled.iter().map(|(n, _)| *n).collect();

    // Then add disk skills, skipping any that shadow a bundled name.
    let mut disk_skills: Vec<(String, PathBuf)> = Vec::new();
    for dir in dirs {
        if let Ok(mut entries) = tokio::fs::read_dir(dir).await {
            while let Ok(Some(entry)) = entries.next_entry().await {
                let path = entry.path();
                if path.extension().is_some_and(|e| e == "md") {
                    if let Some(stem) = path.file_stem().and_then(|s| s.to_str()) {
                        let name = stem.to_string();
                        // Deduplicate — project-level shadows user-level;
                        // bundled skills shadow everything; disabled skills hide.
                        if !disk_skills.iter().any(|(n, _)| n == &name)
                            && !bundled_names.contains(&name.as_str())
                            && !disabled.contains(&name)
                        {
                            disk_skills.push((name, path));
                        }
                    }
                }
            }
        }
    }

    disk_skills.sort_by(|a, b| a.0.cmp(&b.0));
    for (name, path) in &disk_skills {
        let desc = read_skill_description(path).await;
        lines.push(format!("  {} — {}", name, desc));
    }

    // Surface Coven daemon skills as read-only awareness. They live at
    // ~/.coven/skills/<id>/metadata.json and use a manifest-only format
    // that this SkillTool can't expand (no prompt body) — so they are
    // listed for visibility but flagged [daemon, not executable].
    let daemon_skills = claurst_core::coven_shared::list_daemon_skills();
    let daemon_count = daemon_skills.len();
    for skill in &daemon_skills {
        let desc = skill
            .description
            .as_deref()
            .or(skill.name.as_deref())
            .unwrap_or("(no description)");
        lines.push(format!(
            "  {} — {} [daemon, not executable from coven-code]",
            skill.id, desc
        ));
    }

    let total = bundled.len() + disk_skills.len() + daemon_count;
    if total == 0 {
        return ToolResult::success(
            "No skills found. Create .md files in .coven-code/commands/ to define skills.\n\
             Example: .coven-code/commands/review.md"
                .to_string(),
        );
    }

    ToolResult::success(format!(
        "Available skills ({}):\n{}",
        total,
        lines.join("\n")
    ))
}

async fn find_and_read_skill(name: &str, dirs: &[PathBuf]) -> Option<(PathBuf, String)> {
    for dir in dirs {
        let path = dir.join(format!("{}.md", name));
        if let Ok(content) = tokio::fs::read_to_string(&path).await {
            return Some((path, content));
        }
    }
    None
}

async fn read_skill_description(path: &std::path::Path) -> String {
    let Ok(content) = tokio::fs::read_to_string(path).await else {
        return "(no description)".to_string();
    };
    let body = strip_frontmatter(&content);
    // First non-empty, non-heading line
    for line in body.lines() {
        let t = line.trim().trim_start_matches('#').trim();
        if !t.is_empty() {
            let truncated = if t.len() > 80 { &t[..80] } else { t };
            return truncated.to_string();
        }
    }
    "(no description)".to_string()
}

/// Remove YAML frontmatter delimited by `---` at the start of the file.
fn strip_frontmatter(content: &str) -> String {
    if let Some(after_open) = content.strip_prefix("---") {
        // Find closing ---
        if let Some(close_pos) = after_open.find("\n---") {
            // Skip past the closing delimiter and any leading newline
            let rest = &after_open[close_pos + 4..];
            return rest.trim_start_matches('\n').to_string();
        }
    }
    content.to_string()
}
