// claurst-tools: All tool implementations for Coven Code.
//
// Each tool maps to a capability the LLM can invoke: running shell commands,
// reading/writing/editing files, searching codebases, fetching web pages, etc.

use async_trait::async_trait;
use claurst_core::config::PermissionMode;
use claurst_core::cost::CostTracker;
use claurst_core::permissions::{PermissionDecision, PermissionHandler, PermissionRequest};
use claurst_core::types::ToolDefinition;
use serde_json::Value;
use std::collections::{HashMap, VecDeque};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

// Sub-modules – each contains a full tool implementation.
pub mod apply_patch;
pub mod ask_user;
mod background_shell;
pub mod bash;
pub mod batch_edit;
pub mod brief;
pub mod bundled_skills;
pub mod computer_use;
pub mod config_tool;
pub mod cron;
pub mod enter_plan_mode;
pub mod exit_plan_mode;
pub mod file_edit;
pub mod file_read;
pub mod file_write;
pub mod formatter;
pub mod glob_tool;
pub mod goal_complete;
pub mod grep_tool;
pub mod lsp_tool;
pub mod mcp_auth_tool;
pub mod mcp_resources;
pub mod monitor_tool;
pub mod notebook_edit;
pub mod powershell;
pub mod pty_bash;
pub mod remote_trigger;
pub mod repl_tool;
pub mod send_message;
mod shell_output;
mod shell_pipe;
pub mod skill_tool;
pub mod sleep;
pub mod synthetic_output;
pub mod tasks;
pub mod team_tool;
pub mod todo_write;
pub mod tool_search;
pub mod web_fetch;
pub mod web_search;
pub mod worktree;

// Re-exports for convenience.
/// How files stood when approval to change them was asked for. Only metadata is
/// kept: nothing may be read before the approval, and looking at a device or a
/// huge file must cost nothing.
#[derive(Debug, Default)]
pub struct ReviewedFiles(Vec<(PathBuf, Option<FileStamp>)>);

type FileStamp = (u64, std::time::SystemTime);

async fn file_stamp(path: &Path) -> Option<FileStamp> {
    let metadata = tokio::fs::metadata(path).await.ok()?;
    Some((metadata.len(), metadata.modified().ok()?))
}

impl ReviewedFiles {
    pub fn extend(&mut self, other: ReviewedFiles) {
        self.0.extend(other.0);
    }

    /// The refusal to give the model if a file no longer stands as reviewed.
    pub async fn ensure_unchanged(&self) -> Result<(), String> {
        for (path, reviewed) in &self.0 {
            if file_stamp(path).await != *reviewed {
                return Err(format!(
                    "{} changed while waiting for approval, so nothing was written. \
                     Read it again before retrying.",
                    path.display()
                ));
            }
        }
        Ok(())
    }
}

pub use apply_patch::ApplyPatchTool;
pub use ask_user::AskUserQuestionTool;
pub use bash::BashTool;
pub use batch_edit::BatchEditTool;
pub use brief::BriefTool;
pub use computer_use::ComputerUseTool;
pub use config_tool::ConfigTool;
pub use cron::{CronCreateTool, CronDeleteTool, CronListTool};
pub use enter_plan_mode::EnterPlanModeTool;
pub use exit_plan_mode::ExitPlanModeTool;
pub use file_edit::FileEditTool;
pub use file_read::FileReadTool;
pub use file_write::FileWriteTool;
pub use formatter::try_format_file;
pub use glob_tool::GlobTool;
pub use goal_complete::{GoalCompleteTool, PathScopedGoalCompleteTool};
pub use grep_tool::GrepTool;
pub use lsp_tool::LspTool;
pub use mcp_auth_tool::McpAuthTool;
pub use mcp_resources::{ListMcpResourcesTool, ReadMcpResourceTool};
pub use monitor_tool::MonitorTool;
pub use notebook_edit::NotebookEditTool;
pub use powershell::PowerShellTool;
pub use pty_bash::PtyBashTool;
pub use remote_trigger::RemoteTriggerTool;
pub use repl_tool::ReplTool;
pub use send_message::{drain_inbox, peek_inbox, SendMessageTool};
pub use skill_tool::SkillTool;
pub use sleep::SleepTool;
pub use synthetic_output::SyntheticOutputTool;
pub use tasks::{
    Task, TaskCreateTool, TaskGetTool, TaskListTool, TaskOutputTool, TaskStatus, TaskStopTool,
    TaskUpdateTool, TASK_STORE,
};
pub use team_tool::{register_agent_runner, AgentRunFn, TeamCreateTool, TeamDeleteTool};
pub use todo_write::TodoWriteTool;
pub use tool_search::ToolSearchTool;
pub use web_fetch::WebFetchTool;
pub use web_search::WebSearchTool;
pub use worktree::{EnterWorktreeTool, ExitWorktreeTool};

// ---------------------------------------------------------------------------
// AskUser question channel
// ---------------------------------------------------------------------------

/// Event sent through the TUI side-channel when the `AskUserQuestion` tool
/// needs to pause the query loop and collect a response from the user.
pub struct UserQuestionEvent {
    /// The question text to display.
    pub question: String,
    /// Optional predefined choices (for multiple-choice questions).
    pub options: Option<Vec<String>>,
    /// Send the user's answer back through this channel to resume execution.
    pub reply_tx: tokio::sync::oneshot::Sender<String>,
}

// ---------------------------------------------------------------------------
// Core trait & types
// ---------------------------------------------------------------------------

/// The result of executing a tool.
#[derive(Debug, Clone)]
pub struct ToolResult {
    /// Content to send back to the model as the tool result.
    pub content: String,
    /// Whether this invocation was an error.
    pub is_error: bool,
    /// Optional structured metadata (for the TUI to render diffs, etc.).
    pub metadata: Option<Value>,
}

impl ToolResult {
    pub fn success(content: impl Into<String>) -> Self {
        Self {
            content: content.into(),
            is_error: false,
            metadata: None,
        }
    }

    pub fn error(content: impl Into<String>) -> Self {
        Self {
            content: content.into(),
            is_error: true,
            metadata: None,
        }
    }

    pub fn with_metadata(mut self, meta: Value) -> Self {
        self.metadata = Some(meta);
        self
    }
}

/// Permission level required by a tool.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PermissionLevel {
    /// No permission needed (read-only, purely informational).
    None,
    /// Read-only access to the filesystem or network.
    ReadOnly,
    /// Write access to the filesystem.
    Write,
    /// Arbitrary command execution.
    Execute,
    /// Potentially dangerous (e.g., bypass sandbox).
    Dangerous,
    /// Unconditionally forbidden — the action must never be executed regardless
    /// of permission mode.  Used by BashTool when the classifier identifies a
    /// `Critical`-risk command (e.g. `rm -rf /`, fork-bomb, `dd if=…`).
    Forbidden,
}

#[derive(Debug)]
pub struct PendingPermissionRequest {
    pub tool_use_id: String,
    /// The model's tool-use id for the call that asked, when known. Distinct
    /// from `tool_use_id`, which keys this request and may be synthetic.
    pub call_id: Option<String>,
    pub request: claurst_core::permissions::PermissionRequest,
    pub reason: String,
    pub decision_tx: Option<tokio::sync::oneshot::Sender<PermissionDecision>>,
}

tokio::task_local! {
    static CURRENT_TOOL_CALL: String;
}

/// Run `future` as the execution of the model tool call `call_id`, so a
/// permission request it raises can be attributed to that call.
pub async fn with_tool_call<F: std::future::Future>(call_id: String, future: F) -> F::Output {
    CURRENT_TOOL_CALL.scope(call_id, future).await
}

/// The model tool call being executed by the current task, if any.
pub fn current_tool_call() -> Option<String> {
    CURRENT_TOOL_CALL.try_with(Clone::clone).ok()
}

#[derive(Default)]
pub struct PendingPermissionStore {
    pub queue: VecDeque<PendingPermissionRequest>,
    pub waiting: HashMap<String, PendingPermissionRequest>,
}

/// Persistent shell state shared across Bash tool invocations within one session.
///
/// The `BashTool` reads and writes this state on every call so that `cd` and
/// `export` commands persist across separate tool invocations, matching the
/// mental model described in the tool description ("the working directory
/// persists between commands").
#[derive(Debug, Clone, Default)]
pub struct ShellState {
    /// Current working directory as tracked by the shell state.
    /// Starts as the session's `working_dir`; updated after each `cd` command.
    pub cwd: Option<PathBuf>,
    /// Environment variable overrides exported by previous commands.
    pub env_vars: HashMap<String, String>,
}

impl ShellState {
    pub fn new() -> Self {
        Self::default()
    }
}

/// Process-global registry of shell states keyed by session_id.
/// This lets us persist cwd/env across Bash invocations without changing
/// the `ToolContext` struct (which is constructed in places we cannot modify).
static SHELL_STATE_REGISTRY: once_cell::sync::Lazy<
    dashmap::DashMap<String, Arc<parking_lot::Mutex<ShellState>>>,
> = once_cell::sync::Lazy::new(dashmap::DashMap::new);

/// Return the persistent `ShellState` for the given session, creating one if needed.
pub fn session_shell_state(session_id: &str) -> Arc<parking_lot::Mutex<ShellState>> {
    SHELL_STATE_REGISTRY
        .entry(session_id.to_string())
        .or_insert_with(|| Arc::new(parking_lot::Mutex::new(ShellState::new())))
        .clone()
}

/// Remove the shell state for a session (e.g. when the session ends).
pub fn clear_session_shell_state(session_id: &str) {
    SHELL_STATE_REGISTRY.remove(session_id);
}

/// Return the `ShadowSnapshot` for `working_dir`, creating it on first call.
/// Returns `None` when git is unavailable or the directory is not in a git repo.
pub fn session_shadow(
    working_dir: &std::path::Path,
) -> Option<Arc<claurst_core::snapshot::ShadowSnapshot>> {
    claurst_core::snapshot::get_or_create(working_dir)
}

/// Drop the cached shadow snapshot for `working_dir` (e.g. when a session ends).
pub fn clear_session_shadow(working_dir: &std::path::Path) {
    claurst_core::snapshot::remove(working_dir);
}

/// Structured payload describing a background task's terminal state.
/// Carried by [`CompletionNotifier`] so consumers can build their own UI
/// (system-message injection, TUI toasts, terminal bell, etc.) without
/// re-parsing a string.
#[derive(Debug, Clone)]
pub struct BgTaskCompletion {
    pub task_id: String,
    pub command: String,
    /// `true` if the task exited 0; `false` for non-zero, cancellation, or timeout.
    pub success: bool,
    /// Short human-readable status: `"exit 0"`, `"failed: ..."`, `"cancelled"`.
    pub exit_info: String,
    /// Last ~2000 characters of stdout/stderr (for system-message injection).
    pub output_tail: String,
    /// How long the task ran before reaching the terminal state.
    pub duration_secs: u64,
}

/// A cloneable handle invoked when a background bash task reaches a terminal state.
/// Used by `notify_on_complete` to signal completion without polling.
///
/// The closure receives a structured [`BgTaskCompletion`] so it can fan-out to
/// multiple sinks (e.g., inject a system message AND show a TUI toast).
#[derive(Clone)]
pub struct CompletionNotifier(Arc<dyn Fn(BgTaskCompletion) + Send + Sync>);

impl CompletionNotifier {
    pub fn new(f: impl Fn(BgTaskCompletion) + Send + Sync + 'static) -> Self {
        Self(Arc::new(f))
    }
    pub fn notify(&self, info: BgTaskCompletion) {
        (self.0)(info);
    }
}

/// Shared context passed to every tool invocation.
#[derive(Clone)]
pub struct ToolContext {
    pub working_dir: PathBuf,
    pub permission_mode: PermissionMode,
    pub permission_handler: Arc<dyn PermissionHandler>,
    pub cost_tracker: Arc<CostTracker>,
    pub session_id: String,
    /// Completion authority captured once for this logical query.
    pub goal_turn: claurst_core::goal::GoalTurnContext,
    pub file_history: Arc<parking_lot::Mutex<claurst_core::file_history::FileHistory>>,
    pub current_turn: Arc<AtomicUsize>,
    /// If true, suppress interactive prompts (batch / CI mode).
    pub non_interactive: bool,
    /// Optional MCP manager for ListMcpResources / ReadMcpResource tools.
    pub mcp_manager: Option<Arc<claurst_mcp::McpManager>>,
    /// Configured event hooks (PreToolUse, PostToolUse, etc.).
    pub config: claurst_core::config::Config,
    /// Managed agent (manager-executor) configuration, if active.
    pub managed_agent_config: Option<claurst_core::config::ManagedAgentConfig>,
    /// Optional notifier for injecting completion messages into the next agent turn.
    /// Set when the query loop has a command queue wired up.
    pub completion_notifier: Option<CompletionNotifier>,
    /// Queue used by interactive mode to surface permission dialogs to the TUI.
    pub pending_permissions: Option<Arc<parking_lot::Mutex<PendingPermissionStore>>>,
    /// Shared permission manager so the interactive loop can record session/persistent approvals.
    pub permission_manager:
        Option<Arc<std::sync::Mutex<claurst_core::permissions::PermissionManager>>>,
    /// Channel for the `AskUserQuestion` tool to send questions to the TUI and
    /// receive the user's typed answer.  `None` in headless / non-interactive mode.
    pub user_question_tx: Option<tokio::sync::mpsc::UnboundedSender<UserQuestionEvent>>,
}

impl ToolContext {
    /// Resolve a potentially relative path against the working directory.
    pub fn resolve_path(&self, path: &str) -> PathBuf {
        let p = PathBuf::from(path);
        if p.is_absolute() {
            p
        } else {
            self.working_dir.join(p)
        }
    }

    fn permission_allowed_roots(&self) -> Vec<PathBuf> {
        let mut roots = self.config.workspace_paths.clone();
        roots.extend(self.config.additional_dirs.clone());
        roots
    }

    fn build_permission_request(
        &self,
        tool_name: &str,
        description: &str,
        details: Option<String>,
        is_read_only: bool,
        path: Option<PathBuf>,
    ) -> PermissionRequest {
        PermissionRequest {
            tool_name: tool_name.to_string(),
            description: description.to_string(),
            details,
            is_read_only,
            path: path.map(|p| p.display().to_string()),
            working_dir: Some(self.working_dir.clone()),
            allowed_roots: self.permission_allowed_roots(),
            context_description: None,
        }
    }

    fn request_permission_inner(
        &self,
        request: PermissionRequest,
    ) -> Result<(), claurst_core::error::ClaudeError> {
        self.goal_turn
            .require_work(&self.session_id)
            .map_err(|error| {
                claurst_core::error::ClaudeError::PermissionDenied(error.to_string())
            })?;
        let interactive_reason = request.details.clone();
        let decision = self.permission_handler.request_permission(&request);
        let result = match decision {
            PermissionDecision::Allow | PermissionDecision::AllowPermanently => Ok(()),
            PermissionDecision::Ask { reason } if self.non_interactive => {
                Err(claurst_core::error::ClaudeError::PermissionDenied(format!(
                    "Permission denied for tool '{}': {}",
                    request.tool_name,
                    interactive_reason.unwrap_or(reason)
                )))
            }
            PermissionDecision::Ask { reason } => {
                let Some(queue) = &self.pending_permissions else {
                    return Err(claurst_core::error::ClaudeError::PermissionDenied(format!(
                        "Permission denied for tool '{}'",
                        request.tool_name
                    )));
                };

                let (tx, rx) = tokio::sync::oneshot::channel();
                queue.lock().queue.push_back(PendingPermissionRequest {
                    tool_use_id: format!(
                        "perm-{}-{}",
                        self.session_id,
                        self.current_turn.fetch_add(1, Ordering::Relaxed)
                    ),
                    call_id: current_tool_call(),
                    request,
                    reason: interactive_reason.unwrap_or(reason),
                    decision_tx: Some(tx),
                });

                let decision = tokio::task::block_in_place(|| rx.blocking_recv());
                match decision {
                    Ok(PermissionDecision::Allow | PermissionDecision::AllowPermanently) => Ok(()),
                    _ => Err(claurst_core::error::ClaudeError::PermissionDenied(
                        "Permission denied by user".to_string(),
                    )),
                }
            }
            _ => Err(claurst_core::error::ClaudeError::PermissionDenied(format!(
                "Permission denied for tool '{}'",
                request.tool_name
            ))),
        };
        result?;
        self.goal_turn
            .require_work(&self.session_id)
            .map_err(|error| claurst_core::error::ClaudeError::PermissionDenied(error.to_string()))
    }

    /// Check permissions for a tool invocation.
    pub fn check_permission(
        &self,
        tool_name: &str,
        description: &str,
        is_read_only: bool,
    ) -> Result<(), claurst_core::error::ClaudeError> {
        let request =
            self.build_permission_request(tool_name, description, None, is_read_only, None);
        self.request_permission_inner(request)
    }

    /// Note how `paths` stand before asking for approval to change them. Holds
    /// nothing unless this session's approvals are bound to file content.
    pub async fn files_under_review(
        &self,
        paths: impl IntoIterator<Item = PathBuf>,
    ) -> ReviewedFiles {
        let mut reviewed = ReviewedFiles::default();
        if self.permission_handler.binds_approvals_to_content() {
            for path in paths {
                let stamp = file_stamp(&path).await;
                reviewed.0.push((path, stamp));
            }
        }
        reviewed
    }

    pub fn check_permission_for_path(
        &self,
        tool_name: &str,
        description: &str,
        path: PathBuf,
        is_read_only: bool,
    ) -> Result<(), claurst_core::error::ClaudeError> {
        let request =
            self.build_permission_request(tool_name, description, None, is_read_only, Some(path));
        self.request_permission_inner(request)
    }

    /// Hosted repair runs GitHub-supplied prompts with permission bypass, so
    /// file tools must enforce the repository boundary themselves.
    pub fn check_hosted_repair_path(
        &self,
        tool_name: &str,
        path: &Path,
    ) -> Result<(), claurst_core::error::ClaudeError> {
        if !self.config.hosted_review.allow_file_write_tools {
            return Ok(());
        }

        if self.path_is_within_working_dir(path) {
            return Ok(());
        }

        Err(claurst_core::error::ClaudeError::PermissionDenied(format!(
            "Permission denied for tool '{}': hosted repair file tools are limited to {}",
            tool_name,
            self.working_dir.display()
        )))
    }

    /// Like `check_permission` but also passes structured `details` text
    /// (e.g. a risk explanation) that the TUI permission dialog can display.
    pub fn check_permission_with_details(
        &self,
        tool_name: &str,
        description: &str,
        details: &str,
        is_read_only: bool,
    ) -> Result<(), claurst_core::error::ClaudeError> {
        let request = self.build_permission_request(
            tool_name,
            description,
            Some(details.to_string()),
            is_read_only,
            None,
        );
        self.request_permission_inner(request).map_err(|_| {
            claurst_core::error::ClaudeError::PermissionDenied(format!(
                "Permission denied for tool '{}': {}",
                tool_name, details
            ))
        })
    }

    pub fn path_is_within_workspace(&self, path: &std::path::Path) -> bool {
        let resolved = std::fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf());
        let mut roots =
            vec![std::fs::canonicalize(&self.working_dir)
                .unwrap_or_else(|_| self.working_dir.clone())];
        roots.extend(
            self.permission_allowed_roots()
                .into_iter()
                .map(|root| std::fs::canonicalize(&root).unwrap_or(root)),
        );
        roots.iter().any(|root| resolved.starts_with(root))
    }

    fn path_is_within_working_dir(&self, path: &Path) -> bool {
        if let Ok(relative) = path.strip_prefix(&self.working_dir) {
            if contains_git_metadata_component(relative) {
                return false;
            }
        }

        let Ok(root) = std::fs::canonicalize(&self.working_dir) else {
            return false;
        };
        let Ok(resolved) = canonicalize_path_allow_missing(path) else {
            return false;
        };
        let Ok(relative) = resolved.strip_prefix(&root) else {
            return false;
        };

        // Git metadata controls later host-side `git` calls (for example via
        // core.fsmonitor), so hosted repair must treat it as control-plane data.
        !contains_git_metadata_component(relative)
    }

    pub fn check_permission_with_details_and_path(
        &self,
        tool_name: &str,
        description: &str,
        details: &str,
        path: PathBuf,
        is_read_only: bool,
    ) -> Result<(), claurst_core::error::ClaudeError> {
        let request = self.build_permission_request(
            tool_name,
            description,
            Some(details.to_string()),
            is_read_only,
            Some(path),
        );
        self.request_permission_inner(request).map_err(|_| {
            claurst_core::error::ClaudeError::PermissionDenied(format!(
                "Permission denied for tool '{}': {}",
                tool_name, details
            ))
        })
    }

    pub fn current_turn_index(&self) -> usize {
        self.current_turn.load(Ordering::Relaxed)
    }

    pub fn record_file_change(
        &self,
        path: PathBuf,
        before_content: &[u8],
        after_content: &[u8],
        tool_name: &str,
    ) {
        self.file_history.lock().record_modification(
            path,
            before_content,
            after_content,
            self.current_turn_index(),
            tool_name,
        );
    }
}

fn contains_git_metadata_component(path: &Path) -> bool {
    path.components().any(|component| {
        matches!(
            component,
            Component::Normal(name)
                if name.to_str().is_some_and(|name| {
                    // Win32 strips trailing dots/spaces and exposes directories
                    // through alternate streams and 8.3 short names.
                    let name = name.split_once(':').map_or(name, |(base, _)| base);
                    let name = name.trim_end_matches(['.', ' ']);
                    name.eq_ignore_ascii_case(".git") || name.eq_ignore_ascii_case("git~1")
                })
        )
    })
}

/// Resolve every existing component before applying later `..` components,
/// while retaining nonexistent suffixes for file-creation tools.
fn canonicalize_path_allow_missing(path: &Path) -> std::io::Result<PathBuf> {
    if !path.is_absolute() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "hosted repair paths must be absolute",
        ));
    }

    let mut resolved = PathBuf::new();
    for component in path.components() {
        match component {
            Component::Prefix(prefix) => resolved.push(prefix.as_os_str()),
            root @ Component::RootDir => {
                resolved.push(root.as_os_str());
                resolved = std::fs::canonicalize(&resolved)?;
            }
            Component::CurDir => {}
            Component::ParentDir => {
                resolved.pop();
            }
            Component::Normal(name) => {
                let candidate = resolved.join(name);
                match std::fs::symlink_metadata(&candidate) {
                    Ok(_) => resolved = std::fs::canonicalize(candidate)?,
                    Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                        resolved.push(name);
                    }
                    Err(error) => return Err(error),
                }
            }
        }
    }
    Ok(resolved)
}

/// The trait every tool must implement.
#[async_trait]
pub trait Tool: Send + Sync {
    /// Human-readable name (matches the constant in claurst_core::constants).
    fn name(&self) -> &str;

    /// One-line description shown to the LLM.
    fn description(&self) -> &str;

    /// The permission level the tool requires.
    fn permission_level(&self) -> PermissionLevel;

    /// JSON Schema describing the tool's input parameters.
    fn input_schema(&self) -> Value;

    /// Execute the tool with the given JSON input.
    async fn execute(&self, input: Value, ctx: &ToolContext) -> ToolResult;

    /// Produce a `ToolDefinition` suitable for sending to the API.
    fn to_definition(&self) -> ToolDefinition {
        ToolDefinition {
            name: self.name().to_string(),
            description: self.description().to_string(),
            input_schema: self.input_schema(),
        }
    }
}

/// Built-in tool names in the same order as [`all_tools`].
pub const BUILTIN_TOOL_NAMES: &[&str] = &[
    claurst_core::constants::TOOL_NAME_BASH,
    claurst_core::constants::TOOL_NAME_FILE_READ,
    claurst_core::constants::TOOL_NAME_FILE_EDIT,
    claurst_core::constants::TOOL_NAME_FILE_WRITE,
    claurst_core::constants::TOOL_NAME_BATCH_EDIT,
    claurst_core::constants::TOOL_NAME_APPLY_PATCH,
    claurst_core::constants::TOOL_NAME_GLOB,
    claurst_core::constants::TOOL_NAME_GREP,
    claurst_core::constants::TOOL_NAME_WEB_FETCH,
    claurst_core::constants::TOOL_NAME_WEB_SEARCH,
    claurst_core::constants::TOOL_NAME_NOTEBOOK_EDIT,
    claurst_core::constants::TOOL_NAME_TASK_CREATE,
    claurst_core::constants::TOOL_NAME_TASK_GET,
    claurst_core::constants::TOOL_NAME_TASK_UPDATE,
    claurst_core::constants::TOOL_NAME_TASK_LIST,
    claurst_core::constants::TOOL_NAME_TASK_STOP,
    claurst_core::constants::TOOL_NAME_TASK_OUTPUT,
    claurst_core::constants::TOOL_NAME_TODO_WRITE,
    claurst_core::constants::TOOL_NAME_ASK_USER,
    claurst_core::constants::TOOL_NAME_ENTER_PLAN_MODE,
    claurst_core::constants::TOOL_NAME_EXIT_PLAN_MODE,
    "PowerShell",
    "Sleep",
    "CronCreate",
    "CronDelete",
    "CronList",
    "EnterWorktree",
    "ExitWorktree",
    "ListMcpResources",
    "ReadMcpResource",
    "ToolSearch",
    "Brief",
    "Config",
    "SendMessage",
    "Skill",
    "LSP",
    "REPL",
    "TeamCreate",
    "TeamDelete",
    "StructuredOutput",
    "mcp__auth",
    "RemoteTrigger",
    "monitor",
    "GoalComplete",
    #[cfg(feature = "computer-use")]
    "computer",
];

pub fn all_tool_names() -> &'static [&'static str] {
    BUILTIN_TOOL_NAMES
}

/// Return all built-in tools (excluding AgentTool, which lives in cc-query).
pub fn all_tools() -> Vec<Box<dyn Tool>> {
    vec![
        Box::new(PtyBashTool),
        Box::new(FileReadTool),
        Box::new(FileEditTool),
        Box::new(FileWriteTool),
        Box::new(BatchEditTool),
        Box::new(ApplyPatchTool),
        Box::new(GlobTool),
        Box::new(GrepTool),
        Box::new(WebFetchTool),
        Box::new(WebSearchTool),
        Box::new(NotebookEditTool),
        Box::new(TaskCreateTool),
        Box::new(TaskGetTool),
        Box::new(TaskUpdateTool),
        Box::new(TaskListTool),
        Box::new(TaskStopTool),
        Box::new(TaskOutputTool),
        Box::new(TodoWriteTool),
        Box::new(AskUserQuestionTool),
        Box::new(EnterPlanModeTool),
        Box::new(ExitPlanModeTool),
        Box::new(PowerShellTool),
        Box::new(SleepTool),
        Box::new(CronCreateTool),
        Box::new(CronDeleteTool),
        Box::new(CronListTool),
        Box::new(EnterWorktreeTool),
        Box::new(ExitWorktreeTool),
        Box::new(ListMcpResourcesTool),
        Box::new(ReadMcpResourceTool),
        Box::new(ToolSearchTool),
        Box::new(BriefTool),
        Box::new(ConfigTool),
        Box::new(SendMessageTool),
        Box::new(SkillTool),
        Box::new(LspTool),
        Box::new(ReplTool),
        Box::new(TeamCreateTool),
        Box::new(TeamDeleteTool),
        Box::new(SyntheticOutputTool),
        Box::new(McpAuthTool),
        Box::new(RemoteTriggerTool),
        Box::new(MonitorTool),
        Box::new(GoalCompleteTool),
        // Computer Use is only available when compiled with the feature flag.
        #[cfg(feature = "computer-use")]
        Box::new(computer_use::ComputerUseTool),
    ]
}

/// Find a tool by name (case-sensitive).
pub fn find_tool(name: &str) -> Option<Box<dyn Tool>> {
    match name {
        claurst_core::constants::TOOL_NAME_BASH => Some(Box::new(PtyBashTool)),
        claurst_core::constants::TOOL_NAME_FILE_READ => Some(Box::new(FileReadTool)),
        claurst_core::constants::TOOL_NAME_FILE_EDIT => Some(Box::new(FileEditTool)),
        claurst_core::constants::TOOL_NAME_FILE_WRITE => Some(Box::new(FileWriteTool)),
        claurst_core::constants::TOOL_NAME_BATCH_EDIT => Some(Box::new(BatchEditTool)),
        claurst_core::constants::TOOL_NAME_APPLY_PATCH => Some(Box::new(ApplyPatchTool)),
        claurst_core::constants::TOOL_NAME_GLOB => Some(Box::new(GlobTool)),
        claurst_core::constants::TOOL_NAME_GREP => Some(Box::new(GrepTool)),
        claurst_core::constants::TOOL_NAME_WEB_FETCH => Some(Box::new(WebFetchTool)),
        claurst_core::constants::TOOL_NAME_WEB_SEARCH => Some(Box::new(WebSearchTool)),
        claurst_core::constants::TOOL_NAME_NOTEBOOK_EDIT => Some(Box::new(NotebookEditTool)),
        claurst_core::constants::TOOL_NAME_TASK_CREATE => Some(Box::new(TaskCreateTool)),
        claurst_core::constants::TOOL_NAME_TASK_GET => Some(Box::new(TaskGetTool)),
        claurst_core::constants::TOOL_NAME_TASK_UPDATE => Some(Box::new(TaskUpdateTool)),
        claurst_core::constants::TOOL_NAME_TASK_LIST => Some(Box::new(TaskListTool)),
        claurst_core::constants::TOOL_NAME_TASK_STOP => Some(Box::new(TaskStopTool)),
        claurst_core::constants::TOOL_NAME_TASK_OUTPUT => Some(Box::new(TaskOutputTool)),
        claurst_core::constants::TOOL_NAME_TODO_WRITE => Some(Box::new(TodoWriteTool)),
        claurst_core::constants::TOOL_NAME_ASK_USER => Some(Box::new(AskUserQuestionTool)),
        claurst_core::constants::TOOL_NAME_ENTER_PLAN_MODE => Some(Box::new(EnterPlanModeTool)),
        claurst_core::constants::TOOL_NAME_EXIT_PLAN_MODE => Some(Box::new(ExitPlanModeTool)),
        "PowerShell" => Some(Box::new(PowerShellTool)),
        "Sleep" => Some(Box::new(SleepTool)),
        "CronCreate" => Some(Box::new(CronCreateTool)),
        "CronDelete" => Some(Box::new(CronDeleteTool)),
        "CronList" => Some(Box::new(CronListTool)),
        "EnterWorktree" => Some(Box::new(EnterWorktreeTool)),
        "ExitWorktree" => Some(Box::new(ExitWorktreeTool)),
        "ListMcpResources" => Some(Box::new(ListMcpResourcesTool)),
        "ReadMcpResource" => Some(Box::new(ReadMcpResourceTool)),
        "ToolSearch" => Some(Box::new(ToolSearchTool)),
        "Brief" => Some(Box::new(BriefTool)),
        "Config" => Some(Box::new(ConfigTool)),
        "SendMessage" => Some(Box::new(SendMessageTool)),
        "Skill" => Some(Box::new(SkillTool)),
        "LSP" => Some(Box::new(LspTool)),
        "REPL" => Some(Box::new(ReplTool)),
        "TeamCreate" => Some(Box::new(TeamCreateTool)),
        "TeamDelete" => Some(Box::new(TeamDeleteTool)),
        "StructuredOutput" => Some(Box::new(SyntheticOutputTool)),
        "mcp__auth" => Some(Box::new(McpAuthTool)),
        "RemoteTrigger" => Some(Box::new(RemoteTriggerTool)),
        "monitor" => Some(Box::new(MonitorTool)),
        "GoalComplete" => Some(Box::new(GoalCompleteTool)),
        #[cfg(feature = "computer-use")]
        "computer" | "ComputerUse" => Some(Box::new(ComputerUseTool)),
        _ => None,
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    #[tokio::test]
    async fn each_concurrent_tool_call_sees_its_own_call_id() {
        assert_eq!(super::current_tool_call(), None);
        let probe = || async {
            tokio::task::yield_now().await;
            super::current_tool_call()
        };
        let (first, second) = futures::future::join(
            super::with_tool_call("toolu_a".to_string(), probe()),
            super::with_tool_call("toolu_b".to_string(), probe()),
        )
        .await;
        assert_eq!(first.as_deref(), Some("toolu_a"));
        assert_eq!(second.as_deref(), Some("toolu_b"));
        assert_eq!(super::current_tool_call(), None);
    }

    use super::*;

    struct AskPermissionHandler {
        reason: String,
    }

    impl claurst_core::permissions::PermissionHandler for AskPermissionHandler {
        fn check_permission(
            &self,
            _request: &claurst_core::permissions::PermissionRequest,
        ) -> claurst_core::permissions::PermissionDecision {
            claurst_core::permissions::PermissionDecision::Ask {
                reason: self.reason.clone(),
            }
        }

        fn request_permission(
            &self,
            request: &claurst_core::permissions::PermissionRequest,
        ) -> claurst_core::permissions::PermissionDecision {
            self.check_permission(request)
        }
    }

    fn test_tool_context(
        handler: Arc<dyn claurst_core::permissions::PermissionHandler>,
    ) -> ToolContext {
        use claurst_core::config::Config;

        ToolContext {
            working_dir: PathBuf::from("/workspace"),
            permission_mode: claurst_core::config::PermissionMode::Default,
            permission_handler: handler,
            cost_tracker: claurst_core::cost::CostTracker::new(),
            session_id: "test".to_string(),
            goal_turn: Default::default(),
            file_history: Arc::new(parking_lot::Mutex::new(
                claurst_core::file_history::FileHistory::new(),
            )),
            current_turn: Arc::new(AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn goal_permission_wait_rechecks_authority_after_allow() {
        for revoke in [false, true] {
            let dir = tempfile::tempdir().unwrap();
            let path = dir.path().join("goals.sqlite");
            let store = claurst_core::GoalStore::open(&path).unwrap();
            store.set_goal("test", "A", None).unwrap();
            let mut ctx = test_tool_context(Arc::new(AskPermissionHandler {
                reason: "allow write".into(),
            }));
            ctx.working_dir = dir.path().to_path_buf();
            ctx.non_interactive = false;
            ctx.goal_turn = claurst_core::goal::GoalTurnContext::Captured(
                store.capture_active_goal("test").unwrap(),
            );
            let queue = Arc::new(parking_lot::Mutex::new(PendingPermissionStore::default()));
            ctx.pending_permissions = Some(queue.clone());
            let worker = tokio::spawn(async move {
                let permission = ctx.check_permission("Write", "fixture write", false);
                if permission.is_ok() {
                    std::fs::write(ctx.working_dir.join("after-approval.txt"), "work").unwrap();
                }
                permission
            });
            let request = tokio::time::timeout(std::time::Duration::from_secs(2), async {
                loop {
                    if let Some(request) = queue.lock().queue.pop_front() {
                        break request;
                    }
                    tokio::time::sleep(std::time::Duration::from_millis(1)).await;
                }
            })
            .await;
            if request.is_err() {
                queue.lock().queue.clear();
                worker.abort();
                let _ = worker.await;
                panic!("permission request did not reach actual pending queue");
            }
            if revoke {
                store
                    .set_status("test", claurst_core::GoalStatus::Paused)
                    .unwrap();
            }
            request
                .unwrap()
                .decision_tx
                .unwrap()
                .send(PermissionDecision::Allow)
                .unwrap();
            let result = worker.await.unwrap();
            assert_eq!(
                result.is_err(),
                revoke,
                "approval cannot revive goal authority"
            );
            assert_eq!(dir.path().join("after-approval.txt").exists(), !revoke);
        }
    }

    // ---- Tool registry tests ------------------------------------------------

    #[test]
    fn test_all_tools_non_empty() {
        let tools = all_tools();
        assert!(
            !tools.is_empty(),
            "all_tools() must return at least one tool"
        );
    }

    #[test]
    fn test_all_tools_have_unique_names() {
        let tools = all_tools();
        let mut names = std::collections::HashSet::new();
        for tool in &tools {
            assert!(
                names.insert(tool.name().to_string()),
                "Duplicate tool name: {}",
                tool.name()
            );
        }
    }

    #[test]
    fn test_all_tool_names_match_all_tools() {
        let tools = all_tools();
        let from_tools: Vec<&str> = tools.iter().map(|tool| tool.name()).collect();
        assert_eq!(all_tool_names(), from_tools.as_slice());
    }

    #[test]
    fn test_all_tools_have_non_empty_descriptions() {
        for tool in all_tools() {
            assert!(
                !tool.description().is_empty(),
                "Tool '{}' has empty description",
                tool.name()
            );
        }
    }

    #[test]
    fn test_all_tools_have_valid_input_schema() {
        for tool in all_tools() {
            let schema = tool.input_schema();
            assert!(
                schema.is_object(),
                "Tool '{}' input_schema must be a JSON object",
                tool.name()
            );
            assert!(
                schema.get("type").is_some() || schema.get("properties").is_some(),
                "Tool '{}' schema missing type or properties",
                tool.name()
            );
        }
    }

    #[test]
    fn test_advertised_tool_names_round_trip() {
        for &name in all_tool_names() {
            let tool = find_tool(name).unwrap_or_else(|| panic!("Missing tool: {name}"));
            assert_eq!(tool.name(), name);
        }
    }

    #[cfg(feature = "computer-use")]
    #[test]
    fn test_computer_use_lookup_alias() {
        let canonical = find_tool("computer").expect("canonical computer tool");
        let alias = find_tool("ComputerUse").expect("existing ComputerUse alias");
        assert_eq!(canonical.name(), "computer");
        assert_eq!(alias.name(), canonical.name());
        assert_eq!(alias.to_definition().name, canonical.to_definition().name);
        assert_eq!(alias.input_schema(), canonical.input_schema());
        assert_eq!(alias.permission_level(), canonical.permission_level());
    }

    #[test]
    fn test_find_tool_found() {
        let tool = find_tool("Bash");
        assert!(tool.is_some(), "Should find the Bash tool");
        assert_eq!(tool.unwrap().name(), "Bash");
    }

    #[test]
    fn test_find_tool_not_found() {
        assert!(find_tool("NonExistentTool12345").is_none());
    }

    #[test]
    fn test_find_tool_case_sensitive() {
        // Tool names are case-sensitive — "bash" should not match "Bash"
        assert!(find_tool("bash").is_none());
        assert!(find_tool("Bash").is_some());
    }

    #[test]
    fn test_core_tools_present() {
        let expected = [
            "Bash",
            "Read",
            "Edit",
            "Write",
            "Glob",
            "Grep",
            "WebFetch",
            "WebSearch",
            "TodoWrite",
            "Skill",
        ];
        for name in &expected {
            assert!(
                find_tool(name).is_some(),
                "Expected tool '{}' not found in all_tools()",
                name
            );
        }
    }

    // ---- ToolResult tests ---------------------------------------------------

    #[test]
    fn test_tool_result_success() {
        let r = ToolResult::success("done");
        assert!(!r.is_error);
        assert_eq!(r.content, "done");
        assert!(r.metadata.is_none());
    }

    #[test]
    fn test_tool_result_error() {
        let r = ToolResult::error("something went wrong");
        assert!(r.is_error);
        assert_eq!(r.content, "something went wrong");
    }

    #[test]
    fn test_tool_result_with_metadata() {
        let r = ToolResult::success("ok")
            .with_metadata(serde_json::json!({"file": "foo.rs", "lines": 10}));
        assert!(r.metadata.is_some());
        let meta = r.metadata.unwrap();
        assert_eq!(meta["file"], "foo.rs");
    }

    // ---- ToolContext::resolve_path tests ------------------------------------

    #[test]
    fn test_resolve_path_absolute() {
        use claurst_core::permissions::AutoPermissionHandler;

        let handler = Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::Default,
        });
        let ctx = test_tool_context(handler);

        // Absolute paths pass through unchanged
        let resolved = ctx.resolve_path("/absolute/path/file.rs");
        assert_eq!(resolved, PathBuf::from("/absolute/path/file.rs"));
    }

    #[test]
    fn test_resolve_path_relative() {
        use claurst_core::permissions::AutoPermissionHandler;

        let handler = Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::Default,
        });
        let ctx = test_tool_context(handler);

        // Relative paths get joined with working_dir
        let resolved = ctx.resolve_path("src/main.rs");
        assert_eq!(resolved, PathBuf::from("/workspace/src/main.rs"));
    }

    #[test]
    fn test_request_permission_uses_details_for_non_interactive_errors() {
        let ctx = test_tool_context(Arc::new(AskPermissionHandler {
            reason: "generic reason".to_string(),
        }));
        let request = ctx.build_permission_request(
            "PowerShell",
            "[High risk] set execution policy",
            Some("[High risk] This may modify system-wide security policy.".to_string()),
            false,
            Some(PathBuf::from("Set-ExecutionPolicy RemoteSigned")),
        );

        let error = ctx
            .request_permission_inner(request)
            .unwrap_err()
            .to_string();
        assert!(error.contains("[High risk] This may modify system-wide security policy."));
        assert!(!error.contains("generic reason"));
    }

    #[test]
    fn test_request_permission_falls_back_to_handler_reason_without_details() {
        let ctx = test_tool_context(Arc::new(AskPermissionHandler {
            reason: "generic reason".to_string(),
        }));
        let request = ctx.build_permission_request(
            "Bash",
            "run ls",
            None,
            false,
            Some(PathBuf::from("ls -la")),
        );

        let error = ctx
            .request_permission_inner(request)
            .unwrap_err()
            .to_string();
        assert!(error.contains("generic reason"));
    }

    #[test]
    fn hosted_repair_path_check_allows_working_dir_files() {
        use claurst_core::permissions::AutoPermissionHandler;

        let temp = tempfile::tempdir().expect("tempdir");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = temp.path().to_path_buf();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = ctx.resolve_path("src/new.rs");
        assert!(ctx.check_hosted_repair_path("Write", &path).is_ok());
    }

    #[test]
    fn hosted_repair_path_check_rejects_parent_escape() {
        use claurst_core::permissions::AutoPermissionHandler;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir(&workspace).expect("workspace dir");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace;
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = ctx.resolve_path("../outside.txt");
        let error = ctx
            .check_hosted_repair_path("Read", &path)
            .expect_err("parent escape must be rejected")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[test]
    fn hosted_repair_path_check_rejects_uncanonicalizable_working_dir() {
        use claurst_core::permissions::AutoPermissionHandler;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = std::fs::canonicalize(temp.path())
            .expect("canonical tempdir")
            .join("missing-workspace");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace.clone();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = workspace.join("new.rs");
        let error = ctx
            .check_hosted_repair_path("Write", &path)
            .expect_err("uncanonicalizable working dir must fail closed")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[test]
    fn hosted_repair_path_check_rejects_git_metadata() {
        use claurst_core::permissions::AutoPermissionHandler;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir_all(workspace.join(".git")).expect("git metadata dir");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace.clone();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        for path in [
            workspace.join(".git"),
            workspace.join(".git/config"),
            workspace.join("nested/.GiT/config"),
            workspace.join(".git./config"),
            workspace.join(".git /config"),
            workspace.join(".GIT... /config"),
            workspace.join(".git::$INDEX_ALLOCATION/config"),
            workspace.join(".git.::$INDEX_ALLOCATION/config"),
            workspace.join("git~1/config"),
            workspace.join("GIT~1. /config"),
            workspace.join(".git/missing/../../source.rs"),
        ] {
            let error = ctx
                .check_hosted_repair_path("Write", &path)
                .expect_err("Git control metadata must be immutable in hosted repair")
                .to_string();

            assert!(error.contains("hosted repair file tools are limited"));
        }
    }

    #[test]
    fn hosted_repair_path_check_rejects_linked_worktree_gitdir_file() {
        use claurst_core::permissions::AutoPermissionHandler;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir(&workspace).expect("workspace dir");
        std::fs::write(
            workspace.join(".git"),
            "gitdir: ../main.git/worktrees/workspace\n",
        )
        .expect("gitdir file");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace.clone();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let error = ctx
            .check_hosted_repair_path("Edit", &workspace.join(".git"))
            .expect_err("linked-worktree gitdir file must be immutable")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[test]
    fn hosted_repair_path_resolution_does_not_pop_past_filesystem_root() {
        let temp = tempfile::tempdir().expect("tempdir");
        let canonical_temp = std::fs::canonicalize(temp.path()).expect("canonical tempdir");
        let filesystem_root = canonical_temp
            .ancestors()
            .find(|ancestor| ancestor.parent().is_none())
            .expect("filesystem root")
            .to_path_buf();
        let mut path = canonical_temp.clone();
        for _ in 0..canonical_temp.components().count() + 2 {
            path.push("..");
        }
        path.push("new.txt");

        let resolved = canonicalize_path_allow_missing(&path).expect("absolute path");

        assert_eq!(
            resolved,
            std::fs::canonicalize(filesystem_root)
                .expect("canonical filesystem root")
                .join("new.txt")
        );
        assert!(resolved.is_absolute());
    }

    #[cfg(unix)]
    #[test]
    fn hosted_repair_path_check_rejects_symlink_escape() {
        use claurst_core::permissions::AutoPermissionHandler;
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        let outside = temp.path().join("outside");
        std::fs::create_dir(&workspace).expect("workspace dir");
        std::fs::create_dir(&outside).expect("outside dir");
        symlink(&outside, workspace.join("link")).expect("symlink");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace;
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = ctx.resolve_path("link/new.txt");
        let error = ctx
            .check_hosted_repair_path("Write", &path)
            .expect_err("symlink escape must be rejected")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[cfg(unix)]
    #[test]
    fn hosted_repair_path_check_resolves_symlink_before_parent_component() {
        use claurst_core::permissions::AutoPermissionHandler;
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        let outside = temp.path().join("outside");
        let nested = outside.join("nested");
        std::fs::create_dir(&workspace).expect("workspace dir");
        std::fs::create_dir_all(&nested).expect("outside nested dir");
        symlink(&nested, workspace.join("link")).expect("symlink");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace.clone();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = workspace.join("link").join("..").join("secret.txt");
        let error = ctx
            .check_hosted_repair_path("Write", &path)
            .expect_err("symlink must resolve before applying parent component")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[cfg(unix)]
    #[test]
    fn hosted_repair_path_check_rejects_symlink_alias_to_git_metadata() {
        use claurst_core::permissions::AutoPermissionHandler;
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir_all(workspace.join(".git")).expect("git metadata dir");
        symlink(".git", workspace.join("metadata")).expect("symlink");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace.clone();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = workspace.join("metadata/config");
        let error = ctx
            .check_hosted_repair_path("Write", &path)
            .expect_err("symlink alias to Git metadata must be rejected")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[cfg(unix)]
    #[test]
    fn hosted_repair_path_check_rejects_dangling_symlink() {
        use claurst_core::permissions::AutoPermissionHandler;
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().expect("tempdir");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir(&workspace).expect("workspace dir");
        symlink(
            temp.path().join("missing-target"),
            workspace.join("dangling"),
        )
        .expect("symlink");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = workspace.clone();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;

        let path = workspace.join("dangling").join("new.txt");
        let error = ctx
            .check_hosted_repair_path("Write", &path)
            .expect_err("dangling symlink must fail closed")
            .to_string();

        assert!(error.contains("hosted repair file tools are limited"));
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn hosted_repair_does_not_run_configured_formatter() {
        use claurst_core::config::FormatterConfig;
        use claurst_core::permissions::AutoPermissionHandler;

        let temp = tempfile::tempdir().expect("tempdir");
        let marker = temp.path().join("formatter-ran");
        let mut ctx = test_tool_context(Arc::new(AutoPermissionHandler {
            mode: claurst_core::config::PermissionMode::BypassPermissions,
        }));
        ctx.working_dir = temp.path().to_path_buf();
        ctx.config.hosted_review.enabled = true;
        ctx.config.hosted_review.allow_file_write_tools = true;
        ctx.config.formatter.insert(
            "repo-controlled".to_string(),
            FormatterConfig {
                command: vec![
                    "/bin/sh".to_string(),
                    "-c".to_string(),
                    "printf formatter-ran > \"$1\"".to_string(),
                    "formatter-test".to_string(),
                    marker.to_string_lossy().into_owned(),
                    "$FILE".to_string(),
                ],
                extensions: vec![".rs".to_string()],
                disabled: false,
            },
        );

        try_format_file(&temp.path().join("source.rs").to_string_lossy(), &ctx).await;

        assert!(
            !marker.exists(),
            "hosted repair must not execute configured formatter commands"
        );

        ctx.config.hosted_review.enabled = false;
        ctx.config.hosted_review.allow_file_write_tools = false;
        try_format_file(&temp.path().join("source.rs").to_string_lossy(), &ctx).await;

        assert!(
            marker.exists(),
            "local mode should retain configured formatter behavior"
        );
    }

    // ---- PermissionLevel tests ---------------------------------------------

    #[test]
    fn test_permission_level_order() {
        // Just verify the variants exist and are distinct
        assert_ne!(PermissionLevel::None, PermissionLevel::ReadOnly);
        assert_ne!(PermissionLevel::Write, PermissionLevel::Execute);
        assert_ne!(PermissionLevel::Execute, PermissionLevel::Dangerous);
    }

    #[test]
    fn test_bash_tool_permission_level() {
        assert_eq!(PtyBashTool.permission_level(), PermissionLevel::Execute);
    }

    #[test]
    fn test_file_read_permission_level() {
        assert_eq!(FileReadTool.permission_level(), PermissionLevel::ReadOnly);
    }

    #[test]
    fn test_file_edit_permission_level() {
        assert_eq!(FileEditTool.permission_level(), PermissionLevel::Write);
    }

    #[test]
    fn test_file_write_permission_level() {
        assert_eq!(FileWriteTool.permission_level(), PermissionLevel::Write);
    }

    // ---- Tool to_definition tests ------------------------------------------

    #[test]
    fn test_tool_to_definition() {
        let def = PtyBashTool.to_definition();
        assert_eq!(def.name, "Bash");
        assert!(!def.description.is_empty());
        assert!(def.input_schema.is_object());
    }
}
