//! Configurable keyboard shortcuts system

use indexmap::IndexMap;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tracing::warn;

/// All keybinding contexts
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub enum KeyContext {
    Global,
    Chat,
    Autocomplete,
    Confirmation,
    Help,
    Transcript,
    HistorySearch,
    Task,
    ThemePicker,
    Settings,
    Tabs,
    Attachments,
    Footer,
    MessageSelector,
    DiffDialog,
    ModelPicker,
    Select,
    Plugin,
    /// The Next renderer's contextual inspector. Layered over Chat: keys it
    /// does not bind keep their Chat meaning so the composer stays usable.
    Inspector,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParsedKeystroke {
    pub key: String, // normalized key name
    pub ctrl: bool,
    pub alt: bool,
    pub shift: bool,
    pub meta: bool,
}

pub type Chord = Vec<ParsedKeystroke>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParsedBinding {
    pub chord: Chord,
    pub action: Option<String>, // None = unbound
    pub context: KeyContext,
}

/// Parse a keystroke string like "ctrl+shift+enter" into ParsedKeystroke
pub fn parse_keystroke(s: &str) -> Option<ParsedKeystroke> {
    let s = s.trim().to_lowercase();
    let mut ctrl = false;
    let mut alt = false;
    let mut shift = false;
    let mut meta = false;
    let mut key_parts: Vec<&str> = Vec::new();

    for part in s.split('+') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        match part {
            "ctrl" | "control" => ctrl = true,
            "alt" | "opt" | "option" => alt = true,
            "shift" => shift = true,
            "meta" | "cmd" | "command" | "super" | "win" => meta = true,
            _ => key_parts.push(part),
        }
    }

    if key_parts.is_empty() {
        return None;
    }

    let key = normalize_key(key_parts.join("+").as_str());
    Some(ParsedKeystroke {
        key,
        ctrl,
        alt,
        shift,
        meta,
    })
}

fn format_chord_string(chord: &Chord) -> String {
    chord
        .iter()
        .map(|ks| {
            let mut parts = Vec::new();
            if ks.ctrl {
                parts.push("ctrl");
            }
            if ks.alt {
                parts.push("alt");
            }
            if ks.shift {
                parts.push("shift");
            }
            if ks.meta {
                parts.push("meta");
            }
            parts.push(&ks.key);
            parts.join("+")
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// A pretty single-keystroke label for UI hints, e.g. `Ctrl+C`, `Enter`,
/// `Alt+H`, `↑`.
fn prettify_keystroke(ks: &ParsedKeystroke) -> String {
    let mut parts: Vec<String> = Vec::new();
    if ks.ctrl {
        parts.push("Ctrl".to_string());
    }
    if ks.alt {
        parts.push("Alt".to_string());
    }
    if ks.shift {
        parts.push("Shift".to_string());
    }
    if ks.meta {
        parts.push("Meta".to_string());
    }
    let key = match ks.key.as_str() {
        "enter" => "Enter".to_string(),
        "escape" => "Esc".to_string(),
        "up" => "\u{2191}".to_string(),
        "down" => "\u{2193}".to_string(),
        "left" => "\u{2190}".to_string(),
        "right" => "\u{2192}".to_string(),
        "space" => "Space".to_string(),
        "pageup" => "PgUp".to_string(),
        "pagedown" => "PgDn".to_string(),
        "tab" => "Tab".to_string(),
        k if k.chars().count() == 1 => k.to_uppercase(),
        k => {
            let mut c = k.chars();
            c.next()
                .map(|f| f.to_uppercase().collect::<String>() + c.as_str())
                .unwrap_or_default()
        }
    };
    parts.push(key);
    parts.join("+")
}

/// The keystroke currently bound to `action`, as a display string — a user
/// override wins, otherwise the built-in default. `None` if nothing is bound.
///
/// Matches on action name across contexts (action names like `submit` /
/// `openHelp` are unique enough for hint display), so first-run keybinding
/// hints stay in sync with a user's customized `keybindings.json`.
pub fn display_binding_for(user: &UserKeybindings, action: &str) -> Option<String> {
    // User override wins.
    for b in &user.bindings {
        if b.action.as_deref() == Some(action) {
            let first = b.chord.split_whitespace().next().unwrap_or(&b.chord);
            if let Some(ks) = parse_keystroke(first) {
                return Some(prettify_keystroke(&ks));
            }
        }
    }
    // Fall back to the built-in default.
    default_bindings()
        .iter()
        .find(|pb| pb.action.as_deref() == Some(action))
        .and_then(|pb| pb.chord.first().map(prettify_keystroke))
}

fn normalize_key(k: &str) -> String {
    match k {
        "esc" | "escape" => "escape".to_string(),
        "return" | "enter" => "enter".to_string(),
        "del" | "delete" => "delete".to_string(),
        "backspace" | "bs" => "backspace".to_string(),
        "space" | " " => "space".to_string(),
        "up" => "up".to_string(),
        "down" => "down".to_string(),
        "left" => "left".to_string(),
        "right" => "right".to_string(),
        "pageup" | "pgup" => "pageup".to_string(),
        "pagedown" | "pgdn" | "pgdown" => "pagedown".to_string(),
        "home" => "home".to_string(),
        "end" => "end".to_string(),
        "tab" => "tab".to_string(),
        k => k.to_string(),
    }
}

/// Parse a chord (space-separated keystrokes like "ctrl+k ctrl+d")
pub fn parse_chord(s: &str) -> Option<Chord> {
    let keystrokes: Vec<ParsedKeystroke> =
        s.split_whitespace().filter_map(parse_keystroke).collect();
    if keystrokes.is_empty() {
        None
    } else {
        Some(keystrokes)
    }
}

/// Keys that cannot be rebound
pub const NON_REBINDABLE: &[&str] = &["ctrl+c", "ctrl+d", "ctrl+m"];

/// Default keybindings with comprehensive coverage of text editing, navigation, vim, and TUI actions
///
/// # Standard Keybindings (Phase 1 Implementation)
/// - **Ctrl+L**: Clear current input line (like bash) [Chat context only due to conflict]
/// - **Ctrl+Shift+A**: Open the model picker
/// - **Ctrl+K**: Open the command palette
/// - **Ctrl+U**: Kill input from cursor to start of line (Emacs-style)
/// - **Alt+←/Alt+→**: Navigate to previous/next message in transcript
/// - **→ (Right)**: Accept typeahead suggestion when the cursor is at the end of the input
/// - **Ctrl+. (Ctrl+>)**: Jump to next error/issue in messages
/// - **Ctrl+Shift+.**: Jump to previous error/issue
/// - **Shift+Tab**: Reverse indent/unindent in input (cycle permission mode)
/// - **Ctrl+H**: Delete character before cursor (Chat context, Emacs-style)
/// - **Alt+H**: Open help (alternative to F1)
/// - **Ctrl+O**: Jump back in history (command history)
/// - **Ctrl+I**: Jump forward in history
/// - **Alt+D**: Delete word forward (already implemented)
/// - **Ctrl+V**: Paste from clipboard (already implemented)
pub fn default_bindings() -> Vec<ParsedBinding> {
    let defaults: &[(&str, &str, KeyContext)] = &[
        // ========== GLOBAL CONTROL ==========
        ("ctrl+c", "interrupt", KeyContext::Global),
        // Ctrl+D is handled directly for the two-press exit confirmation flow.
        ("ctrl+l", "redraw", KeyContext::Global),
        ("ctrl+r", "historySearch", KeyContext::Global),
        ("ctrl+b", "createBranch", KeyContext::Global),
        ("alt+h", "openHelp", KeyContext::Global),
        // ========== CHAT / INPUT CONTEXT ==========
        // Message submission
        ("enter", "submit", KeyContext::Chat),
        // Newline insertion (Shift+Enter / Ctrl+J for multi-line composing)
        ("shift+enter", "newline", KeyContext::Chat),
        // Fallback for terminals that do not support the kitty keyboard protocol
        // (e.g. Terminal.app, older iTerm2, Windows Terminal, or SSH sessions).
        // Without the protocol, Shift+Enter is sent as a raw newline byte (0x0A,
        // LF); crossterm reports that as KeyCode::Char('j') with CONTROL because
        // Ctrl+J == 0x0A in ASCII. When the protocol is enabled (see
        // PushKeyboardEnhancementFlags in tui/src/lib.rs), terminals like Ghostty
        // send a proper CSI-u sequence with the Shift modifier instead, so this
        // fallback is not needed there. Keep it as a compatibility belt-and-braces
        // for terminals that do not support the protocol.
        ("ctrl+j", "newline", KeyContext::Chat),
        // Line start/end navigation
        ("home", "goLineStart", KeyContext::Chat),
        ("cmd+left", "goLineStart", KeyContext::Chat),
        ("ctrl+a", "goLineStart", KeyContext::Chat),
        ("end", "goLineEnd", KeyContext::Chat),
        ("cmd+right", "goLineEnd", KeyContext::Chat),
        ("ctrl+e", "goLineEnd", KeyContext::Chat),
        // Word navigation
        ("ctrl+left", "moveWordBackward", KeyContext::Chat),
        ("ctrl+right", "moveWordForward", KeyContext::Chat),
        // Cursor movement / typeahead acceptance (fish-style: right arrow at
        // the end of the input accepts the current suggestion)
        ("right", "moveRight", KeyContext::Chat),
        // Word deletion
        ("ctrl+w", "killWord", KeyContext::Chat),
        ("alt+backspace", "killWord", KeyContext::Chat),
        ("alt+d", "deleteWord", KeyContext::Chat),
        // Character/line deletion
        ("ctrl+h", "deleteCharBefore", KeyContext::Chat),
        ("ctrl+u", "killToStart", KeyContext::Chat),
        ("ctrl+l", "clearLine", KeyContext::Chat),
        // History navigation
        ("up", "historyPrev", KeyContext::Chat),
        ("ctrl+o", "historyPrev", KeyContext::Chat),
        ("down", "historyNext", KeyContext::Chat),
        ("ctrl+i", "historyNext", KeyContext::Chat),
        // Message navigation
        ("alt+left", "previousMessage", KeyContext::Chat),
        ("alt+right", "nextMessage", KeyContext::Chat),
        // Error/issue navigation
        ("ctrl+.", "jumpToNextError", KeyContext::Chat),
        ("ctrl+shift+.", "jumpToPreviousError", KeyContext::Chat),
        // Searching
        ("ctrl+f", "findInMessage", KeyContext::Chat),
        ("ctrl+shift+f", "globalSearch", KeyContext::Chat),
        ("f3", "findNext", KeyContext::Chat),
        ("ctrl+]", "findNext", KeyContext::Chat),
        ("shift+f3", "findPrev", KeyContext::Chat),
        ("ctrl+[", "findPrev", KeyContext::Chat),
        ("ctrl+g", "goToLine", KeyContext::Chat),
        // Indentation
        ("tab", "indent", KeyContext::Chat),
        ("shift+tab", "reverseIndent", KeyContext::Chat),
        // Scrolling
        ("pageup", "scrollUp", KeyContext::Chat),
        ("pagedown", "scrollDown", KeyContext::Chat),
        // App shortcuts
        ("ctrl+shift+a", "openModelPicker", KeyContext::Chat),
        ("ctrl+k", "openCommandPalette", KeyContext::Chat),
        // Next renderer only; Classic treats these chords as unbound.
        ("alt+i", "toggleInspector", KeyContext::Chat),
        ("alt+l", "jumpToLive", KeyContext::Chat),
        ("alt+g", "jumpToStart", KeyContext::Chat),
        ("ctrl+z", "suspend", KeyContext::Chat),
        // Hints show the newest default, so Escape is listed last.
        ("alt+i", "closeInspector", KeyContext::Inspector),
        ("escape", "closeInspector", KeyContext::Inspector),
        ("tab", "nextInspectorPage", KeyContext::Inspector),
        ("shift+tab", "previousInspectorPage", KeyContext::Inspector),
        ("pageup", "scrollInspectorUp", KeyContext::Inspector),
        ("pagedown", "scrollInspectorDown", KeyContext::Inspector),
        // ========== CONFIRMATION DIALOGS ==========
        ("y", "yes", KeyContext::Confirmation),
        ("enter", "yes", KeyContext::Confirmation),
        ("n", "no", KeyContext::Confirmation),
        ("escape", "no", KeyContext::Confirmation),
        ("up", "prevOption", KeyContext::Confirmation),
        ("down", "nextOption", KeyContext::Confirmation),
        // ========== HELP OVERLAY ==========
        ("escape", "close", KeyContext::Help),
        ("q", "close", KeyContext::Help),
        ("up", "scrollUp", KeyContext::Help),
        ("down", "scrollDown", KeyContext::Help),
        ("pageup", "pageUp", KeyContext::Help),
        ("pagedown", "pageDown", KeyContext::Help),
        // ========== HISTORY SEARCH ==========
        ("up", "prevResult", KeyContext::HistorySearch),
        ("down", "nextResult", KeyContext::HistorySearch),
        ("enter", "select", KeyContext::HistorySearch),
        ("escape", "cancel", KeyContext::HistorySearch),
        ("tab", "togglePreview", KeyContext::HistorySearch),
        // ========== TRANSCRIPT / MESSAGE SELECTION ==========
        ("up", "prevMessage", KeyContext::Transcript),
        ("down", "nextMessage", KeyContext::Transcript),
        ("pageup", "pageUp", KeyContext::Transcript),
        ("pagedown", "pageDown", KeyContext::Transcript),
        ("home", "goStart", KeyContext::Transcript),
        ("end", "goEnd", KeyContext::Transcript),
        ("enter", "selectMessage", KeyContext::Transcript),
        ("escape", "cancel", KeyContext::Transcript),
        // ========== MESSAGE SELECTOR OVERLAY ==========
        ("up", "prevMessage", KeyContext::MessageSelector),
        ("down", "nextMessage", KeyContext::MessageSelector),
        ("k", "prevMessage", KeyContext::MessageSelector),
        ("j", "nextMessage", KeyContext::MessageSelector),
        ("enter", "select", KeyContext::MessageSelector),
        ("escape", "cancel", KeyContext::MessageSelector),
        // ========== THEME & MODEL PICKERS ==========
        ("up", "prev", KeyContext::ThemePicker),
        ("down", "next", KeyContext::ThemePicker),
        ("k", "prev", KeyContext::ThemePicker),
        ("j", "next", KeyContext::ThemePicker),
        ("pageup", "pageUp", KeyContext::ThemePicker),
        ("pagedown", "pageDown", KeyContext::ThemePicker),
        ("enter", "select", KeyContext::ThemePicker),
        ("escape", "cancel", KeyContext::ThemePicker),
        // ========== TASK LIST ==========
        ("up", "prevTask", KeyContext::Task),
        ("down", "nextTask", KeyContext::Task),
        ("enter", "selectTask", KeyContext::Task),
        ("escape", "closeTask", KeyContext::Task),
        ("x", "toggleDone", KeyContext::Task),
        // ========== DIFF DIALOG ==========
        ("up", "prevDiff", KeyContext::DiffDialog),
        ("down", "nextDiff", KeyContext::DiffDialog),
        ("a", "acceptDiff", KeyContext::DiffDialog),
        ("enter", "acceptDiff", KeyContext::DiffDialog),
        ("r", "rejectDiff", KeyContext::DiffDialog),
        ("escape", "rejectDiff", KeyContext::DiffDialog),
        ("pageup", "pageUp", KeyContext::DiffDialog),
        ("pagedown", "pageDown", KeyContext::DiffDialog),
        // ========== MODAL SELECT (Generic) ==========
        ("up", "prev", KeyContext::Select),
        ("down", "next", KeyContext::Select),
        ("k", "prev", KeyContext::Select),
        ("j", "next", KeyContext::Select),
        ("pageup", "pageUp", KeyContext::Select),
        ("pagedown", "pageDown", KeyContext::Select),
        ("enter", "select", KeyContext::Select),
        ("escape", "cancel", KeyContext::Select),
        ("/", "search", KeyContext::Select),
        // ========== PLUGIN & ATTACHMENTS ==========
        ("up", "prev", KeyContext::Plugin),
        ("down", "next", KeyContext::Plugin),
        ("enter", "select", KeyContext::Plugin),
        ("escape", "cancel", KeyContext::Plugin),
        ("space", "toggle", KeyContext::Attachments),
        ("a", "addAttachment", KeyContext::Attachments),
        ("r", "removeAttachment", KeyContext::Attachments),
    ];

    defaults
        .iter()
        .filter_map(|(chord_str, action, context)| {
            parse_chord(chord_str).map(|chord| ParsedBinding {
                chord,
                action: Some(action.to_string()),
                context: context.clone(),
            })
        })
        .collect()
}

/// Current schema version for keybindings
pub const KEYBINDINGS_SCHEMA_VERSION: u32 = 1;
/// User keybindings loaded from ~/.coven-code/keybindings.json
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserKeybindings {
    #[serde(default = "default_schema_version")]
    pub schema_version: u32,
    pub bindings: Vec<UserBinding>,
}

fn default_schema_version() -> u32 {
    KEYBINDINGS_SCHEMA_VERSION
}

impl Default for UserKeybindings {
    fn default() -> Self {
        Self {
            schema_version: KEYBINDINGS_SCHEMA_VERSION,
            bindings: Vec::new(),
        }
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
struct JsonKeybindingConfig {
    #[serde(default)]
    bindings: Vec<JsonKeybindingBlock>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct JsonKeybindingBlock {
    context: String,
    bindings: IndexMap<String, Option<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserBinding {
    pub chord: String,          // e.g. "ctrl+k ctrl+d"
    pub action: Option<String>, // None = unbound
    pub context: Option<String>,
}

impl UserKeybindings {
    pub fn from_json_str(content: &str) -> Self {
        let mut kb = serde_json::from_str(content)
            .or_else(|_| Self::from_block_config(content))
            .unwrap_or_default();

        // Warn about and filter out non-rebindable keys
        let original_len = kb.bindings.len();
        kb.bindings.retain(|binding| {
            let normalized = binding.chord.to_lowercase();
            if NON_REBINDABLE
                .iter()
                .any(|protected| normalized == *protected)
            {
                warn!(
                    "Cannot rebind protected key '{}' in keybindings.json",
                    binding.chord
                );
                return false;
            }
            true
        });

        if kb.bindings.len() < original_len {
            let filtered_count = original_len - kb.bindings.len();
            warn!(
                "Filtered out {} protected keybinding(s). Protected keys: {}",
                filtered_count,
                NON_REBINDABLE.join(", ")
            );
        }

        kb
    }

    pub fn load(config_dir: &Path) -> Self {
        Self::load_with_renderer_only(config_dir, &[])
    }

    /// [`Self::load`], where `renderer_only` names default actions that one
    /// renderer drops (see [`KeybindingResolver::remove_default_actions`]).
    /// See [`Self::smart_merge_with_defaults_except`].
    pub fn load_with_renderer_only(config_dir: &Path, renderer_only: &[&str]) -> Self {
        let path = config_dir.join("keybindings.json");
        if let Ok(content) = std::fs::read_to_string(&path) {
            let mut kb = Self::from_json_str(&content);
            let old_version = kb.schema_version;
            kb.smart_merge_with_defaults_except(renderer_only);

            // Save back if schema was updated
            if kb.schema_version > old_version {
                if let Err(e) = kb.save(config_dir) {
                    warn!("Failed to save updated keybindings: {}", e);
                }
            }

            kb
        } else {
            Self::default()
        }
    }

    pub fn save(&self, config_dir: &Path) -> anyhow::Result<()> {
        let path = config_dir.join("keybindings.json");
        let json = serde_json::to_string_pretty(self)?;
        std::fs::write(path, json)?;
        Ok(())
    }

    fn from_block_config(content: &str) -> Result<Self, serde_json::Error> {
        let config: JsonKeybindingConfig = serde_json::from_str(content)?;
        let bindings = config
            .bindings
            .into_iter()
            .flat_map(|block| {
                let context = block.context;
                block
                    .bindings
                    .into_iter()
                    .map(move |(chord, action)| UserBinding {
                        chord,
                        action,
                        context: Some(context.clone()),
                    })
            })
            .collect();
        Ok(Self {
            schema_version: 0,
            bindings,
        })
    }

    /// Smart merge: preserve user customizations while adding new defaults
    pub fn smart_merge_with_defaults(&mut self) {
        self.smart_merge_with_defaults_except(&[]);
    }

    /// [`Self::smart_merge_with_defaults`], except that a chord whose every
    /// default is bound to one of `renderer_only` is not taken over. A renderer
    /// that drops those defaults would otherwise leave the user's binding
    /// confined to a default's context; it stays in every context instead, as
    /// it did before those defaults existed. A chord with any other default is
    /// merged as before.
    pub fn smart_merge_with_defaults_except(&mut self, renderer_only: &[&str]) {
        if self.schema_version >= KEYBINDINGS_SCHEMA_VERSION {
            return; // Already up to date
        }

        let old_version = self.schema_version;
        self.schema_version = KEYBINDINGS_SCHEMA_VERSION;

        // Build a set of user-customized bindings (those that differ from old defaults)
        // and bindings user explicitly unbound
        let mut user_customizations: std::collections::HashMap<String, Option<String>> =
            std::collections::HashMap::new();
        for binding in &self.bindings {
            // Migration: remove old bindings that have changed in defaults
            // This distinguishes between "user customized" and "old default that changed"

            // Old: ctrl+a -> openModelPicker (moved to ctrl+shift+a)
            if binding.chord == "ctrl+a" && binding.action.as_deref() == Some("openModelPicker") {
                continue;
            }

            // Old: tab -> togglePreview in Chat context (changed to indent)
            if binding.chord == "tab"
                && binding.context.as_deref() == Some("Chat")
                && binding.action.as_deref() == Some("togglePreview")
            {
                continue;
            }

            user_customizations.insert(binding.chord.clone(), binding.action.clone());
        }

        // Get current defaults and integrate customizations
        let defaults = default_bindings();
        let claimable: std::collections::HashSet<String> = defaults
            .iter()
            .filter(|default| {
                !default
                    .action
                    .as_deref()
                    .is_some_and(|action| renderer_only.contains(&action))
            })
            .map(|default| format_chord_string(&default.chord))
            .collect();
        let mut merged_bindings = Vec::new();
        for default in defaults {
            let chord_str = format_chord_string(&default.chord);
            let context_str = format!("{:?}", default.context);
            let claims_chord = claimable.contains(&chord_str);

            if let Some(custom_action) =
                user_customizations.get(&chord_str).filter(|_| claims_chord)
            {
                // User has customized this binding, use their version
                merged_bindings.push(UserBinding {
                    chord: chord_str.clone(),
                    action: custom_action.clone(),
                    context: Some(context_str),
                });
                user_customizations.remove(&chord_str);
            } else {
                // Use the default
                merged_bindings.push(UserBinding {
                    chord: chord_str,
                    action: default.action.clone(),
                    context: Some(context_str),
                });
            }
        }

        // Add any remaining user customizations that aren't in current defaults
        for (chord, action) in user_customizations {
            merged_bindings.push(UserBinding {
                chord,
                action,
                context: None,
            });
        }

        self.bindings = merged_bindings;
        warn!(
            "Keybindings schema upgraded from v{} to v{}. User customizations preserved.",
            old_version, KEYBINDINGS_SCHEMA_VERSION
        );
    }
}

/// Resolved keybindings (defaults merged with user overrides)
pub struct KeybindingResolver {
    bindings: Vec<ParsedBinding>,
    pending_chord: Vec<ParsedKeystroke>,
    /// Number of leading entries in `bindings` that are defaults.
    default_count: usize,
    /// Chord text of each user binding after the defaults, as written.
    user_chords: Vec<String>,
}

/// Whether a key the interactive loop handles itself wins over bindings.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RoutePrecedence {
    /// Handled before any binding resolves; a binding cannot change it.
    BeforeBindings,
    /// Handled only when no binding resolves the chord to an action.
    WhenUnbound,
}

/// A key the interactive loop handles in Chat outside binding resolution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FixedRoute {
    pub chord: &'static str,
    pub action: &'static str,
    pub precedence: RoutePrecedence,
}

/// Chat keys that work whatever keybindings.json says. Keep in step with
/// the Enter handling in the CLI event loop and the fallback key match in
/// `App::handle_key_event` that runs when no binding resolves. `ctrl+c`
/// needs no entry because it is in [`NON_REBINDABLE`]; `?` (help on an
/// empty prompt) is conditional and deliberately not counted.
pub const CHAT_FIXED_ROUTES: &[FixedRoute] = &[
    FixedRoute {
        chord: "enter",
        action: "submit",
        precedence: RoutePrecedence::BeforeBindings,
    },
    FixedRoute {
        chord: "f1",
        action: "openHelp",
        precedence: RoutePrecedence::WhenUnbound,
    },
    FixedRoute {
        chord: "ctrl+r",
        action: "historySearch",
        precedence: RoutePrecedence::WhenUnbound,
    },
    FixedRoute {
        chord: "ctrl+u",
        action: "killToStart",
        precedence: RoutePrecedence::WhenUnbound,
    },
    FixedRoute {
        chord: "ctrl+w",
        action: "killWord",
        precedence: RoutePrecedence::WhenUnbound,
    },
    FixedRoute {
        chord: "alt+d",
        action: "deleteWord",
        precedence: RoutePrecedence::WhenUnbound,
    },
];

/// Actions that must stay reachable from the Chat composer, the context
/// where bindings are dispatched after every dialog has read its own keys.
/// Permission prompts read y/n/Esc directly, so they are not listed.
pub const ESSENTIAL_ACTIONS: &[&str] = &["submit", "interrupt", "openCommandPalette", "openHelp"];

/// A user binding that leaves a Chat chord doing something other than its
/// default.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BindingConflict {
    /// Chord as written in keybindings.json.
    pub chord: String,
    /// Default action of the chord.
    pub replaced: String,
    /// Action it resolves to now; `None` when the user unbound it.
    pub by: Option<String>,
}

impl KeybindingResolver {
    /// Drop the defaults bound to `actions`, so their chords are free again.
    /// For a renderer that does not handle them: a default that only falls
    /// through would still shadow a user's longer chord. User bindings stay,
    /// except exact copies of a dropped default: upgrading an older
    /// keybindings file copies every default into the user's own bindings.
    pub fn remove_default_actions(&mut self, actions: &[&str]) {
        let dropped = |binding: &ParsedBinding| {
            binding
                .action
                .as_deref()
                .is_some_and(|action| actions.contains(&action))
        };
        let (defaults, users) = self.bindings.split_at(self.default_count);
        let copied = |binding: &ParsedBinding| {
            dropped(binding)
                && defaults.iter().any(|default| {
                    default.chord == binding.chord
                        && default.context == binding.context
                        && default.action == binding.action
                })
        };
        let (users, user_chords): (Vec<ParsedBinding>, Vec<String>) = users
            .iter()
            .zip(&self.user_chords)
            .filter(|(binding, _)| !copied(binding))
            .map(|(binding, chord)| (binding.clone(), chord.clone()))
            .unzip();
        let defaults: Vec<ParsedBinding> = defaults
            .iter()
            .filter(|binding| !dropped(binding))
            .cloned()
            .collect();
        self.default_count = defaults.len();
        self.bindings = defaults.into_iter().chain(users).collect();
        self.user_chords = user_chords;
    }

    pub fn new(user: &UserKeybindings) -> Self {
        let mut bindings = default_bindings();
        let default_count = bindings.len();
        let mut user_chords = Vec::new();

        // Apply user overrides (user bindings win, last match wins)
        for user_binding in &user.bindings {
            if let Some(chord) = parse_chord(&user_binding.chord) {
                let context = user_binding
                    .context
                    .as_deref()
                    .and_then(|c| serde_json::from_str(&format!("\"{}\"", c)).ok())
                    .unwrap_or(KeyContext::Global);

                bindings.push(ParsedBinding {
                    chord,
                    action: user_binding.action.clone(),
                    context,
                });
                user_chords.push(user_binding.chord.clone());
            }
        }

        Self {
            bindings,
            pending_chord: Vec::new(),
            default_count,
            user_chords,
        }
    }

    /// Resolve `chord` in `context` against the first `limit` bindings with
    /// the same rules as [`Self::process`]: Global applies everywhere, the
    /// last exact match wins, and a shorter chord that resolves first
    /// shadows longer ones.
    fn resolve_in(
        &self,
        limit: usize,
        context: &KeyContext,
        chord: &[ParsedKeystroke],
    ) -> Option<&ParsedBinding> {
        let candidates = &self.bindings[..limit];
        (1..=chord.len()).find_map(|len| {
            candidates
                .iter()
                .rev()
                .filter(|b| &b.context == context || b.context == KeyContext::Global)
                .find(|b| b.chord.as_slice() == &chord[..len])
        })
    }

    /// What `chord` does in Chat with the first `limit` bindings, including
    /// the keys the interactive loop handles itself.
    fn chat_effect(&self, limit: usize, chord: &[ParsedKeystroke]) -> Option<String> {
        let route = |precedence: RoutePrecedence| {
            CHAT_FIXED_ROUTES.iter().find(|route| {
                route.precedence == precedence && parse_chord(route.chord).as_deref() == Some(chord)
            })
        };
        if let Some(route) = route(RoutePrecedence::BeforeBindings) {
            return Some(route.action.to_string());
        }
        self.resolve_in(limit, &KeyContext::Chat, chord)
            .and_then(|binding| binding.action.clone())
            .or_else(|| route(RoutePrecedence::WhenUnbound).map(|r| r.action.to_string()))
    }

    /// Chat chords whose final effect differs from their default effect,
    /// one entry per chord. Later entries that restore a default cancel
    /// earlier changes, and keys the loop handles first never conflict.
    pub fn conflicts(&self) -> Vec<BindingConflict> {
        let mut seen: Vec<&[ParsedKeystroke]> = Vec::new();
        let mut conflicts = Vec::new();
        let user = self.bindings[self.default_count..].iter();
        for (binding, chord_text) in user.zip(&self.user_chords) {
            let applies = matches!(binding.context, KeyContext::Chat | KeyContext::Global);
            if !applies || seen.contains(&binding.chord.as_slice()) {
                continue;
            }
            seen.push(&binding.chord);
            let before = self.chat_effect(self.default_count, &binding.chord);
            let after = self.chat_effect(self.bindings.len(), &binding.chord);
            if let Some(replaced) = before {
                if after.as_ref() != Some(&replaced) {
                    conflicts.push(BindingConflict {
                        chord: chord_text.clone(),
                        replaced,
                        by: after,
                    });
                }
            }
        }
        conflicts
    }

    /// A chord that reaches `action` in Chat now, formatted for display. The
    /// most recently defined working binding wins, so hints follow the
    /// user's configuration; keys the loop handles itself come last.
    pub fn reachable_chord(&self, action: &str) -> Option<String> {
        let reaches = |chord: &[ParsedKeystroke]| {
            self.chat_effect(self.bindings.len(), chord).as_deref() == Some(action)
        };
        let bound = self
            .bindings
            .iter()
            .rev()
            .filter(|b| matches!(b.context, KeyContext::Chat | KeyContext::Global))
            .filter(|b| b.action.as_deref() == Some(action))
            .map(|b| b.chord.clone());
        let fixed = CHAT_FIXED_ROUTES
            .iter()
            .filter(|route| route.action == action)
            .filter_map(|route| parse_chord(route.chord));
        bound
            .chain(fixed)
            .find(|chord| reaches(chord))
            .map(|chord| {
                chord
                    .iter()
                    .map(prettify_keystroke)
                    .collect::<Vec<_>>()
                    .join(" ")
            })
    }

    /// The chord that reaches `action` in `context`, layered over Chat the
    /// way the Next inspector resolves keys: the newest binding for the
    /// action whose chord is not taken over by a later binding.
    pub fn reachable_chord_in(&self, action: &str, context: &KeyContext) -> Option<String> {
        let effect = |chord: &[ParsedKeystroke]| {
            self.bindings
                .iter()
                .rev()
                .find(|b| &b.context == context && b.chord.as_slice() == chord)
                .or_else(|| self.resolve_in(self.bindings.len(), &KeyContext::Chat, chord))
                .and_then(|b| b.action.as_deref())
        };
        self.bindings
            .iter()
            .rev()
            .filter(|b| &b.context == context && b.action.as_deref() == Some(action))
            .find(|b| effect(&b.chord) == Some(action))
            .map(|b| {
                b.chord
                    .iter()
                    .map(prettify_keystroke)
                    .collect::<Vec<_>>()
                    .join(" ")
            })
    }

    /// Essential actions no key reaches in Chat.
    pub fn unreachable_essential_actions(&self) -> Vec<&'static str> {
        ESSENTIAL_ACTIONS
            .iter()
            .copied()
            .filter(|action| self.reachable_chord(action).is_none())
            .collect()
    }

    /// Process a keystroke, returns action if binding matches
    pub fn process(
        &mut self,
        keystroke: ParsedKeystroke,
        context: &KeyContext,
    ) -> KeybindingResult {
        self.process_layered(keystroke, std::slice::from_ref(context))
    }

    /// Like [`Self::process`], with `contexts` ordered from most to least
    /// specific. An exact match in an earlier context wins over later ones;
    /// Global ranks with the last context, and within one rank the last
    /// binding wins (user overrides).
    pub fn process_layered(
        &mut self,
        keystroke: ParsedKeystroke,
        contexts: &[KeyContext],
    ) -> KeybindingResult {
        self.pending_chord.push(keystroke);
        let broadest = contexts.len().saturating_sub(1);
        let rank = |binding: &ParsedBinding| {
            contexts
                .iter()
                .position(|context| context == &binding.context)
                .or((binding.context == KeyContext::Global).then_some(broadest))
        };

        let matches: Vec<(usize, &ParsedBinding)> = self
            .bindings
            .iter()
            .filter(|b| b.chord.starts_with(self.pending_chord.as_slice()))
            .filter_map(|b| rank(b).map(|r| (r, b)))
            .collect();

        if matches.is_empty() {
            self.pending_chord.clear();
            return KeybindingResult::NoMatch;
        }

        let exact = matches
            .iter()
            .filter(|(_, b)| b.chord.len() == self.pending_chord.len())
            .fold(
                None,
                |best: Option<(usize, &ParsedBinding)>, &(r, b)| match best {
                    Some((best_rank, _)) if best_rank < r => best,
                    _ => Some((r, b)),
                },
            );

        if let Some((_, binding)) = exact {
            self.pending_chord.clear();
            return match &binding.action {
                Some(action) => KeybindingResult::Action(action.clone()),
                None => KeybindingResult::Unbound,
            };
        }

        // Chord in progress
        KeybindingResult::Pending
    }

    pub fn cancel_chord(&mut self) {
        self.pending_chord.clear();
    }

    pub fn has_pending_chord(&self) -> bool {
        !self.pending_chord.is_empty()
    }
}

impl PartialEq for ParsedKeystroke {
    fn eq(&self, other: &Self) -> bool {
        self.key == other.key
            && self.ctrl == other.ctrl
            && self.alt == other.alt
            && self.shift == other.shift
            && self.meta == other.meta
    }
}

#[derive(Debug, Clone)]
pub enum KeybindingResult {
    Action(String),
    Unbound,
    Pending,
    NoMatch,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn user(bindings: &[(&str, Option<&str>, Option<&str>)]) -> UserKeybindings {
        UserKeybindings {
            schema_version: KEYBINDINGS_SCHEMA_VERSION,
            bindings: bindings
                .iter()
                .map(|(chord, action, context)| UserBinding {
                    chord: chord.to_string(),
                    action: action.map(str::to_string),
                    context: context.map(str::to_string),
                })
                .collect(),
        }
    }

    #[test]
    fn defaults_alone_keep_every_essential_action_reachable() {
        let resolver = KeybindingResolver::new(&UserKeybindings::default());
        assert!(resolver.conflicts().is_empty());
        assert!(resolver.unreachable_essential_actions().is_empty());
        assert_eq!(resolver.reachable_chord("submit").as_deref(), Some("Enter"));
        assert_eq!(
            resolver.reachable_chord("openHelp").as_deref(),
            Some("Alt+H")
        );
    }

    #[test]
    fn overriding_a_bound_chat_chord_is_reported_once_as_a_conflict() {
        let overrides = user(&[
            ("ctrl+k", Some("newline"), Some("Chat")),
            ("ctrl+k", Some("redraw"), Some("Chat")),
            ("f9", Some("openHelp"), None),
        ]);
        let resolver = KeybindingResolver::new(&overrides);
        assert_eq!(
            resolver.conflicts(),
            vec![BindingConflict {
                chord: "ctrl+k".to_string(),
                replaced: "openCommandPalette".to_string(),
                by: Some("redraw".to_string()),
            }]
        );
        assert_eq!(
            resolver.unreachable_essential_actions(),
            vec!["openCommandPalette"]
        );
        // The newest working chord is what hints show.
        assert_eq!(resolver.reachable_chord("openHelp").as_deref(), Some("F9"));
    }

    #[test]
    fn a_later_entry_that_restores_the_default_cancels_the_conflict() {
        let restored = user(&[
            ("ctrl+k", Some("newline"), Some("Chat")),
            ("ctrl+k", Some("openCommandPalette"), Some("Chat")),
        ]);
        let resolver = KeybindingResolver::new(&restored);
        assert!(resolver.conflicts().is_empty());
        assert!(resolver.unreachable_essential_actions().is_empty());
    }

    #[test]
    fn keys_the_loop_handles_itself_are_never_reported_as_changed() {
        // The CLI submits on Enter before bindings resolve, so rebinding it
        // changes nothing a user would see.
        let enter = user(&[("enter", Some("newline"), Some("Chat"))]);
        let resolver = KeybindingResolver::new(&enter);
        assert!(resolver.conflicts().is_empty());
        assert_eq!(resolver.reachable_chord("submit").as_deref(), Some("Enter"));
        // Permission prompts read y/n themselves; a Global `y` does not
        // touch Chat, so there is nothing to report.
        let y = user(&[("y", Some("customAction"), None)]);
        assert!(KeybindingResolver::new(&y).conflicts().is_empty());
    }

    #[test]
    fn a_chat_override_of_a_global_chord_moves_the_hint_to_the_fallback() {
        // Alt+H is Global help, but a Chat binding wins while composing.
        let shadowed = user(&[("alt+h", Some("openSearch"), Some("Chat"))]);
        let resolver = KeybindingResolver::new(&shadowed);
        assert_eq!(
            resolver.conflicts(),
            vec![BindingConflict {
                chord: "alt+h".to_string(),
                replaced: "openHelp".to_string(),
                by: Some("openSearch".to_string()),
            }]
        );
        assert_eq!(resolver.reachable_chord("openHelp").as_deref(), Some("F1"));
    }

    #[test]
    fn unbinding_makes_an_essential_action_unreachable_only_without_a_fallback() {
        let palette = KeybindingResolver::new(&user(&[("ctrl+k", None, None)]));
        assert_eq!(
            palette.conflicts(),
            vec![BindingConflict {
                chord: "ctrl+k".to_string(),
                replaced: "openCommandPalette".to_string(),
                by: None,
            }]
        );
        assert_eq!(
            palette.unreachable_essential_actions(),
            vec!["openCommandPalette"]
        );

        // F1 still opens help when Alt+H is unbound ...
        let help = KeybindingResolver::new(&user(&[("alt+h", None, None)]));
        assert!(help.unreachable_essential_actions().is_empty());
        assert_eq!(help.reachable_chord("openHelp").as_deref(), Some("F1"));
        // ... but not once F1 is bound to something else.
        let both = KeybindingResolver::new(&user(&[
            ("alt+h", None, None),
            ("f1", Some("redraw"), Some("Chat")),
        ]));
        assert_eq!(both.unreachable_essential_actions(), vec!["openHelp"]);
    }

    #[test]
    fn unbinding_a_key_the_app_also_handles_itself_is_not_a_change() {
        // App::handle_key_event handles these chords itself when no binding
        // resolves them, so unbinding leaves them working.
        for chord in ["ctrl+r", "ctrl+u", "ctrl+w", "alt+d"] {
            let unbound = KeybindingResolver::new(&user(&[(chord, None, None)]));
            assert!(
                unbound.conflicts().is_empty(),
                "{chord}: {:?}",
                unbound.conflicts()
            );
        }
        // Binding one to another action does change it.
        let rebound = KeybindingResolver::new(&user(&[("ctrl+r", Some("redraw"), None)]));
        assert_eq!(rebound.conflicts().len(), 1);
    }

    #[test]
    fn a_shorter_chord_shadows_a_longer_one() {
        // `ctrl+x ctrl+p` would open the palette, but `ctrl+x` resolves first.
        let shadowed = user(&[
            ("ctrl+k", Some("newline"), Some("Chat")),
            ("ctrl+x ctrl+p", Some("openCommandPalette"), Some("Chat")),
            ("ctrl+x", Some("redraw"), Some("Chat")),
        ]);
        assert_eq!(
            KeybindingResolver::new(&shadowed).unreachable_essential_actions(),
            vec!["openCommandPalette"]
        );
        let without_prefix = user(&[
            ("ctrl+k", Some("newline"), Some("Chat")),
            ("ctrl+x ctrl+p", Some("openCommandPalette"), Some("Chat")),
        ]);
        assert!(KeybindingResolver::new(&without_prefix)
            .unreachable_essential_actions()
            .is_empty());
    }

    #[test]
    fn test_parse_keystroke_simple() {
        let ks = parse_keystroke("enter").unwrap();
        assert_eq!(ks.key, "enter");
        assert!(!ks.ctrl);
        assert!(!ks.alt);
        assert!(!ks.shift);
        assert!(!ks.meta);
    }

    #[test]
    fn test_parse_keystroke_ctrl_c() {
        let ks = parse_keystroke("ctrl+c").unwrap();
        assert_eq!(ks.key, "c");
        assert!(ks.ctrl);
        assert!(!ks.alt);
    }

    #[test]
    fn test_parse_keystroke_ctrl_shift_enter() {
        let ks = parse_keystroke("ctrl+shift+enter").unwrap();
        assert_eq!(ks.key, "enter");
        assert!(ks.ctrl);
        assert!(ks.shift);
        assert!(!ks.alt);
    }

    #[test]
    fn test_parse_keystroke_normalizes_esc() {
        let ks = parse_keystroke("esc").unwrap();
        assert_eq!(ks.key, "escape");
    }

    #[test]
    fn test_parse_keystroke_normalizes_return() {
        let ks = parse_keystroke("return").unwrap();
        assert_eq!(ks.key, "enter");
    }

    #[test]
    fn test_parse_keystroke_empty_returns_none() {
        assert!(parse_keystroke("ctrl+").is_none());
        assert!(parse_keystroke("").is_none());
    }

    #[test]
    fn test_parse_chord_single() {
        let chord = parse_chord("ctrl+c").unwrap();
        assert_eq!(chord.len(), 1);
        assert_eq!(chord[0].key, "c");
        assert!(chord[0].ctrl);
    }

    #[test]
    fn test_parse_chord_multi() {
        let chord = parse_chord("ctrl+k ctrl+d").unwrap();
        assert_eq!(chord.len(), 2);
        assert_eq!(chord[0].key, "k");
        assert_eq!(chord[1].key, "d");
        assert!(chord[0].ctrl);
        assert!(chord[1].ctrl);
    }

    #[test]
    fn test_parse_chord_empty_returns_none() {
        assert!(parse_chord("").is_none());
    }

    #[test]
    fn test_default_bindings_not_empty() {
        let bindings = default_bindings();
        assert!(!bindings.is_empty());
    }

    #[test]
    fn test_default_bindings_contains_ctrl_c() {
        let bindings = default_bindings();
        let ctrl_c = bindings.iter().find(|b| {
            b.chord.len() == 1
                && b.chord[0].ctrl
                && b.chord[0].key == "c"
                && b.context == KeyContext::Global
        });
        assert!(ctrl_c.is_some());
        assert_eq!(ctrl_c.unwrap().action.as_deref(), Some("interrupt"));
    }

    #[test]
    fn test_default_bindings_map_ctrl_shift_a_and_ctrl_k_to_app_shortcuts() {
        let bindings = default_bindings();

        let ctrl_shift_a = bindings.iter().find(|b| {
            b.chord.len() == 1
                && b.chord[0].ctrl
                && b.chord[0].shift
                && b.chord[0].key == "a"
                && b.context == KeyContext::Chat
        });
        let ctrl_k = bindings.iter().find(|b| {
            b.chord.len() == 1
                && b.chord[0].ctrl
                && b.chord[0].key == "k"
                && b.context == KeyContext::Chat
        });

        assert_eq!(
            ctrl_shift_a.and_then(|b| b.action.as_deref()),
            Some("openModelPicker")
        );
        assert_eq!(
            ctrl_k.and_then(|b| b.action.as_deref()),
            Some("openCommandPalette")
        );
    }

    #[test]
    fn test_resolver_simple_action() {
        let user = UserKeybindings::default();
        let mut resolver = KeybindingResolver::new(&user);
        let ks = parse_keystroke("ctrl+c").unwrap();
        let result = resolver.process(ks, &KeyContext::Global);
        assert!(matches!(result, KeybindingResult::Action(ref a) if a == "interrupt"));
    }

    #[test]
    fn removing_default_actions_frees_their_chords_and_keeps_user_bindings() {
        let user = user(&[
            ("ctrl+z ctrl+x", Some("openHelp"), Some("Chat")),
            ("alt+u", Some("suspend"), Some("Chat")),
        ]);
        let mut resolver = KeybindingResolver::new(&user);
        // The exact default shadows the user's longer chord.
        assert_eq!(
            press(&mut resolver, "ctrl+z", &[KeyContext::Chat]),
            "suspend"
        );

        resolver.remove_default_actions(&["suspend"]);
        let pending =
            resolver.process_layered(parse_keystroke("ctrl+z").unwrap(), &[KeyContext::Chat]);
        assert!(matches!(pending, KeybindingResult::Pending));
        assert_eq!(
            press(&mut resolver, "ctrl+x", &[KeyContext::Chat]),
            "openHelp"
        );
        assert_eq!(
            press(&mut resolver, "alt+u", &[KeyContext::Chat]),
            "suspend",
            "a user's own binding stays"
        );
        assert_eq!(
            press(&mut resolver, "ctrl+k", &[KeyContext::Chat]),
            "openCommandPalette"
        );
    }

    #[test]
    fn removing_default_actions_also_frees_chords_an_upgraded_file_copied() {
        // The block format loads as schema 0, and the schema upgrade copies
        // every default into the user's own bindings, these ones included.
        let mut user = UserKeybindings::from_json_str(
            r#"{"bindings":[{"context":"Chat","bindings":{
                "ctrl+z ctrl+x":"openCommandPalette",
                "alt+i alt+x":"openHelp",
                "alt+u":"suspend"}}]}"#,
        );
        assert_eq!(user.schema_version, 0);
        user.smart_merge_with_defaults();
        let mut resolver = KeybindingResolver::new(&user);

        resolver.remove_default_actions(&["toggleInspector", "jumpToLive", "suspend"]);
        assert_eq!(
            press(&mut resolver, "ctrl+z ctrl+x", &[KeyContext::Chat]),
            "openCommandPalette"
        );
        assert_eq!(
            press(&mut resolver, "alt+i alt+x", &[KeyContext::Chat]),
            "openHelp"
        );
        assert_eq!(
            press(&mut resolver, "alt+u", &[KeyContext::Chat]),
            "suspend",
            "a user's own binding on another chord stays"
        );
    }

    #[test]
    fn upgrading_keeps_an_old_files_binding_on_a_renderer_only_chord_in_every_context() {
        // Before ctrl+z had a default, the upgrade left this binding in every
        // context. A renderer that drops that default must still see it there.
        let renderer_only = ["toggleInspector", "closeInspector", "jumpToLive", "suspend"];
        let resolve = |except: &[&str]| {
            let mut user = UserKeybindings::from_json_str(
                r#"{"bindings":[{"context":"Global","bindings":{"ctrl+z":"openHelp"}}]}"#,
            );
            user.smart_merge_with_defaults_except(except);
            let mut resolver = KeybindingResolver::new(&user);
            resolver.remove_default_actions(&renderer_only);
            [KeyContext::Chat, KeyContext::Transcript]
                .map(|context| press(&mut resolver, "ctrl+z", &[context]))
        };
        assert_eq!(resolve(&renderer_only), ["openHelp", "openHelp"]);
        // The plain upgrade confines it to the default's Chat context.
        assert_eq!(resolve(&[]), ["openHelp", "NoMatch"]);
    }

    #[test]
    fn upgrading_merges_a_chord_with_any_other_default_as_before() {
        // escape's first default is renderer-only, but escape has others, so
        // the file's binding takes that default's place, as it did before.
        let renderer_only = ["toggleInspector", "closeInspector", "jumpToLive", "suspend"];
        let upgrade = |except: &[&str]| {
            let mut user = UserKeybindings::from_json_str(
                r#"{"bindings":[{"context":"Chat","bindings":{"escape":"interrupt"}}]}"#,
            );
            user.smart_merge_with_defaults_except(except);
            user
        };
        let fields = |user: &UserKeybindings| -> Vec<(String, Option<String>, Option<String>)> {
            user.bindings
                .iter()
                .filter(|b| b.chord == "escape")
                .map(|b| (b.chord.clone(), b.action.clone(), b.context.clone()))
                .collect()
        };
        assert_eq!(fields(&upgrade(&renderer_only)), fields(&upgrade(&[])));
        let mut resolver = KeybindingResolver::new(&upgrade(&renderer_only));
        resolver.remove_default_actions(&renderer_only);
        assert_eq!(
            press(&mut resolver, "escape", &[KeyContext::Confirmation]),
            "no"
        );
    }

    #[test]
    fn loading_an_old_file_saves_its_bindings_as_the_upgrade_merges_them() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("keybindings.json");
        std::fs::write(
            &path,
            r#"{"bindings":[{"context":"Global","bindings":{"ctrl+z":"openHelp"}},{"context":"Chat","bindings":{"escape":"interrupt"}}]}"#,
        )
        .unwrap();
        let renderer_only = ["toggleInspector", "closeInspector", "jumpToLive", "suspend"];
        UserKeybindings::load_with_renderer_only(dir.path(), &renderer_only);
        let saved = UserKeybindings::from_json_str(&std::fs::read_to_string(&path).unwrap());
        assert_eq!(saved.schema_version, KEYBINDINGS_SCHEMA_VERSION);
        let ctrl_z: Vec<_> = saved
            .bindings
            .iter()
            .filter(|b| b.chord == "ctrl+z")
            .map(|b| (b.action.as_deref(), b.context.as_deref()))
            .collect();
        assert_eq!(
            ctrl_z,
            [(Some("suspend"), Some("Chat")), (Some("openHelp"), None)]
        );
        // escape has a default outside Next, so its binding takes the first
        // default's place, as on main, and Classic's prompt still says no.
        let escape: Vec<_> = saved
            .bindings
            .iter()
            .filter(|b| b.chord == "escape")
            .map(|b| (b.action.as_deref(), b.context.as_deref()))
            .take(2)
            .collect();
        assert_eq!(
            escape,
            [
                (Some("interrupt"), Some("Inspector")),
                (Some("no"), Some("Confirmation"))
            ]
        );
    }

    #[test]
    fn test_resolver_no_match() {
        let user = UserKeybindings::default();
        let mut resolver = KeybindingResolver::new(&user);
        // ctrl+alt+z has no default binding
        let ks = parse_keystroke("ctrl+alt+z").unwrap();
        let result = resolver.process(ks, &KeyContext::Chat);
        assert!(matches!(result, KeybindingResult::NoMatch));
    }

    #[test]
    fn test_resolver_context_match_global_from_chat() {
        let user = UserKeybindings::default();
        let mut resolver = KeybindingResolver::new(&user);
        // ctrl+l in Chat context maps to "clearLine" (newly added Phase 1 keybinding)
        // Global context is checked after context-specific bindings
        let ks = parse_keystroke("ctrl+l").unwrap();
        let result = resolver.process(ks, &KeyContext::Chat);
        assert!(matches!(result, KeybindingResult::Action(ref a) if a == "clearLine"));
    }

    #[test]
    fn test_keystroke_equality() {
        let ks1 = parse_keystroke("ctrl+enter").unwrap();
        let ks2 = parse_keystroke("ctrl+enter").unwrap();
        let ks3 = parse_keystroke("shift+enter").unwrap();
        assert_eq!(ks1, ks2);
        assert_ne!(ks1, ks3);
    }

    #[test]
    fn test_user_keybindings_default_empty() {
        let user = UserKeybindings::default();
        assert!(user.bindings.is_empty());
    }

    #[test]
    fn test_user_keybindings_supports_ts_block_format() {
        let user = UserKeybindings::from_json_str(
            r#"{
  "bindings": [
    {
      "context": "Chat",
      "bindings": {
        "ctrl+g": "chat:externalEditor",
        "space": null
      }
    }
  ]
}"#,
        );

        assert_eq!(user.bindings.len(), 2);
        assert_eq!(user.bindings[0].context.as_deref(), Some("Chat"));
        assert_eq!(user.bindings[0].chord, "ctrl+g");
        assert_eq!(
            user.bindings[0].action.as_deref(),
            Some("chat:externalEditor")
        );
        assert_eq!(user.bindings[1].chord, "space");
        assert_eq!(user.bindings[1].action, None);
    }

    #[test]
    fn test_ctrl_j_maps_to_newline() {
        let bindings = default_bindings();
        let ctrl_j = bindings.iter().find(|b| {
            b.chord.len() == 1
                && b.chord[0].ctrl
                && b.chord[0].key == "j"
                && b.context == KeyContext::Chat
        });
        assert!(ctrl_j.is_some(), "ctrl+j binding not found");
        assert_eq!(ctrl_j.unwrap().action.as_deref(), Some("newline"));
    }

    #[test]
    fn test_new_phase1_keybindings_registered() {
        // Verify that all Phase 1 keybindings are registered
        let bindings = default_bindings();

        // Build list of keybinding actions
        let actions: Vec<String> = bindings.iter().filter_map(|b| b.action.clone()).collect();

        // Check Phase 1 keybinding actions exist
        assert!(
            actions.contains(&"clearLine".to_string()),
            "clearLine action not found"
        );
        assert!(
            actions.contains(&"submit".to_string()),
            "submit action not found"
        );
        assert!(
            actions.contains(&"jumpToNextError".to_string()),
            "jumpToNextError action not found"
        );
        assert!(
            actions.contains(&"jumpToPreviousError".to_string()),
            "jumpToPreviousError action not found"
        );
        assert!(
            actions.contains(&"previousMessage".to_string()),
            "previousMessage action not found"
        );
        assert!(
            actions.contains(&"nextMessage".to_string()),
            "nextMessage action not found"
        );
        assert!(
            actions.contains(&"openHelp".to_string()),
            "openHelp action not found"
        );
        assert!(
            actions.contains(&"deleteCharBefore".to_string()),
            "deleteCharBefore action not found"
        );
        assert!(
            actions.contains(&"reverseIndent".to_string()),
            "reverseIndent action not found"
        );

        // Verify we have at least 10 new keybindings (Phase 1 requirement)
        assert!(
            actions.len() >= 40,
            "Expected at least 40 keybindings, found {}",
            actions.len()
        );
    }

    #[test]
    fn test_old_format_keybindings_get_upgraded() {
        let old_format_json = r#"{
            "bindings": [
                {
                    "context": "Chat",
                    "bindings": {
                        "ctrl+shift+a": "openModelPicker",
                        "ctrl+e": "goLineEnd"
                    }
                }
            ]
        }"#;

        let mut kb = UserKeybindings::from_json_str(old_format_json);
        assert_eq!(kb.schema_version, 0, "Old format should start at version 0");

        kb.smart_merge_with_defaults();

        assert_eq!(kb.schema_version, 1, "Should be upgraded to version 1");
        assert!(
            kb.bindings.iter().any(|b| b.chord == "meta+left"),
            "meta+left (cmd+left) should be added from defaults after merge"
        );
        assert!(
            kb.bindings.iter().any(
                |b| b.chord == "ctrl+shift+a" && b.action.as_deref() == Some("openModelPicker")
            ),
            "User customization (ctrl+shift+a -> openModelPicker) should be preserved"
        );
    }

    #[test]
    fn test_cmd_left_resolves_to_go_line_start() {
        let user = UserKeybindings::default();
        let mut resolver = KeybindingResolver::new(&user);

        // Create a keystroke for CMD+Left (SUPER modifier + left arrow)
        let keystroke = ParsedKeystroke {
            key: "left".to_string(),
            ctrl: false,
            alt: false,
            shift: false,
            meta: true,
        };

        let result = resolver.process(keystroke, &KeyContext::Chat);
        match result {
            KeybindingResult::Action(action) => {
                assert_eq!(action, "goLineStart", "CMD+Left should map to goLineStart");
            }
            other => panic!("Expected Action(\"goLineStart\"), got {:?}", other),
        }
    }

    #[test]
    fn test_right_resolves_to_move_right_in_chat() {
        let user = UserKeybindings::default();
        let mut resolver = KeybindingResolver::new(&user);

        let keystroke = ParsedKeystroke {
            key: "right".to_string(),
            ctrl: false,
            alt: false,
            shift: false,
            meta: false,
        };

        let result = resolver.process(keystroke, &KeyContext::Chat);
        match result {
            KeybindingResult::Action(action) => {
                assert_eq!(action, "moveRight", "Right should map to moveRight");
            }
            other => panic!("Expected Action(\"moveRight\"), got {:?}", other),
        }
    }

    fn press(resolver: &mut KeybindingResolver, chord: &str, contexts: &[KeyContext]) -> String {
        let mut result = KeybindingResult::NoMatch;
        for stroke in parse_chord(chord).expect("chord") {
            result = resolver.process_layered(stroke, contexts);
        }
        match result {
            KeybindingResult::Action(action) => action,
            other => format!("{other:?}"),
        }
    }

    #[test]
    fn layered_contexts_prefer_the_inspector_and_keep_chat_and_global_keys() {
        let layered = [KeyContext::Inspector, KeyContext::Chat];
        let mut resolver = KeybindingResolver::new(&UserKeybindings::default());
        assert_eq!(press(&mut resolver, "escape", &layered), "closeInspector");
        assert_eq!(press(&mut resolver, "tab", &layered), "nextInspectorPage");
        // Composer keys the inspector does not bind keep their Chat meaning.
        assert_eq!(
            press(&mut resolver, "ctrl+k", &layered),
            "openCommandPalette"
        );
        assert_eq!(press(&mut resolver, "ctrl+a", &layered), "goLineStart");
        assert_eq!(press(&mut resolver, "ctrl+c", &layered), "interrupt");
        // Without the inspector layer the same keys mean their Chat action.
        assert_eq!(press(&mut resolver, "tab", &[KeyContext::Chat]), "indent");
        assert_eq!(
            press(&mut resolver, "alt+i", &[KeyContext::Chat]),
            "toggleInspector"
        );
        assert_eq!(
            press(&mut resolver, "escape", &[KeyContext::Chat]),
            "NoMatch"
        );

        // A user rebinding inside the inspector wins over its default; a
        // user Chat binding does not reach into the inspector layer.
        let mut resolver = KeybindingResolver::new(&user(&[
            ("ctrl+q", Some("closeInspector"), Some("Inspector")),
            ("escape", None, Some("Inspector")),
            ("tab", Some("redraw"), Some("Chat")),
        ]));
        assert_eq!(press(&mut resolver, "ctrl+q", &layered), "closeInspector");
        assert_eq!(press(&mut resolver, "escape", &layered), "Unbound");
        assert_eq!(press(&mut resolver, "tab", &layered), "nextInspectorPage");
        assert_eq!(
            resolver.reachable_chord_in("closeInspector", &KeyContext::Inspector),
            Some("Ctrl+Q".to_string())
        );
        assert_eq!(
            KeybindingResolver::new(&UserKeybindings::default())
                .reachable_chord_in("closeInspector", &KeyContext::Inspector),
            Some("Esc".to_string())
        );
    }
}
