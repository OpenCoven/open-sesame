// cc-query: The core agentic query loop.
//
// This crate implements the main conversation loop that:
// 1. Sends messages to the Anthropic API
// 2. Processes streaming responses
// 3. Detects tool-use requests and dispatches them
// 4. Feeds tool results back to the model
// 5. Handles auto-compact when the context window fills up
// 6. Manages stop conditions (end_turn, max_turns, cancellation)

pub mod agent_tool;
pub mod auto_dream;
pub mod away_summary;
pub mod command_queue;
pub mod compact;
pub mod context_analyzer;
pub mod coordinator;
pub mod cron_scheduler;
pub mod goal_loop;
pub mod managed_orchestrator;
pub mod session_memory;
pub mod skill_prefetch;
pub use agent_tool::{init_team_swarm_runner, AgentTool};
pub use command_queue::{drain_command_queue, CommandPriority, CommandQueue, QueuedCommand};
pub use compact::{
    auto_compact_if_needed, calculate_messages_to_keep_index, calculate_token_warning_state,
    compact_conversation, context_collapse, context_window_for_model, format_compact_summary,
    get_compact_prompt, group_messages_for_compact, micro_compact_if_needed, reactive_compact,
    should_auto_compact, should_compact, should_context_collapse, snip_compact, AutoCompactState,
    CompactResult, CompactTrigger, MessageGroup, MicroCompactConfig, TokenWarningState,
};
pub use cron_scheduler::start_cron_scheduler;
pub use goal_loop::{
    check_and_continue_goal, check_and_continue_goal_at_path,
    check_and_continue_goal_at_path_for_goal, check_and_continue_goal_for_goal, mark_goal_complete,
    GoalContinuation, StopReason,
};
pub use session_memory::{
    ExtractedMemory, MemoryCandidate, MemoryCandidateStatus, MemoryCandidateStore, MemoryCategory,
    MemoryPersistenceOutcome, SessionMemoryExtractor, SessionMemoryState,
};
pub use skill_prefetch::{
    format_skill_listing, prefetch_skills, SharedSkillIndex, SkillDefinition, SkillIndex,
};

use claurst_api::{
    AnthropicStreamEvent, ApiMessage, ApiToolDefinition, CreateMessageRequest, StreamAccumulator,
    StreamHandler, SystemPrompt, ThinkingConfig,
};
use claurst_core::claudemd::MemoryProvenance;
use claurst_core::config::Config;
use claurst_core::cost::CostTracker;
use claurst_core::error::ClaudeError;
use claurst_core::goal::{GoalTurn, GoalTurnPermission};
use claurst_core::types::{ContentBlock, Message, ToolResultContent, UsageInfo};
use claurst_tools::{Tool, ToolContext, ToolResult};
use futures::{FutureExt, StreamExt};
use serde_json::Value;
use std::fs;
use std::path::{Path, PathBuf};
use std::pin::Pin;
use std::sync::Arc;
use tokio::sync::mpsc;
use tracing::{debug, error, info, warn};

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/// Outcome of a single query-loop run.
#[derive(Debug)]
pub enum QueryOutcome {
    /// The model finished its turn (end_turn stop reason).
    EndTurn { message: Message, usage: UsageInfo },
    /// The model hit max_tokens.
    MaxTokens {
        partial_message: Message,
        usage: UsageInfo,
    },
    /// The conversation was cancelled by the user.
    Cancelled,
    /// An unrecoverable error occurred.
    Error(ClaudeError),
    /// The configured USD budget was exceeded.
    BudgetExceeded { cost_usd: f64, limit_usd: f64 },
}

#[derive(Debug, Eq, PartialEq)]
enum AnthropicStreamOutcome {
    Completed,
    PrematureEof,
    Stalled,
    Cancelled,
}

#[derive(Debug, Eq, PartialEq)]
enum ProviderStreamOutcome {
    Completed,
    PrematureEof,
    Stalled,
    Cancelled,
}

type ProviderEventStream = Pin<
    Box<
        dyn futures::Stream<Item = Result<claurst_api::StreamEvent, claurst_api::ProviderError>>
            + Send,
    >,
>;

struct ProviderStreamContext<'a> {
    cancel_token: &'a tokio_util::sync::CancellationToken,
    accumulator: &'a mut StreamAccumulator,
    event_tx: Option<&'a mpsc::UnboundedSender<QueryEvent>>,
    provider_id: &'a str,
    model_id: &'a str,
    terminal_stream_error: &'a mut Option<ClaudeError>,
}

#[cfg(test)]
tokio::task_local! {
    static TEST_STREAM_STALL_TIMEOUT: std::time::Duration;
}

// Goal checks bound the next observable request/work boundary. They cannot
// atomically interrupt work already started in another process or a tool.
async fn wait_for_goal_revocation(
    turn: Option<&GoalTurn>,
    permission: GoalTurnPermission,
) -> ClaudeError {
    let Some(turn) = turn else {
        return futures::future::pending().await;
    };
    loop {
        match turn.validate() {
            Err(error) => return ClaudeError::Api(format!("Goal authority revoked: {error}")),
            Ok(actual) if actual != permission => {
                return ClaudeError::Api("Goal work completed".into())
            }
            Ok(_) => {}
        }
        tokio::time::sleep(std::time::Duration::from_millis(100)).await;
    }
}

async fn await_goal_request<T>(
    turn: Option<&GoalTurn>,
    permission: GoalTurnPermission,
    cancel: &tokio_util::sync::CancellationToken,
    request: impl std::future::Future<Output = Result<T, ClaudeError>>,
) -> Result<T, ClaudeError> {
    tokio::select! {
        biased;
        _ = cancel.cancelled() => Err(ClaudeError::Cancelled),
        error = wait_for_goal_revocation(turn, permission) => Err(error),
        result = request => result,
    }
}

fn stream_stall_timeout() -> std::time::Duration {
    #[cfg(test)]
    if let Ok(timeout) = TEST_STREAM_STALL_TIMEOUT.try_with(|timeout| *timeout) {
        return timeout;
    }

    std::time::Duration::from_secs(45)
}

fn accumulate_and_publish_anthropic_event(
    accumulator: &mut StreamAccumulator,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
    event: AnthropicStreamEvent,
    effective_model: &str,
    terminal_stream_error: &mut Option<ClaudeError>,
) -> bool {
    accumulator.on_event(&event);
    if let Some(tx) = event_tx {
        let _ = tx.send(QueryEvent::Stream(event.clone()));
    }

    match event {
        AnthropicStreamEvent::Error {
            error_type,
            message,
        } => {
            if error_type == "overloaded_error" {
                warn!(model = %effective_model, "API overloaded");
            }
            error!(error_type, message, "Stream error");
            *terminal_stream_error = Some(ClaudeError::Api(format!(
                "Anthropic stream error ({}): {}",
                error_type, message
            )));
            true
        }
        AnthropicStreamEvent::MessageStop => true,
        _ => false,
    }
}

async fn consume_anthropic_stream(
    stream_rx: &mut mpsc::Receiver<AnthropicStreamEvent>,
    cancel_token: &tokio_util::sync::CancellationToken,
    accumulator: &mut StreamAccumulator,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
    effective_model: &str,
    terminal_stream_error: &mut Option<ClaudeError>,
    stall_timeout: std::time::Duration,
) -> AnthropicStreamOutcome {
    let stall_deadline = tokio::time::sleep(stall_timeout);
    tokio::pin!(stall_deadline);

    loop {
        tokio::select! {
            biased;
            _ = cancel_token.cancelled() => {
                // Closing makes the buffered events the explicit cancellation
                // boundary: queued events remain readable while new sends fail.
                stream_rx.close();
                while let Some(event) = stream_rx.recv().await {
                    accumulate_and_publish_anthropic_event(
                        accumulator,
                        event_tx,
                        event,
                        effective_model,
                        terminal_stream_error,
                    );
                }

                return AnthropicStreamOutcome::Cancelled;
            }
            _ = &mut stall_deadline => return AnthropicStreamOutcome::Stalled,
            event = stream_rx.recv() => {
                // Preserve the existing stall semantics: every received item,
                // including channel closure, resets the deadline before it is
                // classified below.
                stall_deadline
                    .as_mut()
                    .reset(tokio::time::Instant::now() + stall_timeout);
                match event {
                    Some(event) => {
                        if accumulate_and_publish_anthropic_event(
                            accumulator,
                            event_tx,
                            event,
                            effective_model,
                            terminal_stream_error,
                        ) {
                            return AnthropicStreamOutcome::Completed;
                        }
                    }
                    None => return AnthropicStreamOutcome::PrematureEof,
                }
            }
        }
    }
}

fn accumulate_and_publish_provider_result(
    accumulator: &mut StreamAccumulator,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
    event: Result<claurst_api::StreamEvent, claurst_api::ProviderError>,
    provider_id: &str,
    model_id: &str,
    terminal_stream_error: &mut Option<ClaudeError>,
) -> bool {
    match event {
        Ok(event) => {
            accumulator.on_provider_event(&event);
            if let Some(tx) = event_tx {
                if let Some(event) = map_to_anthropic_event(&event) {
                    let _ = tx.send(QueryEvent::Stream(event));
                }
            }
            match event {
                claurst_api::StreamEvent::Error {
                    error_type,
                    message,
                } => {
                    *terminal_stream_error = Some(ClaudeError::Api(format!(
                        "Provider '{provider_id}' stream error ({error_type}): {message}"
                    )));
                    true
                }
                claurst_api::StreamEvent::MessageStop => true,
                _ => false,
            }
        }
        Err(error) => {
            error!(provider = %provider_id, error = %error, "Provider stream error");
            let claude_error: ClaudeError = error.into();
            *terminal_stream_error = Some(enrich_error_notice(
                claude_error,
                provider_id,
                model_id,
                active_account_notice(provider_id).as_deref(),
            ));
            true
        }
    }
}

async fn consume_provider_stream(
    mut stream: ProviderEventStream,
    context: &mut ProviderStreamContext<'_>,
    stall_timeout: std::time::Duration,
) -> ProviderStreamOutcome {
    let stall_deadline = tokio::time::sleep(stall_timeout);
    tokio::pin!(stall_deadline);

    loop {
        tokio::select! {
            biased;
            _ = context.cancel_token.cancelled() => {
                // A generic Stream has no receiver-close operation. Drain
                // every immediately-ready item, then drop the stream before
                // finalization so providers stop producing new input.
                loop {
                    match stream.next().now_or_never() {
                        Some(Some(event)) => {
                            accumulate_and_publish_provider_result(
                                context.accumulator,
                                context.event_tx,
                                event,
                                context.provider_id,
                                context.model_id,
                                context.terminal_stream_error,
                            );
                        }
                        Some(None) | None => return ProviderStreamOutcome::Cancelled,
                    }
                }
            }
            _ = &mut stall_deadline => return ProviderStreamOutcome::Stalled,
            event = stream.next() => {
                stall_deadline
                    .as_mut()
                    .reset(tokio::time::Instant::now() + stall_timeout);
                match event {
                    Some(event) => {
                        if accumulate_and_publish_provider_result(
                            context.accumulator,
                            context.event_tx,
                            event,
                            context.provider_id,
                            context.model_id,
                            context.terminal_stream_error,
                        ) {
                            return ProviderStreamOutcome::Completed;
                        }
                    }
                    None => return ProviderStreamOutcome::PrematureEof,
                }
            }
        }
    }
}

fn build_session_memory_provenance(session_id: &str, working_dir: &Path) -> MemoryProvenance {
    let mut provenance = MemoryProvenance::session_memory_extraction(session_id);

    if let Some(git_dir) = find_git_dir(working_dir) {
        if let Some(remote_url) = read_origin_remote_url(&git_dir) {
            if let Some(repo_slug) = parse_origin_repo_slug(&remote_url) {
                provenance = provenance.with_source_repo(repo_slug);
            }
        }

        if let Some(commit) = read_head_commit(&git_dir) {
            provenance = provenance.with_source_commit(commit);
        }
    }

    if let Ok(actor) = std::env::var("GITHUB_ACTOR") {
        provenance = provenance.with_source_actor(actor);
    }

    provenance
}

fn find_git_dir(working_dir: &Path) -> Option<PathBuf> {
    for dir in working_dir.ancestors() {
        let dot_git = dir.join(".git");
        if dot_git.is_dir() {
            return Some(dot_git);
        }

        if dot_git.is_file() {
            let git_file = fs::read_to_string(&dot_git).ok()?;
            let git_dir = git_file.trim().strip_prefix("gitdir:")?.trim();
            let git_dir = Path::new(git_dir);
            return Some(if git_dir.is_absolute() {
                git_dir.to_path_buf()
            } else {
                dir.join(git_dir)
            });
        }
    }
    None
}

fn common_git_dir(git_dir: &Path) -> PathBuf {
    let Some(common_dir) = fs::read_to_string(git_dir.join("commondir"))
        .ok()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
    else {
        return git_dir.to_path_buf();
    };
    let common_dir = Path::new(&common_dir);
    if common_dir.is_absolute() {
        common_dir.to_path_buf()
    } else {
        git_dir.join(common_dir)
    }
}

fn read_origin_remote_url(git_dir: &Path) -> Option<String> {
    let config = fs::read_to_string(common_git_dir(git_dir).join("config")).ok()?;
    let mut in_origin_section = false;

    for line in config.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with('[') && trimmed.ends_with(']') {
            in_origin_section = trimmed == r#"[remote "origin"]"#;
            continue;
        }

        if in_origin_section {
            let Some((key, value)) = trimmed.split_once('=') else {
                continue;
            };
            if key.trim() == "url" {
                let url = value.trim();
                if !url.is_empty() {
                    return Some(url.to_string());
                }
            }
        }
    }

    None
}

fn read_head_commit(git_dir: &Path) -> Option<String> {
    let head = fs::read_to_string(git_dir.join("HEAD")).ok()?;
    let head = head.trim();
    let commit = if let Some(reference) = head.strip_prefix("ref:") {
        let reference = reference.trim();
        fs::read_to_string(git_dir.join(reference))
            .or_else(|_| fs::read_to_string(common_git_dir(git_dir).join(reference)))
            .ok()?
    } else {
        head.to_string()
    };
    let commit = commit.trim();
    if commit.len() == 40 && commit.chars().all(|ch| ch.is_ascii_hexdigit()) {
        Some(commit.to_string())
    } else {
        None
    }
}

fn parse_origin_repo_slug(remote_url: &str) -> Option<String> {
    let trimmed = remote_url.trim();
    let cutoff = trimmed
        .char_indices()
        .find(|(_, ch)| *ch == '?' || *ch == '#')
        .map(|(idx, _)| idx)
        .unwrap_or(trimmed.len());
    let trimmed = trimmed[..cutoff].trim_end_matches('/');
    if trimmed.is_empty() {
        return None;
    }
    let without_git = trimmed.strip_suffix(".git").unwrap_or(trimmed);
    let candidate = if let Some((_, path)) = without_git.split_once("github.com/") {
        path
    } else if let Some((_, path)) = without_git.split_once("github.com:") {
        path
    } else if let Some((_, path)) = without_git.rsplit_once(':') {
        path
    } else {
        without_git
    };
    let components: Vec<&str> = candidate
        .trim_matches('/')
        .split('/')
        .filter(|component| !component.trim().is_empty())
        .collect();
    if components.len() < 2 {
        return None;
    }
    let owner = components[components.len() - 2];
    let repo = components[components.len() - 1];
    if [owner, repo].iter().any(|component| {
        !component
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || ch == '-' || ch == '_' || ch == '.')
    }) {
        return None;
    }
    Some(format!("{owner}/{repo}"))
}

/// Configuration for a single query-loop invocation.
#[derive(Clone)]
pub struct QueryConfig {
    pub model: String,
    pub max_tokens: u32,
    pub max_turns: u32,
    pub system_prompt: Option<String>,
    pub append_system_prompt: Option<String>,
    pub output_style: claurst_core::system_prompt::OutputStyle,
    pub output_style_prompt: Option<String>,
    pub working_directory: Option<String>,
    pub thinking_budget: Option<u32>,
    pub temperature: Option<f32>,
    /// Maximum cumulative character count of all tool results in the message
    /// history before older results are replaced with a truncation notice.
    /// Mirrors the TS `applyToolResultBudget` mechanism.  Default: 50_000.
    pub tool_result_budget: usize,
    /// Optional effort level.  When set and `thinking_budget` is `None`,
    /// the effort level's `thinking_budget_tokens()` is used as the
    /// thinking budget.  Also provides a temperature override when the
    /// level specifies one.
    pub effort_level: Option<claurst_core::effort::EffortLevel>,
    /// T1-4: Optional shared command queue.
    ///
    /// When set, the query loop drains this queue before each API call and
    /// injects any resulting messages into the conversation.  The queue is
    /// shared (Arc-backed) so the TUI input thread can push commands while the
    /// loop is waiting for a model response.
    pub command_queue: Option<CommandQueue>,
    /// T1-5: Optional shared skill index.
    ///
    /// When set, `prefetch_skills` is spawned once before the loop begins and
    /// the resulting index is used to inject a skill listing attachment into
    /// the conversation context.
    pub skill_index: Option<SharedSkillIndex>,
    /// Optional USD spend cap. The query loop checks accumulated cost after
    /// each turn and aborts with `QueryOutcome::BudgetExceeded` when exceeded.
    pub max_budget_usd: Option<f64>,
    /// Fallback model name. Used when the primary model returns overloaded /
    /// rate-limit errors (mirrors TS `--fallback-model`).
    pub fallback_model: Option<String>,
    /// Optional ProviderRegistry for dispatching to non-Anthropic providers.
    /// When `config.provider` is set to something other than "anthropic" and
    /// this registry contains that provider, the registry's provider is used
    /// instead of `AnthropicClient`.
    pub provider_registry: Option<std::sync::Arc<claurst_api::ProviderRegistry>>,
    /// Active agent name (e.g., "build", "plan", "explore", or None for default).
    pub agent_name: Option<String>,
    /// Resolved agent definition for the current session.
    pub agent_definition: Option<claurst_core::AgentDefinition>,
    /// Optional shared model registry for dynamic provider and model resolution.
    /// When set, the query loop uses this instead of constructing a fresh registry.
    pub model_registry: Option<std::sync::Arc<claurst_api::ModelRegistry>>,
    /// Managed agent (manager-executor) configuration.
    pub managed_agents: Option<claurst_core::ManagedAgentConfig>,
    /// Preserve an explicit caller-selected model instead of allowing managed-agent
    /// manager_model to replace it at query runtime.
    pub preserve_selected_model: bool,
}

impl Default for QueryConfig {
    fn default() -> Self {
        Self {
            model: claurst_core::constants::DEFAULT_MODEL.to_string(),
            max_tokens: claurst_core::constants::DEFAULT_MAX_TOKENS,
            max_turns: claurst_core::constants::MAX_TURNS_DEFAULT,
            system_prompt: None,
            append_system_prompt: None,
            output_style: claurst_core::system_prompt::OutputStyle::Default,
            output_style_prompt: None,
            working_directory: None,
            thinking_budget: None,
            temperature: None,
            tool_result_budget: 50_000,
            effort_level: None,
            command_queue: None,
            skill_index: None,
            max_budget_usd: None,
            fallback_model: None,
            provider_registry: None,
            agent_name: None,
            agent_definition: None,
            model_registry: None,
            managed_agents: None,
            preserve_selected_model: false,
        }
    }
}

impl QueryConfig {
    pub fn from_config(cfg: &Config) -> Self {
        Self {
            model: cfg.effective_model().to_string(),
            max_tokens: cfg.effective_max_tokens(),
            output_style: cfg.effective_output_style(),
            output_style_prompt: cfg.resolve_output_style_prompt(),
            working_directory: cfg.project_dir.as_ref().map(|p| p.display().to_string()),
            managed_agents: cfg.managed_agents.clone(),
            ..Default::default()
        }
    }

    /// Build a QueryConfig using dynamic model resolution from the model registry.
    ///
    /// Prefers the best model for the configured provider (from models.dev data)
    /// over the hardcoded defaults.
    pub fn from_config_with_registry(cfg: &Config, registry: &claurst_api::ModelRegistry) -> Self {
        // We can't move the Arc here, but we need a clone for the query loop.
        // Callers typically wrap the registry in an Arc already.
        Self {
            model: claurst_api::effective_model_for_config(cfg, registry),
            max_tokens: cfg.effective_max_tokens(),
            output_style: cfg.effective_output_style(),
            output_style_prompt: cfg.resolve_output_style_prompt(),
            working_directory: cfg.project_dir.as_ref().map(|p| p.display().to_string()),
            managed_agents: cfg.managed_agents.clone(),
            ..Default::default()
        }
    }
}

fn reasoning_effort_for_level(effort_level: claurst_core::effort::EffortLevel) -> &'static str {
    match effort_level {
        claurst_core::effort::EffortLevel::Low => "low",
        claurst_core::effort::EffortLevel::Medium => "medium",
        claurst_core::effort::EffortLevel::High | claurst_core::effort::EffortLevel::Max => "high",
    }
}

fn google_thinking_level_for_effort(
    effort_level: Option<claurst_core::effort::EffortLevel>,
) -> &'static str {
    match effort_level.unwrap_or(claurst_core::effort::EffortLevel::High) {
        claurst_core::effort::EffortLevel::Low => "low",
        claurst_core::effort::EffortLevel::Medium => "medium",
        claurst_core::effort::EffortLevel::High | claurst_core::effort::EffortLevel::Max => "high",
    }
}

fn is_openai_reasoning_model(model_id: &str) -> bool {
    let model_id = model_id.to_ascii_lowercase();
    model_id.starts_with("gpt-5")
        || model_id.starts_with("o1")
        || model_id.starts_with("o3")
        || model_id.starts_with("o4")
}

fn is_openaiish_provider(provider_id: &str) -> bool {
    matches!(
        provider_id,
        "openai"
            | "azure"
            | "groq"
            | "mistral"
            | "deepseek"
            | "xai"
            | "openrouter"
            | "togetherai"
            | "together-ai"
            | "perplexity"
            | "cerebras"
            | "deepinfra"
            | "venice"
            | "huggingface"
            | "nvidia"
            | "siliconflow"
            | "sambanova"
            | "moonshot"
            | "zhipu"
            | "zai"
            | "qwen"
            | "nebius"
            | "novita"
            | "ovhcloud"
            | "scaleway"
            | "vultr"
            | "vultr-ai"
            | "baseten"
            | "friendli"
            | "upstage"
            | "stepfun"
            | "fireworks"
            | "ollama"
            | "codex"
            | "openai-codex"
            | "lmstudio"
            | "lm-studio"
            | "llamacpp"
            | "llama-cpp"
    )
}

fn build_provider_options(
    provider_id: &str,
    model_id: &str,
    effort_level: Option<claurst_core::effort::EffortLevel>,
    thinking_budget: Option<u32>,
) -> Value {
    let mut options = serde_json::Map::new();
    let model_id = model_id.to_ascii_lowercase();

    if provider_id == "github-copilot" {
        if model_id.contains("claude") {
            options.insert(
                "thinking_budget".to_string(),
                serde_json::json!(thinking_budget.unwrap_or(4_000)),
            );
        } else if model_id.starts_with("gpt-5") && !model_id.contains("gpt-5-pro") {
            let reasoning_effort = effort_level
                .map(reasoning_effort_for_level)
                .unwrap_or("medium");
            options.insert(
                "reasoningEffort".to_string(),
                serde_json::json!(reasoning_effort),
            );
            options.insert("reasoningSummary".to_string(), serde_json::json!("auto"));
            options.insert(
                "include".to_string(),
                serde_json::json!(["reasoning.encrypted_content"]),
            );

            if model_id.contains("gpt-5.")
                && !model_id.contains("codex")
                && !model_id.contains("-chat")
            {
                options.insert("textVerbosity".to_string(), serde_json::json!("low"));
            }
        }
    }

    if provider_id == "google" && model_id.contains("gemini") {
        if model_id.contains("2.5") {
            if let Some(budget) = thinking_budget {
                options.insert(
                    "thinkingConfig".to_string(),
                    serde_json::json!({
                        "includeThoughts": true,
                        "thinkingBudget": budget,
                    }),
                );
            }
        } else if model_id.contains("3.") || model_id.contains("gemini-3") {
            options.insert(
                "thinkingConfig".to_string(),
                serde_json::json!({
                    "includeThoughts": true,
                    "thinkingLevel": google_thinking_level_for_effort(effort_level),
                }),
            );
        }
    }

    if provider_id == "amazon-bedrock" {
        if model_id.contains("anthropic") || model_id.contains("claude") {
            if let Some(budget) = thinking_budget {
                options.insert(
                    "reasoningConfig".to_string(),
                    serde_json::json!({
                        "type": "enabled",
                        "budgetTokens": budget.min(31_999),
                    }),
                );
            }
        } else if let Some(level) = effort_level {
            options.insert(
                "reasoningConfig".to_string(),
                serde_json::json!({
                    "type": "enabled",
                    "maxReasoningEffort": reasoning_effort_for_level(level),
                }),
            );
        }
    }

    if is_openaiish_provider(provider_id) && is_openai_reasoning_model(&model_id) {
        let reasoning_effort = effort_level
            .map(reasoning_effort_for_level)
            .unwrap_or("medium");
        options.insert(
            "reasoningEffort".to_string(),
            serde_json::json!(reasoning_effort),
        );

        if model_id.starts_with("gpt-5")
            && model_id.contains("gpt-5.")
            && !model_id.contains("codex")
            && !model_id.contains("-chat")
            && provider_id != "azure"
        {
            options.insert("textVerbosity".to_string(), serde_json::json!("low"));

            // DeepSeek V4 thinking mode: map effort level to thinking/reasoning_effort params.
            // DeepSeek docs: thinking={"type":"enabled/disabled"}, reasoning_effort="high"|"max"
            // low/medium are mapped to "high" by the API; xhigh mapped to "max".
            if provider_id == "deepseek" {
                match effort_level {
                    None
                    | Some(claurst_core::effort::EffortLevel::Medium)
                    | Some(claurst_core::effort::EffortLevel::High) => {
                        options.insert(
                            "thinking".to_string(),
                            serde_json::json!({"type": "enabled"}),
                        );
                        options.insert("reasoningEffort".to_string(), serde_json::json!("high"));
                    }
                    Some(claurst_core::effort::EffortLevel::Max) => {
                        options.insert(
                            "thinking".to_string(),
                            serde_json::json!({"type": "enabled"}),
                        );
                        options.insert("reasoningEffort".to_string(), serde_json::json!("max"));
                    }
                    Some(claurst_core::effort::EffortLevel::Low) => {
                        options.insert(
                            "thinking".to_string(),
                            serde_json::json!({"type": "disabled"}),
                        );
                    }
                }
            }
        }
    }

    if provider_id == "openrouter" {
        options.insert("usage".to_string(), serde_json::json!({ "include": true }));
        if model_id.contains("gemini-3") {
            options.insert(
                "reasoning".to_string(),
                serde_json::json!({ "effort": "high" }),
            );
        }
    }

    if provider_id == "qwen" && thinking_budget.is_some() && !model_id.contains("kimi-k2-thinking")
    {
        options.insert("enable_thinking".to_string(), serde_json::json!(true));
    }

    if (provider_id == "zhipu" || provider_id == "zai") && thinking_budget.is_some() {
        options.insert(
            "thinking".to_string(),
            serde_json::json!({
                "type": "enabled",
                "clear_thinking": false,
            }),
        );
    }

    if options.is_empty() {
        Value::Null
    } else {
        Value::Object(options)
    }
}

/// Events emitted by the query loop for the TUI to render.
#[derive(Debug, Clone)]
pub enum QueryEvent {
    /// A stream event from the API.
    Stream(AnthropicStreamEvent),
    /// A tool is about to be executed.
    ToolStart {
        tool_name: String,
        tool_id: String,
        input_json: String,
    },
    /// A tool has finished executing.
    ToolEnd {
        tool_name: String,
        tool_id: String,
        result: String,
        is_error: bool,
    },
    /// The model finished a turn.
    TurnComplete {
        turn: u32,
        stop_reason: String,
        usage: Option<UsageInfo>,
    },
    /// An informational status message.
    Status(String),
    /// An error.
    Error(String),
    /// Token usage has crossed a warning threshold.
    /// `state` is Warning (≥ 80 %) or Critical (≥ 95 %).
    /// `pct_used` is the fraction of the context window consumed (0.0–1.0).
    TokenWarning {
        state: TokenWarningState,
        pct_used: f64,
    },
    /// A finalized assistant or tool-result transcript fact that must survive
    /// context compaction and other working-history rewrites.
    DurableMessage { message: Message },
}

fn emit_durable_message(event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>, message: &Message) {
    if let Some(tx) = event_tx {
        let _ = tx.send(QueryEvent::DurableMessage {
            message: message.clone(),
        });
    }
}

fn emit_turn_complete(
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
    turn: u32,
    stop_reason: &str,
    usage: &UsageInfo,
) {
    if let Some(tx) = event_tx {
        let _ = tx.send(QueryEvent::TurnComplete {
            turn,
            stop_reason: stop_reason.to_string(),
            usage: Some(usage.clone()),
        });
    }
}

fn sync_finalized_assistant_message(messages: &mut Vec<Message>, finalized: &Message) -> usize {
    if let Some(uuid) = finalized.uuid.as_deref() {
        if let Some((index, stored)) = messages
            .iter_mut()
            .enumerate()
            .rev()
            .find(|(_, message)| message.uuid.as_deref() == Some(uuid))
        {
            *stored = finalized.clone();
            return index;
        }
    }
    messages.push(finalized.clone());
    messages.len() - 1
}

fn finish_stream_accumulator(
    accumulator: StreamAccumulator,
) -> (Message, UsageInfo, Option<String>) {
    let (mut assistant_msg, usage, stop_reason) = accumulator.finish();
    // Provider message IDs may be reused across transport retries or sessions.
    // Durable transcript identity belongs to this individual sampling attempt.
    assistant_msg.uuid = Some(uuid::Uuid::new_v4().to_string());
    (assistant_msg, usage, stop_reason)
}

fn sampled_attempt_has_material(assistant_msg: &Message) -> bool {
    assistant_msg
        .content_blocks()
        .iter()
        .any(|block| match block {
            ContentBlock::Text { text } => !text.trim().is_empty(),
            ContentBlock::Thinking {
                thinking,
                signature,
            } => !thinking.trim().is_empty() || !signature.is_empty(),
            ContentBlock::RedactedThinking { data } => !data.is_empty(),
            _ => true,
        })
}

async fn finalize_terminal_assistant_message(
    messages: &mut Vec<Message>,
    assistant_msg: &mut Message,
    shadow_snap: Option<&Arc<claurst_core::snapshot::ShadowSnapshot>>,
    initial_snapshot: Option<&str>,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
) -> usize {
    if let (Some(snap), Some(hash)) = (shadow_snap, initial_snapshot) {
        let patch = snap.patch(hash).await;
        if !patch.files.is_empty() {
            assistant_msg.snapshot_patch = Some(patch);
        }
    }
    let assistant_index = sync_finalized_assistant_message(messages, assistant_msg);
    emit_durable_message(event_tx, assistant_msg);
    assistant_index
}

fn unexecuted_tool_result_message(
    messages: &[Message],
    assistant_msg: &Message,
    reason: &str,
) -> Option<Message> {
    let completed_ids: std::collections::HashSet<_> = messages
        .iter()
        .flat_map(|message| match &message.content {
            claurst_core::types::MessageContent::Blocks(blocks) => blocks.iter(),
            _ => [].iter(),
        })
        .filter_map(|block| {
            if let ContentBlock::ToolResult { tool_use_id, .. } = block {
                Some(tool_use_id.as_str())
            } else {
                None
            }
        })
        .collect();
    let mut emitted_ids = std::collections::HashSet::new();
    let blocks: Vec<_> = assistant_msg
        .get_tool_use_blocks()
        .into_iter()
        .filter_map(|block| {
            if let ContentBlock::ToolUse { id, .. } = block {
                (!completed_ids.contains(id.as_str()) && emitted_ids.insert(id.clone())).then(
                    || ContentBlock::ToolResult {
                        tool_use_id: id.clone(),
                        content: ToolResultContent::Text(format!(
                            "Tool was not executed because the response {reason}."
                        )),
                        is_error: Some(true),
                    },
                )
            } else {
                None
            }
        })
        .collect();
    (!blocks.is_empty()).then(|| Message::user_blocks(blocks))
}

fn insert_unexecuted_tool_result_after_assistant(
    messages: &mut Vec<Message>,
    assistant_index: usize,
    assistant_msg: &Message,
    reason: &str,
) -> Option<Message> {
    let tool_result_message = unexecuted_tool_result_message(messages, assistant_msg, reason)?;
    messages.insert(assistant_index + 1, tool_result_message.clone());
    Some(tool_result_message)
}

async fn finalize_terminal_assistant_with_unexecuted_tool_results(
    messages: &mut Vec<Message>,
    assistant_msg: &mut Message,
    shadow_snap: Option<&Arc<claurst_core::snapshot::ShadowSnapshot>>,
    initial_snapshot: Option<&str>,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
    reason: &str,
) {
    let assistant_index = finalize_terminal_assistant_message(
        messages,
        assistant_msg,
        shadow_snap,
        initial_snapshot,
        event_tx,
    )
    .await;
    if let Some(tool_result_message) = insert_unexecuted_tool_result_after_assistant(
        messages,
        assistant_index,
        assistant_msg,
        reason,
    ) {
        emit_durable_message(event_tx, &tool_result_message);
    }
}

async fn finish_anthropic_stall(
    messages: &mut Vec<Message>,
    assistant_msg: &mut Message,
    shadow_snap: Option<&Arc<claurst_core::snapshot::ShadowSnapshot>>,
    initial_snapshot: Option<&str>,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
) -> QueryOutcome {
    finalize_terminal_assistant_with_unexecuted_tool_results(
        messages,
        assistant_msg,
        shadow_snap,
        initial_snapshot,
        event_tx,
        "stream stalled",
    )
    .await;
    QueryOutcome::Error(ClaudeError::Api(
        "Anthropic stream stalled after all retry attempts".to_string(),
    ))
}

async fn finalize_stalled_attempt_before_retry(
    messages: &mut Vec<Message>,
    assistant_msg: &mut Message,
    usage: &UsageInfo,
    cost_tracker: &Arc<CostTracker>,
    shadow_snap: Option<&Arc<claurst_core::snapshot::ShadowSnapshot>>,
    initial_snapshot: Option<&str>,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
) {
    cost_tracker.add_usage(
        usage.input_tokens,
        usage.output_tokens,
        usage.cache_creation_input_tokens,
        usage.cache_read_input_tokens,
    );
    if !sampled_attempt_has_material(assistant_msg) {
        return;
    }
    finalize_terminal_assistant_with_unexecuted_tool_results(
        messages,
        assistant_msg,
        shadow_snap,
        initial_snapshot,
        event_tx,
        "stream stalled before retry",
    )
    .await;
}

// ---------------------------------------------------------------------------
// T1-3: Post-sampling hooks
// ---------------------------------------------------------------------------

/// Result returned by `fire_post_sampling_hooks`.
#[derive(Debug, Default)]
pub struct PostSamplingHookResult {
    /// Error messages produced by hooks with non-zero exit codes.
    /// These are injected into the conversation as user messages before the
    /// next model turn so the model can react to them.
    pub blocking_errors: Vec<claurst_core::types::Message>,
    /// When `true` the query loop must not continue and should surface the
    /// error messages to the caller.  Set when any hook exits with code > 1.
    pub prevent_continuation: bool,
}

/// Execute all `PostModelTurn` hooks defined in `config.hooks`.
///
/// Each hook is run synchronously (blocking via `std::process::Command`).
/// On a non-zero exit code, the hook's stderr (falling back to stdout) is
/// wrapped in a user `Message` and appended to `blocking_errors`.
/// If the exit code is **strictly greater than 1** `prevent_continuation` is
/// set so the query loop can return early.
pub fn fire_post_sampling_hooks(
    _turn_result: &claurst_core::types::Message,
    config: &claurst_core::config::Config,
) -> PostSamplingHookResult {
    use claurst_core::config::HookEvent;
    use claurst_core::types::Message;

    let mut result = PostSamplingHookResult::default();

    let entries = match config.hooks.get(&HookEvent::PostModelTurn) {
        Some(e) => e,
        None => return result,
    };

    for entry in entries {
        let sh = if cfg!(windows) { "cmd" } else { "sh" };
        let flag = if cfg!(windows) { "/C" } else { "-c" };

        let output = match std::process::Command::new(sh)
            .args([flag, &entry.command])
            .stdin(std::process::Stdio::null())
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .output()
        {
            Ok(o) => o,
            Err(e) => {
                tracing::warn!(command = %entry.command, error = %e, "PostModelTurn hook spawn failed");
                continue;
            }
        };

        if output.status.success() {
            continue;
        }

        let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
        let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
        let body = if !stderr.trim().is_empty() {
            stderr
        } else {
            stdout
        };

        tracing::warn!(
            command = %entry.command,
            exit_code = ?output.status.code(),
            "PostModelTurn hook returned non-zero exit"
        );

        result.blocking_errors.push(Message::user(format!(
            "[Hook '{}' error]:\n{}",
            entry.command,
            body.trim()
        )));

        // Exit code > 1 → hard veto of continuation.
        if output.status.code().unwrap_or(1) > 1 {
            result.prevent_continuation = true;
        }
    }

    result
}

/// Spawn all `Stop` hooks in fire-and-forget background tasks.
///
/// Stop hooks are non-blocking by design: the caller does not wait for them.
/// Returns an empty `Vec` immediately; results (if any) are lost.
/// Query callers supply work-only authority; independent callers may use `None`.
/// A detached thread checks before starting its child and reaps that child.
/// Its lifetime does not hold Tokio runtime shutdown open.
pub fn stop_hooks_with_full_behavior(
    turn_result: &claurst_core::types::Message,
    config: &claurst_core::config::Config,
    working_dir: std::path::PathBuf,
    goal_turn: Option<GoalTurn>,
) -> Vec<claurst_core::types::Message> {
    stop_hooks_with_reaper_observer(turn_result, config, working_dir, goal_turn, None)
}

fn stop_hooks_with_reaper_observer(
    turn_result: &claurst_core::types::Message,
    config: &claurst_core::config::Config,
    working_dir: std::path::PathBuf,
    goal_turn: Option<GoalTurn>,
    reaper_tx: Option<std::sync::mpsc::Sender<std::thread::JoinHandle<()>>>,
) -> Vec<claurst_core::types::Message> {
    use claurst_core::config::HookEvent;

    let entries = match config.hooks.get(&HookEvent::Stop) {
        Some(e) if !e.is_empty() => e.clone(),
        _ => return Vec::new(),
    };

    let output_text = turn_result.get_all_text();

    for entry in entries {
        let cmd = entry.command.clone();
        let dir = working_dir.clone();
        let text = output_text.clone();
        let goal_turn = goal_turn.clone();
        let reaper_tx = reaper_tx.clone();

        tokio::task::spawn_blocking(move || {
            // The blocking pool only schedules the reaper; it never waits for
            // the hook's lifetime. Detached hooks retain their existing ability
            // to outlive the runtime (and potentially the engine process).
            match std::thread::Builder::new()
                .name("coven-stop-hook".into())
                .spawn(move || {
                    if let Some(turn) = &goal_turn {
                        if turn.validate() != Ok(GoalTurnPermission::Work) {
                            return;
                        }
                    }
                    let sh = if cfg!(windows) { "cmd" } else { "sh" };
                    let flag = if cfg!(windows) { "/C" } else { "-c" };
                    let _ = std::process::Command::new(sh)
                        .args([flag, &cmd])
                        .current_dir(&dir)
                        .env("CLAUDE_HOOK_OUTPUT", &text)
                        .stdin(std::process::Stdio::null())
                        .stdout(std::process::Stdio::null())
                        .stderr(std::process::Stdio::null())
                        .status();
                }) {
                Ok(handle) => {
                    if let Some(tx) = reaper_tx {
                        let _ = tx.send(handle);
                    }
                }
                Err(error) => warn!(%error, "Could not start Stop hook reaper"),
            }
        });
    }

    Vec::new()
}

// ---------------------------------------------------------------------------
// Tool-result budgeting
// ---------------------------------------------------------------------------

/// Return the combined character count of all tool-result content blocks found
/// in `messages`.  Only user messages are examined (tool results always live
/// in user turns).
fn total_tool_result_chars(messages: &[Message]) -> usize {
    messages
        .iter()
        .filter(|m| m.role == claurst_core::types::Role::User)
        .flat_map(|m| match &m.content {
            claurst_core::types::MessageContent::Blocks(blocks) => blocks.as_slice(),
            _ => &[],
        })
        .filter_map(|b| {
            if let ContentBlock::ToolResult { content, .. } = b {
                Some(match content {
                    ToolResultContent::Text(t) => t.len(),
                    ToolResultContent::Blocks(blocks) => blocks
                        .iter()
                        .map(|b| {
                            if let ContentBlock::Text { text } = b {
                                text.len()
                            } else {
                                0
                            }
                        })
                        .sum(),
                })
            } else {
                None
            }
        })
        .sum()
}

/// When the cumulative tool-result content exceeds `budget` characters, walk
/// the message list from oldest to newest and replace individual
/// `ToolResult` content with a placeholder until the running total is back
/// under budget.  Returns the (possibly modified) message list and the
/// number of results that were truncated.
///
/// Mirrors the spirit of the TypeScript `applyToolResultBudget` /
/// `enforceToolResultBudget` logic, simplified to a straightforward
/// oldest-first eviction without the session-persistence layer.
fn apply_tool_result_budget(messages: Vec<Message>, budget: usize) -> (Vec<Message>, usize) {
    let total = total_tool_result_chars(&messages);
    if total <= budget {
        return (messages, 0);
    }

    let mut to_shed = total - budget;
    let mut truncated = 0usize;
    let mut result = messages;

    'outer: for msg in result.iter_mut() {
        if msg.role != claurst_core::types::Role::User {
            continue;
        }
        let blocks = match &mut msg.content {
            claurst_core::types::MessageContent::Blocks(b) => b,
            _ => continue,
        };
        for block in blocks.iter_mut() {
            if let ContentBlock::ToolResult { content, .. } = block {
                let size = match &*content {
                    ToolResultContent::Text(t) => t.len(),
                    ToolResultContent::Blocks(inner) => inner
                        .iter()
                        .map(|b| {
                            if let ContentBlock::Text { text } = b {
                                text.len()
                            } else {
                                0
                            }
                        })
                        .sum(),
                };
                if size == 0 {
                    continue;
                }
                *content =
                    ToolResultContent::Text("[tool result truncated to save context]".to_string());
                truncated += 1;
                if size > to_shed {
                    break 'outer;
                }
                to_shed -= size;
            }
        }
    }

    (result, truncated)
}

// ---------------------------------------------------------------------------
// Query loop
// ---------------------------------------------------------------------------

/// Maximum number of max_tokens continuation attempts before surfacing the
/// partial response.  Mirrors `MAX_OUTPUT_TOKENS_RECOVERY_LIMIT` in query.ts.
const MAX_TOKENS_RECOVERY_LIMIT: u32 = 3;

/// Message injected when the model hits its output-token limit.
/// Mirrors the TS recovery message in query.ts lines 1224-1228.
const MAX_TOKENS_RECOVERY_MSG: &str =
    "Output token limit hit. Resume directly — no apology, no recap of what \
     you were doing. Pick up mid-thought if that is where the cut happened. \
     Break remaining work into smaller pieces.";

/// Maximum automatic continuation nudges per user turn when the model ends
/// the turn right after announcing an action it never executed (issue #165:
/// "agent announces work and just stops"). Bounded like the max_tokens
/// recovery so a model that keeps narrating can't loop forever.
const STALL_RECOVERY_LIMIT: u32 = 2;

/// Message injected when the model ends a turn with announced-but-unexecuted
/// work (or with no output at all) and no tool calls.
const STALL_RECOVERY_MSG: &str =
    "You ended the turn right after announcing an action, without executing \
     it. Do not narrate what you are about to do. If work remains, call the \
     tools and do it now; if everything is actually complete, state the \
     final outcome without announcing further actions.";

/// Stall recovery is on by default; set COVEN_CODE_DISABLE_STALL_RECOVERY=1
/// (or true/yes/on) to restore the old end-the-turn-as-announced behavior.
fn stall_recovery_enabled() -> bool {
    !claurst_core::feature_gates::is_env_truthy(
        std::env::var("COVEN_CODE_DISABLE_STALL_RECOVERY")
            .ok()
            .as_deref(),
    )
}

/// Heuristic for an "announce-then-stop" stall: an assistant round that
/// ended with `end_turn`, executed no tools, and whose visible text is
/// either empty or closes on an imminent-action announcement ("Writing the
/// CLI uninstall module now.") rather than a completed-work statement or a
/// deliberate handoff back to the user ("Should I…?", "Let me know…").
///
/// False positives are cheap by design: the recovery nudge explicitly tells
/// the model to state the final outcome if the work is already done, and
/// the whole mechanism is bounded by [`STALL_RECOVERY_LIMIT`].
fn is_stalled_announcement(text: &str) -> bool {
    let trimmed = text.trim();
    // No visible output at all is always a stall (the #149 placeholder case).
    if trimmed.is_empty() {
        return true;
    }

    // Work on the final sentence-like chunk. Chunks with fewer than two
    // words are punctuation debris from dotted identifiers (`main.rs`.),
    // not sentences — skip past them.
    let last_sentence = trimmed
        .rsplit(['.', '!', '?', '…', '\n'])
        .find(|chunk| {
            chunk
                .split_whitespace()
                .filter(|word| word.chars().any(|c| c.is_alphabetic()))
                .count()
                >= 2
        })
        .unwrap_or(trimmed)
        .trim()
        .to_ascii_lowercase();

    // A question mark anywhere in the tail means the model handed control
    // back to the user on purpose.
    let tail: String = trimmed
        .chars()
        .rev()
        .take(240)
        .collect::<String>()
        .chars()
        .rev()
        .collect::<String>()
        .to_ascii_lowercase();
    if tail.contains('?') {
        return false;
    }

    // Deliberate wait-for-user phrasings are handoffs, not stalls.
    const HANDOFF_MARKERS: [&str; 10] = [
        "let me know",
        "should i",
        "do you",
        "would you",
        "if you",
        "wait",
        "once you",
        "when you",
        "your call",
        "your review",
    ];
    if HANDOFF_MARKERS
        .iter()
        .any(|marker| last_sentence.contains(marker))
    {
        return false;
    }

    // Imminent-action openers ("Writing the module now.", "Now running the
    // tests.") and first-person intent markers ("then I'll wire it in").
    const ANNOUNCEMENT_OPENERS: [&str; 15] = [
        "writing ",
        "creating ",
        "implementing ",
        "building ",
        "adding ",
        "updating ",
        "editing ",
        "wiring ",
        "running ",
        "starting ",
        "proceeding ",
        "next,",
        "next up",
        "on to ",
        "time to ",
    ];
    const INTENT_MARKERS: [&str; 6] = [
        "let me ",
        "i'll ",
        "i will ",
        "going to ",
        "about to ",
        "now to ",
    ];
    let opener = last_sentence.strip_prefix("now ").unwrap_or(&last_sentence);
    ANNOUNCEMENT_OPENERS
        .iter()
        .any(|pattern| opener.starts_with(pattern))
        || INTENT_MARKERS
            .iter()
            .any(|marker| last_sentence.contains(marker))
}

fn should_emit_turn_complete(
    stop: &str,
    _max_tokens_recovery_count: u32,
    stall_recovery_pending: bool,
) -> bool {
    if stall_recovery_pending {
        return false;
    }
    match stop {
        "end_turn" | "stop_sequence" => true,
        "tool_use" | "max_tokens" | "content_filtered" => false,
        _ => false,
    }
}

fn selected_model_for_query(config: &QueryConfig) -> String {
    let selected_model = if let Some(ref agent) = config.agent_definition {
        agent.model.clone().unwrap_or_else(|| config.model.clone())
    } else {
        config.model.clone()
    };

    if config.preserve_selected_model {
        return selected_model;
    }

    if let Some(ref ma_config) = config.managed_agents {
        if ma_config.enabled && !ma_config.manager_model.is_empty() {
            return ma_config.manager_model.clone();
        }
    }

    selected_model
}

fn is_fallback_worthy_api_error(err: &ClaudeError) -> bool {
    match err {
        ClaudeError::RateLimit { .. } => true,
        ClaudeError::ApiStatus { status, message } => {
            *status == 429 || *status == 529 || message.to_lowercase().contains("overloaded")
        }
        _ => {
            let err_str = err.to_string().to_lowercase();
            err_str.contains("overloaded")
                || err_str.contains("529")
                || err_str.contains("rate_limit")
                || err_str.contains("rate limit")
        }
    }
}

fn enrich_error_notice(
    err: ClaudeError,
    provider: &str,
    model: &str,
    account: Option<&str>,
) -> ClaudeError {
    match err {
        ClaudeError::RateLimit {
            retry_after_secs,
            message,
        } => ClaudeError::RateLimit {
            retry_after_secs,
            message: Some(rate_limit_notice(
                provider,
                model,
                account,
                message.as_deref(),
                retry_after_secs,
            )),
        },
        ClaudeError::ApiStatus {
            status: 429,
            message,
        } => ClaudeError::RateLimit {
            retry_after_secs: None,
            message: Some(rate_limit_notice(
                provider,
                model,
                account,
                Some(&message),
                None,
            )),
        },
        other => other,
    }
}

fn rate_limit_notice(
    provider: &str,
    model: &str,
    account: Option<&str>,
    provider_message: Option<&str>,
    retry_after_secs: Option<u64>,
) -> String {
    let account_part = account
        .filter(|value| !value.trim().is_empty())
        .map(|value| format!(" on account `{}`", value.trim()))
        .unwrap_or_default();
    let mut message = format!(
        "Claude rate limit for model `{model}`{account_part}.\n\n\
         Anthropic/Claude Max limits are model-tier scoped: Sonnet/Opus can be limited while Haiku still works.\n\
         Try switching to Haiku, switching Anthropic accounts, or waiting before retrying."
    );
    if let Some(secs) = retry_after_secs {
        message.push_str(&format!(
            "\n\nThe provider says the limit resets in {}.",
            format_reset_delay(secs)
        ));
    }
    if account
        .map(|value| value.to_lowercase().contains("claude-code"))
        .unwrap_or(false)
    {
        message.push_str(
            "\n\nThis is an imported Claude Code credential. Coven is using the imported token for direct Anthropic requests; it is not running the `claude` CLI for this turn.",
        );
    }

    let provider_message = provider_message
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .filter(|value| !value.eq_ignore_ascii_case("error"));
    if let Some(provider_message) = provider_message {
        message.push_str(&format!("\n\nProvider message: {provider_message}"));
    } else if provider != "anthropic" {
        message.push_str(&format!("\n\nProvider: {provider}"));
    }

    message
}

/// Format a reset delay in seconds as a compact human duration ("45s",
/// "3m 20s", "1h 12m").
pub fn format_reset_delay(secs: u64) -> String {
    if secs >= 3600 {
        let h = secs / 3600;
        let m = (secs % 3600) / 60;
        if m == 0 {
            format!("{h}h")
        } else {
            format!("{h}h {m}m")
        }
    } else if secs >= 60 {
        let m = secs / 60;
        let s = secs % 60;
        if s == 0 {
            format!("{m}m")
        } else {
            format!("{m}m {s}s")
        }
    } else {
        format!("{secs}s")
    }
}

fn active_account_notice(provider: &str) -> Option<String> {
    let registry = claurst_core::accounts::AccountRegistry::load();
    let profile = registry.active_profile(provider)?;
    let display_name = profile.display_name();
    let mut label = if display_name == profile.id {
        profile.id.clone()
    } else {
        format!("{} ({})", profile.id, display_name)
    };
    if let Some(tier) = profile
        .subscription_tier
        .as_deref()
        .map(str::trim)
        .filter(|tier| !tier.is_empty())
    {
        label.push_str(&format!(" [{tier}]"));
    }
    Some(label)
}

// Spinner verbs are imported from claurst_core::spinner

/// Run the agentic query loop.
///
/// This sends the conversation to the API, handles tool calls in a loop, and
/// returns when the model issues an end_turn or an error/limit is hit.
///
/// `pending_messages` is an optional queue of user messages that were enqueued
/// during tool execution (e.g. by the UI or a command queue).  Each string is
/// appended as a plain user message between turns.  Callers that do not need
/// command queuing may pass `None` or an empty `Vec`.
//
// Allowed: the inputs here are intentionally separate domain values (HTTP
// client, mutable message log, immutable tool set, tool execution context,
// query knobs, cost accumulator, event channel, cancellation token, pending
// messages). Bundling them behind a single config struct would mostly move
// the parameter count from the signature into the struct without improving
// clarity — and several of these arguments need separate lifetimes that a
// struct can't easily express.
#[allow(clippy::too_many_arguments)]
pub async fn run_query_loop(
    client: &claurst_api::AnthropicClient,
    messages: &mut Vec<Message>,
    tools: &[Box<dyn Tool>],
    tool_ctx: &ToolContext,
    config: &QueryConfig,
    cost_tracker: Arc<CostTracker>,
    event_tx: Option<mpsc::UnboundedSender<QueryEvent>>,
    cancel_token: tokio_util::sync::CancellationToken,
    mut pending_messages: Option<&mut Vec<String>>,
) -> QueryOutcome {
    // One logical query owns one capture, including every tool follow-up and
    // its final reply. A caller-supplied capture (including absence) is final.
    let mut turn_ctx = tool_ctx.clone();
    if let Err(error) = turn_ctx.goal_turn.capture(&turn_ctx.session_id) {
        warn!(%error, "Could not capture goal turn");
        if let Some(tx) = &event_tx {
            let _ = tx.send(QueryEvent::Status(format!(
                "Goal error: could not capture turn: {error}"
            )));
        }
        return QueryOutcome::Error(ClaudeError::Api(format!("Goal authority failed: {error}")));
    }
    let tool_ctx = &turn_ctx;
    let mut turn_config = config.clone();
    if let Some(turn) = tool_ctx.goal_turn.captured() {
        let addendum = claurst_core::goal_system_prompt_addendum(turn.goal());
        turn_config.append_system_prompt = Some(match turn_config.append_system_prompt {
            Some(existing) => format!("{existing}\n{addendum}"),
            None => addendum,
        });
    }
    let config = &turn_config;
    let mut turn = 0u32;
    let mut compact_state = compact::AutoCompactState::default();
    // Tracks how many consecutive max_tokens recoveries we've attempted so
    // we don't loop forever on a model that can't finish within any budget.
    let mut max_tokens_recovery_count: u32 = 0;
    // Automatic continuation nudges used for announce-then-stop stalls this
    // user turn (issue #165). Reset whenever a tool round actually executes.
    let mut stall_recovery_count: u32 = 0;
    // Active model — may switch to fallback on overloaded errors.
    // Agent model override takes priority over the session model when set.
    let mut effective_model = selected_model_for_query(config);

    let mut used_fallback = false;
    // How many automatic retries remain when a stream stalls (no data for 45s).
    let mut retries_left: u32 = 2;

    // If an agent defines a max_turns override, respect it (agent wins over config).
    let effective_max_turns = config
        .agent_definition
        .as_ref()
        .and_then(|a| a.max_turns)
        .unwrap_or(config.max_turns);

    // Shadow-git snapshot: capture the worktree state before any tools run so we
    // can produce a per-turn file-change patch when the turn ends.
    let shadow_snap: Option<std::sync::Arc<claurst_core::snapshot::ShadowSnapshot>> =
        if tool_ctx.config.auto_commits == Some(true) {
            claurst_core::snapshot::get_or_create(&tool_ctx.working_dir)
        } else {
            None
        };
    // Pre-capture tree hash; refreshed at the start of each turn's tool phase.
    let initial_snapshot: Option<String> = if let Some(ref s) = shadow_snap {
        s.track().await
    } else {
        None
    };

    macro_rules! require_goal_work {
        ($message:expr) => {
            let permission = tool_ctx.goal_turn.validate(&tool_ctx.session_id);
            if permission != Ok(GoalTurnPermission::Work) {
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut $message,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "goal work is no longer authorized",
                )
                .await;
                match permission {
                    Ok(
                        GoalTurnPermission::FinalResponse | GoalTurnPermission::ReturnToForeground,
                    ) => continue,
                    Err(error) => {
                        return QueryOutcome::Error(ClaudeError::Api(format!(
                            "Goal authority revoked: {error}"
                        )))
                    }
                    Ok(GoalTurnPermission::Work) => {
                        unreachable!("work was handled before finalization")
                    }
                }
            }
        };
    }

    loop {
        let goal_permission = match tool_ctx.goal_turn.validate(&tool_ctx.session_id) {
            Ok(permission) => permission,
            Err(error) => {
                return QueryOutcome::Error(ClaudeError::Api(format!(
                    "Goal authority revoked: {error}"
                )))
            }
        };
        if goal_permission == GoalTurnPermission::ReturnToForeground {
            // Return received findings and tool evidence without another model
            // request. The foreground needs the successful completion audit.
            let mut findings = Vec::new();
            for message in messages.iter() {
                match &message.content {
                    claurst_core::types::MessageContent::Text(text)
                        if message.role == claurst_core::types::Role::Assistant =>
                    {
                        findings.push(text.as_str())
                    }
                    claurst_core::types::MessageContent::Blocks(blocks) => {
                        for block in blocks {
                            match block {
                                ContentBlock::Text { text }
                                    if message.role == claurst_core::types::Role::Assistant =>
                                {
                                    findings.push(text.as_str())
                                }
                                ContentBlock::ToolResult {
                                    content: ToolResultContent::Text(text),
                                    ..
                                } => findings.push(text.as_str()),
                                ContentBlock::ToolResult {
                                    content: ToolResultContent::Blocks(blocks),
                                    ..
                                } => {
                                    findings.extend(blocks.iter().filter_map(
                                        |block| match block {
                                            ContentBlock::Text { text } => Some(text.as_str()),
                                            _ => None,
                                        },
                                    ));
                                }
                                _ => {}
                            }
                        }
                    }
                    _ => {}
                }
            }
            let text = if findings.is_empty() {
                "Goal marked complete.".to_owned()
            } else {
                findings.join("\n\n")
            };
            return QueryOutcome::EndTurn {
                message: Message::assistant(text),
                usage: UsageInfo::default(),
            };
        }
        let final_response = goal_permission == GoalTurnPermission::FinalResponse;
        let final_reservation = if final_response {
            match tool_ctx
                .goal_turn
                .captured()
                .map(GoalTurn::reserve_final_response)
                .transpose()
            {
                Ok(reservation) => reservation,
                Err(error) => {
                    return QueryOutcome::Error(ClaudeError::Api(format!(
                        "Goal final response unavailable: {error}"
                    )))
                }
            }
        } else {
            None
        };
        let goal_client = tool_ctx
            .goal_turn
            .captured()
            .map(|turn| client.for_goal_turn(turn, goal_permission));
        let client = goal_client.as_ref().unwrap_or(client);
        turn += 1;
        tool_ctx
            .current_turn
            .store(turn as usize, std::sync::atomic::Ordering::Relaxed);
        if turn > effective_max_turns {
            info!(turns = turn, "Max turns reached");
            if let Some(ref tx) = event_tx {
                let _ = tx.send(QueryEvent::Status(format!(
                    "Reached maximum turn limit ({})",
                    effective_max_turns
                )));
            }
            return QueryOutcome::Error(ClaudeError::Api(format!(
                "Maximum turn limit ({}) reached",
                effective_max_turns
            )));
        }

        // Check for cancellation
        if cancel_token.is_cancelled() {
            return QueryOutcome::Cancelled;
        }

        // Drain any pending user messages that were queued during the previous
        // tool-execution phase (e.g. commands entered while tools ran).
        // Mirrors the TS `messageQueueManager` drain between turns.
        if let Some(queue) = pending_messages.as_deref_mut().filter(|_| !final_response) {
            for text in queue.drain(..) {
                debug!("Injecting pending message: {}", &text);
                messages.push(Message::user(text));
            }
        }

        // T1-4: Drain the priority command queue (if wired up) and prepend any
        // resulting messages to the conversation before the API call.
        // Mirrors the TS `messageQueueManager` priority-queue drain.
        if let Some(cq) = config.command_queue.as_ref().filter(|_| !final_response) {
            if !cq.is_empty() {
                let injected = drain_command_queue(cq);
                if !injected.is_empty() {
                    debug!(count = injected.len(), "Injecting command-queue messages");
                    // Prepend so that higher-priority commands appear first.
                    let tail = std::mem::take(messages);
                    messages.extend(injected);
                    messages.extend(tail);
                }
            }
        }

        // Apply tool-result budget: if the cumulative size of all tool results
        // in the conversation exceeds the configured threshold, replace the
        // oldest results with a placeholder until we're back under budget.
        // This mirrors the TS `applyToolResultBudget` call in query.ts.
        if !final_response && config.tool_result_budget > 0 {
            let (budgeted, truncated) =
                apply_tool_result_budget(std::mem::take(messages), config.tool_result_budget);
            *messages = budgeted;
            if truncated > 0 {
                info!(
                    truncated,
                    budget = config.tool_result_budget,
                    "Tool-result budget exceeded: truncated {} result(s)",
                    truncated
                );
                if let Some(ref tx) = event_tx {
                    let _ = tx.send(QueryEvent::Status(format!(
                        "[{} older tool result(s) truncated to save context]",
                        truncated
                    )));
                }
            }
        }

        // Build API request
        let api_messages: Vec<ApiMessage> = messages.iter().map(ApiMessage::from).collect();
        let api_tools: Vec<ApiToolDefinition> = tools
            .iter()
            .filter(|_| !final_response)
            .map(|t| ApiToolDefinition::from(&t.to_definition()))
            .collect();

        // Verification nudge: if there are incomplete todos for this session
        // and the conversation has more than 2 turns, append a reminder.
        let system = {
            // Build a (possibly patched) config for system-prompt assembly.
            // Agent prompt prefix and todo nudge are both applied here.
            let mut patched = config.clone();

            // Apply agent system-prompt prefix: prepend before the main system prompt.
            if let Some(ref agent) = config.agent_definition {
                if let Some(ref agent_prompt) = agent.prompt {
                    patched.system_prompt = Some(match &config.system_prompt {
                        Some(existing) => format!("{}\n\n{}", agent_prompt, existing),
                        None => agent_prompt.clone(),
                    });
                }
            }

            // If managed-agent mode is active, append orchestration instructions.
            if let Some(ref ma_config) = config.managed_agents {
                if ma_config.enabled {
                    let ma_prompt =
                        crate::managed_orchestrator::managed_agent_system_prompt(ma_config);
                    patched.append_system_prompt = Some(match &patched.append_system_prompt {
                        Some(existing) => format!("{}\n\n{}", existing, ma_prompt),
                        None => ma_prompt,
                    });
                }
            }

            // Apply todo nudge on turns > 2.
            if turn > 2 {
                let nudge = build_todo_nudge(&tool_ctx.session_id);
                if !nudge.is_empty() {
                    patched.append_system_prompt = Some(match &config.append_system_prompt {
                        Some(existing) => format!("{}\n\n{}", existing, nudge),
                        None => nudge,
                    });
                }
            }

            if final_response {
                let instruction = "The captured goal was completed by this turn. Respond only with the final summary of that completed work. Do not use tools, initiate work, or continue the objective.";
                patched.append_system_prompt = Some(match patched.append_system_prompt {
                    Some(existing) => format!("{existing}\n{instruction}"),
                    None => instruction.to_owned(),
                });
            }
            build_system_prompt(&patched)
        };

        let system_for_provider = system.clone(); // used by non-Anthropic dispatch below
        let mut req_builder = CreateMessageRequest::builder(&effective_model, config.max_tokens)
            .messages(api_messages)
            .system(system)
            .tools(api_tools);

        // Resolve effective thinking budget:
        //   1. Explicit `thinking_budget` in config takes precedence.
        //   2. Fall back to the effort level's budget when no explicit budget is set.
        let effective_thinking_budget = config.thinking_budget.or_else(|| {
            config
                .effort_level
                .and_then(|el| el.thinking_budget_tokens())
        });

        // Apply temperature: explicit config value takes precedence, then agent override,
        // then effort-level override.
        let effective_temperature = config
            .temperature
            .or_else(|| {
                config
                    .agent_definition
                    .as_ref()
                    .and_then(|a| a.temperature)
                    .map(|t| t as f32)
            })
            .or_else(|| config.effort_level.and_then(|el| el.temperature()));

        // Newer Anthropic models (Opus 4.7+, Opus 4.8, Fable 5) use *adaptive*
        // thinking: they reject `budget_tokens`, `temperature`, `top_p`, and
        // `top_k` with a 400. For those, send `thinking: {type: "adaptive"}`
        // and steer reasoning depth via `output_config.effort` instead.
        if claurst_core::effort::model_uses_adaptive_thinking(&effective_model) {
            // Enable adaptive thinking whenever the user expressed any
            // reasoning intent (an explicit budget or a chosen effort level).
            if effective_thinking_budget.is_some() || config.effort_level.is_some() {
                req_builder = req_builder.thinking(ThinkingConfig::adaptive());
            }
            if let Some(level) = config.effort_level {
                req_builder = req_builder.effort(level.as_str());
            }
            // Deliberately omit temperature / budget_tokens — rejected by these
            // models.
        } else {
            if let Some(budget) = effective_thinking_budget {
                req_builder = req_builder.thinking(ThinkingConfig::enabled(budget));
            }
            if let Some(t) = effective_temperature {
                req_builder = req_builder.temperature(t);
            }
        }

        let request = req_builder.build();

        // The query loop publishes events after it has durably accumulated
        // them, so UI-triggered cancellation cannot lose visible output.
        let handler: Arc<dyn StreamHandler> = Arc::new(claurst_api::streaming::NullStreamHandler);

        // Non-Anthropic provider dispatch: if the model is "provider/model"
        // format and the registry has that provider, use it directly.
        //
        // Provider resolution priority:
        //   1. Explicit "provider/model" format in the model string
        //   2. config.provider setting (from --provider flag or settings.json)
        //   3. Model registry lookup (e.g. "gemini-3-flash-preview" → google)
        //   4. Default to "anthropic"
        if let Some(ref registry) = config.provider_registry {
            let (provider_id_str, model_id_str) = if let Some(p) = tool_ctx
                .config
                .provider
                .as_deref()
                .filter(|p| *p != "anthropic")
            {
                // Explicit non-Anthropic provider in config — use it.
                // If the stored model is in canonical "provider/model" form,
                // strip the top-level provider prefix before sending it to the
                // provider adapter. If it contains an additional slash
                // (e.g. "meta-llama/Llama-3.3..." on OpenRouter), preserve it.
                let provider_prefix = format!("{}/", p);
                let model_id = effective_model
                    .strip_prefix(&provider_prefix)
                    .unwrap_or(&effective_model)
                    .to_string();
                (p.to_string(), model_id)
            } else if let Some((p, m)) = effective_model.split_once('/') {
                // No explicit provider but model has "provider/model" format.
                // Check whether `p` is a known provider or just a model
                // namespace (e.g. "meta-llama/Llama-3" on OpenRouter).
                let known_providers = [
                    // Native (non-OpenAI-compat) providers
                    "anthropic",
                    "openai",
                    "google",
                    "azure",
                    "amazon-bedrock",
                    "github-copilot",
                    "codex",
                    "openai-codex",
                    "cohere",
                    "minimax",
                    // Local / self-hosted
                    "ollama",
                    "lmstudio",
                    "lm-studio",
                    "llamacpp",
                    "llama-cpp",
                    "llama-server",
                    // OpenAI-compat cloud providers
                    "groq",
                    "mistral",
                    "deepseek",
                    "xai",
                    "perplexity",
                    "cerebras",
                    "openrouter",
                    "togetherai",
                    "together-ai",
                    "deepinfra",
                    "venice",
                    "huggingface",
                    "nvidia",
                    "fireworks",
                    "sambanova",
                    // Additional OpenAI-compat providers
                    "qwen",
                    "siliconflow",
                    "moonshot",
                    "moonshotai",
                    "zhipu",
                    "zhipuai",
                    "zai",
                    "nebius",
                    "novita",
                    "ovhcloud",
                    "scaleway",
                    "vultr",
                    "vultr-ai",
                    "baseten",
                    "friendli",
                    "upstage",
                    "stepfun",
                ];
                if known_providers.contains(&p) {
                    (p.to_string(), m.to_string())
                } else {
                    // Treat the whole string as the model ID, fall through
                    // to auto-detection below.
                    let fallback_provider =
                        tool_ctx.config.provider.as_deref().unwrap_or("anthropic");
                    (fallback_provider.to_string(), effective_model.clone())
                }
            } else {
                // No explicit provider set (or set to "anthropic"): try the
                // model registry to auto-detect provider from the model name.
                // Use the shared model registry from QueryConfig if available;
                // otherwise construct a temporary one.
                let temp_reg;
                let model_reg: &claurst_api::ModelRegistry = if let Some(ref shared) =
                    config.model_registry
                {
                    shared
                } else {
                    temp_reg = {
                        let mut r = claurst_api::ModelRegistry::new();
                        if let Some(cache_dir) = dirs::cache_dir() {
                            let cache_path = cache_dir.join("coven-code").join("models_dev.json");
                            r.load_cache(&cache_path);
                        }
                        r
                    };
                    &temp_reg
                };
                if let Some(detected_pid) = model_reg.find_provider_for_model(&effective_model) {
                    let pid_str = detected_pid.to_string();
                    if pid_str != "anthropic" {
                        (pid_str, effective_model.clone())
                    } else {
                        ("anthropic".to_string(), effective_model.clone())
                    }
                } else {
                    // Fall back to config.provider (may be "anthropic" or None→"anthropic")
                    let p = tool_ctx.config.provider.as_deref().unwrap_or("anthropic");
                    (p.to_string(), effective_model.clone())
                }
            };

            // Dispatch through the provider path for non-Anthropic providers,
            // AND for Anthropic when the pre-built client has no API key
            // (user started without ANTHROPIC_API_KEY but added one via /connect).
            let use_provider_dispatch = provider_id_str != "anthropic" || client.api_key_is_empty();

            if use_provider_dispatch {
                let pid = claurst_core::provider_id::ProviderId::new(&provider_id_str);

                // Always prefer a fresh provider built from the auth_store so
                // that keys added at runtime via /connect are picked up
                // immediately — even when the provider was pre-registered at
                // startup with a stale or missing key.
                let runtime_provider =
                    claurst_api::registry::runtime_provider_for(&provider_id_str);

                let registry_provider = if runtime_provider.is_some() {
                    // Fresh auth_store key available — use it instead of the
                    // (possibly stale) registry entry.
                    None
                } else {
                    registry.get(&pid).cloned()
                };

                let mut provider = runtime_provider.or(registry_provider);

                // Rebuild providers using the unified base resolver so overrides
                // from settings/env/defaults are applied consistently.
                if claurst_api::registry::resolve_provider_api_base(
                    &tool_ctx.config,
                    &provider_id_str,
                )
                .is_some()
                {
                    if let Some(overridden) = claurst_api::registry::provider_from_config(
                        &tool_ctx.config,
                        &provider_id_str,
                    ) {
                        provider = Some(overridden);
                    }
                }
                if let Some(provider) = provider {
                    debug!(provider = %provider_id_str, model = %model_id_str, "Dispatching to non-Anthropic provider");

                    // Notify TUI that we're calling the provider using a random spinner verb
                    if let Some(ref tx) = event_tx {
                        use claurst_core::sample_spinner_verb;
                        let seed = provider_id_str.len() ^ model_id_str.len();
                        let verb = sample_spinner_verb(seed);
                        let _ = tx.send(QueryEvent::Status(format!("✳ {}…", verb)));
                    }

                    // Build ProviderRequest from the already-assembled request data.
                    // tools comes from the api_tools we already built above.
                    // Filter unsupported modalities: replace Image/Document blocks
                    // with placeholder text when the provider doesn't support them,
                    // preventing crashes on text-only models.
                    let mut caps = provider.capabilities();
                    if let Some(model_entry) =
                        config.model_registry.as_ref().and_then(|model_registry| {
                            model_registry.get(&provider_id_str, &model_id_str)
                        })
                    {
                        caps.image_input = model_entry.vision();
                        caps.tool_calling = model_entry.tool_calling;
                        caps.thinking = model_entry.reasoning;
                    }
                    let provider_tools: Vec<claurst_core::types::ToolDefinition> =
                        if caps.tool_calling && !final_response {
                            tools.iter().map(|t| t.to_definition()).collect()
                        } else {
                            Vec::new()
                        };
                    let provider_messages: Vec<claurst_core::types::Message> = messages
                        .iter()
                        .map(|msg| {
                            let mut msg = msg.clone();
                            if let claurst_core::types::MessageContent::Blocks(ref mut blocks) =
                                msg.content
                            {
                                for block in blocks.iter_mut() {
                                    match block {
                                        claurst_core::types::ContentBlock::Image { .. }
                                            if !caps.image_input =>
                                        {
                                            *block = claurst_core::types::ContentBlock::Text {
                                                text: "[Image not supported by this model]"
                                                    .to_string(),
                                            };
                                        }
                                        claurst_core::types::ContentBlock::Document { .. }
                                            if !caps.pdf_input =>
                                        {
                                            *block = claurst_core::types::ContentBlock::Text {
                                                text: "[PDF not supported by this model]"
                                                    .to_string(),
                                            };
                                        }
                                        _ => {}
                                    }
                                }
                            }
                            msg
                        })
                        .collect();

                    let provider_request = claurst_api::ProviderRequest {
                        model: model_id_str.to_owned(),
                        messages: provider_messages,
                        system_prompt: Some(system_for_provider.clone()),
                        tools: provider_tools,
                        max_tokens: config.max_tokens,
                        temperature: effective_temperature.map(|t| t as f64),
                        top_p: None,
                        top_k: None,
                        stop_sequences: vec![],
                        thinking: if caps.thinking {
                            effective_thinking_budget.map(claurst_api::ThinkingConfig::enabled)
                        } else {
                            None
                        },
                        provider_options: build_provider_options(
                            &provider_id_str,
                            &model_id_str,
                            config.effort_level,
                            effective_thinking_budget,
                        ),
                    };

                    // Use create_message_stream so the TUI receives real-time
                    // text deltas instead of waiting for the full response.
                    if let Err(error) = tool_ctx.goal_turn.validate(&tool_ctx.session_id) {
                        return QueryOutcome::Error(ClaudeError::Api(format!(
                            "Goal authority revoked: {error}"
                        )));
                    }
                    let stream = match await_goal_request(
                        tool_ctx.goal_turn.captured(),
                        goal_permission,
                        &cancel_token,
                        async {
                            provider
                                .create_message_stream_for_goal(
                                    provider_request,
                                    tool_ctx.goal_turn.captured(),
                                    goal_permission,
                                )
                                .await
                                .map_err(ClaudeError::from)
                        },
                    )
                    .await
                    {
                        Ok(s) => s,
                        Err(ClaudeError::Cancelled) => return QueryOutcome::Cancelled,
                        Err(e) => {
                            if !final_response
                                && matches!(
                                    tool_ctx.goal_turn.validate(&tool_ctx.session_id),
                                    Ok(GoalTurnPermission::FinalResponse
                                        | GoalTurnPermission::ReturnToForeground)
                                )
                            {
                                continue;
                            }
                            error!(provider = %provider_id_str, error = %e, "Provider stream failed");
                            let claude_error = e;
                            return QueryOutcome::Error(enrich_error_notice(
                                claude_error,
                                &provider_id_str,
                                &model_id_str,
                                active_account_notice(&provider_id_str).as_deref(),
                            ));
                        }
                    };

                    let provider_stall_timeout = stream_stall_timeout();
                    let mut terminal_stream_error = None;
                    let mut accumulator = StreamAccumulator::new();
                    let stream_cancel = cancel_token.child_token();
                    let (provider_stream_outcome, goal_revocation) = {
                        let mut provider_stream_context = ProviderStreamContext {
                            cancel_token: &stream_cancel,
                            accumulator: &mut accumulator,
                            event_tx: event_tx.as_ref(),
                            provider_id: &provider_id_str,
                            model_id: &model_id_str,
                            terminal_stream_error: &mut terminal_stream_error,
                        };
                        let receive = consume_provider_stream(
                            stream,
                            &mut provider_stream_context,
                            provider_stall_timeout,
                        );
                        tokio::pin!(receive);
                        tokio::select! {
                            biased;
                            error = wait_for_goal_revocation(tool_ctx.goal_turn.captured(), goal_permission) => {
                                stream_cancel.cancel();
                                (receive.await, Some(error))
                            }
                            outcome = &mut receive => (outcome, None),
                        }
                    };
                    let goal_revoked = goal_revocation.is_some();
                    if let Some(error) = goal_revocation {
                        terminal_stream_error = Some(error);
                    }
                    let provider_stream_cancelled = !goal_revoked
                        && provider_stream_outcome == ProviderStreamOutcome::Cancelled;
                    let provider_stream_stalled =
                        provider_stream_outcome == ProviderStreamOutcome::Stalled;

                    if provider_stream_outcome == ProviderStreamOutcome::PrematureEof {
                        terminal_stream_error = Some(ClaudeError::Api(format!(
                            "Provider '{}' stream ended before MessageStop",
                            provider_id_str
                        )));
                    }

                    let (mut assistant_msg, usage, stop_reason) =
                        finish_stream_accumulator(accumulator);
                    let stop_str = stop_reason.unwrap_or_else(|| "end_turn".to_string());

                    let permission_now = tool_ctx.goal_turn.validate(&tool_ctx.session_id);
                    let own_completion = !final_response
                        && matches!(
                            permission_now,
                            Ok(GoalTurnPermission::FinalResponse
                                | GoalTurnPermission::ReturnToForeground)
                        );
                    let goal_error = permission_now.err();
                    if goal_error.is_some()
                        || own_completion
                        || (final_response
                            && !provider_stream_cancelled
                            && !provider_stream_stalled
                            && terminal_stream_error.is_none())
                    {
                        cost_tracker.add_usage(
                            usage.input_tokens,
                            usage.output_tokens,
                            usage.cache_creation_input_tokens,
                            usage.cache_read_input_tokens,
                        );
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "goal work is no longer authorized",
                        )
                        .await;
                        if let Some(error) = goal_error {
                            return QueryOutcome::Error(ClaudeError::Api(format!(
                                "Goal authority revoked: {error}"
                            )));
                        }
                        if let Err(error) = tool_ctx.goal_turn.validate(&tool_ctx.session_id) {
                            return QueryOutcome::Error(ClaudeError::Api(format!(
                                "Goal authority revoked: {error}"
                            )));
                        }
                        // Keep cancelled handoffs under the normal loop terminal checks.
                        if own_completion && cancel_token.is_cancelled() {
                            continue;
                        }
                        if let Some(reservation) = &final_reservation {
                            reservation.finish();
                        }
                        // Goal permission does not waive the independent session cost cap.
                        if let Some(limit) = config.max_budget_usd {
                            let spent = cost_tracker.total_cost_usd();
                            if spent >= limit {
                                if let Some(ref tx) = event_tx {
                                    let _ = tx.send(QueryEvent::Status(format!(
                                        "Budget limit ${:.4} exceeded (spent ${:.4}) — stopping.",
                                        limit, spent
                                    )));
                                }
                                return QueryOutcome::BudgetExceeded {
                                    cost_usd: spent,
                                    limit_usd: limit,
                                };
                            }
                        }
                        if own_completion {
                            continue;
                        }
                        if !assistant_msg.get_tool_use_blocks().is_empty() {
                            return QueryOutcome::Error(ClaudeError::Api("Completed goal permits only a final response; tool calls were not executed".into()));
                        }
                        if stop_str == "end_turn" || stop_str == "stop_sequence" {
                            emit_turn_complete(event_tx.as_ref(), turn, &stop_str, &usage);
                            return QueryOutcome::EndTurn {
                                message: assistant_msg,
                                usage,
                            };
                        }
                        if stop_str == "max_tokens" {
                            return QueryOutcome::MaxTokens {
                                partial_message: assistant_msg,
                                usage,
                            };
                        }
                        return QueryOutcome::Error(ClaudeError::Api(format!(
                            "Final response ended with {stop_str}"
                        )));
                    }

                    // Stalled attempts may have been visible and billable even
                    // though they never reached a protocol terminal event.
                    // Preserve them before issuing a fresh request.
                    if provider_stream_stalled && retries_left > 0 {
                        finalize_stalled_attempt_before_retry(
                            messages,
                            &mut assistant_msg,
                            &usage,
                            &cost_tracker,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                        )
                        .await;
                        retries_left -= 1;
                        warn!(provider = %provider_id_str, model = %model_id_str, retries_left, "Provider stream stalled — retrying");
                        if let Some(ref tx) = event_tx {
                            let _ = tx.send(QueryEvent::Status(format!(
                                "No response for 45s — retrying ({} left)…",
                                retries_left + 1
                            )));
                        }
                        turn -= 1;
                        continue;
                    }
                    if provider_stream_stalled {
                        terminal_stream_error = Some(ClaudeError::Api(format!(
                            "Provider '{}' stream stalled after all retry attempts",
                            provider_id_str
                        )));
                    }

                    cost_tracker.add_usage(
                        usage.input_tokens,
                        usage.output_tokens,
                        usage.cache_creation_input_tokens,
                        usage.cache_read_input_tokens,
                    );

                    if provider_stream_cancelled {
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "stream was cancelled",
                        )
                        .await;
                        return QueryOutcome::Cancelled;
                    }

                    if let Some(error) = terminal_stream_error {
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "stream failed",
                        )
                        .await;
                        return QueryOutcome::Error(error);
                    }

                    // Apply terminal guards before any tool execution. Provider
                    // responses use the same finalization path as Anthropic so
                    // durable history is complete before reporting a terminal
                    // outcome.
                    if let Some(limit) = config.max_budget_usd {
                        let spent = cost_tracker.total_cost_usd();
                        if spent >= limit {
                            if let Some(ref tx) = event_tx {
                                let _ = tx.send(QueryEvent::Status(format!(
                                    "Budget limit ${:.4} exceeded (spent ${:.4}) — stopping.",
                                    limit, spent
                                )));
                            }
                            finalize_terminal_assistant_with_unexecuted_tool_results(
                                messages,
                                &mut assistant_msg,
                                shadow_snap.as_ref(),
                                initial_snapshot.as_deref(),
                                event_tx.as_ref(),
                                "budget limit was exceeded",
                            )
                            .await;
                            return QueryOutcome::BudgetExceeded {
                                cost_usd: spent,
                                limit_usd: limit,
                            };
                        }
                    }

                    messages.push(assistant_msg.clone());

                    // Handle tool-use turn: execute tools and loop.
                    let tool_use_blocks: Vec<_> = assistant_msg
                        .get_tool_use_blocks()
                        .into_iter()
                        .filter_map(|b| {
                            if let ContentBlock::ToolUse { id, name, input } = b {
                                Some((id.clone(), name.clone(), input.clone()))
                            } else {
                                None
                            }
                        })
                        .collect();

                    // PostModelTurn hooks run before tool execution, matching
                    // the Anthropic stream path. A hard veto makes the sampled
                    // response terminal and must not be converted into a
                    // successful end turn.
                    let hook_result = fire_post_sampling_hooks(&assistant_msg, &tool_ctx.config);
                    if !hook_result.blocking_errors.is_empty() {
                        if hook_result.prevent_continuation {
                            let hook_reason = hook_result
                                .blocking_errors
                                .iter()
                                .map(Message::get_all_text)
                                .collect::<Vec<_>>()
                                .join("\n");
                            if let Some(ref tx) = event_tx {
                                let _ = tx.send(QueryEvent::Status(
                                    "PostModelTurn hook vetoed continuation.".to_string(),
                                ));
                            }
                            finalize_terminal_assistant_with_unexecuted_tool_results(
                                messages,
                                &mut assistant_msg,
                                shadow_snap.as_ref(),
                                initial_snapshot.as_deref(),
                                event_tx.as_ref(),
                                "post-model hook vetoed continuation",
                            )
                            .await;
                            for err_msg in hook_result.blocking_errors {
                                messages.push(err_msg);
                            }
                            return QueryOutcome::Error(ClaudeError::Api(format!(
                                "PostModelTurn hook vetoed continuation: {}",
                                hook_reason
                            )));
                        }
                        for err_msg in hook_result.blocking_errors {
                            debug!("PostModelTurn hook injecting error message");
                            messages.push(err_msg);
                        }
                    }

                    require_goal_work!(assistant_msg);
                    if stop_str == "max_tokens" {
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "maximum output tokens were reached",
                        )
                        .await;
                        return QueryOutcome::MaxTokens {
                            partial_message: assistant_msg,
                            usage,
                        };
                    }

                    if stop_str == "content_filtered"
                        || !matches!(
                            stop_str.as_str(),
                            "end_turn" | "tool_use" | "max_tokens" | "stop_sequence"
                        )
                    {
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "response ended abnormally",
                        )
                        .await;
                        return QueryOutcome::Error(ClaudeError::Api(format!(
                            "Provider '{}' returned unsupported stop reason '{}'",
                            provider_id_str, stop_str
                        )));
                    }

                    if stop_str == "tool_use" && tool_use_blocks.is_empty() {
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "turn ended before tool execution",
                        )
                        .await;
                        return QueryOutcome::Error(ClaudeError::Api(
                            "Provider returned tool_use without tool blocks".to_string(),
                        ));
                    }

                    // Execute tool-use blocks through the same hook-aware path used by
                    // Anthropic streaming. Some OpenAI-compatible providers return
                    // finish_reason "stop" even when tool calls are present, so the
                    // block presence is authoritative here, but execution must still
                    // enforce PreToolUse/plugin policy and emit post-hook events.
                    if !tool_use_blocks.is_empty() {
                        emit_durable_message(event_tx.as_ref(), &assistant_msg);
                        let tool_results = execute_tool_blocks_with_hooks(
                            tool_use_blocks,
                            tools,
                            tool_ctx,
                            event_tx.as_ref(),
                        )
                        .await;
                        let tool_result_message = Message {
                            role: claurst_core::types::Role::User,
                            content: claurst_core::types::MessageContent::Blocks(tool_results),
                            uuid: None,
                            cost: None,
                            snapshot_patch: None,
                        };
                        messages.push(tool_result_message.clone());
                        emit_durable_message(event_tx.as_ref(), &tool_result_message);
                        // Real tool work happened; give the next
                        // announce-then-stop stall a fresh recovery budget.
                        stall_recovery_count = 0;
                        continue; // loop for next turn
                    }

                    // Announce-then-stop stall detection (issue #165), before
                    // the end-of-turn placeholder/TurnComplete below: a round
                    // that executed no tools and whose text is empty or ends
                    // on an imminent-action announcement gets a bounded
                    // continuation nudge instead of ending the turn.
                    let combined_text = assistant_msg.get_all_text();
                    let stalled_announcement =
                        stall_recovery_enabled() && is_stalled_announcement(&combined_text);
                    if stalled_announcement && stall_recovery_count < STALL_RECOVERY_LIMIT {
                        stall_recovery_count += 1;
                        warn!(
                            attempt = stall_recovery_count,
                            limit = STALL_RECOVERY_LIMIT,
                            provider = %provider_id_str,
                            "end_turn with announced-but-unexecuted work — injecting continuation nudge"
                        );
                        if let Some(ref tx) = event_tx {
                            let _ = tx.send(QueryEvent::Status(format!(
                                "Model announced work but ended the turn — nudging it to \
                                 continue (attempt {}/{})",
                                stall_recovery_count, STALL_RECOVERY_LIMIT
                            )));
                        }
                        if sampled_attempt_has_material(&assistant_msg) {
                            emit_durable_message(event_tx.as_ref(), &assistant_msg);
                        } else {
                            messages.retain(|message| message.uuid != assistant_msg.uuid);
                        }
                        messages.push(Message::user(STALL_RECOVERY_MSG));
                        continue;
                    }

                    // End turn — notify TUI and return.
                    // Issue #149 follow-up: providers occasionally end the
                    // turn after a tool round without emitting any text or
                    // tool calls, which left the user staring at a blank
                    // screen ("agent randomly stops"). Surface a placeholder
                    // so the user always sees *some* assistant output and
                    // knows the turn really ended.
                    if combined_text.is_empty() && assistant_msg.get_thinking_blocks().is_empty() {
                        let placeholder = format!(
                            "(no response — model ended the turn with stop_reason \"{}\")",
                            stop_str
                        );
                        if let Some(ref tx) = event_tx {
                            let _ = tx.send(QueryEvent::Stream(
                                AnthropicStreamEvent::ContentBlockDelta {
                                    index: 0,
                                    delta: claurst_api::streaming::ContentDelta::TextDelta {
                                        text: placeholder.clone(),
                                    },
                                },
                            ));
                        }
                        if let claurst_core::types::MessageContent::Blocks(ref mut blocks) =
                            assistant_msg.content
                        {
                            blocks.push(ContentBlock::Text {
                                text: placeholder.clone(),
                            });
                        }
                        if let Some(last) = messages.last_mut() {
                            *last = assistant_msg.clone();
                        }
                    }

                    finalize_terminal_assistant_with_unexecuted_tool_results(
                        messages,
                        &mut assistant_msg,
                        shadow_snap.as_ref(),
                        initial_snapshot.as_deref(),
                        event_tx.as_ref(),
                        "turn ended before tool execution",
                    )
                    .await;

                    if !(stalled_announcement && stall_recovery_count >= STALL_RECOVERY_LIMIT) {
                        emit_turn_complete(event_tx.as_ref(), turn, &stop_str, &usage);
                    }
                    if stalled_announcement && stall_recovery_count >= STALL_RECOVERY_LIMIT {
                        return QueryOutcome::Error(ClaudeError::Api(format!(
                            "Provider '{}' repeatedly ended without completing the turn",
                            provider_id_str
                        )));
                    }
                    return QueryOutcome::EndTurn {
                        message: assistant_msg,
                        usage,
                    };
                } else if provider_id_str != "anthropic" {
                    // Non-Anthropic provider detected but no API key / credentials
                    // available.  Return a clear error instead of silently falling
                    // through to the Anthropic client.
                    let hint = match provider_id_str.as_str() {
                        "codex" | "openai-codex" => {
                            "Run `coven-code auth login --provider codex` to sign in to Codex with ChatGPT."
                        }
                        _ => "Sign in to Claude with `coven-code auth login`, or use Codex with `coven-code auth login --provider codex`.",
                    };
                    error!(
                        provider = %provider_id_str,
                        model = %model_id_str,
                        "No credentials found for provider"
                    );
                    return QueryOutcome::Error(ClaudeError::Api(format!(
                        "No API key for provider '{}' (model '{}'). {}",
                        provider_id_str, model_id_str, hint
                    )));
                }
                // Anthropic with no auth_store key: fall through to the raw
                // client path below (which has its own deferred key validation
                // with detailed model-specific hints).
            }
        }

        // Send to API
        debug!(turn, model = %effective_model, "Sending API request");
        if let Err(error) = tool_ctx.goal_turn.validate(&tool_ctx.session_id) {
            return QueryOutcome::Error(ClaudeError::Api(format!(
                "Goal authority revoked: {error}"
            )));
        }
        let mut stream_rx = match await_goal_request(
            tool_ctx.goal_turn.captured(),
            goal_permission,
            &cancel_token,
            client.create_message_stream(request, handler),
        )
        .await
        {
            Ok(rx) => rx,
            Err(ClaudeError::Cancelled) => return QueryOutcome::Cancelled,
            Err(e) => {
                if !final_response
                    && matches!(
                        tool_ctx.goal_turn.validate(&tool_ctx.session_id),
                        Ok(GoalTurnPermission::FinalResponse
                            | GoalTurnPermission::ReturnToForeground)
                    )
                {
                    continue;
                }
                // On overloaded/rate-limit errors, attempt one switch to the fallback model.
                if !used_fallback && is_fallback_worthy_api_error(&e) {
                    if let Some(ref fb) = config.fallback_model {
                        warn!(
                            primary = %effective_model,
                            fallback = %fb,
                            "Primary model unavailable — switching to fallback"
                        );
                        if let Some(ref tx) = event_tx {
                            let _ = tx.send(QueryEvent::Status(format!(
                                "Model unavailable — switching to fallback ({})",
                                fb
                            )));
                        }
                        effective_model = fb.clone();
                        used_fallback = true;
                        turn -= 1; // don't count this attempt against max_turns
                        continue;
                    }
                }
                error!(error = %e, "API request failed");
                return QueryOutcome::Error(enrich_error_notice(
                    e,
                    "anthropic",
                    &effective_model,
                    active_account_notice("anthropic").as_deref(),
                ));
            }
        };

        // Accumulate the streamed response.
        // A stall timeout auto-retries the request if no data arrives for 45s
        // (some providers are slow; we don't want to give up too early).
        let stall_timeout = stream_stall_timeout();
        let mut accumulator = StreamAccumulator::new();
        let mut terminal_stream_error = None;
        let stream_cancel = cancel_token.child_token();
        let (stream_outcome, goal_revocation) = {
            let receive = consume_anthropic_stream(
                &mut stream_rx,
                &stream_cancel,
                &mut accumulator,
                event_tx.as_ref(),
                &effective_model,
                &mut terminal_stream_error,
                stall_timeout,
            );
            tokio::pin!(receive);
            tokio::select! {
                biased;
                error = wait_for_goal_revocation(tool_ctx.goal_turn.captured(), goal_permission) => {
                    stream_cancel.cancel();
                    (receive.await, Some(error))
                }
                outcome = &mut receive => (outcome, None),
            }
        };
        let goal_revoked = goal_revocation.is_some();
        if let Some(error) = goal_revocation {
            terminal_stream_error = Some(error);
        }
        let stream_cancelled = !goal_revoked && stream_outcome == AnthropicStreamOutcome::Cancelled;
        let stream_stalled = stream_outcome == AnthropicStreamOutcome::Stalled;
        let stream_ended_prematurely = stream_outcome == AnthropicStreamOutcome::PrematureEof;

        if stream_ended_prematurely {
            terminal_stream_error = Some(ClaudeError::Api(
                "Anthropic stream ended before MessageStop".to_string(),
            ));
        }

        let (mut assistant_msg, usage, stop_reason) = finish_stream_accumulator(accumulator);
        let stop_str = stop_reason.as_deref().unwrap_or("end_turn");

        let permission_now = tool_ctx.goal_turn.validate(&tool_ctx.session_id);
        let own_completion = !final_response
            && matches!(
                permission_now,
                Ok(GoalTurnPermission::FinalResponse | GoalTurnPermission::ReturnToForeground)
            );
        let goal_error = permission_now.err();
        if goal_error.is_some()
            || own_completion
            || (final_response
                && !stream_cancelled
                && !stream_stalled
                && terminal_stream_error.is_none())
        {
            cost_tracker.add_usage(
                usage.input_tokens,
                usage.output_tokens,
                usage.cache_creation_input_tokens,
                usage.cache_read_input_tokens,
            );
            finalize_terminal_assistant_with_unexecuted_tool_results(
                messages,
                &mut assistant_msg,
                shadow_snap.as_ref(),
                initial_snapshot.as_deref(),
                event_tx.as_ref(),
                "goal work is no longer authorized",
            )
            .await;
            if let Some(error) = goal_error {
                return QueryOutcome::Error(ClaudeError::Api(format!(
                    "Goal authority revoked: {error}"
                )));
            }
            if let Err(error) = tool_ctx.goal_turn.validate(&tool_ctx.session_id) {
                return QueryOutcome::Error(ClaudeError::Api(format!(
                    "Goal authority revoked: {error}"
                )));
            }
            // Keep cancelled handoffs under the normal loop terminal checks.
            if own_completion && cancel_token.is_cancelled() {
                continue;
            }
            if let Some(reservation) = &final_reservation {
                reservation.finish();
            }
            // Goal permission does not waive the independent session cost cap.
            if let Some(limit) = config.max_budget_usd {
                let spent = cost_tracker.total_cost_usd();
                if spent >= limit {
                    if let Some(ref tx) = event_tx {
                        let _ = tx.send(QueryEvent::Status(format!(
                            "Budget limit ${:.4} exceeded (spent ${:.4}) — stopping.",
                            limit, spent
                        )));
                    }
                    return QueryOutcome::BudgetExceeded {
                        cost_usd: spent,
                        limit_usd: limit,
                    };
                }
            }
            if own_completion {
                continue;
            }
            if !assistant_msg.get_tool_use_blocks().is_empty() {
                return QueryOutcome::Error(ClaudeError::Api(
                    "Completed goal permits only a final response; tool calls were not executed"
                        .into(),
                ));
            }
            if stop_str == "end_turn" || stop_str == "stop_sequence" {
                emit_turn_complete(event_tx.as_ref(), turn, stop_str, &usage);
                return QueryOutcome::EndTurn {
                    message: assistant_msg,
                    usage,
                };
            }
            if stop_str == "max_tokens" {
                return QueryOutcome::MaxTokens {
                    partial_message: assistant_msg,
                    usage,
                };
            }
            return QueryOutcome::Error(ClaudeError::Api(format!(
                "Final response ended with {stop_str}"
            )));
        }

        if stream_stalled && retries_left > 0 {
            finalize_stalled_attempt_before_retry(
                messages,
                &mut assistant_msg,
                &usage,
                &cost_tracker,
                shadow_snap.as_ref(),
                initial_snapshot.as_deref(),
                event_tx.as_ref(),
            )
            .await;
            retries_left -= 1;
            warn!(model = %effective_model, retries_left, "Stream stalled — retrying request");
            if let Some(ref tx) = event_tx {
                let _ = tx.send(QueryEvent::Status(format!(
                    "No response for 45s — retrying ({} left)…",
                    retries_left + 1
                )));
            }
            turn -= 1; // don't count this stalled attempt
            continue;
        }

        cost_tracker.add_usage(
            usage.input_tokens,
            usage.output_tokens,
            usage.cache_creation_input_tokens,
            usage.cache_read_input_tokens,
        );

        if stream_cancelled {
            finalize_terminal_assistant_with_unexecuted_tool_results(
                messages,
                &mut assistant_msg,
                shadow_snap.as_ref(),
                initial_snapshot.as_deref(),
                event_tx.as_ref(),
                "stream was cancelled",
            )
            .await;
            return QueryOutcome::Cancelled;
        }

        if stream_stalled {
            return finish_anthropic_stall(
                messages,
                &mut assistant_msg,
                shadow_snap.as_ref(),
                initial_snapshot.as_deref(),
                event_tx.as_ref(),
            )
            .await;
        }

        if let Some(error) = terminal_stream_error {
            finalize_terminal_assistant_with_unexecuted_tool_results(
                messages,
                &mut assistant_msg,
                shadow_snap.as_ref(),
                initial_snapshot.as_deref(),
                event_tx.as_ref(),
                "stream failed",
            )
            .await;
            return QueryOutcome::Error(error);
        }

        // Budget guard: abort the loop if the configured USD cap is exceeded.
        if let Some(limit) = config.max_budget_usd {
            let spent = cost_tracker.total_cost_usd();
            if spent >= limit {
                if let Some(ref tx) = event_tx {
                    let _ = tx.send(QueryEvent::Status(format!(
                        "Budget limit ${:.4} exceeded (spent ${:.4}) — stopping.",
                        limit, spent
                    )));
                }
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut assistant_msg,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "budget limit was exceeded",
                )
                .await;
                return QueryOutcome::BudgetExceeded {
                    cost_usd: spent,
                    limit_usd: limit,
                };
            }
        }

        // Append assistant message to conversation
        messages.push(assistant_msg.clone());

        // Unknown stop reasons are terminal failures. In particular, do not
        // infer tool continuation from blocks when the provider could not
        // report a recognized completion reason.
        let raw_stop = stop_reason.as_deref().unwrap_or("end_turn");
        let stop = match raw_stop {
            "end_turn" | "tool_use" | "max_tokens" | "stop_sequence" | "content_filtered" => {
                raw_stop
            }
            _ => raw_stop,
        };

        // T1-3: Fire PostModelTurn hooks after the model samples a response.
        // Hooks can inject blocking errors or veto continuation entirely.
        {
            let hook_result = fire_post_sampling_hooks(&assistant_msg, &tool_ctx.config);
            if !hook_result.blocking_errors.is_empty() {
                if hook_result.prevent_continuation {
                    let hook_reason = hook_result
                        .blocking_errors
                        .iter()
                        .map(Message::get_all_text)
                        .collect::<Vec<_>>()
                        .join("\n");
                    if let Some(ref tx) = event_tx {
                        let _ = tx.send(QueryEvent::Status(
                            "PostModelTurn hook vetoed continuation.".to_string(),
                        ));
                    }
                    finalize_terminal_assistant_with_unexecuted_tool_results(
                        messages,
                        &mut assistant_msg,
                        shadow_snap.as_ref(),
                        initial_snapshot.as_deref(),
                        event_tx.as_ref(),
                        "post-model hook vetoed continuation",
                    )
                    .await;
                    for err_msg in hook_result.blocking_errors {
                        messages.push(err_msg);
                    }
                    return QueryOutcome::Error(ClaudeError::Api(format!(
                        "PostModelTurn hook vetoed continuation: {}",
                        hook_reason
                    )));
                }
                // Soft errors: inject them so the model can react next turn.
                for err_msg in hook_result.blocking_errors {
                    debug!("PostModelTurn hook injecting error message");
                    messages.push(err_msg);
                }
            }
        }

        // Emit token warning events when approaching context limits.
        // Thresholds mirror TypeScript autoCompact.ts: 80% → Warning, 95% → Critical.
        {
            let warning_state =
                compact::calculate_token_warning_state(usage.input_tokens, &config.model);
            if warning_state != compact::TokenWarningState::Ok {
                if let Some(ref tx) = event_tx {
                    let window = compact::context_window_for_model(&config.model);
                    let pct_used = usage.input_tokens as f64 / window as f64;
                    let _ = tx.send(QueryEvent::TokenWarning {
                        state: warning_state,
                        pct_used,
                    });
                }
            }
        }

        require_goal_work!(assistant_msg);

        // Auto-compact: if context is near-full, summarise older messages now
        // (before the next turn's API call would fail with prompt-too-long).
        //
        // Reactive compact (T1-1): when the CLAUDE_REACTIVE_COMPACT feature gate
        // is enabled, we replace the proactive auto-compact path with reactive
        // compact / context-collapse instead. This fires on every streaming turn
        // so it can act before a prompt-too-long error is returned by the API.
        //
        // Feature gate check: COVEN_CODE_FEATURE_REACTIVE_COMPACT=1
        let reactive_compact_enabled =
            claurst_core::feature_gates::is_feature_enabled("reactive_compact");

        if reactive_compact_enabled {
            // Reactive path: emergency collapse takes priority over normal compact.
            let context_limit = compact::context_window_for_model(&config.model);
            if compact::should_context_collapse(usage.input_tokens, context_limit) {
                if let Some(ref tx) = event_tx {
                    let _ = tx.send(QueryEvent::Status(
                        "Compacting context... (emergency collapse)".to_string(),
                    ));
                }
                let original_messages = std::mem::take(messages);
                let collapse_result = {
                    let collapse =
                        compact::context_collapse(original_messages.clone(), client, config);
                    tokio::pin!(collapse);
                    tokio::select! {
                        _ = cancel_token.cancelled() => None,
                        result = &mut collapse => Some(result),
                    }
                };
                match collapse_result {
                    None => {
                        warn!("Context-collapse was cancelled");
                        *messages = original_messages;
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "context compaction was cancelled",
                        )
                        .await;
                        return QueryOutcome::Cancelled;
                    }
                    Some(Ok(result)) => {
                        if tool_ctx
                            .goal_turn
                            .require_work(&tool_ctx.session_id)
                            .is_err()
                        {
                            *messages = original_messages;
                            require_goal_work!(assistant_msg);
                        }
                        *messages = result.messages;
                        info!(
                            tokens_freed = result.tokens_freed,
                            "Context-collapse complete"
                        );
                    }
                    Some(Err(e)) => {
                        warn!(error = %e, "Context-collapse failed");
                        *messages = original_messages;
                        require_goal_work!(assistant_msg);
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "context compaction failed",
                        )
                        .await;
                        return QueryOutcome::Error(e);
                    }
                }
            } else if compact::should_compact(usage.input_tokens, context_limit) {
                if let Some(ref tx) = event_tx {
                    let _ = tx.send(QueryEvent::Status("Compacting context...".to_string()));
                }
                let original_messages = std::mem::take(messages);
                match compact::reactive_compact(
                    original_messages.clone(),
                    client,
                    config,
                    cancel_token.clone(),
                    &[],
                )
                .await
                {
                    Ok(result) => {
                        if tool_ctx
                            .goal_turn
                            .require_work(&tool_ctx.session_id)
                            .is_err()
                        {
                            *messages = original_messages;
                            require_goal_work!(assistant_msg);
                        }
                        *messages = result.messages;
                        info!(
                            tokens_freed = result.tokens_freed,
                            "Reactive compact complete"
                        );
                    }
                    Err(claurst_core::error::ClaudeError::Cancelled) => {
                        warn!("Reactive compact was cancelled");
                        *messages = original_messages;
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "context compaction was cancelled",
                        )
                        .await;
                        return QueryOutcome::Cancelled;
                    }
                    Err(e) => {
                        warn!(error = %e, "Reactive compact failed");
                        *messages = original_messages;
                        require_goal_work!(assistant_msg);
                        finalize_terminal_assistant_with_unexecuted_tool_results(
                            messages,
                            &mut assistant_msg,
                            shadow_snap.as_ref(),
                            initial_snapshot.as_deref(),
                            event_tx.as_ref(),
                            "context compaction failed",
                        )
                        .await;
                        return QueryOutcome::Error(e);
                    }
                }
            }
        } else if stop == "end_turn" || stop == "tool_use" {
            // Proactive auto-compact (original path, used when reactive compact is off).
            let compaction_required =
                compact::should_auto_compact(usage.input_tokens, &config.model, &compact_state);
            let original_messages = messages.clone();
            let compaction_result = {
                let compaction = compact::auto_compact_if_needed(
                    client,
                    &original_messages,
                    usage.input_tokens,
                    &config.model,
                    &mut compact_state,
                );
                tokio::pin!(compaction);
                tokio::select! {
                    _ = cancel_token.cancelled() => None,
                    result = &mut compaction => Some(result),
                }
            };
            match compaction_result {
                None => {
                    *messages = original_messages;
                    finalize_terminal_assistant_with_unexecuted_tool_results(
                        messages,
                        &mut assistant_msg,
                        shadow_snap.as_ref(),
                        initial_snapshot.as_deref(),
                        event_tx.as_ref(),
                        "context compaction was cancelled",
                    )
                    .await;
                    return QueryOutcome::Cancelled;
                }
                Some(Some(new_messages)) => {
                    require_goal_work!(assistant_msg);
                    *messages = new_messages;
                    if let Some(ref tx) = event_tx {
                        let _ = tx.send(QueryEvent::Status(
                            "Context compacted to stay within limits.".to_string(),
                        ));
                    }
                }
                Some(None) if compaction_required => {
                    *messages = original_messages;
                    require_goal_work!(assistant_msg);
                    finalize_terminal_assistant_with_unexecuted_tool_results(
                        messages,
                        &mut assistant_msg,
                        shadow_snap.as_ref(),
                        initial_snapshot.as_deref(),
                        event_tx.as_ref(),
                        "context compaction failed",
                    )
                    .await;
                    return QueryOutcome::Error(ClaudeError::Other(
                        "Auto-compaction failed after a completed response".to_string(),
                    ));
                }
                Some(None) => {}
            }
        }

        require_goal_work!(assistant_msg);

        // Announce-then-stop stall detection (issue #165): an `end_turn`
        // round with no tool calls whose text is empty or closes on an
        // imminent-action announcement gets a bounded continuation nudge
        // instead of ending the turn. Decided before TurnComplete emission
        // so recovered rounds stay invisible, like max_tokens recovery.
        let stalled_announcement = stop == "end_turn"
            && stall_recovery_enabled()
            && assistant_msg.get_tool_use_blocks().is_empty()
            && is_stalled_announcement(&assistant_msg.get_all_text());
        let stall_recovery_pending =
            stalled_announcement && stall_recovery_count < STALL_RECOVERY_LIMIT;
        let stall_recovery_exhausted =
            stalled_announcement && stall_recovery_count >= STALL_RECOVERY_LIMIT;

        // Helper closure for firing the Stop hook.
        macro_rules! fire_stop_hook {
            ($msg:expr) => {{
                require_goal_work!($msg);
                let stop_ctx = claurst_core::hooks::HookContext {
                    event: "Stop".to_string(),
                    tool_name: None,
                    tool_input: None,
                    tool_output: Some($msg.get_all_text()),
                    is_error: None,
                    session_id: Some(tool_ctx.session_id.clone()),
                };
                claurst_core::hooks::run_hooks(
                    &tool_ctx.config.hooks,
                    claurst_core::config::HookEvent::Stop,
                    &stop_ctx,
                    &tool_ctx.working_dir,
                )
                .await;
                require_goal_work!($msg);
            }};
        }

        match stop {
            "end_turn" => {
                if stall_recovery_pending {
                    stall_recovery_count += 1;
                    warn!(
                        attempt = stall_recovery_count,
                        limit = STALL_RECOVERY_LIMIT,
                        "end_turn with announced-but-unexecuted work — injecting continuation nudge"
                    );
                    if let Some(ref tx) = event_tx {
                        let _ = tx.send(QueryEvent::Status(format!(
                            "Model announced work but ended the turn — nudging it to continue \
                             (attempt {}/{})",
                            stall_recovery_count, STALL_RECOVERY_LIMIT
                        )));
                    }
                    // The stalled assistant message is already in the history,
                    // so the nudge reads in context. Stop hooks are not fired:
                    // the turn is not over.
                    sync_finalized_assistant_message(messages, &assistant_msg);
                    if sampled_attempt_has_material(&assistant_msg) {
                        emit_durable_message(event_tx.as_ref(), &assistant_msg);
                    } else {
                        messages.retain(|message| message.uuid != assistant_msg.uuid);
                    }
                    messages.push(Message::user(STALL_RECOVERY_MSG));
                    continue;
                }

                fire_stop_hook!(assistant_msg);

                // T1-3: Fire Stop hooks in background (fire-and-forget).
                // `stop_hooks_with_full_behavior` spawns blocking tasks internally
                // and returns immediately with an empty Vec.
                let _bg = stop_hooks_with_full_behavior(
                    &assistant_msg,
                    &tool_ctx.config,
                    tool_ctx.working_dir.clone(),
                    tool_ctx.goal_turn.for_background_work().captured().cloned(),
                );

                // Asynchronously extract and persist session memories if warranted.
                // Runs in a detached Tokio task so it doesn't block the query loop.
                if session_memory::SessionMemoryExtractor::should_extract(messages) {
                    let model_clone = config.model.clone();
                    let messages_clone = messages.clone();
                    let working_dir_clone = tool_ctx.working_dir.clone();
                    let runtime_mode = tool_ctx.config.runtime_mode();
                    let hosted_review_config = tool_ctx.config.hosted_review.clone();
                    let session_id_clone = tool_ctx.session_id.clone();

                    // Build a fresh client using the same API key.  This avoids
                    // requiring an Arc in the existing run_query_loop signature.
                    if let Ok(api_key) = std::env::var("ANTHROPIC_API_KEY") {
                        if !api_key.is_empty() {
                            if let Ok(sm_client) = claurst_api::AnthropicClient::new(
                                claurst_api::client::ClientConfig {
                                    api_key,
                                    ..Default::default()
                                },
                            ) {
                                let background_goal = tool_ctx.goal_turn.for_background_work();
                                let sm_client = match background_goal.captured() {
                                    Some(turn) => {
                                        sm_client.for_goal_turn(turn, GoalTurnPermission::Work)
                                    }
                                    None => sm_client,
                                };
                                let sm_client = std::sync::Arc::new(sm_client);
                                tokio::spawn(async move {
                                    if background_goal.require_work(&session_id_clone).is_err() {
                                        return;
                                    }
                                    let memory_provenance = build_session_memory_provenance(
                                        &session_id_clone,
                                        &working_dir_clone,
                                    );
                                    let extractor =
                                        session_memory::SessionMemoryExtractor::new(&model_clone);
                                    match extractor
                                        .extract(&messages_clone, &working_dir_clone, &sm_client)
                                        .await
                                    {
                                        Ok(memories) if !memories.is_empty() => {
                                            if background_goal
                                                .require_work(&session_id_clone)
                                                .is_err()
                                            {
                                                return;
                                            }
                                            let target = working_dir_clone
                                                .join(".coven-code")
                                                .join("AGENTS.md");
                                            let candidate_store =
                                                session_memory::MemoryCandidateStore::for_working_dir(
                                                    &working_dir_clone,
                                                );
                                            if let Err(e) = session_memory::SessionMemoryExtractor::persist_with_policy(
                                                &memories,
                                                &target,
                                                &candidate_store,
                                                runtime_mode,
                                                &hosted_review_config,
                                                &memory_provenance,
                                            )
                                            .await
                                            {
                                                tracing::warn!(
                                                    error = %e,
                                                    "Failed to store session memories"
                                                );
                                            }
                                        }
                                        Ok(_) => {} // no memories extracted
                                        Err(e) => {
                                            tracing::debug!(
                                                error = %e,
                                                "Session memory extraction failed (non-fatal)"
                                            );
                                        }
                                    }
                                });
                            }
                        }
                    }
                }

                // Trigger AutoDream consolidation check (non-blocking, best-effort).
                // maybe_trigger() checks gates + acquires lock. If it returns
                // Some(task), we spawn a background subagent via AgentTool so
                // the spawn doesn't call run_query_loop recursively from within
                // its own future (which would make the future !Send).
                {
                    require_goal_work!(assistant_msg);
                    let memory_dir = claurst_core::config::config_home().join("memory");
                    let conversations_dir =
                        claurst_core::config::config_home().join("conversations");
                    {
                        let dreamer =
                            crate::auto_dream::AutoDream::new(memory_dir, conversations_dir);
                        if let Ok(Some(task)) = dreamer.maybe_trigger().await {
                            // Run the consolidation subagent in a background Tokio
                            // task. We use the AgentTool execute path (via
                            // poll_background_agent / BACKGROUND_AGENTS) to avoid
                            // re-entering run_query_loop from within the same
                            // future graph.
                            let agent_input = serde_json::json!({
                                "description": "memory consolidation",
                                "prompt": task.prompt,
                                "tools": ["Read", "Glob", "Grep"],
                                "max_turns": 20,
                                "system_prompt": "You are performing automatic read-only memory consolidation. Complete the task and return a brief summary with any suggested changes. Do not read transcripts, run commands, access the network, or modify files.",
                                "run_in_background": true,
                                "isolation": null
                            });
                            let mut ctx_for_dream = tool_ctx.clone();
                            ctx_for_dream.goal_turn = tool_ctx.goal_turn.for_background_work();
                            tokio::spawn(async move {
                                if ctx_for_dream
                                    .goal_turn
                                    .require_work(&ctx_for_dream.session_id)
                                    .is_err()
                                {
                                    let _ = tokio::fs::remove_file(&task.lock_file).await;
                                    return;
                                }
                                let agent = crate::agent_tool::AgentTool;
                                let _result = claurst_tools::Tool::execute(
                                    &agent,
                                    agent_input,
                                    &ctx_for_dream,
                                )
                                .await;
                                if ctx_for_dream
                                    .goal_turn
                                    .require_work(&ctx_for_dream.session_id)
                                    .is_ok()
                                {
                                    crate::auto_dream::AutoDream::finish_consolidation(&task).await;
                                } else {
                                    let _ = tokio::fs::remove_file(&task.lock_file).await;
                                }
                            });
                        }
                    }
                }

                require_goal_work!(assistant_msg);
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut assistant_msg,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "turn ended before tool execution",
                )
                .await;
                if !stall_recovery_exhausted
                    && should_emit_turn_complete(stop, max_tokens_recovery_count, false)
                {
                    emit_turn_complete(event_tx.as_ref(), turn, stop, &usage);
                }

                if stall_recovery_exhausted {
                    return QueryOutcome::Error(ClaudeError::Api(
                        "Model repeatedly ended without completing the turn".to_string(),
                    ));
                }
                return QueryOutcome::EndTurn {
                    message: assistant_msg,
                    usage,
                };
            }
            "max_tokens" => {
                // Mirror the TS recovery loop: inject a continuation nudge and
                // retry up to MAX_TOKENS_RECOVERY_LIMIT times before surfacing
                // the partial response as QueryOutcome::MaxTokens.
                if max_tokens_recovery_count < MAX_TOKENS_RECOVERY_LIMIT {
                    max_tokens_recovery_count += 1;
                    warn!(
                        attempt = max_tokens_recovery_count,
                        limit = MAX_TOKENS_RECOVERY_LIMIT,
                        "max_tokens hit — injecting continuation message (attempt {}/{})",
                        max_tokens_recovery_count,
                        MAX_TOKENS_RECOVERY_LIMIT,
                    );
                    if let Some(ref tx) = event_tx {
                        let _ = tx.send(QueryEvent::Status(format!(
                            "Output token limit hit — continuing (attempt {}/{})",
                            max_tokens_recovery_count, MAX_TOKENS_RECOVERY_LIMIT
                        )));
                    }
                    // Preserve sampled material for the continuation without
                    // manufacturing an empty durable assistant for a retry.
                    if sampled_attempt_has_material(&assistant_msg) {
                        let assistant_index =
                            sync_finalized_assistant_message(messages, &assistant_msg);
                        emit_durable_message(event_tx.as_ref(), &assistant_msg);
                        if let Some(tool_result_message) =
                            insert_unexecuted_tool_result_after_assistant(
                                messages,
                                assistant_index,
                                &assistant_msg,
                                "maximum output tokens were reached",
                            )
                        {
                            emit_durable_message(event_tx.as_ref(), &tool_result_message);
                        }
                    } else {
                        messages.retain(|message| message.uuid != assistant_msg.uuid);
                    }
                    messages.push(Message::user(MAX_TOKENS_RECOVERY_MSG));
                    continue;
                }
                // Recovery exhausted — surface the partial response.
                warn!(
                    "max_tokens recovery exhausted after {} attempts",
                    MAX_TOKENS_RECOVERY_LIMIT
                );
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut assistant_msg,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "maximum output tokens were reached",
                )
                .await;
                if should_emit_turn_complete(stop, max_tokens_recovery_count, false) {
                    emit_turn_complete(event_tx.as_ref(), turn, stop, &usage);
                }
                return QueryOutcome::MaxTokens {
                    partial_message: assistant_msg,
                    usage,
                };
            }
            "tool_use" => {
                // A completed tool-use turn counts as a successful recovery
                // boundary; reset the max_tokens retry counter.
                max_tokens_recovery_count = 0;
                // Real tool work happened, so any earlier announce-then-stop
                // stall resolved itself; give the next stall a fresh budget.
                stall_recovery_count = 0;
                // Extract tool calls and execute them
                let tool_blocks = assistant_msg.get_tool_use_blocks();
                if tool_blocks.is_empty() {
                    // Shouldn't happen but treat as end_turn
                    finalize_terminal_assistant_with_unexecuted_tool_results(
                        messages,
                        &mut assistant_msg,
                        shadow_snap.as_ref(),
                        initial_snapshot.as_deref(),
                        event_tx.as_ref(),
                        "turn ended before tool execution",
                    )
                    .await;
                    return QueryOutcome::Error(ClaudeError::Api(
                        "Provider returned tool_use without tool blocks".to_string(),
                    ));
                }

                let tool_invocations: Vec<_> = tool_blocks
                    .into_iter()
                    .filter_map(|block| {
                        if let ContentBlock::ToolUse { id, name, input } = block {
                            Some((id.clone(), name.clone(), input.clone()))
                        } else {
                            None
                        }
                    })
                    .collect();
                sync_finalized_assistant_message(messages, &assistant_msg);
                emit_durable_message(event_tx.as_ref(), &assistant_msg);
                let result_blocks = execute_tool_blocks_with_hooks(
                    tool_invocations,
                    tools,
                    tool_ctx,
                    event_tx.as_ref(),
                )
                .await;

                // Append tool results as a user message
                let tool_result_message = Message::user_blocks(result_blocks);
                messages.push(tool_result_message.clone());
                emit_durable_message(event_tx.as_ref(), &tool_result_message);

                // Continue the loop to send results back to the model
                continue;
            }
            "stop_sequence" => {
                fire_stop_hook!(assistant_msg);
                let _bg = stop_hooks_with_full_behavior(
                    &assistant_msg,
                    &tool_ctx.config,
                    tool_ctx.working_dir.clone(),
                    tool_ctx.goal_turn.for_background_work().captured().cloned(),
                );
                require_goal_work!(assistant_msg);
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut assistant_msg,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "turn ended before tool execution",
                )
                .await;
                if should_emit_turn_complete(stop, max_tokens_recovery_count, false) {
                    emit_turn_complete(event_tx.as_ref(), turn, stop, &usage);
                }
                return QueryOutcome::EndTurn {
                    message: assistant_msg,
                    usage,
                };
            }
            "content_filtered" => {
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut assistant_msg,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "content was filtered",
                )
                .await;
                if should_emit_turn_complete(stop, max_tokens_recovery_count, false) {
                    emit_turn_complete(event_tx.as_ref(), turn, stop, &usage);
                }
                return QueryOutcome::Error(ClaudeError::Api(
                    "Provider content filter blocked the response".to_string(),
                ));
            }
            other => {
                warn!(stop_reason = other, "Unknown stop reason");
                fire_stop_hook!(assistant_msg);
                let _bg = stop_hooks_with_full_behavior(
                    &assistant_msg,
                    &tool_ctx.config,
                    tool_ctx.working_dir.clone(),
                    tool_ctx.goal_turn.for_background_work().captured().cloned(),
                );
                finalize_terminal_assistant_with_unexecuted_tool_results(
                    messages,
                    &mut assistant_msg,
                    shadow_snap.as_ref(),
                    initial_snapshot.as_deref(),
                    event_tx.as_ref(),
                    "provider returned an unknown stop reason",
                )
                .await;
                if should_emit_turn_complete(stop, max_tokens_recovery_count, false) {
                    emit_turn_complete(event_tx.as_ref(), turn, stop, &usage);
                }
                return QueryOutcome::Error(ClaudeError::Api(format!(
                    "Provider returned unsupported stop reason '{other}'"
                )));
            }
        }
    }
}

struct PreparedTool {
    id: String,
    name: String,
    input: Value,
    blocked_result: Option<ToolResult>,
}

/// Execute tool invocations through the common policy-aware tool path.
async fn execute_tool_blocks_with_hooks(
    tool_blocks: Vec<(String, String, Value)>,
    tools: &[Box<dyn Tool>],
    tool_ctx: &ToolContext,
    event_tx: Option<&mpsc::UnboundedSender<QueryEvent>>,
) -> Vec<ContentBlock> {
    // Phase 1: Run PreToolUse hooks sequentially so policy denials can block
    // execution before any tool side effects occur.
    let mut prepared: Vec<PreparedTool> = Vec::with_capacity(tool_blocks.len());
    for (id, name, input) in tool_blocks {
        if let Err(error) = tool_ctx.goal_turn.require_work(&tool_ctx.session_id) {
            prepared.push(PreparedTool {
                id,
                name,
                input,
                blocked_result: Some(ToolResult::error(format!(
                    "Goal authority denied tool: {error}"
                ))),
            });
            continue;
        }
        if let Some(tx) = event_tx {
            let _ = tx.send(QueryEvent::ToolStart {
                tool_name: name.clone(),
                tool_id: id.clone(),
                input_json: input.to_string(),
            });
        }

        let hook_ctx = claurst_core::hooks::HookContext {
            event: "PreToolUse".to_string(),
            tool_name: Some(name.clone()),
            tool_input: Some(input.clone()),
            tool_output: None,
            is_error: None,
            session_id: Some(tool_ctx.session_id.clone()),
        };
        let pre_outcome = claurst_core::hooks::run_hooks(
            &tool_ctx.config.hooks,
            claurst_core::config::HookEvent::PreToolUse,
            &hook_ctx,
            &tool_ctx.working_dir,
        )
        .await;

        if let Err(error) = tool_ctx.goal_turn.require_work(&tool_ctx.session_id) {
            prepared.push(PreparedTool {
                id,
                name,
                input,
                blocked_result: Some(ToolResult::error(format!(
                    "Goal authority denied tool: {error}"
                ))),
            });
            continue;
        }
        let plugin_pre_outcome =
            claurst_plugins::run_global_pre_tool_hook(&name, &input, &tool_ctx.working_dir);

        let blocked_result = if let claurst_core::hooks::HookOutcome::Blocked(reason) = pre_outcome
        {
            warn!(tool = %name, reason = %reason, "PreToolUse hook blocked execution");
            Some(claurst_tools::ToolResult::error(format!(
                "Blocked by hook: {}",
                reason
            )))
        } else if let claurst_plugins::HookOutcome::Deny(reason) = plugin_pre_outcome {
            warn!(tool = %name, reason = %reason, "Plugin PreToolUse hook blocked execution");
            Some(claurst_tools::ToolResult::error(format!(
                "Blocked by plugin hook: {}",
                reason
            )))
        } else {
            None
        };

        prepared.push(PreparedTool {
            id,
            name,
            input,
            blocked_result,
        });
    }

    // Phase 2: execute non-blocked tools concurrently, except that tools which
    // write take turns in the order requested. Each reads its target and writes
    // it back, so two at once would start from the same content and one change
    // would vanish while both report success.
    //
    // Request order rests on two things: tokio's Mutex grants the lock in the
    // order tasks first wait for it, and `join_all` first polls its futures in
    // the order given, so each writer starts waiting in request order.
    let writer_turn = tokio::sync::Mutex::new(());
    let writer_turn = &writer_turn;
    let exec_futures: Vec<_> = prepared
        .iter()
        .map(|p| {
            if let Some(result) = p.blocked_result.clone() {
                futures::future::Either::Left(async move { result })
            } else {
                let name = p.name.clone();
                let input = p.input.clone();
                let call_id = p.id.clone();
                let writes = tools.iter().any(|tool| {
                    tool.name() == name
                        && tool.permission_level() == claurst_tools::PermissionLevel::Write
                });
                futures::future::Either::Right(claurst_tools::with_tool_call(call_id, async move {
                    let _turn = if writes {
                        Some(writer_turn.lock().await)
                    } else {
                        None
                    };
                    execute_tool(&name, &input, tools, tool_ctx).await
                }))
            }
        })
        .collect();
    let exec_results: Vec<ToolResult> = futures::future::join_all(exec_futures).await;

    // Phase 3: run post-hooks, emit completion events, and return result blocks.
    let mut result_blocks: Vec<ContentBlock> = Vec::with_capacity(prepared.len());
    for (p, result) in prepared.iter().zip(exec_results) {
        let post_ctx = claurst_core::hooks::HookContext {
            event: "PostToolUse".to_string(),
            tool_name: Some(p.name.clone()),
            tool_input: Some(p.input.clone()),
            tool_output: Some(result.content.clone()),
            is_error: Some(result.is_error),
            session_id: Some(tool_ctx.session_id.clone()),
        };
        if tool_ctx
            .goal_turn
            .require_work(&tool_ctx.session_id)
            .is_ok()
        {
            claurst_core::hooks::run_hooks(
                &tool_ctx.config.hooks,
                claurst_core::config::HookEvent::PostToolUse,
                &post_ctx,
                &tool_ctx.working_dir,
            )
            .await;

            if tool_ctx
                .goal_turn
                .require_work(&tool_ctx.session_id)
                .is_ok()
            {
                claurst_plugins::run_global_post_tool_hook(
                    &p.name,
                    &p.input,
                    &result.content,
                    result.is_error,
                    &tool_ctx.working_dir,
                );
            }
        }

        if let Some(tx) = event_tx {
            let _ = tx.send(QueryEvent::ToolEnd {
                tool_name: p.name.clone(),
                tool_id: p.id.clone(),
                result: result.content.clone(),
                is_error: result.is_error,
            });
        }

        result_blocks.push(ContentBlock::ToolResult {
            tool_use_id: p.id.clone(),
            content: ToolResultContent::Text(result.content),
            is_error: if result.is_error { Some(true) } else { None },
        });
    }

    result_blocks
}

/// Execute a single tool invocation.
async fn execute_tool(
    name: &str,
    input: &Value,
    tools: &[Box<dyn Tool>],
    ctx: &ToolContext,
) -> ToolResult {
    if let Err(error) = ctx.goal_turn.require_work(&ctx.session_id) {
        return ToolResult::error(format!("Goal authority denied tool: {error}"));
    }
    let tool = tools.iter().find(|t| t.name() == name);

    match tool {
        Some(tool) => {
            debug!(tool = name, "Executing tool");
            tool.execute(input.clone(), ctx).await
        }
        None => {
            warn!(tool = name, "Unknown tool requested");
            ToolResult::error(format!("Unknown tool: {}", name))
        }
    }
}

/// Load persisted todos for `session_id` and return a nudge string if any are
/// incomplete (status != "completed"). Returns empty string otherwise.
fn build_todo_nudge(session_id: &str) -> String {
    let todos = claurst_tools::todo_write::load_todos(session_id);
    let incomplete_count = todos
        .iter()
        .filter(|t| t["status"].as_str() != Some("completed"))
        .count();
    if incomplete_count == 0 {
        String::new()
    } else {
        format!(
            "You have {} incomplete task{} in your TodoWrite list. \
             Make sure to complete all tasks before ending your response.",
            incomplete_count,
            if incomplete_count == 1 { "" } else { "s" }
        )
    }
}

/// Build the system prompt from config.
///
/// Delegates to `claurst_core::system_prompt::build_system_prompt` so that all
/// default content (capabilities, safety guidelines, dynamic-boundary marker,
/// etc.) is assembled in one place.  The `QueryConfig` fields map directly to
/// `SystemPromptOptions`:
///
/// - `system_prompt`        → `custom_system_prompt` (added to cacheable block)
/// - `append_system_prompt` → `append_system_prompt` (added after boundary)
fn build_system_prompt(config: &QueryConfig) -> SystemPrompt {
    use claurst_core::system_prompt::SystemPromptOptions;

    let opts = SystemPromptOptions {
        custom_system_prompt: config.system_prompt.clone(),
        append_system_prompt: config.append_system_prompt.clone(),
        // All other fields use sensible defaults:
        // - prefix:                auto-detect from env
        // - memory_content:        empty (callers inject via append if needed)
        // - replace_system_prompt: false (additive mode)
        // - coordinator_mode:      false
        output_style: config.output_style,
        custom_output_style_prompt: config.output_style_prompt.clone(),
        working_directory: config.working_directory.clone(),
        ..Default::default()
    };

    let text = claurst_core::system_prompt::build_system_prompt(&opts);
    SystemPrompt::Text(text)
}

// ---------------------------------------------------------------------------
// Provider stream event mapping
// ---------------------------------------------------------------------------

/// Map a unified `StreamEvent` (from a non-Anthropic provider) onto the
/// equivalent `AnthropicStreamEvent` so that the TUI stream consumer sees a
/// single, consistent event type regardless of which provider produced it.
fn map_to_anthropic_event(
    evt: &claurst_api::StreamEvent,
) -> Option<claurst_api::AnthropicStreamEvent> {
    use claurst_api::streaming::{AnthropicStreamEvent, ContentDelta};
    use claurst_api::StreamEvent;

    match evt {
        StreamEvent::MessageStart { id, model, usage } => {
            Some(AnthropicStreamEvent::MessageStart {
                id: id.clone(),
                model: model.clone(),
                usage: usage.clone(),
            })
        }
        StreamEvent::ContentBlockStart {
            index,
            content_block,
        } => Some(AnthropicStreamEvent::ContentBlockStart {
            index: *index,
            content_block: content_block.clone(),
        }),
        StreamEvent::TextDelta { index, text } => Some(AnthropicStreamEvent::ContentBlockDelta {
            index: *index,
            delta: ContentDelta::TextDelta { text: text.clone() },
        }),
        StreamEvent::ThinkingDelta { index, thinking } => {
            Some(AnthropicStreamEvent::ContentBlockDelta {
                index: *index,
                delta: ContentDelta::ThinkingDelta {
                    thinking: thinking.clone(),
                },
            })
        }
        StreamEvent::ReasoningDelta { index, reasoning } => {
            Some(AnthropicStreamEvent::ContentBlockDelta {
                index: *index,
                delta: ContentDelta::ThinkingDelta {
                    thinking: reasoning.clone(),
                },
            })
        }
        StreamEvent::InputJsonDelta {
            index,
            partial_json,
        } => Some(AnthropicStreamEvent::ContentBlockDelta {
            index: *index,
            delta: ContentDelta::InputJsonDelta {
                partial_json: partial_json.clone(),
            },
        }),
        StreamEvent::SignatureDelta { index, signature } => {
            Some(AnthropicStreamEvent::ContentBlockDelta {
                index: *index,
                delta: ContentDelta::SignatureDelta {
                    signature: signature.clone(),
                },
            })
        }
        StreamEvent::ContentBlockStop { index } => {
            Some(AnthropicStreamEvent::ContentBlockStop { index: *index })
        }
        StreamEvent::MessageDelta { stop_reason, usage } => {
            // Convert the unified StopReason to the string form used by
            // AnthropicStreamEvent::MessageDelta.
            let stop_reason_str = stop_reason.as_ref().map(|r| match r {
                claurst_api::provider_types::StopReason::ToolUse => "tool_use".to_string(),
                claurst_api::provider_types::StopReason::MaxTokens => "max_tokens".to_string(),
                claurst_api::provider_types::StopReason::StopSequence => {
                    "stop_sequence".to_string()
                }
                claurst_api::provider_types::StopReason::EndTurn => "end_turn".to_string(),
                claurst_api::provider_types::StopReason::ContentFiltered => {
                    "content_filtered".to_string()
                }
                claurst_api::provider_types::StopReason::Other(s) => s.clone(),
            });
            Some(AnthropicStreamEvent::MessageDelta {
                stop_reason: stop_reason_str,
                usage: usage.clone(),
            })
        }
        StreamEvent::MessageStop => Some(AnthropicStreamEvent::MessageStop),
        // The consumer already reset its stall deadline before mapping this event.
        StreamEvent::Ping => None,
        StreamEvent::Error {
            error_type,
            message,
        } => Some(AnthropicStreamEvent::Error {
            error_type: error_type.clone(),
            message: message.clone(),
        }),
    }
}

// ---------------------------------------------------------------------------
// Single-shot query (non-looping, for simple one-off calls)
// ---------------------------------------------------------------------------

/// Run a single (non-agentic) query – no tool loop, just one API call.
pub async fn run_single_query(
    client: &claurst_api::AnthropicClient,
    messages: Vec<Message>,
    config: &QueryConfig,
) -> Result<Message, ClaudeError> {
    let api_messages: Vec<ApiMessage> = messages.iter().map(ApiMessage::from).collect();
    let system = build_system_prompt(config);

    let request = CreateMessageRequest::builder(&config.model, config.max_tokens)
        .messages(api_messages)
        .system(system)
        .build();

    let handler: Arc<dyn StreamHandler> = Arc::new(claurst_api::streaming::NullStreamHandler);

    let mut rx = client.create_message_stream(request, handler).await?;
    let mut acc = StreamAccumulator::new();

    while let Some(evt) = rx.recv().await {
        acc.on_event(&evt);
        if matches!(evt, AnthropicStreamEvent::MessageStop) {
            break;
        }
    }

    let (msg, _usage, _stop) = acc.finish();
    Ok(msg)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    include!("goal_completion_tests.rs");
    use std::collections::{HashSet, VecDeque};
    use std::pin::Pin;
    use std::process::Command;
    use std::sync::{Arc, Mutex};

    use super::*;
    use async_trait::async_trait;
    use claurst_api::provider_types::{
        ProviderCapabilities, ProviderRequest, ProviderResponse, ProviderStatus,
        StopReason as ProviderStopReason, StreamEvent, SystemPromptStyle,
    };
    use claurst_api::{LlmProvider, ModelInfo, ProviderError, SystemPrompt};
    use claurst_core::config::{Config, HookEntry, HookEvent, PermissionMode};
    use claurst_core::permissions::AutoPermissionHandler;
    use claurst_core::provider_id::ProviderId;
    use claurst_core::types::{MessageContent, Role};
    use claurst_tools::{PermissionLevel, ToolResult};
    use futures::{Stream, StreamExt};

    const SCRIPTED_PROVIDER_ID: &str = "scripted-goal-journal";
    static REACTIVE_COMPACT_FEATURE_GATE_LOCK: tokio::sync::Mutex<()> =
        tokio::sync::Mutex::const_new(());

    type ScriptedProviderEvent = Result<StreamEvent, ProviderError>;
    type ScriptedEventSender = mpsc::Sender<ScriptedProviderEvent>;
    type QueuedScriptedEvents = (ScriptedEventSender, Vec<StreamEvent>);

    struct ScriptedProvider {
        id: ProviderId,
        rounds: Mutex<VecDeque<ScriptedRound>>,
    }

    enum ScriptedRound {
        Events(Vec<ScriptedProviderEvent>),
        PendingAfter(Vec<ScriptedProviderEvent>),
        ChannelAfter(
            Vec<ScriptedProviderEvent>,
            mpsc::Receiver<ScriptedProviderEvent>,
        ),
    }

    impl ScriptedProvider {
        fn new(rounds: Vec<Vec<StreamEvent>>) -> Self {
            Self {
                id: ProviderId::new(SCRIPTED_PROVIDER_ID),
                rounds: Mutex::new(
                    rounds
                        .into_iter()
                        .map(|round| ScriptedRound::Events(round.into_iter().map(Ok).collect()))
                        .collect(),
                ),
            }
        }

        fn with_results(rounds: Vec<Vec<ScriptedProviderEvent>>) -> Self {
            Self {
                id: ProviderId::new(SCRIPTED_PROVIDER_ID),
                rounds: Mutex::new(rounds.into_iter().map(ScriptedRound::Events).collect()),
            }
        }

        fn partial_then_pending(events: Vec<StreamEvent>) -> Self {
            Self {
                id: ProviderId::new(SCRIPTED_PROVIDER_ID),
                rounds: Mutex::new(
                    vec![ScriptedRound::PendingAfter(
                        events.into_iter().map(Ok).collect(),
                    )]
                    .into(),
                ),
            }
        }

        fn partial_then_success(
            partial_events: Vec<StreamEvent>,
            success_events: Vec<StreamEvent>,
        ) -> Self {
            Self {
                id: ProviderId::new(SCRIPTED_PROVIDER_ID),
                rounds: Mutex::new(
                    vec![
                        ScriptedRound::PendingAfter(partial_events.into_iter().map(Ok).collect()),
                        ScriptedRound::Events(success_events.into_iter().map(Ok).collect()),
                    ]
                    .into(),
                ),
            }
        }

        fn channel_after(initial_events: Vec<StreamEvent>) -> (Self, ScriptedEventSender) {
            let (sender, receiver) = mpsc::channel(32);
            (
                Self {
                    id: ProviderId::new(SCRIPTED_PROVIDER_ID),
                    rounds: Mutex::new(
                        vec![ScriptedRound::ChannelAfter(
                            initial_events.into_iter().map(Ok).collect(),
                            receiver,
                        )]
                        .into(),
                    ),
                },
                sender,
            )
        }
    }

    #[async_trait]
    impl LlmProvider for ScriptedProvider {
        fn id(&self) -> &ProviderId {
            &self.id
        }

        fn name(&self) -> &str {
            "Scripted goal journal provider"
        }

        async fn create_message(
            &self,
            _request: ProviderRequest,
        ) -> Result<ProviderResponse, ProviderError> {
            Ok(ProviderResponse {
                id: "unused".to_string(),
                content: Vec::new(),
                stop_reason: ProviderStopReason::EndTurn,
                usage: UsageInfo::default(),
                model: "scripted".to_string(),
            })
        }

        async fn create_message_stream(
            &self,
            _request: ProviderRequest,
        ) -> Result<
            Pin<Box<dyn Stream<Item = Result<StreamEvent, ProviderError>> + Send>>,
            ProviderError,
        > {
            let round = self
                .rounds
                .lock()
                .unwrap()
                .pop_front()
                .expect("scripted provider ran out of rounds");
            let stream: Pin<Box<dyn Stream<Item = Result<StreamEvent, ProviderError>> + Send>> =
                match round {
                    ScriptedRound::Events(events) => Box::pin(futures::stream::iter(events)),
                    ScriptedRound::PendingAfter(events) => {
                        Box::pin(futures::stream::iter(events).chain(futures::stream::pending()))
                    }
                    ScriptedRound::ChannelAfter(events, receiver) => {
                        let queued_events =
                            futures::stream::unfold(receiver, |mut receiver| async {
                                receiver.recv().await.map(|event| (event, receiver))
                            });
                        Box::pin(futures::stream::iter(events).chain(queued_events))
                    }
                };
            Ok(stream)
        }

        async fn list_models(&self) -> Result<Vec<ModelInfo>, ProviderError> {
            Ok(Vec::new())
        }

        async fn health_check(&self) -> Result<ProviderStatus, ProviderError> {
            Ok(ProviderStatus::Healthy)
        }

        fn capabilities(&self) -> ProviderCapabilities {
            ProviderCapabilities {
                streaming: true,
                tool_calling: true,
                thinking: false,
                image_input: false,
                pdf_input: false,
                audio_input: false,
                video_input: false,
                caching: false,
                structured_output: false,
                system_prompt_style: SystemPromptStyle::TopLevel,
            }
        }
    }

    struct WriteFixtureTool;

    #[async_trait]
    impl Tool for WriteFixtureTool {
        fn name(&self) -> &str {
            "WriteFixture"
        }

        fn description(&self) -> &str {
            "Writes the durable-message journal test fixture"
        }

        fn permission_level(&self) -> PermissionLevel {
            PermissionLevel::None
        }

        fn input_schema(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        async fn execute(&self, _input: Value, ctx: &ToolContext) -> ToolResult {
            match tokio::fs::write(ctx.working_dir.join("fixture.txt"), "written\n").await {
                Ok(()) => ToolResult::success("wrote fixture.txt"),
                Err(error) => ToolResult::error(error.to_string()),
            }
        }
    }

    fn scripted_round(
        id: &str,
        blocks: Vec<ContentBlock>,
        stop_reason: ProviderStopReason,
    ) -> Vec<StreamEvent> {
        let mut events = vec![StreamEvent::MessageStart {
            id: id.to_string(),
            model: "scripted".to_string(),
            usage: UsageInfo {
                input_tokens: 1,
                ..UsageInfo::default()
            },
        }];
        for (index, block) in blocks.into_iter().enumerate() {
            let start_block = match &block {
                ContentBlock::Text { .. } => ContentBlock::Text {
                    text: String::new(),
                },
                ContentBlock::ToolUse { id, name, .. } => ContentBlock::ToolUse {
                    id: id.clone(),
                    name: name.clone(),
                    input: serde_json::json!({}),
                },
                _ => block.clone(),
            };
            events.push(StreamEvent::ContentBlockStart {
                index,
                content_block: start_block,
            });
            match block {
                ContentBlock::Text { text } => {
                    events.push(StreamEvent::TextDelta { index, text });
                }
                ContentBlock::ToolUse { input, .. } => {
                    events.push(StreamEvent::InputJsonDelta {
                        index,
                        partial_json: input.to_string(),
                    });
                }
                _ => {}
            }
            events.push(StreamEvent::ContentBlockStop { index });
        }
        events.extend([
            StreamEvent::MessageDelta {
                stop_reason: Some(stop_reason),
                usage: Some(UsageInfo {
                    output_tokens: 1,
                    ..UsageInfo::default()
                }),
            },
            StreamEvent::MessageStop,
        ]);
        events
    }

    fn init_test_repository(path: &std::path::Path) {
        let run = |args: &[&str]| {
            let output = Command::new("git")
                .args(args)
                .current_dir(path)
                .output()
                .unwrap();
            assert!(
                output.status.success(),
                "git {args:?} failed: {}",
                String::from_utf8_lossy(&output.stderr)
            );
        };
        run(&["init", "-b", "main"]);
        run(&["config", "user.email", "test@example.invalid"]);
        run(&["config", "user.name", "Test"]);
        std::fs::write(path.join("seed.txt"), "seed\n").unwrap();
        run(&["add", "seed.txt"]);
        run(&["commit", "-m", "seed"]);
    }

    fn is_tool_result_carrier(message: &Message) -> bool {
        matches!(message.role, Role::User)
            && matches!(
                &message.content,
                MessageContent::Blocks(blocks)
                    if blocks.iter().any(|block| matches!(block, ContentBlock::ToolResult { .. }))
            )
    }

    fn assert_unexecuted_tool_result_is_durable_once(
        events: &[QueryEvent],
        messages: &[Message],
        tool_use_id: &str,
    ) {
        let assistant_event_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message }
                if message.get_tool_use_blocks().iter().any(|block| matches!(
                    block,
                    ContentBlock::ToolUse { id, .. } if id == tool_use_id
                )))
            })
            .expect("terminal assistant must be durable");
        let matching_result = |message: &Message| {
            matches!(
                &message.content,
                MessageContent::Blocks(blocks)
                    if message.role == Role::User
                        && blocks.len() == 1
                        && matches!(
                            &blocks[0],
                            ContentBlock::ToolResult {
                                tool_use_id: id,
                                content: ToolResultContent::Text(text),
                                is_error: Some(true),
                            } if id == tool_use_id && !text.is_empty()
                        )
            )
        };
        let result_event_indexes: Vec<_> = events
            .iter()
            .enumerate()
            .filter_map(|(index, event)| match event {
                QueryEvent::DurableMessage { message } if matching_result(message) => Some(index),
                _ => None,
            })
            .collect();
        assert_eq!(
            result_event_indexes.len(),
            1,
            "an unexecuted tool use needs exactly one durable error result"
        );
        assert!(
            assistant_event_index < result_event_indexes[0],
            "the assistant must be durable before its tool-result carrier"
        );
        assert_eq!(
            messages
                .iter()
                .filter(|message| matching_result(message))
                .count(),
            1,
            "the exact durable carrier must appear once in history"
        );
        let assistant_index = messages
            .iter()
            .position(|message| {
                message.get_tool_use_blocks().iter().any(|block| {
                    matches!(
                        block,
                        ContentBlock::ToolUse { id, .. } if id == tool_use_id
                    )
                })
            })
            .expect("terminal assistant must be in history");
        let result_index = messages
            .iter()
            .position(matching_result)
            .expect("tool-result carrier must be in history");
        assert!(
            assistant_index < result_index,
            "the assistant must precede its tool-result carrier in history"
        );
        assert!(
            events
                .iter()
                .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })),
            "non-successful terminal paths must not emit TurnComplete"
        );
    }

    fn unique_message_fingerprints(messages: &[Message]) -> HashSet<String> {
        messages
            .iter()
            .map(|message| serde_json::to_string(message).unwrap())
            .collect()
    }

    async fn run_scripted_provider(
        provider: ScriptedProvider,
    ) -> (QueryOutcome, Vec<QueryEvent>, Vec<Message>) {
        run_scripted_provider_with(
            provider,
            make_config(None, None),
            Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            &[],
        )
        .await
    }

    async fn run_scripted_provider_with(
        provider: ScriptedProvider,
        config: QueryConfig,
        tool_config: Config,
        tools: &[Box<dyn Tool>],
    ) -> (QueryOutcome, Vec<QueryEvent>, Vec<Message>) {
        let (outcome, events, messages, _) = run_scripted_provider_with_token(
            provider,
            config,
            tool_config,
            tools,
            tokio_util::sync::CancellationToken::new(),
        )
        .await;
        (outcome, events, messages)
    }

    async fn run_scripted_provider_with_token(
        provider: ScriptedProvider,
        mut config: QueryConfig,
        tool_config: Config,
        tools: &[Box<dyn Tool>],
        cancel_token: tokio_util::sync::CancellationToken,
    ) -> (
        QueryOutcome,
        Vec<QueryEvent>,
        Vec<Message>,
        Arc<claurst_core::cost::CostTracker>,
    ) {
        let temp = tempfile::tempdir().unwrap();
        let mut registry = claurst_api::ProviderRegistry::new();
        registry.register(Arc::new(provider));
        config.model = "scripted".to_string();
        config.provider_registry = Some(Arc::new(registry));
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "provider-outcome".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: tool_config,
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "unused-test-key".to_string(),
            ..Default::default()
        })
        .unwrap();
        let mut messages = vec![Message::user("test provider outcome")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let outcome = run_query_loop(
            &client,
            &mut messages,
            tools,
            &tool_ctx,
            &config,
            cost_tracker.clone(),
            Some(event_tx),
            cancel_token,
            None,
        )
        .await;
        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        (outcome, events, messages, cost_tracker)
    }

    async fn run_scripted_provider_until_partial_then_cancel(
        provider: ScriptedProvider,
        queued_events: Option<QueuedScriptedEvents>,
    ) -> (
        QueryOutcome,
        Vec<QueryEvent>,
        Vec<Message>,
        Arc<CostTracker>,
    ) {
        let temp = tempfile::tempdir().unwrap();
        let mut registry = claurst_api::ProviderRegistry::new();
        registry.register(Arc::new(provider));
        let mut config = make_config(None, None);
        config.model = "scripted".to_string();
        config.provider_registry = Some(Arc::new(registry));
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "provider-cancellation".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "unused-test-key".to_string(),
            ..Default::default()
        })
        .unwrap();
        let mut messages = vec![Message::user("test provider cancellation")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let cancel_token = tokio_util::sync::CancellationToken::new();
        let mut events = Vec::new();
        let mut queued_events = queued_events;
        let outcome = {
            let query = run_query_loop(
                &client,
                &mut messages,
                &[],
                &tool_ctx,
                &config,
                cost_tracker.clone(),
                Some(event_tx),
                cancel_token.clone(),
                None,
            );
            tokio::pin!(query);
            loop {
                tokio::select! {
                    outcome = &mut query => break outcome,
                    event = event_rx.recv() => {
                        let event = event.expect("query event channel must stay open before cancellation");
                        let received_partial = matches!(
                            &event,
                            QueryEvent::Stream(AnthropicStreamEvent::ContentBlockDelta {
                                delta: claurst_api::streaming::ContentDelta::TextDelta { text },
                                ..
                            }) if text == "partial before cancellation"
                        );
                        events.push(event);
                        if received_partial {
                            if let Some((sender, queued_events)) = queued_events.take() {
                                for queued_event in queued_events {
                                    sender
                                        .try_send(Ok(queued_event))
                                        .expect("queued provider event must fit in the channel");
                                }
                            }
                            cancel_token.cancel();
                        }
                    }
                }
            }
        };
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        (outcome, events, messages, cost_tracker)
    }

    async fn serve_anthropic_sse_sequence(bodies: Vec<&'static str>) -> String {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind Anthropic test listener");
        let addr = listener.local_addr().expect("Anthropic test listener addr");
        tokio::spawn(async move {
            for body in bodies {
                let (mut stream, _) = listener
                    .accept()
                    .await
                    .expect("accept Anthropic test connection");
                let mut request = [0u8; 8192];
                let _ = stream.read(&mut request).await;
                let response = format!(
                    "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                    body.len(),
                    body
                );
                stream
                    .write_all(response.as_bytes())
                    .await
                    .expect("write Anthropic test response");
                let _ = stream.shutdown().await;
            }
        });
        format!("http://{addr}")
    }

    async fn serve_anthropic_sse(body: &'static str) -> String {
        serve_anthropic_sse_sequence(vec![body]).await
    }

    async fn serve_anthropic_partial_sse(body: &'static str) -> String {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind partial Anthropic test listener");
        let addr = listener
            .local_addr()
            .expect("partial Anthropic test listener addr");
        tokio::spawn(async move {
            let (mut stream, _) = listener
                .accept()
                .await
                .expect("accept partial Anthropic test connection");
            let mut request = [0u8; 8192];
            let _ = stream.read(&mut request).await;
            let response = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nConnection: keep-alive\r\n\r\n{}",
                body
            );
            stream
                .write_all(response.as_bytes())
                .await
                .expect("write partial Anthropic test response");
            stream
                .flush()
                .await
                .expect("flush partial Anthropic response");
            std::future::pending::<()>().await;
        });
        format!("http://{addr}")
    }

    async fn serve_anthropic_stalled_then_success_sse(
        stalled_body: &'static str,
        success_body: &'static str,
    ) -> String {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind stalled-then-success Anthropic test listener");
        let addr = listener
            .local_addr()
            .expect("stalled-then-success Anthropic test listener addr");
        tokio::spawn(async move {
            let (mut stalled_stream, _) = listener
                .accept()
                .await
                .expect("accept stalled Anthropic test connection");
            let mut request = [0u8; 8192];
            let _ = stalled_stream.read(&mut request).await;
            let stalled_response = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nConnection: keep-alive\r\n\r\n{}",
                stalled_body
            );
            stalled_stream
                .write_all(stalled_response.as_bytes())
                .await
                .expect("write stalled Anthropic response");
            stalled_stream
                .flush()
                .await
                .expect("flush stalled Anthropic response");

            let (mut success_stream, _) = listener
                .accept()
                .await
                .expect("accept retry Anthropic test connection");
            let _ = success_stream.read(&mut request).await;
            let success_response = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                success_body.len(),
                success_body
            );
            success_stream
                .write_all(success_response.as_bytes())
                .await
                .expect("write retry Anthropic response");
            let _ = success_stream.shutdown().await;

            let mut byte = [0_u8; 1];
            while stalled_stream
                .read(&mut byte)
                .await
                .expect("observe stalled stream closure")
                != 0
            {}
        });
        format!("http://{addr}")
    }

    async fn serve_anthropic_sse_then_wait_for_compaction(
        body: &'static str,
    ) -> (String, tokio::sync::oneshot::Receiver<()>) {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind compaction Anthropic test listener");
        let addr = listener
            .local_addr()
            .expect("compaction Anthropic test listener addr");
        let (compaction_started_tx, compaction_started_rx) = tokio::sync::oneshot::channel();
        tokio::spawn(async move {
            let (mut first_stream, _) = listener
                .accept()
                .await
                .expect("accept initial Anthropic test connection");
            let mut request = [0u8; 8192];
            let _ = first_stream.read(&mut request).await;
            let response = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                body.len(),
                body
            );
            first_stream
                .write_all(response.as_bytes())
                .await
                .expect("write initial Anthropic test response");
            let _ = first_stream.shutdown().await;

            let (mut compact_stream, _) = listener
                .accept()
                .await
                .expect("accept compaction Anthropic test connection");
            let _ = compact_stream.read(&mut request).await;
            let _ = compaction_started_tx.send(());
            std::future::pending::<()>().await;
        });
        (format!("http://{addr}"), compaction_started_rx)
    }

    async fn serve_anthropic_sse_then_observe_compaction_close(
        body: &'static str,
    ) -> (
        String,
        tokio::sync::oneshot::Receiver<()>,
        tokio::sync::oneshot::Receiver<()>,
    ) {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind proactive-compaction Anthropic test listener");
        let addr = listener
            .local_addr()
            .expect("proactive-compaction Anthropic test listener addr");
        let (compaction_started_tx, compaction_started_rx) = tokio::sync::oneshot::channel();
        let (compaction_closed_tx, compaction_closed_rx) = tokio::sync::oneshot::channel();
        tokio::spawn(async move {
            let (mut first_stream, _) = listener
                .accept()
                .await
                .expect("accept initial proactive-compaction connection");
            let mut request = [0u8; 8192];
            let _ = first_stream.read(&mut request).await;
            let response = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                body.len(),
                body
            );
            first_stream
                .write_all(response.as_bytes())
                .await
                .expect("write initial proactive-compaction response");
            let _ = first_stream.shutdown().await;

            let (mut compact_stream, _) = listener
                .accept()
                .await
                .expect("accept proactive-compaction request");
            let _ = compact_stream.read(&mut request).await;
            compact_stream
                .write_all(
                    b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nConnection: keep-alive\r\n\r\n",
                )
                .await
                .expect("write stalled proactive-compaction headers");
            compact_stream
                .flush()
                .await
                .expect("flush stalled proactive-compaction headers");
            let _ = compaction_started_tx.send(());

            let mut byte = [0_u8; 1];
            loop {
                match compact_stream.read(&mut byte).await {
                    Ok(0) => {
                        let _ = compaction_closed_tx.send(());
                        return;
                    }
                    Err(error) if error.kind() == std::io::ErrorKind::ConnectionReset => {
                        let _ = compaction_closed_tx.send(());
                        return;
                    }
                    Ok(_) => {}
                    Err(error) => panic!("observe proactive-compaction stream closure: {error}"),
                }
            }
        });
        (
            format!("http://{addr}"),
            compaction_started_rx,
            compaction_closed_rx,
        )
    }

    async fn run_anthropic_sse(
        body: &'static str,
        tool_config: Config,
    ) -> (QueryOutcome, Vec<QueryEvent>, Vec<Message>) {
        let temp = tempfile::tempdir().unwrap();
        let api_base = serve_anthropic_sse(body).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "anthropic-outcome".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: tool_config,
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let mut messages = vec![Message::user("test Anthropic outcome")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let outcome = run_query_loop(
            &client,
            &mut messages,
            &[],
            &tool_ctx,
            &make_config(None, None),
            cost_tracker,
            Some(event_tx),
            tokio_util::sync::CancellationToken::new(),
            None,
        )
        .await;
        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        (outcome, events, messages)
    }

    async fn run_anthropic_until_partial_then_cancel(
        body: &'static str,
        cancel_on_input_json: bool,
    ) -> (
        QueryOutcome,
        Vec<QueryEvent>,
        Vec<Message>,
        Arc<CostTracker>,
    ) {
        let temp = tempfile::tempdir().unwrap();
        let api_base = serve_anthropic_partial_sse(body).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "anthropic-cancellation".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let mut messages = vec![Message::user("test Anthropic cancellation")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let cancel_token = tokio_util::sync::CancellationToken::new();
        let query_config = make_config(None, None);
        let mut events = Vec::new();
        let outcome = {
            let query = run_query_loop(
                &client,
                &mut messages,
                &[],
                &tool_ctx,
                &query_config,
                cost_tracker.clone(),
                Some(event_tx),
                cancel_token.clone(),
                None,
            );
            tokio::pin!(query);
            loop {
                tokio::select! {
                    outcome = &mut query => break outcome,
                    event = event_rx.recv() => {
                        let event = event.expect("query event channel must stay open before cancellation");
                        let cancellation_boundary = matches!(
                            &event,
                            QueryEvent::Stream(AnthropicStreamEvent::ContentBlockStop { index: 0 })
                        ) || (cancel_on_input_json && matches!(
                            &event,
                            QueryEvent::Stream(AnthropicStreamEvent::ContentBlockDelta {
                                index: 0,
                                delta: claurst_api::streaming::ContentDelta::InputJsonDelta { .. },
                            })
                        ));
                        events.push(event);
                        if cancellation_boundary {
                            cancel_token.cancel();
                        }
                    }
                }
            }
        };
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        (outcome, events, messages, cost_tracker)
    }

    async fn run_anthropic_sse_sequence_in_worktree(
        bodies: Vec<&'static str>,
        working_dir: &std::path::Path,
        tool_config: Config,
        query_config: QueryConfig,
        tools: &[Box<dyn Tool>],
    ) -> (QueryOutcome, Vec<QueryEvent>, Vec<Message>) {
        let api_base = serve_anthropic_sse_sequence(bodies).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: working_dir.to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "anthropic-snapshot".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: tool_config,
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let mut messages = vec![Message::user("exercise terminal snapshot")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let outcome = run_query_loop(
            &client,
            &mut messages,
            tools,
            &tool_ctx,
            &query_config,
            cost_tracker,
            Some(event_tx),
            tokio_util::sync::CancellationToken::new(),
            None,
        )
        .await;
        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        (outcome, events, messages)
    }

    fn durable_uuid<'a>(events: &'a [QueryEvent], selector: &str) -> &'a str {
        let message = events.iter().find_map(|event| match event {
            QueryEvent::DurableMessage { message } if message.role == Role::Assistant => {
                (message.get_all_text() == selector || message.get_tool_use_blocks().iter().any(|block| {
                    matches!(block, ContentBlock::ToolUse { id, .. } if id == selector)
                })).then_some(message)
            }
            _ => None,
        }).expect("expected semantic assistant in durable events");
        let id = message.uuid.as_deref().expect("durable attempt UUID");
        uuid::Uuid::parse_str(id).expect("attempt UUID must be independent of provider ID");
        id
    }

    fn make_config(sys: Option<&str>, append: Option<&str>) -> QueryConfig {
        QueryConfig {
            model: "claude-sonnet-4-6".to_string(),
            max_tokens: 4096,
            max_turns: 10,
            system_prompt: sys.map(String::from),
            append_system_prompt: append.map(String::from),
            output_style: claurst_core::system_prompt::OutputStyle::Default,
            output_style_prompt: None,
            working_directory: None,
            thinking_budget: None,
            temperature: None,
            tool_result_budget: 50_000,
            effort_level: None,
            command_queue: None,
            skill_index: None,
            max_budget_usd: None,
            fallback_model: None,
            provider_registry: None,
            agent_name: None,
            agent_definition: None,
            model_registry: None,
            managed_agents: None,
            preserve_selected_model: false,
        }
    }

    #[tokio::test]
    async fn empty_max_tokens_retry_does_not_persist_an_empty_assistant() {
        const EMPTY_LIMIT: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"same-provider-id\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"max_tokens\"},\"usage\":{\"output_tokens\":2}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        const COMPLETE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"same-provider-id\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"All tests pass.\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":3}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        let temp = tempfile::tempdir().unwrap();
        let (outcome, events, messages) = run_anthropic_sse_sequence_in_worktree(
            vec![EMPTY_LIMIT, COMPLETE],
            temp.path(),
            Config::default(),
            make_config(None, None),
            &[],
        )
        .await;
        assert!(matches!(outcome, QueryOutcome::EndTurn { .. }));
        let assistants: Vec<_> = messages
            .iter()
            .filter(|m| m.role == Role::Assistant)
            .collect();
        assert_eq!(assistants.len(), 1);
        assert_eq!(assistants[0].get_all_text(), "All tests pass.");
        let durable: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                QueryEvent::DurableMessage { message } if message.role == Role::Assistant => {
                    Some(message)
                }
                _ => None,
            })
            .collect();
        assert_eq!(durable.len(), 1);
        assert_eq!(durable[0].uuid, assistants[0].uuid);
    }

    #[tokio::test]
    async fn durable_message_event_survives_context_rewrite() {
        let (tx, mut rx) = mpsc::unbounded_channel();
        let mut assistant = Message::assistant("");
        let mut messages = vec![assistant.clone()];
        assistant = Message::assistant("final placeholder");
        messages[0] = assistant.clone();
        emit_durable_message(Some(&tx), &assistant);
        messages = vec![Message::user("compacted summary")];

        let event = rx.recv().await.unwrap();
        match event {
            QueryEvent::DurableMessage { message } => {
                assert_eq!(message.get_all_text(), "final placeholder")
            }
            _ => panic!("expected durable message event"),
        }
        assert_eq!(messages.len(), 1);
    }

    #[tokio::test]
    async fn exhausted_anthropic_stall_finalizes_partial_assistant_before_error() {
        let (tx, mut rx) = mpsc::unbounded_channel();
        let mut messages = vec![Message::user("continue")];
        let mut assistant = Message::assistant("partial response");
        assistant.uuid = Some("stalled-response".to_string());

        let outcome =
            finish_anthropic_stall(&mut messages, &mut assistant, None, None, Some(&tx)).await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        let event = rx.recv().await.unwrap();
        assert!(matches!(
            event,
            QueryEvent::DurableMessage { message }
                if message.uuid.as_deref() == Some("stalled-response")
                    && message.get_all_text() == "partial response"
        ));
        assert!(messages.iter().any(|message| {
            message.uuid.as_deref() == Some("stalled-response")
                && message.get_all_text() == "partial response"
        }));
    }

    #[test]
    fn finalized_assistant_is_restored_once_after_context_rewrite() {
        let mut finalized = Message::assistant("final response");
        finalized.uuid = Some("current-response".to_string());
        let mut unrelated = Message::assistant("compacted summary");
        unrelated.uuid = Some("summary".to_string());
        let mut messages = vec![unrelated.clone()];

        sync_finalized_assistant_message(&mut messages, &finalized);
        sync_finalized_assistant_message(&mut messages, &finalized);

        assert_eq!(messages.len(), 2);
        assert_eq!(messages[0].uuid, unrelated.uuid);
        assert_eq!(messages[0].get_all_text(), "compacted summary");
        assert_eq!(messages[1].uuid, finalized.uuid);
        assert_eq!(messages[1].get_all_text(), "final response");
    }

    #[tokio::test]
    async fn provider_eof_without_message_stop_is_an_error_and_preserves_incomplete_tool_json() {
        let raw_json = r#"{"path":"unfinished"#;
        let provider = ScriptedProvider::new(vec![vec![
            StreamEvent::MessageStart {
                id: "provider-premature-eof".to_string(),
                model: "scripted".to_string(),
                usage: UsageInfo::default(),
            },
            StreamEvent::ContentBlockStart {
                index: 0,
                content_block: ContentBlock::ToolUse {
                    id: "provider-incomplete-tool".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                },
            },
            StreamEvent::InputJsonDelta {
                index: 0,
                partial_json: raw_json.to_string(),
            },
        ]]);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];

        let (outcome, events, messages) = run_scripted_provider_with(
            provider,
            make_config(None, None),
            Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            &tools,
        )
        .await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                QueryEvent::ToolStart { tool_id, .. } | QueryEvent::ToolEnd { tool_id, .. }
                    if tool_id == "provider-incomplete-tool"
            )
        }));
        let assistant_index = messages
            .iter()
            .position(|message| {
                message.uuid.as_deref() == Some(durable_uuid(&events, "provider-incomplete-tool"))
            })
            .expect("partial assistant must be durable");
        assert!(matches!(
            &messages[assistant_index].content,
            MessageContent::Blocks(blocks)
                if matches!(
                    &blocks[0],
                    ContentBlock::ToolUse { input, .. } if input == &Value::String(raw_json.into())
                )
        ));
        assert!(is_tool_result_carrier(&messages[assistant_index + 1]));
    }

    #[tokio::test]
    async fn provider_stream_error_is_terminal_without_tool_execution() {
        let provider = ScriptedProvider::new(vec![vec![
            StreamEvent::MessageStart {
                id: "provider-stream-event-error".to_string(),
                model: "scripted".to_string(),
                usage: UsageInfo::default(),
            },
            StreamEvent::ContentBlockStart {
                index: 0,
                content_block: ContentBlock::ToolUse {
                    id: "provider-event-error-tool".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                },
            },
            StreamEvent::InputJsonDelta {
                index: 0,
                partial_json: "{}".to_string(),
            },
            StreamEvent::Error {
                error_type: "provider_failure".to_string(),
                message: "stream stopped".to_string(),
            },
        ]]);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];

        let (outcome, events, messages) = run_scripted_provider_with(
            provider,
            make_config(None, None),
            Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            &tools,
        )
        .await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                QueryEvent::ToolStart { tool_id, .. } | QueryEvent::ToolEnd { tool_id, .. }
                    if tool_id == "provider-event-error-tool"
            )
        }));
        let assistant_index = messages
            .iter()
            .position(|message| {
                message.uuid.as_deref() == Some(durable_uuid(&events, "provider-event-error-tool"))
            })
            .expect("erroring assistant must be durable");
        assert!(is_tool_result_carrier(&messages[assistant_index + 1]));
    }

    #[tokio::test]
    async fn anthropic_eof_without_message_stop_is_an_error_and_preserves_incomplete_tool_json() {
        const PREMATURE_EOF_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-premature-eof\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"tool_use\",\"id\":\"anthropic-incomplete-tool\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"input_json_delta\",\"partial_json\":\"{\\\"path\\\":\\\"unfinished\"}}\n\n",
        );
        let (outcome, events, messages) =
            run_anthropic_sse(PREMATURE_EOF_SSE, Config::default()).await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
        let assistant_index = messages
            .iter()
            .position(|message| {
                message.get_tool_use_blocks().iter().any(|block| {
                    matches!(
                        block,
                        ContentBlock::ToolUse { id, .. } if id == "anthropic-incomplete-tool"
                    )
                })
            })
            .expect("partial assistant must be durable");
        assert!(matches!(
            &messages[assistant_index].content,
            MessageContent::Blocks(blocks)
                if matches!(
                    &blocks[0],
                    ContentBlock::ToolUse { input, .. }
                        if input == &Value::String(r#"{"path":"unfinished"#.into())
                )
        ));
        assert!(is_tool_result_carrier(&messages[assistant_index + 1]));
    }

    #[tokio::test]
    async fn terminal_tool_result_carrier_is_adjacent_and_deduplicated_after_hook_messages() {
        let mut tool_config = Config::default();
        tool_config.hooks.insert(
            HookEvent::PostModelTurn,
            vec![HookEntry {
                command: "printf 'hook injected' >&2; exit 1".to_string(),
                tool_filter: None,
                blocking: false,
            }],
        );
        let mut assistant = Message::assistant_blocks(vec![
            ContentBlock::ToolUse {
                id: "duplicate-tool".to_string(),
                name: "WriteFixture".to_string(),
                input: serde_json::json!({}),
            },
            ContentBlock::ToolUse {
                id: "duplicate-tool".to_string(),
                name: "WriteFixture".to_string(),
                input: serde_json::json!({}),
            },
            ContentBlock::ToolUse {
                id: "already-closed".to_string(),
                name: "WriteFixture".to_string(),
                input: serde_json::json!({}),
            },
        ]);
        assistant.uuid = Some("terminal-duplicate-tools".to_string());
        let hook_message = fire_post_sampling_hooks(&assistant, &tool_config)
            .blocking_errors
            .pop()
            .expect("the failing hook must inject a user message");
        let existing_result = Message::user_blocks(vec![ContentBlock::ToolResult {
            tool_use_id: "already-closed".to_string(),
            content: ToolResultContent::Text("already handled".to_string()),
            is_error: Some(true),
        }]);
        let mut messages = vec![
            Message::user("start"),
            assistant.clone(),
            existing_result,
            hook_message,
        ];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();

        finalize_terminal_assistant_with_unexecuted_tool_results(
            &mut messages,
            &mut assistant,
            None,
            None,
            Some(&event_tx),
            "stream failed",
        )
        .await;

        assert_eq!(
            messages[1].uuid.as_deref(),
            Some("terminal-duplicate-tools")
        );
        let MessageContent::Blocks(carrier_blocks) = &messages[2].content else {
            panic!("the immediate follower must be the tool-result carrier");
        };
        assert_eq!(carrier_blocks.len(), 1);
        assert!(matches!(
            &carrier_blocks[0],
            ContentBlock::ToolResult { tool_use_id, .. } if tool_use_id == "duplicate-tool"
        ));
        assert!(matches!(
            &messages[3].content,
            MessageContent::Blocks(blocks)
                if matches!(
                    &blocks[0],
                    ContentBlock::ToolResult { tool_use_id, .. } if tool_use_id == "already-closed"
                )
        ));
        assert!(messages[4].get_all_text().contains("hook injected"));
        assert_eq!(
            messages
                .iter()
                .flat_map(|message| match &message.content {
                    MessageContent::Blocks(blocks) => blocks.iter(),
                    _ => [].iter(),
                })
                .filter(|block| {
                    matches!(
                        block,
                        ContentBlock::ToolResult { tool_use_id, .. } if tool_use_id == "duplicate-tool"
                    )
                })
                .count(),
            1
        );
        assert_eq!(
            messages
                .iter()
                .flat_map(|message| match &message.content {
                    MessageContent::Blocks(blocks) => blocks.iter(),
                    _ => [].iter(),
                })
                .filter(|block| {
                    matches!(
                        block,
                        ContentBlock::ToolResult { tool_use_id, .. } if tool_use_id == "already-closed"
                    )
                })
                .count(),
            1
        );
        assert!(matches!(
            event_rx.recv().await,
            Some(QueryEvent::DurableMessage { message })
                if message.uuid.as_deref() == Some("terminal-duplicate-tools")
        ));
        assert!(matches!(
            event_rx.recv().await,
            Some(QueryEvent::DurableMessage { message }) if is_tool_result_carrier(&message)
        ));
    }

    #[tokio::test(start_paused = true)]
    async fn provider_keepalives_extend_liveness_without_transcript_content() {
        let (sender, receiver) = mpsc::channel(8);
        let stream = futures::stream::unfold(receiver, |mut receiver| async {
            receiver.recv().await.map(|event| (event, receiver))
        });
        let producer = tokio::spawn(async move {
            for _ in 0..4 {
                tokio::time::sleep(std::time::Duration::from_millis(50)).await;
                sender.send(Ok(StreamEvent::Ping)).await.unwrap();
            }
            sender.send(Ok(StreamEvent::MessageStop)).await.unwrap();
        });
        let cancel = tokio_util::sync::CancellationToken::new();
        let mut accumulator = StreamAccumulator::new();
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let mut terminal_error = None;
        let outcome = consume_provider_stream(
            Box::pin(stream),
            &mut ProviderStreamContext {
                cancel_token: &cancel,
                accumulator: &mut accumulator,
                event_tx: Some(&event_tx),
                provider_id: "anthropic",
                model_id: "test",
                terminal_stream_error: &mut terminal_error,
            },
            std::time::Duration::from_millis(150),
        )
        .await;
        producer.await.unwrap();
        assert_eq!(outcome, ProviderStreamOutcome::Completed);
        assert!(terminal_error.is_none());
        assert!(accumulator.received_message_stop());
        let (message, usage, _) = accumulator.finish();
        assert!(message.content_blocks().is_empty());
        assert_eq!(usage.output_tokens, 0);
        assert!(matches!(
            event_rx.try_recv(),
            Ok(QueryEvent::Stream(AnthropicStreamEvent::MessageStop))
        ));
        assert!(event_rx.try_recv().is_err());
    }

    #[tokio::test]
    async fn provider_stream_error_finalizes_partial_response_before_returning_error() {
        let error = ProviderError::StreamError {
            provider: ProviderId::new(SCRIPTED_PROVIDER_ID),
            message: "scripted stream failed".to_string(),
            partial_response: Some("partial".to_string()),
        };
        let provider = ScriptedProvider::with_results(vec![vec![
            Ok(StreamEvent::MessageStart {
                id: "stream-error".to_string(),
                model: "scripted".to_string(),
                usage: UsageInfo::default(),
            }),
            Ok(StreamEvent::TextDelta {
                index: 0,
                text: "partial".to_string(),
            }),
            Err(error),
        ]]);

        let (outcome, events, messages) = run_scripted_provider(provider).await;

        assert!(matches!(&outcome, QueryOutcome::Error(_)));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        let durable = events
            .iter()
            .find_map(|event| match event {
                QueryEvent::DurableMessage { message } => Some(message),
                _ => None,
            })
            .expect("stream error must publish its finalized partial assistant");
        assert_eq!(
            durable.uuid.as_deref(),
            Some(durable_uuid(&events, "partial"))
        );
        assert_eq!(durable.get_all_text(), "partial");
        assert!(messages.iter().any(|message| {
            message.uuid == durable.uuid && message.get_all_text() == "partial"
        }));
    }

    #[tokio::test]
    async fn provider_cancellation_after_partial_sampling_finalizes_exactly_once() {
        let provider = ScriptedProvider::partial_then_pending(vec![
            StreamEvent::MessageStart {
                id: "provider-cancelled-partial".to_string(),
                model: "scripted".to_string(),
                usage: UsageInfo {
                    input_tokens: 1,
                    ..UsageInfo::default()
                },
            },
            StreamEvent::TextDelta {
                index: 0,
                text: "partial before cancellation".to_string(),
            },
        ]);

        let (outcome, events, messages, costs) =
            run_scripted_provider_until_partial_then_cancel(provider, None).await;

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        assert_eq!(costs.input_tokens(), 1);
        let durable_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message }
                    if message.uuid.as_deref() == Some(durable_uuid(&events, "partial before cancellation"))
                        && message.get_all_text() == "partial before cancellation")
            })
            .expect("cancelled provider response must be durable");
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(event, QueryEvent::DurableMessage { message }
                        if message.uuid.as_deref() == Some(durable_uuid(&events, "partial before cancellation")))
                })
                .count(),
            1
        );
        assert!(messages.iter().any(|message| {
            message.uuid.as_deref() == Some(durable_uuid(&events, "partial before cancellation"))
                && message.get_all_text() == "partial before cancellation"
        }));
        assert!(events[durable_index + 1..]
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn cancelled_provider_drains_queued_indexed_blocks_before_finalizing() {
        let (provider, queued_sender) = ScriptedProvider::channel_after(vec![
            StreamEvent::MessageStart {
                id: "queued-provider-cancellation".to_string(),
                model: "scripted".to_string(),
                usage: UsageInfo {
                    input_tokens: 7,
                    cache_creation_input_tokens: 2,
                    cache_read_input_tokens: 3,
                    ..UsageInfo::default()
                },
            },
            StreamEvent::ContentBlockStart {
                index: 2,
                content_block: ContentBlock::Text {
                    text: "text ".to_string(),
                },
            },
            StreamEvent::TextDelta {
                index: 2,
                text: "partial before cancellation".to_string(),
            },
        ]);
        let queued_events = vec![
            StreamEvent::ContentBlockStart {
                index: 0,
                content_block: ContentBlock::Thinking {
                    thinking: "think ".to_string(),
                    signature: "sig-".to_string(),
                },
            },
            StreamEvent::ThinkingDelta {
                index: 0,
                thinking: "more".to_string(),
            },
            StreamEvent::SignatureDelta {
                index: 0,
                signature: "more".to_string(),
            },
            StreamEvent::ContentBlockStart {
                index: 1,
                content_block: ContentBlock::ToolUse {
                    id: "queued-tool".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                },
            },
            StreamEvent::InputJsonDelta {
                index: 1,
                partial_json: r#"{"path":"unfinished"#.to_string(),
            },
            StreamEvent::TextDelta {
                index: 2,
                text: " tail".to_string(),
            },
            StreamEvent::ContentBlockStart {
                index: 3,
                content_block: ContentBlock::Text {
                    text: "complete".to_string(),
                },
            },
            StreamEvent::ContentBlockStop { index: 3 },
            StreamEvent::MessageDelta {
                stop_reason: Some(ProviderStopReason::EndTurn),
                usage: Some(UsageInfo {
                    output_tokens: 5,
                    ..UsageInfo::default()
                }),
            },
            StreamEvent::MessageStop,
        ];

        let (outcome, events, messages, costs) = run_scripted_provider_until_partial_then_cancel(
            provider,
            Some((queued_sender, queued_events)),
        )
        .await;

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        assert_eq!(costs.input_tokens(), 7);
        assert_eq!(costs.output_tokens(), 5);
        assert_eq!(costs.cache_creation_tokens(), 2);
        assert_eq!(costs.cache_read_tokens(), 3);
        let assistant = messages
            .iter()
            .find(|message| message.uuid.as_deref() == Some(durable_uuid(&events, "queued-tool")))
            .expect("queued provider events must be finalized into durable history");
        let MessageContent::Blocks(blocks) = &assistant.content else {
            panic!("queued provider response must keep block content");
        };
        assert!(matches!(
            blocks.as_slice(),
            [
                ContentBlock::Thinking { thinking, signature },
                ContentBlock::ToolUse { id, name, input },
                ContentBlock::Text { text: partial_text },
                ContentBlock::Text { text: completed_text },
            ] if thinking == "think more"
                && signature == "sig-more"
                && id == "queued-tool"
                && name == "WriteFixture"
                && input == &Value::String(r#"{"path":"unfinished"#.to_string())
                && partial_text == "text partial before cancellation tail"
                && completed_text == "complete"
        ));
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(event, QueryEvent::Stream(_)))
                .count(),
            13,
            "each queued provider event must be published exactly once"
        );
        assert_unexecuted_tool_result_is_durable_once(&events, &messages, "queued-tool");
    }

    #[tokio::test]
    async fn provider_stall_retry_durably_closes_the_partial_attempt_once() {
        let provider = ScriptedProvider::partial_then_success(
            vec![
                StreamEvent::MessageStart {
                    id: "provider-stalled-attempt".to_string(),
                    model: "scripted".to_string(),
                    usage: UsageInfo {
                        input_tokens: 3,
                        ..UsageInfo::default()
                    },
                },
                StreamEvent::ContentBlockStart {
                    index: 0,
                    content_block: ContentBlock::Text {
                        text: String::new(),
                    },
                },
                StreamEvent::TextDelta {
                    index: 0,
                    text: "partial provider output".to_string(),
                },
                StreamEvent::ContentBlockStop { index: 0 },
                StreamEvent::ContentBlockStart {
                    index: 1,
                    content_block: ContentBlock::ToolUse {
                        id: "provider-stalled-tool".to_string(),
                        name: "WriteFixture".to_string(),
                        input: serde_json::json!({}),
                    },
                },
                StreamEvent::InputJsonDelta {
                    index: 1,
                    partial_json: "{}".to_string(),
                },
                StreamEvent::ContentBlockStop { index: 1 },
                StreamEvent::MessageDelta {
                    stop_reason: Some(ProviderStopReason::ToolUse),
                    usage: Some(UsageInfo {
                        output_tokens: 2,
                        ..UsageInfo::default()
                    }),
                },
            ],
            scripted_round(
                "provider-stalled-attempt",
                vec![ContentBlock::Text {
                    text: "fresh successful response".to_string(),
                }],
                ProviderStopReason::EndTurn,
            ),
        );

        let (outcome, events, messages, cost_tracker) = TEST_STREAM_STALL_TIMEOUT
            .scope(
                std::time::Duration::from_millis(10),
                run_scripted_provider_with_token(
                    provider,
                    make_config(None, None),
                    Config {
                        provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                        permission_mode: PermissionMode::BypassPermissions,
                        ..Config::default()
                    },
                    &[],
                    tokio_util::sync::CancellationToken::new(),
                ),
            )
            .await;

        assert!(matches!(
            outcome,
            QueryOutcome::EndTurn { ref message, .. }
                if message.get_all_text() == "fresh successful response"
        ));
        assert_ne!(
            durable_uuid(&events, "partial provider output"),
            durable_uuid(&events, "fresh successful response")
        );
        assert_eq!(cost_tracker.input_tokens(), 4);
        assert_eq!(cost_tracker.output_tokens(), 3);
        assert_eq!(cost_tracker.total_tokens(), 7);
        assert_eq!(
            messages
                .iter()
                .filter(|message| {
                    message.uuid.as_deref()
                        == Some(durable_uuid(&events, "partial provider output"))
                        && message.get_all_text() == "partial provider output"
                })
                .count(),
            1,
            "the partial attempt must remain in history exactly once"
        );
        let partial_index = messages
            .iter()
            .position(|message| {
                message.uuid.as_deref() == Some(durable_uuid(&events, "partial provider output"))
            })
            .expect("the stalled partial assistant must remain in history");
        assert!(is_tool_result_carrier(&messages[partial_index + 1]));
        assert_eq!(
            messages
                .iter()
                .flat_map(|message| match &message.content {
                    MessageContent::Blocks(blocks) => blocks.iter(),
                    _ => [].iter(),
                })
                .filter(|block| {
                    matches!(
                        block,
                        ContentBlock::ToolResult { tool_use_id, is_error: Some(true), .. }
                            if tool_use_id == "provider-stalled-tool"
                    )
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(
                        event,
                        QueryEvent::DurableMessage { message }
                            if message.uuid.as_deref() == Some(durable_uuid(&events, "partial provider output"))
                    )
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(event, QueryEvent::TurnComplete { .. }))
                .count(),
            1,
            "only the successful retry may complete the turn"
        );
    }

    #[tokio::test]
    async fn anthropic_stall_retry_durably_closes_the_partial_attempt_once() {
        const STALLED_ATTEMPT: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-stalled-attempt\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":4,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"partial anthropic output\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":1,\"content_block\":{\"type\":\"tool_use\",\"id\":\"anthropic-stalled-tool\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":1,\"delta\":{\"type\":\"input_json_delta\",\"partial_json\":\"{}\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":1}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"tool_use\"},\"usage\":{\"output_tokens\":3}}\n\n",
        );
        const SUCCESSFUL_RETRY: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-retry-success\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"fresh Anthropic response\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );

        let temp = tempfile::tempdir().unwrap();
        let api_base =
            serve_anthropic_stalled_then_success_sse(STALLED_ATTEMPT, SUCCESSFUL_RETRY).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "anthropic-stall-retry".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let mut messages = vec![Message::user("exercise Anthropic stall retry")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let outcome = TEST_STREAM_STALL_TIMEOUT
            .scope(
                std::time::Duration::from_millis(10),
                run_query_loop(
                    &client,
                    &mut messages,
                    &[],
                    &tool_ctx,
                    &make_config(None, None),
                    cost_tracker.clone(),
                    Some(event_tx),
                    tokio_util::sync::CancellationToken::new(),
                    None,
                ),
            )
            .await;
        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }

        assert!(matches!(
            outcome,
            QueryOutcome::EndTurn { ref message, .. }
                if message.get_all_text() == "fresh Anthropic response"
        ));
        assert_eq!(cost_tracker.input_tokens(), 5);
        assert_eq!(cost_tracker.output_tokens(), 4);
        assert_eq!(cost_tracker.total_tokens(), 9);
        let partial_index = messages
            .iter()
            .position(|message| {
                message.uuid.as_deref() == Some(durable_uuid(&events, "partial anthropic output"))
            })
            .expect("the stalled Anthropic attempt must remain in history");
        assert_eq!(
            messages
                .iter()
                .filter(|message| {
                    message.uuid.as_deref()
                        == Some(durable_uuid(&events, "partial anthropic output"))
                        && message.get_all_text() == "partial anthropic output"
                })
                .count(),
            1
        );
        assert!(is_tool_result_carrier(&messages[partial_index + 1]));
        assert_eq!(
            messages
                .iter()
                .flat_map(|message| match &message.content {
                    MessageContent::Blocks(blocks) => blocks.iter(),
                    _ => [].iter(),
                })
                .filter(|block| {
                    matches!(
                        block,
                        ContentBlock::ToolResult { tool_use_id, is_error: Some(true), .. }
                            if tool_use_id == "anthropic-stalled-tool"
                    )
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(
                        event,
                        QueryEvent::DurableMessage { message }
                            if message.uuid.as_deref() == Some(durable_uuid(&events, "partial anthropic output"))
                    )
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(event, QueryEvent::TurnComplete { .. }))
                .count(),
            1,
            "only the successful retry may complete the turn"
        );
    }

    #[tokio::test]
    async fn anthropic_stream_error_finalizes_partial_response_before_returning_error() {
        const STREAM_ERROR_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-stream-error\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"partial\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: error\n",
            "data: {\"error\":{\"type\":\"api_error\",\"message\":\"scripted stream failed\"}}\n\n",
        );

        let (outcome, events, messages) =
            run_anthropic_sse(STREAM_ERROR_SSE, Config::default()).await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        let durable = events
            .iter()
            .find_map(|event| match event {
                QueryEvent::DurableMessage { message } => Some(message),
                _ => None,
            })
            .expect("stream error must publish its finalized partial assistant");
        assert_eq!(durable.get_all_text(), "partial");
        assert!(messages.iter().any(|message| {
            message.uuid == durable.uuid && message.get_all_text() == "partial"
        }));
    }

    #[tokio::test]
    async fn anthropic_cancellation_after_partial_sampling_finalizes_exactly_once() {
        const PARTIAL_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-cancelled-partial\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":2,\"cache_creation_input_tokens\":3,\"cache_read_input_tokens\":4}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"partial before cancellation\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
        );

        let (outcome, events, messages, costs) =
            run_anthropic_until_partial_then_cancel(PARTIAL_SSE, false).await;

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        assert_eq!(costs.input_tokens(), 1);
        assert_eq!(costs.output_tokens(), 2);
        assert_eq!(costs.cache_creation_tokens(), 3);
        assert_eq!(costs.cache_read_tokens(), 4);
        let durable_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message }
                    if message.get_all_text() == "partial before cancellation")
            })
            .unwrap_or_else(|| {
                panic!("cancelled Anthropic response must be durable; events: {events:?}")
            });
        let durable_uuid = match &events[durable_index] {
            QueryEvent::DurableMessage { message } => message.uuid.clone(),
            _ => unreachable!("durable index points to durable event"),
        };
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(event, QueryEvent::DurableMessage { message }
                        if message.uuid == durable_uuid)
                })
                .count(),
            1
        );
        assert_eq!(
            messages
                .iter()
                .filter(|message| message.uuid == durable_uuid)
                .count(),
            1
        );
        assert!(events[durable_index + 1..]
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn cancelled_anthropic_tool_use_is_closed_with_one_durable_error_result() {
        const TOOL_USE_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"cancelled-complete-tool\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"tool_use\",\"id\":\"cancelled-tool\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"input_json_delta\",\"partial_json\":\"{}\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
        );

        let (outcome, events, messages, costs) =
            run_anthropic_until_partial_then_cancel(TOOL_USE_SSE, false).await;

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        assert_eq!(costs.input_tokens(), 1);
        assert_unexecuted_tool_result_is_durable_once(&events, &messages, "cancelled-tool");
    }

    #[tokio::test]
    async fn cancelled_anthropic_open_tool_use_is_closed_with_one_durable_error_result() {
        const OPEN_TOOL_USE_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"cancelled-open-tool\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"tool_use\",\"id\":\"open-tool\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"input_json_delta\",\"partial_json\":\"{\\\"path\\\":\\\"fixture.txt\\\"}\"}}\n\n",
        );

        let (outcome, events, messages, costs) =
            run_anthropic_until_partial_then_cancel(OPEN_TOOL_USE_SSE, true).await;

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        assert_eq!(costs.input_tokens(), 1);
        assert_unexecuted_tool_result_is_durable_once(&events, &messages, "open-tool");
    }

    #[tokio::test]
    async fn anthropic_stream_error_tool_use_is_closed_with_one_durable_error_result() {
        const STREAM_ERROR_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"errored-tool\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"tool_use\",\"id\":\"errored-tool-use\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: error\n",
            "data: {\"error\":{\"type\":\"api_error\",\"message\":\"scripted stream failed\"}}\n\n",
        );

        let (outcome, events, messages) =
            run_anthropic_sse(STREAM_ERROR_SSE, Config::default()).await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        assert_unexecuted_tool_result_is_durable_once(&events, &messages, "errored-tool-use");
    }

    #[tokio::test]
    async fn cancellation_drains_prequeued_anthropic_events_before_finalizing() {
        let (stream_tx, mut stream_rx) = mpsc::channel(6);
        stream_tx
            .send(AnthropicStreamEvent::MessageStart {
                id: "queued-before-cancellation".to_string(),
                model: "claude-test".to_string(),
                usage: UsageInfo::default(),
            })
            .await
            .unwrap();
        stream_tx
            .send(AnthropicStreamEvent::ContentBlockStart {
                index: 0,
                content_block: ContentBlock::Text {
                    text: String::new(),
                },
            })
            .await
            .unwrap();
        stream_tx
            .send(AnthropicStreamEvent::ContentBlockDelta {
                index: 0,
                delta: claurst_api::streaming::ContentDelta::TextDelta {
                    text: "queued assistant text".to_string(),
                },
            })
            .await
            .unwrap();
        stream_tx
            .send(AnthropicStreamEvent::ContentBlockStop { index: 0 })
            .await
            .unwrap();
        stream_tx
            .send(AnthropicStreamEvent::MessageDelta {
                stop_reason: Some("end_turn".to_string()),
                usage: None,
            })
            .await
            .unwrap();
        stream_tx
            .send(AnthropicStreamEvent::MessageStop)
            .await
            .unwrap();

        let cancel_token = tokio_util::sync::CancellationToken::new();
        cancel_token.cancel();
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let mut accumulator = StreamAccumulator::new();
        let mut terminal_stream_error = None;

        let outcome = consume_anthropic_stream(
            &mut stream_rx,
            &cancel_token,
            &mut accumulator,
            Some(&event_tx),
            "claude-test",
            &mut terminal_stream_error,
            std::time::Duration::from_secs(45),
        )
        .await;

        assert!(matches!(outcome, AnthropicStreamOutcome::Cancelled));
        assert!(terminal_stream_error.is_none());
        assert!(
            stream_tx.try_send(AnthropicStreamEvent::Ping).is_err(),
            "cancellation must reject events that were not queued before stream_rx.close()"
        );
        let (mut assistant, _, _) = accumulator.finish();
        assistant.uuid = Some("queued-before-cancellation".to_string());
        let mut messages = vec![Message::user("test queued cancellation")];
        finalize_terminal_assistant_message(
            &mut messages,
            &mut assistant,
            None,
            None,
            Some(&event_tx),
        )
        .await;

        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(event, QueryEvent::Stream(AnthropicStreamEvent::ContentBlockDelta {
                        delta: claurst_api::streaming::ContentDelta::TextDelta { text },
                        ..
                    }) if text == "queued assistant text")
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(event, QueryEvent::DurableMessage { message }
                        if message.uuid.as_deref() == Some("queued-before-cancellation")
                            && message.get_all_text() == "queued assistant text")
                })
                .count(),
            1
        );
        assert_eq!(
            messages
                .iter()
                .filter(|message| {
                    message.uuid.as_deref() == Some("queued-before-cancellation")
                        && message.get_all_text() == "queued assistant text"
                })
                .count(),
            1
        );
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn proactive_compaction_cancellation_restores_history_and_closes_its_stream() {
        let _feature_gate_lock = REACTIVE_COMPACT_FEATURE_GATE_LOCK.lock().await;

        struct FeatureGateGuard {
            prior: Option<std::ffi::OsString>,
        }

        impl FeatureGateGuard {
            fn disable_reactive_compact() -> Self {
                let prior = std::env::var_os("COVEN_CODE_FEATURE_REACTIVE_COMPACT");
                std::env::remove_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT");
                Self { prior }
            }
        }

        impl Drop for FeatureGateGuard {
            fn drop(&mut self) {
                match self.prior.take() {
                    Some(value) => std::env::set_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT", value),
                    None => std::env::remove_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT"),
                }
            }
        }

        const COMPACTION_TRIGGER_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"proactive-compaction-cancelled\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":180000,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"sampled before proactive compaction cancellation\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );

        let _feature_gate = FeatureGateGuard::disable_reactive_compact();
        let temp = tempfile::tempdir().unwrap();
        let (api_base, compaction_started, compaction_closed) =
            serve_anthropic_sse_then_observe_compaction_close(COMPACTION_TRIGGER_SSE).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "proactive-compaction-cancellation".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let query_config = make_config(None, None);
        let original_messages = (0..12)
            .map(|index| Message::user(format!("history {index}")))
            .collect::<Vec<_>>();
        let mut messages = original_messages.clone();
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let cancel_token = tokio_util::sync::CancellationToken::new();
        let outcome = {
            tokio::pin!(compaction_started);
            let query = run_query_loop(
                &client,
                &mut messages,
                &[],
                &tool_ctx,
                &query_config,
                cost_tracker,
                Some(event_tx),
                cancel_token.clone(),
                None,
            );
            tokio::pin!(query);
            tokio::select! {
                outcome = &mut query => outcome,
                result = &mut compaction_started => {
                    result.expect("proactive compaction request must start");
                    cancel_token.cancel();
                    tokio::time::timeout(std::time::Duration::from_secs(1), &mut query)
                        .await
                        .expect("proactive compaction must observe cancellation")
                }
            }
        };
        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        tokio::time::timeout(std::time::Duration::from_secs(1), compaction_closed)
            .await
            .expect("cancelling proactive compaction must close its stream")
            .expect("proactive compaction server must observe receiver closure");
        assert_eq!(messages.len(), original_messages.len() + 1);
        for original in &original_messages {
            assert_eq!(
                messages
                    .iter()
                    .filter(|message| {
                        serde_json::to_string(message).unwrap()
                            == serde_json::to_string(original).unwrap()
                    })
                    .count(),
                1,
                "cancellation must restore each pre-compaction history message"
            );
        }
        assert_eq!(
            messages
                .iter()
                .filter(|message| {
                    message.uuid.as_deref()
                        == Some(durable_uuid(
                            &events,
                            "sampled before proactive compaction cancellation",
                        ))
                        && message.get_all_text()
                            == "sampled before proactive compaction cancellation"
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(
                        event,
                        QueryEvent::DurableMessage { message }
                            if message.uuid.as_deref() == Some(durable_uuid(&events, "sampled before proactive compaction cancellation"))
                    )
                })
                .count(),
            1
        );
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn reactive_compaction_cancellation_restores_and_finalizes_sampled_assistant() {
        let _feature_gate_lock = REACTIVE_COMPACT_FEATURE_GATE_LOCK.lock().await;

        struct FeatureGateGuard {
            prior: Option<std::ffi::OsString>,
        }

        impl FeatureGateGuard {
            fn enable_reactive_compact() -> Self {
                let prior = std::env::var_os("COVEN_CODE_FEATURE_REACTIVE_COMPACT");
                std::env::set_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT", "1");
                Self { prior }
            }
        }

        impl Drop for FeatureGateGuard {
            fn drop(&mut self) {
                match self.prior.take() {
                    Some(value) => std::env::set_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT", value),
                    None => std::env::remove_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT"),
                }
            }
        }

        const COMPACTION_TRIGGER_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"compaction-cancelled\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":180000,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"sampled before compaction cancellation\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );

        let _feature_gate = FeatureGateGuard::enable_reactive_compact();
        let temp = tempfile::tempdir().unwrap();
        let (api_base, compaction_started) =
            serve_anthropic_sse_then_wait_for_compaction(COMPACTION_TRIGGER_SSE).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "compaction-cancellation".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let query_config = make_config(None, None);
        let mut messages = (0..12)
            .map(|index| Message::user(format!("history {index}")))
            .collect::<Vec<_>>();
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let cancel_token = tokio_util::sync::CancellationToken::new();
        let mut events = Vec::new();
        let outcome = {
            tokio::pin!(compaction_started);
            let query = run_query_loop(
                &client,
                &mut messages,
                &[],
                &tool_ctx,
                &query_config,
                cost_tracker,
                Some(event_tx),
                cancel_token.clone(),
                None,
            );
            tokio::pin!(query);
            tokio::select! {
                outcome = &mut query => outcome,
                result = &mut compaction_started => {
                    result.expect("compaction request must start");
                    cancel_token.cancel();
                    tokio::time::timeout(std::time::Duration::from_secs(1), &mut query)
                        .await
                        .expect("reactive compaction must observe cancellation")
                }
            }
        };
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        let durable_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message }
                    if message.get_all_text() == "sampled before compaction cancellation")
            })
            .expect("cancelled compaction response must be durable");
        let durable_uuid = match &events[durable_index] {
            QueryEvent::DurableMessage { message } => message.uuid.clone(),
            _ => unreachable!("durable index points to durable event"),
        };
        assert_eq!(
            messages
                .iter()
                .filter(|message| {
                    message.uuid == durable_uuid
                        && message.get_all_text() == "sampled before compaction cancellation"
                })
                .count(),
            1
        );
    }

    #[tokio::test]
    async fn emergency_context_collapse_cancellation_restores_history_and_finalizes_once() {
        let _feature_gate_lock = REACTIVE_COMPACT_FEATURE_GATE_LOCK.lock().await;

        struct FeatureGateGuard {
            prior: Option<std::ffi::OsString>,
        }

        impl FeatureGateGuard {
            fn enable_reactive_compact() -> Self {
                let prior = std::env::var_os("COVEN_CODE_FEATURE_REACTIVE_COMPACT");
                std::env::set_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT", "1");
                Self { prior }
            }
        }

        impl Drop for FeatureGateGuard {
            fn drop(&mut self) {
                match self.prior.take() {
                    Some(value) => std::env::set_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT", value),
                    None => std::env::remove_var("COVEN_CODE_FEATURE_REACTIVE_COMPACT"),
                }
            }
        }

        const COLLAPSE_TRIGGER_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"collapse-cancelled\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":195000,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"sampled before collapse cancellation\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );

        let _feature_gate = FeatureGateGuard::enable_reactive_compact();
        let temp = tempfile::tempdir().unwrap();
        let (api_base, collapse_started) =
            serve_anthropic_sse_then_wait_for_compaction(COLLAPSE_TRIGGER_SSE).await;
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "test-key".to_string(),
            api_base,
            max_retries: 0,
            ..Default::default()
        })
        .unwrap();
        let cost_tracker = claurst_core::cost::CostTracker::new();
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "collapse-cancellation".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let query_config = make_config(None, None);
        let original_messages = (0..12)
            .map(|index| Message::user(format!("history {index}")))
            .collect::<Vec<_>>();
        let mut messages = original_messages.clone();
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();
        let cancel_token = tokio_util::sync::CancellationToken::new();
        let outcome = {
            tokio::pin!(collapse_started);
            let query = run_query_loop(
                &client,
                &mut messages,
                &[],
                &tool_ctx,
                &query_config,
                cost_tracker,
                Some(event_tx),
                cancel_token.clone(),
                None,
            );
            tokio::pin!(query);
            tokio::select! {
                outcome = &mut query => outcome,
                result = &mut collapse_started => {
                    result.expect("context-collapse request must start");
                    cancel_token.cancel();
                    tokio::time::timeout(std::time::Duration::from_secs(1), &mut query)
                        .await
                        .expect("context collapse must observe cancellation")
                }
            }
        };
        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }

        assert!(matches!(outcome, QueryOutcome::Cancelled));
        assert!(original_messages.iter().all(|original| {
            messages.iter().any(|message| {
                message.role == original.role && message.get_all_text() == original.get_all_text()
            })
        }));
        assert_eq!(
            messages
                .iter()
                .filter(|message| {
                    message.get_all_text() == "sampled before collapse cancellation"
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(event, QueryEvent::DurableMessage { message }
                        if message.get_all_text() == "sampled before collapse cancellation")
                })
                .count(),
            1
        );
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn provider_max_tokens_is_not_goal_continuation_eligible() {
        let provider = ScriptedProvider::new(vec![scripted_round(
            "max-tokens",
            vec![ContentBlock::Text {
                text: "partial response".to_string(),
            }],
            ProviderStopReason::MaxTokens,
        )]);

        let (outcome, events, _) = run_scripted_provider(provider).await;

        assert!(matches!(&outcome, QueryOutcome::MaxTokens { .. }));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        let durable: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                QueryEvent::DurableMessage { message } => Some(message),
                _ => None,
            })
            .collect();
        assert_eq!(durable.len(), 1);
        assert_eq!(
            durable[0].uuid.as_deref(),
            Some(durable_uuid(&events, "partial response"))
        );
        let _durable_index = events
            .iter()
            .position(|event| matches!(event, QueryEvent::DurableMessage { .. }))
            .unwrap();
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn provider_max_tokens_with_tool_blocks_does_not_execute_or_continue_tools() {
        let provider = ScriptedProvider::new(vec![
            scripted_round(
                "max-tokens-tool",
                vec![ContentBlock::ToolUse {
                    id: "write-fixture".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                }],
                ProviderStopReason::MaxTokens,
            ),
            scripted_round(
                "must-not-request-second-round",
                vec![ContentBlock::Text {
                    text: "unexpected continuation".to_string(),
                }],
                ProviderStopReason::EndTurn,
            ),
        ]);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];

        let (outcome, events, _) = run_scripted_provider_with(
            provider,
            make_config(None, None),
            Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            &tools,
        )
        .await;

        assert!(matches!(&outcome, QueryOutcome::MaxTokens { .. }));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                QueryEvent::ToolStart { tool_id, .. } | QueryEvent::ToolEnd { tool_id, .. }
                    if tool_id == "write-fixture"
            )
        }));
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "write-fixture"))))
                .count(),
            1
        );
    }

    #[tokio::test]
    async fn provider_max_tokens_runs_hard_post_model_veto_before_classification() {
        let provider = ScriptedProvider::new(vec![scripted_round(
            "max-tokens-veto",
            vec![ContentBlock::ToolUse {
                id: "write-fixture".to_string(),
                name: "WriteFixture".to_string(),
                input: serde_json::json!({}),
            }],
            ProviderStopReason::MaxTokens,
        )]);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];
        let mut tool_config = Config {
            provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
            permission_mode: PermissionMode::BypassPermissions,
            ..Config::default()
        };
        tool_config.hooks.insert(
            HookEvent::PostModelTurn,
            vec![HookEntry {
                command: "printf 'max-token veto ran' >&2; exit 2".to_string(),
                tool_filter: None,
                blocking: true,
            }],
        );

        let (outcome, events, _) =
            run_scripted_provider_with(provider, make_config(None, None), tool_config, &tools)
                .await;

        assert!(
            matches!(&outcome, QueryOutcome::Error(error) if error.to_string().contains("max-token veto ran"))
        );
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        assert!(!matches!(&outcome, QueryOutcome::MaxTokens { .. }));
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                QueryEvent::ToolStart { tool_id, .. } | QueryEvent::ToolEnd { tool_id, .. }
                    if tool_id == "write-fixture"
            )
        }));
        let _durable_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "write-fixture")))
            })
            .expect("vetoed max_tokens response must be durable");
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn provider_content_filtered_and_unknown_stops_are_non_successful_and_durable() {
        for (id, stop_reason) in [
            (
                "provider-content-filtered",
                ProviderStopReason::ContentFiltered,
            ),
            (
                "provider-unknown-stop",
                ProviderStopReason::Other("provider_extension".to_string()),
            ),
        ] {
            let provider = ScriptedProvider::new(vec![scripted_round(
                id,
                vec![ContentBlock::Text {
                    text: "sampled terminal text".to_string(),
                }],
                stop_reason,
            )]);

            let (outcome, events, messages) = run_scripted_provider(provider).await;

            assert!(matches!(&outcome, QueryOutcome::Error(_)));
            assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
            let _durable_index = events
                .iter()
                .position(|event| {
                    matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "sampled terminal text")))
                })
                .expect("terminal provider response must be durable");
            assert!(events
                .iter()
                .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
            assert_eq!(
                messages
                    .iter()
                    .filter(|message| message.uuid.as_deref()
                        == Some(durable_uuid(&events, "sampled terminal text")))
                    .count(),
                1
            );
        }
    }

    #[tokio::test]
    async fn provider_budget_exhaustion_with_tool_blocks_does_not_execute_or_continue_tools() {
        let provider = ScriptedProvider::new(vec![
            scripted_round(
                "over-budget-tool",
                vec![ContentBlock::ToolUse {
                    id: "write-fixture".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                }],
                ProviderStopReason::ToolUse,
            ),
            scripted_round(
                "must-not-request-second-round",
                vec![ContentBlock::Text {
                    text: "unexpected continuation".to_string(),
                }],
                ProviderStopReason::EndTurn,
            ),
        ]);
        let mut query_config = make_config(None, None);
        query_config.max_budget_usd = Some(0.0);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];

        let (outcome, events, _) = run_scripted_provider_with(
            provider,
            query_config,
            Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            &tools,
        )
        .await;

        assert!(matches!(&outcome, QueryOutcome::BudgetExceeded { .. }));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                QueryEvent::ToolStart { tool_id, .. } | QueryEvent::ToolEnd { tool_id, .. }
                    if tool_id == "write-fixture"
            )
        }));
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "write-fixture"))))
                .count(),
            1
        );
    }

    #[tokio::test]
    async fn provider_tool_use_without_tool_blocks_is_a_non_successful_terminal() {
        let provider = ScriptedProvider::new(vec![scripted_round(
            "malformed-tool-use",
            Vec::new(),
            ProviderStopReason::ToolUse,
        )]);

        let (outcome, events, _) = run_scripted_provider(provider).await;

        assert!(matches!(&outcome, QueryOutcome::Error(_)));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        let _durable_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "")))
            })
            .expect("malformed provider terminal must be durable");
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn max_turn_exhaustion_after_a_tool_round_is_not_goal_continuation_eligible() {
        let provider = ScriptedProvider::new(vec![scripted_round(
            "max-turn-tool-round",
            vec![ContentBlock::ToolUse {
                id: "write-fixture".to_string(),
                name: "WriteFixture".to_string(),
                input: serde_json::json!({}),
            }],
            ProviderStopReason::ToolUse,
        )]);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];
        let mut config = make_config(None, None);
        config.max_turns = 1;

        let (outcome, events, messages) = run_scripted_provider_with(
            provider,
            config,
            Config {
                provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
                permission_mode: PermissionMode::BypassPermissions,
                ..Config::default()
            },
            &tools,
        )
        .await;

        assert!(matches!(&outcome, QueryOutcome::Error(_)));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        assert_eq!(
            events
                .iter()
                .filter(|event| {
                    matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "write-fixture")))
                })
                .count(),
            1
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| match event {
                    QueryEvent::DurableMessage { message } => is_tool_result_carrier(message),
                    _ => false,
                })
                .count(),
            1
        );
        assert_eq!(
            messages
                .iter()
                .filter(|message| message.uuid.as_deref()
                    == Some(durable_uuid(&events, "write-fixture")))
                .count(),
            1
        );
    }

    #[tokio::test]
    async fn provider_hard_post_model_veto_prevents_tool_execution_and_end_turn() {
        let provider = ScriptedProvider::new(vec![
            scripted_round(
                "vetoed-tool-round",
                vec![ContentBlock::ToolUse {
                    id: "write-fixture".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                }],
                ProviderStopReason::ToolUse,
            ),
            scripted_round(
                "must-not-request-second-round",
                vec![ContentBlock::Text {
                    text: "unexpected continuation".to_string(),
                }],
                ProviderStopReason::EndTurn,
            ),
        ]);
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];
        let mut tool_config = Config {
            provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
            permission_mode: PermissionMode::BypassPermissions,
            ..Config::default()
        };
        tool_config.hooks.insert(
            HookEvent::PostModelTurn,
            vec![HookEntry {
                command: "printf 'blocked by policy' >&2; exit 2".to_string(),
                tool_filter: None,
                blocking: true,
            }],
        );

        let (outcome, events, _) =
            run_scripted_provider_with(provider, make_config(None, None), tool_config, &tools)
                .await;

        assert!(
            matches!(&outcome, QueryOutcome::Error(error) if error.to_string().contains("blocked by policy"))
        );
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                QueryEvent::ToolStart { tool_id, .. } | QueryEvent::ToolEnd { tool_id, .. }
                    if tool_id == "write-fixture"
            )
        }));
        let _durable_index = events
            .iter()
            .position(|event| {
                matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_deref() == Some(durable_uuid(&events, "write-fixture")))
            })
            .expect("vetoed provider response must be durable");
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn provider_stall_recovery_exhaustion_is_not_a_successful_end_turn() {
        let provider = ScriptedProvider::new(vec![
            scripted_round("stall-1", Vec::new(), ProviderStopReason::EndTurn),
            scripted_round("stall-2", Vec::new(), ProviderStopReason::EndTurn),
            scripted_round("stall-exhausted", Vec::new(), ProviderStopReason::EndTurn),
        ]);

        let (outcome, events, _) = run_scripted_provider(provider).await;

        assert!(matches!(&outcome, QueryOutcome::Error(_)));
        assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
        let final_durable = events.iter().rev().find_map(|event| match event {
            QueryEvent::DurableMessage { message } => Some(message),
            _ => None,
        });
        assert_eq!(
            final_durable.map(Message::get_all_text).as_deref(),
            Some("(no response — model ended the turn with stop_reason \"end_turn\")")
        );
    }

    #[tokio::test]
    async fn hard_post_model_hook_veto_is_not_goal_continuation_eligible() {
        const END_TURN_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"hard-veto\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"sampled answer\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":2}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        let mut tool_config = Config::default();
        tool_config.hooks.insert(
            HookEvent::PostModelTurn,
            vec![HookEntry {
                command: "printf 'blocked by policy' >&2; exit 2".to_string(),
                tool_filter: None,
                blocking: true,
            }],
        );

        let (outcome, events, _) = run_anthropic_sse(END_TURN_SSE, tool_config).await;

        match outcome {
            QueryOutcome::Error(error) => {
                assert!(error.to_string().contains("blocked by policy"));
            }
            other => panic!("hard hook veto must be non-success, got {other:?}"),
        }
        let _durable_index = events
            .iter()
            .position(|event| matches!(event, QueryEvent::DurableMessage { .. }))
            .unwrap();
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn anthropic_content_filtered_and_unknown_stops_are_non_successful_and_durable() {
        const CONTENT_FILTERED_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-content-filtered\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"filtered terminal text\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"content_filtered\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        const UNKNOWN_STOP_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"anthropic-unknown-stop\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"unknown terminal text\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"provider_extension\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );

        for (text, body) in [
            ("filtered terminal text", CONTENT_FILTERED_SSE),
            ("unknown terminal text", UNKNOWN_STOP_SSE),
        ] {
            let (outcome, events, messages) = run_anthropic_sse(body, Config::default()).await;

            assert!(matches!(&outcome, QueryOutcome::Error(_)));
            assert!(!matches!(&outcome, QueryOutcome::EndTurn { .. }));
            let durable_index = events
                .iter()
                .position(|event| {
                    matches!(event, QueryEvent::DurableMessage { message } if message.get_all_text() == text)
                })
                .expect("terminal Anthropic response must be durable");
            assert!(events
                .iter()
                .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
            let durable_uuid = match &events[durable_index] {
                QueryEvent::DurableMessage { message } => message.uuid.clone(),
                _ => unreachable!("durable index points to durable event"),
            };
            assert_eq!(
                messages
                    .iter()
                    .filter(|message| message.uuid == durable_uuid)
                    .count(),
                1
            );
        }
    }

    #[tokio::test]
    async fn malformed_tool_use_terminal_keeps_cumulative_snapshot_durable() {
        const TOOL_USE_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"write-round\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"tool_use\",\"id\":\"write-fixture\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"tool_use\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        const MALFORMED_TOOL_USE_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"malformed-tool-use\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1,\"output_tokens\":0}}}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"tool_use\"},\"usage\":{\"output_tokens\":1}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        let temp = tempfile::tempdir().unwrap();
        init_test_repository(temp.path());
        let mut tool_config = Config {
            auto_commits: Some(true),
            permission_mode: PermissionMode::BypassPermissions,
            ..Config::default()
        };
        tool_config.project_dir = Some(temp.path().to_path_buf());
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];

        let (outcome, events, messages) = run_anthropic_sse_sequence_in_worktree(
            vec![TOOL_USE_SSE, MALFORMED_TOOL_USE_SSE],
            temp.path(),
            tool_config,
            make_config(None, None),
            &tools,
        )
        .await;

        assert!(matches!(outcome, QueryOutcome::Error(_)));
        let final_durable = events.iter().rev().find_map(|event| match event {
            QueryEvent::DurableMessage { message } if message.role == Role::Assistant => {
                Some(message)
            }
            _ => None,
        });
        let final_durable = final_durable.expect("malformed terminal must be durable");
        assert!(final_durable.snapshot_patch.is_some());
        let final_uuid = final_durable.uuid.clone().expect("stable assistant UUID");
        assert!(messages.iter().any(|message| {
            message.uuid.as_ref() == Some(&final_uuid) && message.snapshot_patch.is_some()
        }));
        let _durable_index = events
            .iter()
            .position(|event| matches!(event, QueryEvent::DurableMessage { message } if message.uuid.as_ref() == Some(&final_uuid)))
            .unwrap();
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn budget_exhaustion_finalizes_sampled_response_with_cumulative_snapshot() {
        const ZERO_COST_TOOL_USE_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"budget-write-round\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":0,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"tool_use\",\"id\":\"write-fixture\",\"name\":\"WriteFixture\",\"input\":{}}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"tool_use\"},\"usage\":{\"output_tokens\":0}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        const EXPENSIVE_END_TURN_SSE: &str = concat!(
            "event: message_start\n",
            "data: {\"message\":{\"id\":\"budget-terminal\",\"model\":\"claude-test\",\"usage\":{\"input_tokens\":1000000,\"output_tokens\":0}}}\n\n",
            "event: content_block_start\n",
            "data: {\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n",
            "event: content_block_delta\n",
            "data: {\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\"sampled before budget stop\"}}\n\n",
            "event: content_block_stop\n",
            "data: {\"index\":0}\n\n",
            "event: message_delta\n",
            "data: {\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":1000000}}\n\n",
            "event: message_stop\n",
            "data: {}\n\n",
        );
        let temp = tempfile::tempdir().unwrap();
        init_test_repository(temp.path());
        let mut tool_config = Config {
            auto_commits: Some(true),
            permission_mode: PermissionMode::BypassPermissions,
            ..Config::default()
        };
        tool_config.project_dir = Some(temp.path().to_path_buf());
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];
        let mut query_config = make_config(None, None);
        query_config.max_budget_usd = Some(0.000_001);

        let (outcome, events, messages) = run_anthropic_sse_sequence_in_worktree(
            vec![ZERO_COST_TOOL_USE_SSE, EXPENSIVE_END_TURN_SSE],
            temp.path(),
            tool_config,
            query_config,
            &tools,
        )
        .await;

        assert!(matches!(outcome, QueryOutcome::BudgetExceeded { .. }));
        let final_durable = events.iter().rev().find_map(|event| match event {
            QueryEvent::DurableMessage { message }
                if message.get_all_text() == "sampled before budget stop" =>
            {
                Some(message)
            }
            _ => None,
        });
        let final_durable = final_durable.expect("budget terminal assistant must be durable");
        assert!(final_durable.snapshot_patch.is_some());
        let final_uuid = final_durable.uuid.as_ref().expect("stable assistant UUID");
        assert_eq!(
            messages
                .iter()
                .filter(|message| message.uuid.as_ref() == Some(final_uuid))
                .count(),
            1
        );
        assert!(messages.iter().any(|message| {
            message.uuid.as_ref() == Some(final_uuid)
                && message.get_all_text() == "sampled before budget stop"
                && message.snapshot_patch.is_some()
        }));
        assert!(matches!(
            events.last(),
            Some(QueryEvent::DurableMessage { message })
                if message.uuid.as_ref() == Some(final_uuid)
        ));
        assert!(!events
            .iter()
            .any(|event| matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[tokio::test]
    async fn provider_dispatch_emits_finalized_durable_messages_exactly_once() {
        let temp = tempfile::tempdir().unwrap();
        init_test_repository(temp.path());

        let rounds = vec![
            scripted_round(
                "tool-round",
                vec![ContentBlock::ToolUse {
                    id: "write-fixture".to_string(),
                    name: "WriteFixture".to_string(),
                    input: serde_json::json!({}),
                }],
                ProviderStopReason::ToolUse,
            ),
            scripted_round("stall-round-1", Vec::new(), ProviderStopReason::EndTurn),
            scripted_round("stall-round-2", Vec::new(), ProviderStopReason::EndTurn),
            scripted_round("final-round", Vec::new(), ProviderStopReason::EndTurn),
        ];
        let mut registry = claurst_api::ProviderRegistry::new();
        registry.register(Arc::new(ScriptedProvider::new(rounds)));

        let mut config = make_config(None, None);
        config.model = "scripted".to_string();
        config.provider_registry = Some(Arc::new(registry));

        let cost_tracker = claurst_core::cost::CostTracker::new();
        let mut tool_config = Config {
            provider: Some(SCRIPTED_PROVIDER_ID.to_string()),
            auto_commits: Some(true),
            permission_mode: PermissionMode::BypassPermissions,
            ..Config::default()
        };
        tool_config.project_dir = Some(temp.path().to_path_buf());
        let tool_ctx = ToolContext {
            working_dir: temp.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: cost_tracker.clone(),
            session_id: "durable-journal".to_string(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: tool_config,
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        let client = claurst_api::AnthropicClient::new(claurst_api::client::ClientConfig {
            api_key: "unused-test-key".to_string(),
            ..Default::default()
        })
        .unwrap();
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(WriteFixtureTool)];
        let mut messages = vec![Message::user("write the fixture")];
        let (event_tx, mut event_rx) = mpsc::unbounded_channel();

        let outcome = run_query_loop(
            &client,
            &mut messages,
            &tools,
            &tool_ctx,
            &config,
            cost_tracker,
            Some(event_tx),
            tokio_util::sync::CancellationToken::new(),
            None,
        )
        .await;
        assert!(matches!(outcome, QueryOutcome::Error(_)));

        let mut events = Vec::new();
        while let Ok(event) = event_rx.try_recv() {
            events.push(event);
        }
        let durable: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                QueryEvent::DurableMessage { message } => Some(message.clone()),
                _ => None,
            })
            .collect();

        assert_eq!(durable.len(), 3);
        let assistant_ids: Vec<_> = durable
            .iter()
            .filter(|message| matches!(message.role, Role::Assistant))
            .map(|message| message.uuid.as_deref().unwrap())
            .collect();
        assert_eq!(assistant_ids.len(), 2);
        assert_ne!(assistant_ids[0], assistant_ids[1]);
        for id in &assistant_ids {
            uuid::Uuid::parse_str(id).expect("attempt UUID");
        }
        assert!(!durable[0].get_tool_use_blocks().is_empty());
        assert!(is_tool_result_carrier(&durable[1]));
        assert_eq!(
            durable[2].get_all_text(),
            "(no response — model ended the turn with stop_reason \"end_turn\")"
        );
        assert!(durable[2].snapshot_patch.is_some());
        assert_eq!(unique_message_fingerprints(&durable).len(), durable.len());
        let _final_durable_index = events
            .iter()
            .rposition(|event| matches!(event, QueryEvent::DurableMessage { .. }))
            .unwrap();
        assert!(events
            .iter()
            .all(|event| !matches!(event, QueryEvent::TurnComplete { .. })));
    }

    #[test]
    fn parses_github_origin_repo_slug_without_credentials() {
        assert_eq!(
            parse_origin_repo_slug("https://github.com/OpenCoven/coven-code.git").as_deref(),
            Some("OpenCoven/coven-code")
        );
        assert_eq!(
            parse_origin_repo_slug("git@github.com:OpenCoven/coven-code.git").as_deref(),
            Some("OpenCoven/coven-code")
        );
        assert_eq!(
            parse_origin_repo_slug("https://token@example@github.com/OpenCoven/coven-code.git")
                .as_deref(),
            Some("OpenCoven/coven-code")
        );
        assert_eq!(
            parse_origin_repo_slug("https://github.com/OpenCoven/coven-code.git?token=SECRET")
                .as_deref(),
            Some("OpenCoven/coven-code")
        );
        assert_eq!(
            parse_origin_repo_slug("https://github.com/OpenCoven/coven-code.git#token=SECRET")
                .as_deref(),
            Some("OpenCoven/coven-code")
        );
    }

    #[test]
    fn ignores_origin_strings_without_repo_slug() {
        assert!(parse_origin_repo_slug("").is_none());
        assert!(parse_origin_repo_slug("https://github.com/OpenCoven").is_none());
        assert!(parse_origin_repo_slug("https://github.com/token@example").is_none());
    }

    #[test]
    fn reads_session_memory_provenance_from_git_metadata() {
        let temp = tempfile::tempdir().unwrap();
        let workspace = temp.path().join("workspace");
        std::fs::create_dir(&workspace).unwrap();
        std::fs::create_dir(workspace.join(".git")).unwrap();
        std::fs::create_dir_all(workspace.join(".git").join("refs").join("heads")).unwrap();
        std::fs::write(
            workspace.join(".git").join("config"),
            "[remote \"origin\"]\n    url = https://github.com/OpenCoven/coven-code.git\n",
        )
        .unwrap();
        std::fs::write(
            workspace.join(".git").join("HEAD"),
            "ref: refs/heads/main\n",
        )
        .unwrap();
        std::fs::write(
            workspace
                .join(".git")
                .join("refs")
                .join("heads")
                .join("main"),
            "0123456789abcdef0123456789abcdef01234567\n",
        )
        .unwrap();
        let provenance = build_session_memory_provenance("session-1", &workspace);

        assert_eq!(
            provenance.source_repo.as_deref(),
            Some("OpenCoven/coven-code")
        );
        assert_eq!(
            provenance.source_commit.as_deref(),
            Some("0123456789abcdef0123456789abcdef01234567")
        );
    }

    #[test]
    fn reads_linked_worktree_metadata_from_common_git_dir() {
        let temp = tempfile::tempdir().unwrap();
        let workspace = temp.path().join("workspace");
        let common_git_dir = temp.path().join("main.git");
        let git_dir = common_git_dir.join("worktrees").join("workspace");
        std::fs::create_dir(&workspace).unwrap();
        std::fs::create_dir_all(common_git_dir.join("refs").join("heads")).unwrap();
        std::fs::create_dir_all(&git_dir).unwrap();
        std::fs::write(
            workspace.join(".git"),
            format!("gitdir: {}\n", git_dir.display()),
        )
        .unwrap();
        std::fs::write(
            common_git_dir.join("config"),
            "[remote \"origin\"]\n    url = git@github.com:OpenCoven/coven-code.git\n",
        )
        .unwrap();
        std::fs::write(git_dir.join("commondir"), "../..\n").unwrap();
        std::fs::write(git_dir.join("HEAD"), "ref: refs/heads/main\n").unwrap();
        std::fs::write(
            common_git_dir.join("refs").join("heads").join("main"),
            "abcdef0123456789abcdef0123456789abcdef01\n",
        )
        .unwrap();

        let provenance = build_session_memory_provenance("session-1", &workspace);

        assert_eq!(
            provenance.source_repo.as_deref(),
            Some("OpenCoven/coven-code")
        );
        assert_eq!(
            provenance.source_commit.as_deref(),
            Some("abcdef0123456789abcdef0123456789abcdef01")
        );
    }

    // ---- build_system_prompt tests ------------------------------------------

    #[test]
    fn test_system_prompt_default_when_empty() {
        // The default prompt (no custom system prompt set) should include the
        // Coven Code attribution and standard sections.
        let cfg = make_config(None, None);
        let prompt = build_system_prompt(&cfg);
        if let SystemPrompt::Text(text) = prompt {
            assert!(
                text.contains("Coven") || text.contains("Claude agent"),
                "Default prompt should contain attribution: {}",
                text
            );
            assert!(
                text.contains(claurst_core::system_prompt::SYSTEM_PROMPT_DYNAMIC_BOUNDARY),
                "Default prompt must contain the dynamic boundary marker"
            );
        } else {
            panic!("Expected SystemPrompt::Text");
        }
    }

    #[test]
    fn test_system_prompt_with_custom() {
        // A custom system prompt is injected into the cacheable section as
        // <custom_instructions>; the default sections are still present.
        let cfg = make_config(Some("You are a code reviewer."), None);
        let prompt = build_system_prompt(&cfg);
        if let SystemPrompt::Text(text) = prompt {
            assert!(
                text.contains("You are a code reviewer."),
                "Custom prompt text should appear in the output"
            );
            assert!(
                text.contains("Coven") || text.contains("Claude agent"),
                "Default attribution should still be present"
            );
        } else {
            panic!("Expected SystemPrompt::Text");
        }
    }

    #[test]
    fn test_system_prompt_with_append() {
        // Appended text lands after the dynamic boundary.
        let cfg = make_config(Some("Base prompt."), Some("Additional context."));
        let prompt = build_system_prompt(&cfg);
        if let SystemPrompt::Text(text) = prompt {
            assert!(text.contains("Base prompt."));
            assert!(text.contains("Additional context."));
            // append_system_prompt appears after the boundary
            let boundary_pos = text
                .find(claurst_core::system_prompt::SYSTEM_PROMPT_DYNAMIC_BOUNDARY)
                .expect("boundary must exist");
            let append_pos = text.find("Additional context.").unwrap();
            assert!(
                append_pos > boundary_pos,
                "Appended text must appear after the dynamic boundary"
            );
        } else {
            panic!("Expected SystemPrompt::Text");
        }
    }

    #[test]
    fn test_system_prompt_append_only() {
        // When only append is set, default sections are present plus the
        // appended text after the dynamic boundary.
        let cfg = make_config(None, Some("Appended text."));
        let prompt = build_system_prompt(&cfg);
        if let SystemPrompt::Text(text) = prompt {
            assert!(
                text.contains("Appended text."),
                "Appended text must appear in the prompt"
            );
            let boundary_pos = text
                .find(claurst_core::system_prompt::SYSTEM_PROMPT_DYNAMIC_BOUNDARY)
                .expect("boundary must exist");
            let append_pos = text.find("Appended text.").unwrap();
            assert!(
                append_pos > boundary_pos,
                "Appended text must appear after the dynamic boundary"
            );
        } else {
            panic!("Expected SystemPrompt::Text");
        }
    }

    #[test]
    fn test_system_prompt_with_custom_output_style_prompt() {
        let mut cfg = make_config(None, None);
        cfg.output_style_prompt = Some("Answer like a pirate.".to_string());
        let prompt = build_system_prompt(&cfg);
        if let SystemPrompt::Text(text) = prompt {
            assert!(text.contains("Answer like a pirate."));
        } else {
            panic!("Expected SystemPrompt::Text");
        }
    }

    // ---- QueryConfig tests --------------------------------------------------

    #[test]
    fn test_query_config_clone() {
        let cfg = make_config(Some("test"), Some("append"));
        let cloned = cfg.clone();
        assert_eq!(cloned.model, "claude-sonnet-4-6");
        assert_eq!(cloned.max_tokens, 4096);
        assert_eq!(cloned.system_prompt, Some("test".to_string()));
    }

    #[test]
    fn test_managed_agent_manager_model_overrides_by_default() {
        let mut cfg = make_config(None, None);
        cfg.managed_agents = Some(claurst_core::ManagedAgentConfig {
            enabled: true,
            manager_model: "openai/gpt-4o".to_string(),
            executor_model: "anthropic/claude-sonnet-4-6".to_string(),
            executor_max_turns: 10,
            max_concurrent_executors: 4,
            budget_split: claurst_core::BudgetSplitPolicy::SharedPool,
            total_budget_usd: None,
            preset_name: None,
            executor_isolation: false,
        });

        assert_eq!(selected_model_for_query(&cfg), "openai/gpt-4o");
    }

    #[test]
    fn test_explicit_model_selection_blocks_managed_agent_override() {
        let mut cfg = make_config(None, None);
        cfg.preserve_selected_model = true;
        cfg.managed_agents = Some(claurst_core::ManagedAgentConfig {
            enabled: true,
            manager_model: "openai/gpt-4o".to_string(),
            executor_model: "anthropic/claude-sonnet-4-6".to_string(),
            executor_max_turns: 10,
            max_concurrent_executors: 4,
            budget_split: claurst_core::BudgetSplitPolicy::SharedPool,
            total_budget_usd: None,
            preset_name: None,
            executor_isolation: false,
        });

        assert_eq!(selected_model_for_query(&cfg), "claude-sonnet-4-6");
    }

    // ---- QueryOutcome variant tests -----------------------------------------

    #[test]
    fn test_query_outcome_debug() {
        // Ensure the enum variants can be created and debug-formatted
        let outcome = QueryOutcome::Cancelled;
        let s = format!("{:?}", outcome);
        assert!(s.contains("Cancelled"));

        let err_outcome = QueryOutcome::Error(claurst_core::error::ClaudeError::RateLimit {
            retry_after_secs: None,
            message: None,
        });
        let s2 = format!("{:?}", err_outcome);
        assert!(s2.contains("Error"));
    }

    #[test]
    fn test_typed_rate_limit_uses_fallback() {
        let err = claurst_core::error::ClaudeError::RateLimit {
            retry_after_secs: Some(30),
            message: None,
        };
        assert!(is_fallback_worthy_api_error(&err));
    }

    #[test]
    fn test_generic_429_error_is_enriched_for_model_tier_limits() {
        let err = claurst_core::error::ClaudeError::ApiStatus {
            status: 429,
            message: "Error".to_string(),
        };

        let enriched = enrich_error_notice(
            err,
            "anthropic",
            "claude-sonnet-4-6",
            Some("claude-code-10 [max]"),
        );

        let text = enriched.to_string();
        assert!(text.contains("Claude rate limit"));
        assert!(text.contains("claude-sonnet-4-6"));
        assert!(text.contains("claude-code-10 [max]"));
        assert!(text.contains("imported Claude Code credential"));
        assert!(text.contains("not running the `claude` CLI"));
        assert!(text.contains("model-tier"));
        assert!(text.contains("Haiku"));
    }

    #[test]
    fn test_provider_rate_limit_error_is_enriched_for_model_tier_limits() {
        let err: claurst_core::error::ClaudeError =
            claurst_api::provider_error::ProviderError::RateLimited {
                provider: claurst_core::ProviderId::new("anthropic"),
                retry_after: Some(60),
            }
            .into();

        let enriched = enrich_error_notice(err, "anthropic", "claude-opus-4-8", None);

        // Structure survives enrichment so the TUI recovery flow can use it.
        match &enriched {
            claurst_core::error::ClaudeError::RateLimit {
                retry_after_secs, ..
            } => assert_eq!(*retry_after_secs, Some(60)),
            other => panic!("expected RateLimit, got {other:?}"),
        }

        let text = enriched.to_string();
        assert!(text.contains("Claude rate limit"));
        assert!(text.contains("claude-opus-4-8"));
        assert!(text.contains("model-tier"));
        assert!(text.contains("Haiku"));
        assert!(text.contains("resets in 1m"));
    }

    #[test]
    fn test_format_reset_delay_buckets() {
        assert_eq!(format_reset_delay(45), "45s");
        assert_eq!(format_reset_delay(60), "1m");
        assert_eq!(format_reset_delay(200), "3m 20s");
        assert_eq!(format_reset_delay(3600), "1h");
        assert_eq!(format_reset_delay(4320), "1h 12m");
    }

    #[test]
    fn test_build_provider_options_for_google_gemini_3() {
        let options = build_provider_options(
            "google",
            "gemini-3-flash-preview",
            Some(claurst_core::effort::EffortLevel::High),
            None,
        );
        assert_eq!(
            options["thinkingConfig"]["thinkingLevel"],
            serde_json::json!("high")
        );
        assert_eq!(
            options["thinkingConfig"]["includeThoughts"],
            serde_json::json!(true)
        );
    }

    #[test]
    fn test_build_provider_options_for_openrouter_gpt5() {
        let options = build_provider_options(
            "openrouter",
            "gpt-5.4",
            Some(claurst_core::effort::EffortLevel::Medium),
            None,
        );
        assert_eq!(options["reasoningEffort"], serde_json::json!("medium"));
        assert_eq!(options["textVerbosity"], serde_json::json!("low"));
        assert_eq!(options["usage"]["include"], serde_json::json!(true));
    }

    #[test]
    fn test_build_provider_options_for_bedrock_anthropic() {
        let options = build_provider_options(
            "amazon-bedrock",
            "anthropic.claude-sonnet-4-6-v1",
            Some(claurst_core::effort::EffortLevel::High),
            Some(10_000),
        );
        assert_eq!(
            options["reasoningConfig"]["budgetTokens"],
            serde_json::json!(10_000)
        );
    }

    #[test]
    fn turn_complete_emission_skips_intermediate_tool_turns() {
        assert!(!should_emit_turn_complete("tool_use", 0, false));
    }

    #[test]
    fn turn_complete_emission_skips_max_tokens_turns() {
        assert!(!should_emit_turn_complete("max_tokens", 0, false));
        assert!(!should_emit_turn_complete("max_tokens", 1, false));
        assert!(!should_emit_turn_complete("max_tokens", 2, false));
        assert!(!should_emit_turn_complete(
            "max_tokens",
            MAX_TOKENS_RECOVERY_LIMIT,
            false
        ));
    }

    #[test]
    fn turn_complete_emission_skips_non_successful_terminal_reasons() {
        assert!(should_emit_turn_complete("end_turn", 0, false));
        assert!(should_emit_turn_complete("stop_sequence", 0, false));
        assert!(!should_emit_turn_complete("content_filtered", 0, false));
        assert!(!should_emit_turn_complete("unknown_stop", 0, false));
    }

    #[test]
    fn turn_complete_emission_skips_stall_recovery_rounds() {
        // While a stall nudge is pending the turn is not over, exactly like
        // an in-budget max_tokens recovery round.
        assert!(!should_emit_turn_complete("end_turn", 0, true));
        assert!(should_emit_turn_complete("end_turn", 0, false));
    }

    #[test]
    fn stalled_announcement_matches_observed_stall_transcripts() {
        // Real assistant texts from the issue #165 session that ended with
        // end_turn, zero tool calls, and no follow-through.
        assert!(is_stalled_announcement(""));
        assert!(is_stalled_announcement("   \n"));
        assert!(is_stalled_announcement(
            "Writing the CLI uninstall module now."
        ));
        assert!(is_stalled_announcement(
            "Now writing the CLI uninstall module."
        ));
        assert!(is_stalled_announcement(
            "Enough exploration — I have the wiring points. Writing the CLI \
             command now. First the self-contained module with unit-tested \
             pure helpers, then I'll wire it into `main.rs`."
        ));
        assert!(is_stalled_announcement(
            "Implementing now. Let me confirm available deps, then write the \
             CLI uninstall module."
        ));
        assert!(is_stalled_announcement(
            "I'll start by reading the manifest, then patch the loader."
        ));
    }

    #[test]
    fn stalled_announcement_ignores_completed_work_statements() {
        assert!(!is_stalled_announcement(
            "Done — the module is wired in and all tests pass."
        ));
        assert!(!is_stalled_announcement(
            "The uninstall command is implemented and tested; docs updated."
        ));
        // "now" inside a completion statement is not an announcement.
        assert!(!is_stalled_announcement("All 45 tests pass now."));
    }

    #[test]
    fn stalled_announcement_respects_deliberate_handoffs() {
        assert!(!is_stalled_announcement("Should I also update the docs?"));
        assert!(!is_stalled_announcement(
            "Let me know if you want the Windows path covered too."
        ));
        assert!(!is_stalled_announcement("I'll wait for your review."));
        assert!(!is_stalled_announcement(
            "Two options: (1) uninstall module in the CLI, (2) Cave-side \
             cleanup. Which do you want?"
        ));
        assert!(!is_stalled_announcement(
            "Waiting on your decision before touching main.rs."
        ));
    }

    #[test]
    fn stall_recovery_disable_env_is_read() {
        // Not set in the test environment → enabled by default.
        assert!(stall_recovery_enabled());
    }
    #[tokio::test]
    async fn plugin_hooks_use_tool_context_project_without_refreshing_globals() {
        // This is the only query test that writes the plugin hook registry. A
        // unique matcher keeps other concurrently running tool tests unaffected.
        struct ResetHooks;
        impl Drop for ResetHooks {
            fn drop(&mut self) {
                claurst_plugins::set_global_hooks(Default::default());
            }
        }
        let _reset = ResetHooks;
        let owner = tempfile::tempdir().unwrap();
        let foreign = tempfile::tempdir().unwrap();
        let mut registry = claurst_plugins::HookRegistry::new();
        for event in ["PreToolUse", "PostToolUse"] {
            let command = if cfg!(windows) {
                format!("echo ran>\"%CLAUDE_PLUGIN_ROOT%\\{event}\"")
            } else {
                format!("printf ran > \"$CLAUDE_PLUGIN_ROOT/{event}\"")
            };
            let hook = claurst_plugins::RegisteredHook {
                command,
                matcher: Some("PluginScopeFixture".into()),
                blocking: false,
                plugin_root: owner.path().to_string_lossy().into_owned(),
                plugin_name: "fixture".into(),
                plugin_source: "fixture@project".into(),
                plugin_capabilities: Some(vec!["shell".into()]),
                scope: claurst_plugins::hooks::HookScope::Project(
                    owner.path().canonicalize().unwrap(),
                ),
            };
            registry.insert(event.into(), vec![hook]);
        }
        claurst_plugins::set_global_hooks(registry);
        let mut ctx = ToolContext {
            working_dir: foreign.path().to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: CostTracker::new(),
            session_id: "plugin-hook-scope".into(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        };
        // Exercise the actual tool path, without a provider call or cache refresh.
        for (working_dir, allowed) in [
            (foreign.path(), false),
            (owner.path(), true),
            (foreign.path(), false),
        ] {
            ctx.working_dir = working_dir.to_path_buf();
            let results = execute_tool_blocks_with_hooks(
                vec![(
                    "scope-test".into(),
                    "PluginScopeFixture".into(),
                    serde_json::json!({}),
                )],
                &[],
                &ctx,
                None,
            )
            .await;
            assert_eq!(results.len(), 1);
            for event in ["PreToolUse", "PostToolUse"] {
                let marker = owner.path().join(event);
                assert_eq!(
                    marker.exists(),
                    allowed,
                    "{event} crossed caller project boundary"
                );
                if allowed {
                    std::fs::remove_file(marker).unwrap();
                }
            }
        }
    }

    fn scheduling_ctx(working_dir: &std::path::Path) -> ToolContext {
        ToolContext {
            working_dir: working_dir.to_path_buf(),
            permission_mode: PermissionMode::BypassPermissions,
            permission_handler: Arc::new(AutoPermissionHandler {
                mode: PermissionMode::BypassPermissions,
            }),
            cost_tracker: CostTracker::new(),
            session_id: "tool-scheduling".into(),
            goal_turn: Default::default(),
            file_history: Default::default(),
            current_turn: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
            non_interactive: true,
            mcp_manager: None,
            config: Config::default(),
            managed_agent_config: None,
            completion_notifier: None,
            pending_permissions: None,
            permission_manager: None,
            user_question_tx: None,
        }
    }

    fn assert_all_succeeded(results: &[ContentBlock]) {
        let text = serde_json::to_string(results).unwrap();
        assert!(!text.contains(r#""is_error":true"#), "{text}");
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn every_edit_to_one_file_in_a_response_lands() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("notes.txt");
        let lines: Vec<String> = (0..8).map(|i| format!("line {i}")).collect();
        std::fs::write(&path, lines.join("\n")).unwrap();
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(claurst_tools::FileEditTool)];
        let calls = lines
            .iter()
            .enumerate()
            .map(|(i, line)| {
                (
                    format!("edit-{i}"),
                    "Edit".to_string(),
                    serde_json::json!({
                        "file_path": path,
                        "old_string": line,
                        "new_string": format!("edited {i}"),
                    }),
                )
            })
            .collect();

        let results =
            execute_tool_blocks_with_hooks(calls, &tools, &scheduling_ctx(dir.path()), None).await;

        assert_all_succeeded(&results);
        let expected: Vec<String> = (0..8).map(|i| format!("edited {i}")).collect();
        assert_eq!(std::fs::read_to_string(&path).unwrap(), expected.join("\n"));
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn writing_tools_in_a_response_run_in_the_order_requested() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("new.txt");
        let tools: Vec<Box<dyn Tool>> = vec![
            Box::new(claurst_tools::FileWriteTool),
            Box::new(claurst_tools::FileEditTool),
        ];
        let calls = vec![
            (
                "write".to_string(),
                "Write".to_string(),
                serde_json::json!({"file_path": path, "content": "draft\n"}),
            ),
            (
                "edit".to_string(),
                "Edit".to_string(),
                serde_json::json!({"file_path": path, "old_string": "draft", "new_string": "final"}),
            ),
        ];

        let results =
            execute_tool_blocks_with_hooks(calls, &tools, &scheduling_ctx(dir.path()), None).await;

        assert_all_succeeded(&results);
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "final\n");
    }

    fn result_for<'a>(results: &'a [ContentBlock], id: &str) -> (&'a ContentBlock, bool) {
        let block = results
            .iter()
            .find(|block| matches!(block, ContentBlock::ToolResult { tool_use_id, .. } if tool_use_id == id))
            .unwrap_or_else(|| panic!("no result for {id}"));
        let is_error = matches!(
            block,
            ContentBlock::ToolResult {
                is_error: Some(true),
                ..
            }
        );
        (block, is_error)
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn edit_batch_edit_and_apply_patch_on_one_file_land_in_order() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("notes.txt");
        std::fs::write(&path, "line 0\nline 1\nline 2\n").unwrap();
        let tools: Vec<Box<dyn Tool>> = vec![
            Box::new(claurst_tools::FileEditTool),
            Box::new(claurst_tools::BatchEditTool),
            Box::new(claurst_tools::ApplyPatchTool),
        ];
        let name = |i: usize| tools[i].name().to_string();
        // Each call changes what the one before it wrote, so all three succeed
        // only when they run in the order they were asked for.
        let calls = vec![
            (
                "edit".to_string(),
                name(0),
                serde_json::json!({"file_path": path, "old_string": "line 0", "new_string": "edited 0"}),
            ),
            (
                "batch".to_string(),
                name(1),
                serde_json::json!({"edits": [{"file_path": path, "old_string": "edited 0", "new_string": "batched 0"}]}),
            ),
            (
                "patch".to_string(),
                name(2),
                serde_json::json!({"patch": "--- a/notes.txt\n+++ b/notes.txt\n@@ -1,1 +1,1 @@\n-batched 0\n+patched 0\n"}),
            ),
        ];

        let results = tokio::time::timeout(
            std::time::Duration::from_secs(60),
            execute_tool_blocks_with_hooks(calls, &tools, &scheduling_ctx(dir.path()), None),
        )
        .await
        .expect("the writers finish");

        assert_all_succeeded(&results);
        assert_eq!(
            std::fs::read_to_string(&path).unwrap(),
            "patched 0\nline 1\nline 2\n"
        );
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn a_failed_first_edit_frees_the_turn_for_the_next() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("notes.txt");
        std::fs::write(&path, "alpha\nbeta\n").unwrap();
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(claurst_tools::FileEditTool)];
        let calls = vec![
            (
                "missing".to_string(),
                "Edit".to_string(),
                serde_json::json!({"file_path": path, "old_string": "not in the file", "new_string": "x"}),
            ),
            (
                "valid".to_string(),
                "Edit".to_string(),
                serde_json::json!({"file_path": path, "old_string": "beta", "new_string": "gamma"}),
            ),
        ];

        let results = tokio::time::timeout(
            std::time::Duration::from_secs(60),
            execute_tool_blocks_with_hooks(calls, &tools, &scheduling_ctx(dir.path()), None),
        )
        .await
        .expect("the second edit is not held up");

        assert!(result_for(&results, "missing").1, "{results:?}");
        assert!(!result_for(&results, "valid").1, "{results:?}");
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "alpha\ngamma\n");
    }

    /// Denies the first permission request and allows the rest.
    struct DenyFirst(std::sync::atomic::AtomicUsize);

    impl claurst_core::permissions::PermissionHandler for DenyFirst {
        fn check_permission(
            &self,
            request: &claurst_core::permissions::PermissionRequest,
        ) -> claurst_core::permissions::PermissionDecision {
            self.request_permission(request)
        }

        fn request_permission(
            &self,
            _request: &claurst_core::permissions::PermissionRequest,
        ) -> claurst_core::permissions::PermissionDecision {
            if self.0.fetch_add(1, std::sync::atomic::Ordering::SeqCst) == 0 {
                claurst_core::permissions::PermissionDecision::Deny
            } else {
                claurst_core::permissions::PermissionDecision::Allow
            }
        }
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn a_denied_first_edit_frees_the_turn_for_the_next() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("notes.txt");
        std::fs::write(&path, "alpha\nbeta\n").unwrap();
        let tools: Vec<Box<dyn Tool>> = vec![Box::new(claurst_tools::FileEditTool)];
        let calls = vec![
            (
                "denied".to_string(),
                "Edit".to_string(),
                serde_json::json!({"file_path": path, "old_string": "alpha", "new_string": "omega"}),
            ),
            (
                "allowed".to_string(),
                "Edit".to_string(),
                serde_json::json!({"file_path": path, "old_string": "beta", "new_string": "gamma"}),
            ),
        ];
        let mut ctx = scheduling_ctx(dir.path());
        ctx.permission_handler = Arc::new(DenyFirst(Default::default()));

        let results = tokio::time::timeout(
            std::time::Duration::from_secs(60),
            execute_tool_blocks_with_hooks(calls, &tools, &ctx, None),
        )
        .await
        .expect("the second edit is not held up");

        let (denied, denied_is_error) = result_for(&results, "denied");
        assert!(denied_is_error, "{results:?}");
        // What the model is told, not the block's Debug text, which also holds
        // the call's id.
        let ContentBlock::ToolResult {
            content: ToolResultContent::Text(told),
            ..
        } = denied
        else {
            panic!("{denied:?}");
        };
        assert!(told.contains("Permission denied for tool 'Edit'"), "{told}");
        assert!(!result_for(&results, "allowed").1, "{results:?}");
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "alpha\ngamma\n");
    }

    /// Finishes only once every tool sharing the barrier is running at once.
    struct RendezvousTool {
        name: &'static str,
        level: PermissionLevel,
        barrier: Arc<tokio::sync::Barrier>,
    }

    #[async_trait]
    impl Tool for RendezvousTool {
        fn name(&self) -> &str {
            self.name
        }

        fn description(&self) -> &str {
            "Waits for the other tools in its response"
        }

        fn permission_level(&self) -> PermissionLevel {
            self.level
        }

        fn input_schema(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        async fn execute(&self, _input: Value, _ctx: &ToolContext) -> ToolResult {
            self.barrier.wait().await;
            ToolResult::success("met")
        }
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn a_writing_tool_does_not_hold_up_the_others_in_its_response() {
        let dir = tempfile::tempdir().unwrap();
        let barrier = Arc::new(tokio::sync::Barrier::new(4));
        let tool = |name, level| -> Box<dyn Tool> {
            Box::new(RendezvousTool {
                name,
                level,
                barrier: barrier.clone(),
            })
        };
        let tools = vec![
            tool("Writes", PermissionLevel::Write),
            tool("RunsOne", PermissionLevel::Execute),
            tool("RunsTwo", PermissionLevel::Execute),
            tool("Reads", PermissionLevel::ReadOnly),
        ];
        let calls = ["Writes", "RunsOne", "RunsTwo", "Reads"]
            .map(|name| (name.to_string(), name.to_string(), serde_json::json!({})))
            .to_vec();
        let ctx = scheduling_ctx(dir.path());

        let results = tokio::time::timeout(
            std::time::Duration::from_secs(10),
            execute_tool_blocks_with_hooks(calls, &tools, &ctx, None),
        )
        .await
        .expect("tools in a response must still run at the same time");

        assert_all_succeeded(&results);
    }

    #[test]
    fn repeated_provider_ids_keep_independent_attempt_uuids() {
        let mut messages = Vec::new();
        for text in ["first partial", "retry result"] {
            let mut accumulator = StreamAccumulator::new();
            accumulator.on_event(&AnthropicStreamEvent::MessageStart {
                id: "reused-provider-session".into(),
                model: "model".into(),
                usage: UsageInfo::default(),
            });
            accumulator.on_event(&AnthropicStreamEvent::ContentBlockStart {
                index: 0,
                content_block: ContentBlock::Text { text: text.into() },
            });
            let (assistant, _, _) = finish_stream_accumulator(accumulator);
            sync_finalized_assistant_message(&mut messages, &assistant);
        }
        assert_eq!(messages.len(), 2);
        assert_ne!(messages[0].uuid, messages[1].uuid);
        for message in &messages {
            uuid::Uuid::parse_str(message.uuid.as_deref().unwrap()).expect("attempt UUID");
        }
    }

    #[tokio::test]
    async fn empty_retry_attempts_keep_usage_without_durable_assistants() {
        for content in [
            vec![],
            vec![ContentBlock::Text {
                text: String::new(),
            }],
            vec![ContentBlock::Thinking {
                thinking: String::new(),
                signature: String::new(),
            }],
        ] {
            let mut messages = vec![Message::user("prompt")];
            let mut assistant = Message::assistant_blocks(content);
            assistant.uuid = Some("empty-attempt".into());
            let usage = UsageInfo {
                input_tokens: 7,
                output_tokens: 5,
                cache_creation_input_tokens: 2,
                cache_read_input_tokens: 3,
            };
            let costs = CostTracker::new();
            let (tx, mut rx) = mpsc::unbounded_channel();
            finalize_stalled_attempt_before_retry(
                &mut messages,
                &mut assistant,
                &usage,
                &costs,
                None,
                None,
                Some(&tx),
            )
            .await;
            assert_eq!(costs.total_tokens(), 17);
            assert_eq!(messages.len(), 1);
            assert!(rx.try_recv().is_err());
        }
    }
}
