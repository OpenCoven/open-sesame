use crate::backend::{McpBackendKind, McpClientBackend, McpClientSnapshot};
use crate::transport;
use crate::types::{
    CallToolResult, GetPromptResult, McpContent, McpPrompt, McpPromptArgument, McpResource,
    McpTool, PromptMessage, PromptMessageContent, PromptsCapability, ResourceContents,
    ResourcesCapability, ServerCapabilities, ServerInfo, ToolsCapability,
};
use async_trait::async_trait;
use futures::stream::BoxStream;
use rmcp::model as rmcp_model;
use rmcp::service::RunningService;
use rmcp::transport::{
    streamable_http_client::StreamableHttpClientTransportConfig, ConfigureCommandExt,
    StreamableHttpClientTransport, TokioChildProcess,
};
use rmcp::{ClientHandler, RoleClient, ServiceExt};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::{Arc, Mutex as StdMutex};
use tokio::process::Command;
use tokio::sync::{mpsc, oneshot, watch, Mutex};
use tokio::task::JoinHandle;
use tokio_stream::wrappers::ReceiverStream;

pub struct RmcpNotificationClient {
    notifications_tx: Arc<StdMutex<Option<mpsc::UnboundedSender<Value>>>>,
    client_info: rmcp_model::ClientInfo,
}

impl RmcpNotificationClient {
    pub fn new(
        notifications_tx: mpsc::UnboundedSender<Value>,
        client_info: rmcp_model::ClientInfo,
    ) -> Self {
        Self {
            notifications_tx: Arc::new(StdMutex::new(Some(notifications_tx))),
            client_info,
        }
    }

    fn send_notification(&self, method: &str, params: Option<Value>) {
        let payload = match params {
            Some(params) => json!({
                "jsonrpc": "2.0",
                "method": method,
                "params": params,
            }),
            None => json!({
                "jsonrpc": "2.0",
                "method": method,
            }),
        };
        let sender = match self.notifications_tx.lock() {
            Ok(sender) => sender,
            Err(poisoned) => poisoned.into_inner(),
        };
        // Enqueue and retirement use the same lock. Once retirement removes
        // the sender, no handler can enqueue another notification.
        if let Some(sender) = sender.as_ref() {
            let _ = sender.send(payload);
        }
    }
}

impl ClientHandler for RmcpNotificationClient {
    async fn on_resource_updated(
        &self,
        params: rmcp_model::ResourceUpdatedNotificationParam,
        _context: rmcp::service::NotificationContext<RoleClient>,
    ) {
        self.send_notification(
            "notifications/resources/updated",
            Some(json!({ "uri": params.uri })),
        );
    }

    async fn on_resource_list_changed(
        &self,
        _context: rmcp::service::NotificationContext<RoleClient>,
    ) {
        self.send_notification("notifications/resources/list_changed", Some(json!({})));
    }

    async fn on_tool_list_changed(&self, _context: rmcp::service::NotificationContext<RoleClient>) {
        self.send_notification("notifications/tools/list_changed", Some(json!({})));
    }

    async fn on_prompt_list_changed(
        &self,
        _context: rmcp::service::NotificationContext<RoleClient>,
    ) {
        self.send_notification("notifications/prompts/list_changed", Some(json!({})));
    }

    fn get_info(&self) -> rmcp_model::ClientInfo {
        self.client_info.clone()
    }
}

pub struct RmcpClientBackend {
    snapshot: McpClientSnapshot,
    peer: rmcp::Peer<RoleClient>,
    running: Mutex<RunningService<RoleClient, RmcpNotificationClient>>,
    notifications_rx: Arc<Mutex<mpsc::UnboundedReceiver<Value>>>,
    notifications_tx: Arc<StdMutex<Option<mpsc::UnboundedSender<Value>>>>,
    notification_shutdown: watch::Sender<bool>,
    notification_tasks: StdMutex<Vec<JoinHandle<()>>>,
    transport_completion: Option<crate::owned_transport::Completion>,
}

impl RmcpClientBackend {
    pub async fn connect_stdio(
        config: &claurst_core::config::McpServerConfig,
        shutdown: Option<watch::Receiver<bool>>,
    ) -> anyhow::Result<Self> {
        let command = config.command.clone().ok_or_else(|| {
            anyhow::anyhow!("MCP server '{}' has no command configured", config.name)
        })?;

        let transport = TokioChildProcess::new(Command::new(&command).configure(|cmd| {
            cmd.args(&config.args);
            cmd.envs(&config.env);
        }))
        .map_err(|e| {
            anyhow::anyhow!(
                "failed to spawn rmcp stdio child for '{}': {}",
                config.name,
                e
            )
        })?;

        let client_info = build_client_info(rmcp_model::ProtocolVersion::default());
        Self::connect_with_transport(config, transport, client_info, "stdio", shutdown).await
    }

    pub async fn connect_http(
        config: &claurst_core::config::McpServerConfig,
        auth_token: Option<String>,
        protocol_version: rmcp_model::ProtocolVersion,
        shutdown: Option<watch::Receiver<bool>>,
    ) -> anyhow::Result<Self> {
        let endpoint = config
            .url
            .clone()
            .ok_or_else(|| anyhow::anyhow!("MCP server '{}' has no URL configured", config.name))?;

        let mut transport_config = StreamableHttpClientTransportConfig::with_uri(endpoint);
        if let Some(token) = auth_token {
            transport_config = transport_config.auth_header(token);
        }

        let client_info = build_client_info(protocol_version);
        if let Some(shutdown) = shutdown {
            let transport =
                crate::owned_http::OwnedHttpTransport::new(transport_config, shutdown.clone());
            Self::connect_with_transport(config, transport, client_info, "http", Some(shutdown))
                .await
        } else {
            let transport = StreamableHttpClientTransport::from_config(transport_config);
            Self::connect_with_transport(config, transport, client_info, "http", None).await
        }
    }

    pub async fn connect_legacy_sse(
        config: &claurst_core::config::McpServerConfig,
        auth_token: Option<String>,
        shutdown: Option<watch::Receiver<bool>>,
    ) -> anyhow::Result<Self> {
        // Legacy SSE servers still expose the real POST endpoint via
        // `event: endpoint`; keep a thin compatibility shim here and hand the
        // session and capability flow back to rmcp once connected.
        let transport =
            LegacySseRmcpTransport::connect(config, auth_token, shutdown.clone()).await?;
        let client_info = build_client_info(rmcp_model::ProtocolVersion::V_2024_11_05);
        Self::connect_with_transport(config, transport, client_info, "sse", shutdown).await
    }

    async fn connect_with_transport<T, E, A>(
        config: &claurst_core::config::McpServerConfig,
        transport: T,
        client_info: rmcp_model::ClientInfo,
        transport_label: &str,
        shutdown: Option<watch::Receiver<bool>>,
    ) -> anyhow::Result<Self>
    where
        T: rmcp::transport::IntoTransport<RoleClient, E, A>,
        E: std::error::Error + Send + Sync + 'static,
    {
        let (notifications_tx, notifications_rx) = mpsc::unbounded_channel();
        let handler = RmcpNotificationClient::new(notifications_tx, client_info);
        let notifications_tx = Arc::clone(&handler.notifications_tx);
        let mut transport_completion = None;
        let connection = if let Some(shutdown) = shutdown {
            let owned =
                crate::owned_transport::OwnedTransport::new(transport.into_transport(), shutdown);
            transport_completion = Some(owned.completion.clone());
            handler.serve(owned).await
        } else {
            handler.serve(transport).await
        };
        let mut running = match connection {
            Ok(running) => running,
            Err(error) => {
                if let Some(completion) = transport_completion {
                    completion
                        .await
                        .map_err(crate::owned_transport::RetirementError)?;
                }
                anyhow::bail!(
                    "rmcp {} client '{}' failed to initialize: {}",
                    transport_label,
                    config.name,
                    error
                );
            }
        };
        let peer = running.peer().clone();
        let snapshot = match build_snapshot(config, &peer).await {
            Ok(snapshot) => snapshot,
            Err(error) => {
                let close = running.close().await;
                if let Some(completion) = transport_completion {
                    completion
                        .await
                        .map_err(crate::owned_transport::RetirementError)?;
                }
                close
                    .map_err(|error| crate::owned_transport::RetirementError(error.to_string()))?;
                return Err(error);
            }
        };

        Ok(Self {
            snapshot,
            peer,
            running: Mutex::new(running),
            notifications_rx: Arc::new(Mutex::new(notifications_rx)),
            notifications_tx,
            notification_shutdown: watch::channel(false).0,
            notification_tasks: StdMutex::new(Vec::new()),
            transport_completion,
        })
    }
}

fn build_client_info(protocol_version: rmcp_model::ProtocolVersion) -> rmcp_model::ClientInfo {
    let mut client_info = rmcp_model::ClientInfo::default();
    client_info.protocol_version = protocol_version;
    client_info.capabilities.roots = Some(rmcp_model::RootsCapabilities {
        list_changed: Some(false),
    });
    client_info.client_info = rmcp_model::Implementation::new(
        claurst_core::constants::APP_NAME,
        claurst_core::constants::APP_VERSION,
    );
    client_info
}

#[derive(Debug, thiserror::Error)]
enum LegacySseTransportError {
    #[error(transparent)]
    Other(#[from] anyhow::Error),
}

struct LegacySseRmcpTransport {
    server_name: String,
    sse_url: String,
    client: reqwest::Client,
    auth_token: Option<String>,
    post_endpoint: Arc<StdMutex<Option<String>>>,
    incoming_tx: mpsc::UnboundedSender<rmcp::service::RxJsonRpcMessage<RoleClient>>,
    incoming_rx: Arc<Mutex<mpsc::UnboundedReceiver<rmcp::service::RxJsonRpcMessage<RoleClient>>>>,
    background_tasks: Arc<StdMutex<Vec<JoinHandle<()>>>>,
}

impl LegacySseRmcpTransport {
    async fn connect(
        config: &claurst_core::config::McpServerConfig,
        auth_token: Option<String>,
        mut shutdown: Option<watch::Receiver<bool>>,
    ) -> anyhow::Result<Self> {
        let sse_url = config
            .url
            .clone()
            .ok_or_else(|| anyhow::anyhow!("MCP server '{}' has no URL configured", config.name))?;
        let client = reqwest::Client::new();
        let (incoming_tx, incoming_rx) = mpsc::unbounded_channel();
        let mut transport = Self {
            server_name: config.name.clone(),
            sse_url,
            client,
            auth_token,
            post_endpoint: Arc::new(StdMutex::new(None)),
            incoming_tx,
            incoming_rx: Arc::new(Mutex::new(incoming_rx)),
            background_tasks: Arc::new(StdMutex::new(Vec::new())),
        };
        let result = if let Some(shutdown) = &mut shutdown {
            if *shutdown.borrow() {
                anyhow::bail!("Plugin MCP authority has been revoked");
            }
            tokio::select! {
                biased;
                _ = shutdown.changed() => Err(anyhow::anyhow!("Plugin MCP authority has been revoked")),
                result = transport.start_sse_listener() => result,
            }
        } else {
            transport.start_sse_listener().await
        };
        if let Err(error) = result {
            rmcp::transport::Transport::close(&mut transport)
                .await
                .map_err(|error| crate::owned_transport::RetirementError(error.to_string()))?;
            return Err(error);
        }
        Ok(transport)
    }

    async fn start_sse_listener(&self) -> anyhow::Result<()> {
        let (endpoint_tx, endpoint_rx) = oneshot::channel::<anyhow::Result<String>>();
        let endpoint_tx = Arc::new(StdMutex::new(Some(endpoint_tx)));

        let mut request = self
            .client
            .get(&self.sse_url)
            .header(reqwest::header::ACCEPT, "text/event-stream");
        if let Some(token) = &self.auth_token {
            request = request.header(
                reqwest::header::AUTHORIZATION,
                transport::bearer_header_value(token)?,
            );
        }
        let response = request.send().await.map_err(|e| {
            anyhow::anyhow!(
                "MCP server '{}': failed to open legacy SSE stream '{}': {}",
                self.server_name,
                self.sse_url,
                e
            )
        })?;
        if !response.status().is_success() {
            anyhow::bail!(
                "MCP server '{}': legacy SSE stream returned HTTP {}",
                self.server_name,
                response.status()
            );
        }

        let server_name = self.server_name.clone();
        let sse_url = self.sse_url.clone();
        let post_endpoint = Arc::clone(&self.post_endpoint);
        let incoming_tx = self.incoming_tx.clone();
        let endpoint_tx_for_task = Arc::clone(&endpoint_tx);
        let task = tokio::spawn(async move {
            let result = transport::process_sse_response(response, |event, data| {
                if matches!(event, Some("endpoint")) {
                    let endpoint = transport::resolve_legacy_endpoint(&sse_url, data)?;
                    *post_endpoint.lock().expect("endpoint mutex poisoned") =
                        Some(endpoint.clone());
                    if let Some(tx) = endpoint_tx_for_task
                        .lock()
                        .expect("endpoint sender mutex poisoned")
                        .take()
                    {
                        let _ = tx.send(Ok(endpoint));
                    }
                    return Ok(());
                }

                if data.trim().is_empty() {
                    return Ok(());
                }

                let message = parse_server_message(&server_name, data)?;
                let _ = incoming_tx.send(message);
                Ok(())
            })
            .await;

            if let Err(e) = result {
                tracing::warn!(server = %server_name, error = %e, "Legacy SSE stream closed with error");
                if let Some(tx) = endpoint_tx_for_task
                    .lock()
                    .expect("endpoint sender mutex poisoned")
                    .take()
                {
                    let _ = tx.send(Err(anyhow::anyhow!(e.to_string())));
                }
            } else if let Some(tx) = endpoint_tx_for_task
                .lock()
                .expect("endpoint sender mutex poisoned")
                .take()
            {
                let _ = tx.send(Err(anyhow::anyhow!(
                    "legacy SSE stream closed before announcing endpoint"
                )));
            }
        });
        self.background_tasks
            .lock()
            .expect("task mutex poisoned")
            .push(task);

        let endpoint = tokio::time::timeout(std::time::Duration::from_secs(10), endpoint_rx)
            .await
            .map_err(|_| {
                anyhow::anyhow!(
                    "MCP server '{}': timed out waiting for legacy SSE endpoint event",
                    self.server_name
                )
            })?
            .map_err(|_| {
                anyhow::anyhow!(
                    "MCP server '{}': legacy SSE stream ended before endpoint discovery",
                    self.server_name
                )
            })??;
        *self.post_endpoint.lock().expect("endpoint mutex poisoned") = Some(endpoint);
        Ok(())
    }
}

impl Drop for LegacySseRmcpTransport {
    fn drop(&mut self) {
        // Some upper-layer paths drop the backend instead of calling close()
        // explicitly. Abort the listener tasks again here so legacy SSE does
        // not outlive the connection teardown.
        let mut tasks = self.background_tasks.lock().expect("task mutex poisoned");
        for handle in tasks.drain(..) {
            handle.abort();
        }
    }
}

impl rmcp::transport::Transport<RoleClient> for LegacySseRmcpTransport {
    type Error = LegacySseTransportError;

    fn send(
        &mut self,
        item: rmcp::service::TxJsonRpcMessage<RoleClient>,
    ) -> impl std::future::Future<Output = Result<(), Self::Error>> + Send + 'static {
        let endpoint = self
            .post_endpoint
            .lock()
            .expect("endpoint mutex poisoned")
            .clone();
        let client = self.client.clone();
        let auth_token = self.auth_token.clone();
        let server_name = self.server_name.clone();
        let incoming_tx = self.incoming_tx.clone();
        let background_tasks = Arc::clone(&self.background_tasks);
        async move {
            let endpoint = endpoint.ok_or_else(|| {
                anyhow::anyhow!(
                    "MCP server '{}': legacy SSE POST endpoint has not been discovered",
                    server_name
                )
            })?;

            let mut request = client
                .post(endpoint)
                .header(reqwest::header::CONTENT_TYPE, "application/json")
                .json(&item);
            if let Some(token) = &auth_token {
                request = request.header(
                    reqwest::header::AUTHORIZATION,
                    transport::bearer_header_value(token)?,
                );
            }

            let response = request.send().await.map_err(|e| {
                anyhow::anyhow!(
                    "MCP server '{}': legacy SSE POST request failed: {}",
                    server_name,
                    e
                )
            })?;

            handle_legacy_sse_http_response(server_name, response, incoming_tx, background_tasks)
                .await
                .map_err(Into::into)
        }
    }

    fn receive(
        &mut self,
    ) -> impl std::future::Future<Output = Option<rmcp::service::RxJsonRpcMessage<RoleClient>>> + Send
    {
        let incoming_rx = Arc::clone(&self.incoming_rx);
        async move {
            let mut rx = incoming_rx.lock().await;
            rx.recv().await
        }
    }

    fn close(&mut self) -> impl std::future::Future<Output = Result<(), Self::Error>> + Send {
        let background_tasks = Arc::clone(&self.background_tasks);
        async move {
            let tasks = {
                let mut tasks = background_tasks
                    .lock()
                    .unwrap_or_else(|error| error.into_inner());
                std::mem::take(&mut *tasks)
            };
            for handle in &tasks {
                handle.abort();
            }
            let mut result = Ok(());
            for handle in tasks {
                if let Err(error) = handle.await {
                    if !error.is_cancelled() {
                        result = result.and(Err(anyhow::anyhow!(error).into()));
                    }
                }
            }
            result
        }
    }
}

fn parse_server_message(
    server_name: &str,
    data: &str,
) -> anyhow::Result<rmcp::service::RxJsonRpcMessage<RoleClient>> {
    serde_json::from_str(data).map_err(|e| {
        anyhow::anyhow!(
            "MCP server '{}': failed to parse legacy SSE JSON payload: {}",
            server_name,
            e
        )
    })
}

async fn handle_legacy_sse_http_response(
    server_name: String,
    response: reqwest::Response,
    incoming_tx: mpsc::UnboundedSender<rmcp::service::RxJsonRpcMessage<RoleClient>>,
    background_tasks: Arc<StdMutex<Vec<JoinHandle<()>>>>,
) -> anyhow::Result<()> {
    let status = response.status();
    if !status.is_success() && status != reqwest::StatusCode::ACCEPTED {
        anyhow::bail!(
            "MCP server '{}': HTTP {} from legacy SSE transport",
            server_name,
            status
        );
    }

    if status == reqwest::StatusCode::ACCEPTED {
        return Ok(());
    }

    if transport::is_event_stream_response(&response) {
        let server_name_for_task = server_name.clone();
        let task = tokio::spawn(async move {
            if let Err(e) = transport::process_sse_response(response, |_, data| {
                if data.trim().is_empty() {
                    return Ok(());
                }
                let message = parse_server_message(&server_name_for_task, data)?;
                let _ = incoming_tx.send(message);
                Ok(())
            })
            .await
            {
                tracing::warn!(server = %server_name_for_task, error = %e, "legacy SSE POST stream closed with error");
            }
        });
        background_tasks
            .lock()
            .expect("task mutex poisoned")
            .push(task);
        return Ok(());
    }

    let text = response.text().await.map_err(|e| {
        anyhow::anyhow!(
            "MCP server '{}': failed to read legacy SSE HTTP response body: {}",
            server_name,
            e
        )
    })?;
    if text.trim().is_empty() {
        return Ok(());
    }

    let message = parse_server_message(&server_name, &text)?;
    let _ = incoming_tx.send(message);
    Ok(())
}

#[async_trait]
impl McpClientBackend for RmcpClientBackend {
    async fn shutdown(&self) -> anyhow::Result<()> {
        self.shutdown_notifications();
        let mut result = self
            .running
            .lock()
            .await
            .close()
            .await
            .map(|_| ())
            .map_err(anyhow::Error::from);
        if let Some(completion) = &self.transport_completion {
            result = result.and(completion.clone().await.map_err(anyhow::Error::msg));
        }
        let tasks = {
            let mut tasks = self
                .notification_tasks
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            std::mem::take(&mut *tasks)
        };
        for task in tasks {
            result = result.and(task.await.map_err(anyhow::Error::from));
        }
        result
    }

    fn kind(&self) -> McpBackendKind {
        McpBackendKind::Rmcp
    }

    fn snapshot(&self) -> McpClientSnapshot {
        self.snapshot.clone()
    }

    async fn list_tools(&self) -> anyhow::Result<Vec<McpTool>> {
        let tools = self
            .peer
            .list_all_tools()
            .await
            .map_err(|e| anyhow::anyhow!("rmcp list_tools failed: {}", e))?;
        Ok(tools.into_iter().map(convert_tool).collect())
    }

    async fn call_tool(
        &self,
        name: &str,
        arguments: Option<Value>,
    ) -> anyhow::Result<CallToolResult> {
        let mut params = rmcp_model::CallToolRequestParams::new(name.to_string());
        if let Some(arguments) = arguments {
            params = params.with_arguments(json_value_to_object(arguments)?);
        }
        let result = self
            .peer
            .call_tool(params)
            .await
            .map_err(|e| anyhow::anyhow!("rmcp call_tool '{}' failed: {}", name, e))?;
        Ok(convert_call_tool_result(result))
    }

    async fn list_resources(&self) -> anyhow::Result<Vec<McpResource>> {
        let resources = self
            .peer
            .list_all_resources()
            .await
            .map_err(|e| anyhow::anyhow!("rmcp list_resources failed: {}", e))?;
        Ok(resources.into_iter().map(convert_resource).collect())
    }

    async fn read_resource(&self, uri: &str) -> anyhow::Result<ResourceContents> {
        let result = self
            .peer
            .read_resource(rmcp_model::ReadResourceRequestParams::new(uri.to_string()))
            .await
            .map_err(|e| anyhow::anyhow!("rmcp read_resource '{}' failed: {}", uri, e))?;
        let first =
            result.contents.into_iter().next().ok_or_else(|| {
                anyhow::anyhow!("rmcp read_resource '{}' returned no contents", uri)
            })?;
        Ok(convert_resource_contents(first))
    }

    async fn list_prompts(&self) -> anyhow::Result<Vec<McpPrompt>> {
        let prompts = self
            .peer
            .list_all_prompts()
            .await
            .map_err(|e| anyhow::anyhow!("rmcp list_prompts failed: {}", e))?;
        Ok(prompts.into_iter().map(convert_prompt).collect())
    }

    async fn get_prompt(
        &self,
        name: &str,
        arguments: Option<HashMap<String, String>>,
    ) -> anyhow::Result<GetPromptResult> {
        let mut params = rmcp_model::GetPromptRequestParams::new(name.to_string());
        if let Some(arguments) = arguments {
            let args = arguments
                .into_iter()
                .map(|(key, value)| (key, Value::String(value)))
                .collect();
            params = params.with_arguments(args);
        }
        let result = self
            .peer
            .get_prompt(params)
            .await
            .map_err(|e| anyhow::anyhow!("rmcp get_prompt '{}' failed: {}", name, e))?;
        Ok(convert_get_prompt_result(result))
    }

    async fn subscribe_resource(&self, uri: &str) -> anyhow::Result<()> {
        self.peer
            .subscribe(rmcp_model::SubscribeRequestParams::new(uri.to_string()))
            .await
            .map_err(|e| anyhow::anyhow!("rmcp subscribe '{}' failed: {}", uri, e))
    }

    async fn unsubscribe_resource(&self, uri: &str) -> anyhow::Result<()> {
        self.peer
            .unsubscribe(rmcp_model::UnsubscribeRequestParams::new(uri.to_string()))
            .await
            .map_err(|e| anyhow::anyhow!("rmcp unsubscribe '{}' failed: {}", uri, e))
    }

    fn subscribe_to_notifications(&self) -> BoxStream<'static, anyhow::Result<Value>> {
        let notifications_rx = Arc::clone(&self.notifications_rx);
        let (tx, rx) = mpsc::channel::<anyhow::Result<Value>>(100);
        let mut tasks = self
            .notification_tasks
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        tasks.retain(|task| !task.is_finished());
        tasks.push(tokio::spawn(forward_notifications(
            notifications_rx,
            tx,
            self.notification_shutdown.subscribe(),
        )));
        Box::pin(ReceiverStream::new(rx))
    }

    fn shutdown_notifications(&self) {
        match self.notifications_tx.lock() {
            Ok(mut sender) => {
                sender.take();
            }
            Err(poisoned) => {
                poisoned.into_inner().take();
            }
        }
        self.notification_shutdown.send_replace(true);
        // There may be no bridge left (or none may ever have started). Clear
        // synchronously when possible; otherwise the lock-owning bridge is
        // woken by shutdown and clears the queue before releasing its ownership.
        if let Ok(mut receiver) = self.notifications_rx.try_lock() {
            receiver.close();
            while receiver.try_recv().is_ok() {}
        }
    }
}

async fn forward_notifications(
    notifications_rx: Arc<Mutex<mpsc::UnboundedReceiver<Value>>>,
    tx: mpsc::Sender<anyhow::Result<Value>>,
    mut notification_shutdown: watch::Receiver<bool>,
) {
    loop {
        if *notification_shutdown.borrow() {
            break;
        }
        let next = tokio::select! {
            biased;

            _ = notification_shutdown.changed() => break,

            // The returned stream owns this bridge. A quiet input (or
            // another subscription holding the mutex) must not keep it
            // alive after its consumer has gone away.
            () = tx.closed() => break,
            next = async {
                let mut receiver = notifications_rx.lock().await;
                receiver.recv().await
            } => next,
        };
        match next {
            Some(value) => {
                tokio::select! {
                    biased;
                    _ = notification_shutdown.changed() => break,
                    result = tx.send(Ok(value)) => {
                        if result.is_err() { break; }
                    }
                }
            }
            None => break,
        }
    }
    drop(tx);
    if *notification_shutdown.borrow() {
        let mut receiver = notifications_rx.lock().await;
        receiver.close();
        while receiver.try_recv().is_ok() {}
    }
}

async fn build_snapshot(
    config: &claurst_core::config::McpServerConfig,
    peer: &rmcp::Peer<RoleClient>,
) -> anyhow::Result<McpClientSnapshot> {
    let server_info = peer.peer_info().cloned();

    let (server_info_value, capabilities, instructions) = match server_info {
        Some(info) => (
            Some(ServerInfo {
                name: info.server_info.name,
                version: info.server_info.version,
            }),
            convert_server_capabilities(info.capabilities),
            info.instructions,
        ),
        None => (None, ServerCapabilities::default(), None),
    };

    let tools = if capabilities.tools.is_some() {
        peer.list_all_tools()
            .await
            .map_err(|e| anyhow::anyhow!("rmcp list_all_tools failed: {}", e))?
            .into_iter()
            .map(convert_tool)
            .collect()
    } else {
        vec![]
    };

    let resources = if capabilities.resources.is_some() {
        peer.list_all_resources()
            .await
            .map_err(|e| anyhow::anyhow!("rmcp list_all_resources failed: {}", e))?
            .into_iter()
            .map(convert_resource)
            .collect()
    } else {
        vec![]
    };

    let prompts = if capabilities.prompts.is_some() {
        peer.list_all_prompts()
            .await
            .map_err(|e| anyhow::anyhow!("rmcp list_all_prompts failed: {}", e))?
            .into_iter()
            .map(convert_prompt)
            .collect()
    } else {
        vec![]
    };

    Ok(McpClientSnapshot {
        server_name: config.name.clone(),
        server_info: server_info_value,
        capabilities,
        tools,
        resources,
        prompts,
        instructions,
    })
}

fn convert_server_capabilities(capabilities: rmcp_model::ServerCapabilities) -> ServerCapabilities {
    ServerCapabilities {
        tools: capabilities.tools.map(|tools| ToolsCapability {
            list_changed: tools.list_changed.unwrap_or(false),
        }),
        resources: capabilities.resources.map(|resources| ResourcesCapability {
            subscribe: resources.subscribe.unwrap_or(false),
            list_changed: resources.list_changed.unwrap_or(false),
        }),
        prompts: capabilities.prompts.map(|prompts| PromptsCapability {
            list_changed: prompts.list_changed.unwrap_or(false),
        }),
        logging: capabilities.logging.map(Value::Object),
    }
}

fn convert_tool(tool: rmcp_model::Tool) -> McpTool {
    McpTool {
        name: tool.name.into_owned(),
        description: tool.description.map(|description| description.into_owned()),
        input_schema: Value::Object((*tool.input_schema).clone()),
    }
}

fn convert_resource(resource: rmcp_model::Resource) -> McpResource {
    McpResource {
        uri: resource.uri.clone(),
        name: resource.name.clone(),
        description: resource.description.clone(),
        mime_type: resource.mime_type.clone(),
        annotations: resource
            .annotations
            .as_ref()
            .and_then(|annotations| serde_json::to_value(annotations).ok()),
    }
}

fn convert_prompt(prompt: rmcp_model::Prompt) -> McpPrompt {
    McpPrompt {
        name: prompt.name,
        description: prompt.description,
        arguments: prompt
            .arguments
            .unwrap_or_default()
            .into_iter()
            .map(|argument| McpPromptArgument {
                name: argument.name,
                description: argument.description,
                required: argument.required.unwrap_or(false),
            })
            .collect(),
    }
}

fn convert_resource_contents(resource: rmcp_model::ResourceContents) -> ResourceContents {
    match resource {
        rmcp_model::ResourceContents::TextResourceContents {
            uri,
            mime_type,
            text,
            ..
        } => ResourceContents {
            uri,
            mime_type,
            text: Some(text),
            blob: None,
        },
        rmcp_model::ResourceContents::BlobResourceContents {
            uri,
            mime_type,
            blob,
            ..
        } => ResourceContents {
            uri,
            mime_type,
            text: None,
            blob: Some(blob),
        },
    }
}

fn convert_prompt_message(message: rmcp_model::PromptMessage) -> PromptMessage {
    PromptMessage {
        role: match message.role {
            rmcp_model::PromptMessageRole::User => "user".to_string(),
            rmcp_model::PromptMessageRole::Assistant => "assistant".to_string(),
        },
        content: match message.content {
            rmcp_model::PromptMessageContent::Text { text } => PromptMessageContent::Text { text },
            rmcp_model::PromptMessageContent::Image { image } => PromptMessageContent::Image {
                data: image.data.clone(),
                mime_type: image.mime_type.clone(),
            },
            rmcp_model::PromptMessageContent::Resource { resource } => {
                PromptMessageContent::Resource {
                    resource: serde_json::to_value(resource).unwrap_or(Value::Null),
                }
            }
            rmcp_model::PromptMessageContent::ResourceLink { link } => {
                PromptMessageContent::Resource {
                    resource: serde_json::to_value(link).unwrap_or(Value::Null),
                }
            }
        },
    }
}

fn convert_get_prompt_result(result: rmcp_model::GetPromptResult) -> GetPromptResult {
    GetPromptResult {
        description: result.description,
        messages: result
            .messages
            .into_iter()
            .map(convert_prompt_message)
            .collect(),
    }
}

fn convert_call_tool_result(result: rmcp_model::CallToolResult) -> CallToolResult {
    CallToolResult {
        content: result.content.into_iter().map(convert_content).collect(),
        is_error: result.is_error.unwrap_or(false),
    }
}

fn convert_content(content: rmcp_model::Content) -> McpContent {
    match content.raw {
        rmcp_model::RawContent::Text(text) => McpContent::Text { text: text.text },
        rmcp_model::RawContent::Image(image) => McpContent::Image {
            data: image.data.clone(),
            mime_type: image.mime_type.clone(),
        },
        rmcp_model::RawContent::Resource(resource) => McpContent::Resource {
            resource: convert_resource_contents(resource.resource),
        },
        rmcp_model::RawContent::ResourceLink(link) => McpContent::Resource {
            resource: ResourceContents {
                uri: link.uri,
                mime_type: link.mime_type,
                text: None,
                blob: None,
            },
        },
        rmcp_model::RawContent::Audio(audio) => McpContent::Text {
            text: format!("[Audio: {} | base64 bytes omitted]", audio.mime_type),
        },
    }
}

fn json_value_to_object(value: Value) -> anyhow::Result<rmcp_model::JsonObject> {
    match value {
        Value::Object(map) => Ok(map),
        other => Err(anyhow::anyhow!(
            "rmcp tool arguments must be a JSON object, got {}",
            other
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use claurst_core::config::McpServerConfig;
    use futures::StreamExt;
    use tokio::io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader};
    use tokio::net::TcpListener;
    use tokio::time::{timeout, Duration};

    async fn notification_backend() -> (
        RmcpClientBackend,
        mpsc::UnboundedSender<Value>,
        JoinHandle<()>,
    ) {
        let (client_io, server_io) = tokio::io::duplex(4096);
        let server = tokio::spawn(async move {
            let mut server_io = BufReader::new(server_io);
            let mut line = String::new();
            server_io.read_line(&mut line).await.unwrap();
            let request: crate::types::JsonRpcRequest = serde_json::from_str(&line).unwrap();
            assert_eq!(request.method, "initialize");
            let response = json!({
                "jsonrpc": "2.0", "id": request.id,
                "result": {
                    "protocolVersion": "2024-11-05", "capabilities": {},
                    "serverInfo": {"name": "notification-test", "version": "1"}
                }
            });
            server_io
                .get_mut()
                .write_all(format!("{response}\n").as_bytes())
                .await
                .unwrap();
            // Keep requests usable while notification-only shutdown is tested.
            loop {
                line.clear();
                if server_io.read_line(&mut line).await.unwrap() == 0 {
                    break;
                }
                let request: Value = serde_json::from_str(&line).unwrap();
                if request.get("id").is_none() {
                    continue;
                }
                assert_eq!(request["method"], "tools/list");
                let response = json!({
                    "jsonrpc": "2.0", "id": request["id"],
                    "result": {"tools": [{
                        "name": "retained-request", "inputSchema": {"type": "object"}
                    }]}
                });
                server_io
                    .get_mut()
                    .write_all(format!("{response}\n").as_bytes())
                    .await
                    .unwrap();
            }
        });
        let backend = timeout(
            Duration::from_secs(2),
            RmcpClientBackend::connect_with_transport(
                &test_sse_config("unused".to_string()),
                client_io,
                build_client_info(rmcp_model::ProtocolVersion::V_2024_11_05),
                "memory",
                None,
            ),
        )
        .await
        .unwrap()
        .unwrap();
        let input = backend
            .running
            .lock()
            .await
            .service()
            .notifications_tx
            .lock()
            .unwrap()
            .as_ref()
            .unwrap()
            .clone();
        (backend, input, server)
    }

    async fn bridge_releases_receiver(backend: &RmcpClientBackend) {
        timeout(Duration::from_secs(2), async {
            while Arc::strong_count(&backend.notifications_rx) != 1 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("dropping the consumer must release the bridge's receiver ownership");
    }

    #[tokio::test]
    async fn notification_bridge_stops_when_quiet_consumer_drops() {
        let (backend, _input, server) = notification_backend().await;
        let stream = backend.subscribe_to_notifications();
        timeout(Duration::from_secs(2), async {
            while backend.notifications_rx.try_lock().is_ok() {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("bridge must be waiting on its quiet receiver");

        drop(stream);
        bridge_releases_receiver(&backend).await;
        assert!(backend.notifications_rx.try_lock().is_ok());
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_bridge_stops_while_waiting_for_receiver_lock() {
        let (backend, _input, server) = notification_backend().await;
        let receiver = backend.notifications_rx.lock().await;
        let (tx, rx) = mpsc::channel(100);
        let stream = ReceiverStream::new(rx);
        let mut bridge = Box::pin(forward_notifications(
            Arc::clone(&backend.notifications_rx),
            tx,
            backend.notification_shutdown.subscribe(),
        ));
        // Poll the exact worker spawned by subscribe_to_notifications. The
        // output is open and the receiver lock is held, so this reaches Pending
        // in lock acquisition before any recv/send can run.
        assert!(futures::poll!(bridge.as_mut()).is_pending());
        drop(stream);
        assert!(
            futures::poll!(bridge.as_mut()).is_ready(),
            "consumer drop must cancel an already-pending receiver lock"
        );
        drop(bridge);
        assert_eq!(Arc::strong_count(&backend.notifications_rx), 1);
        assert!(backend.notifications_rx.try_lock().is_err());
        drop(receiver);
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_bridge_stops_when_saturated_consumer_drops() {
        let (backend, input, server) = notification_backend().await;
        let stream = backend.subscribe_to_notifications();
        for sequence in 0..102 {
            input.send(json!({"sequence": sequence})).unwrap();
        }
        timeout(Duration::from_secs(2), async {
            loop {
                if backend
                    .notifications_rx
                    .try_lock()
                    .is_ok_and(|rx| rx.len() == 1)
                {
                    break;
                }
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("bridge must fill its 100-item output and block on item 101");

        drop(stream);
        bridge_releases_receiver(&backend).await;
        assert_eq!(backend.notifications_rx.lock().await.len(), 1);
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_bridge_preserves_active_delivery_order_across_capacity() {
        let (backend, input, server) = notification_backend().await;
        let mut stream = backend.subscribe_to_notifications();
        for sequence in 0..205 {
            input.send(json!({"sequence": sequence})).unwrap();
        }
        for sequence in 0..205 {
            let actual = timeout(Duration::from_secs(2), stream.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap();
            assert_eq!(actual, json!({"sequence": sequence}));
        }
        drop(stream);
        bridge_releases_receiver(&backend).await;
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    fn retaining_manager(backend: &Arc<RmcpClientBackend>) -> crate::McpManager {
        let mut manager = crate::McpManager::new();
        manager.clients.insert(
            "retained".to_string(),
            Arc::new(crate::McpClient::from_test_backend(backend.clone())),
        );
        manager
    }

    async fn assert_retired_ingress_and_live_requests(
        manager: &crate::McpManager,
        backend: &RmcpClientBackend,
    ) {
        // Exercise the actual handler's producer after forwarding has ended,
        // while both the backend and its ordinary request owner remain alive.
        {
            let running = backend.running.lock().await;
            for sequence in 0..1024 {
                running.service().send_notification(
                    "notifications/resources/updated",
                    Some(json!({"uri": format!("test://{sequence}")})),
                );
            }
        }
        let tools = timeout(
            Duration::from_secs(2),
            manager.clients["retained"].list_tools(None),
        )
        .await
        .unwrap()
        .unwrap();
        assert_eq!(tools[0].name, "retained-request");
        let receiver = backend.notifications_rx.lock().await;
        assert_eq!(
            receiver.len(),
            0,
            "retirement must discard buffered and subsequent input"
        );
        assert!(receiver.is_closed(), "retired ingress must stay closed");
    }

    #[tokio::test]
    async fn notification_retirement_clears_input_after_last_bridge_exits() {
        let (backend, input, server) = notification_backend().await;
        let backend = Arc::new(backend);
        let manager = retaining_manager(&backend);
        let stream = backend.subscribe_to_notifications();
        drop(stream);
        bridge_releases_receiver(&backend).await;
        for sequence in 0..5 {
            input.send(json!({"sequence": sequence})).unwrap();
        }
        manager.shutdown_notification_poll_loops();
        manager.shutdown_notification_poll_loops();
        assert_retired_ingress_and_live_requests(&manager, &backend).await;
        drop(manager);
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_retirement_clears_input_before_any_bridge_starts() {
        let (backend, input, server) = notification_backend().await;
        let backend = Arc::new(backend);
        let manager = retaining_manager(&backend);
        for sequence in 0..5 {
            input.send(json!({"sequence": sequence})).unwrap();
        }
        manager.shutdown_notification_poll_loops();
        assert_retired_ingress_and_live_requests(&manager, &backend).await;
        // A subscription created after shutdown observes the sticky retirement.
        let mut stream = backend.subscribe_to_notifications();
        assert!(timeout(Duration::from_secs(2), stream.next())
            .await
            .unwrap()
            .is_none());
        bridge_releases_receiver(&backend).await;
        drop(manager);
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_retirement_stops_quiet_bridge() {
        assert_retirement_stops_bridge(false).await;
    }

    #[tokio::test]
    async fn notification_retirement_stops_saturated_bridge() {
        assert_retirement_stops_bridge(true).await;
    }

    async fn assert_retirement_stops_bridge(saturated: bool) {
        let (backend, input, server) = notification_backend().await;
        let backend = Arc::new(backend);
        let manager = retaining_manager(&backend);
        let stream = backend.subscribe_to_notifications();
        if saturated {
            for sequence in 0..102 {
                input.send(json!({"sequence": sequence})).unwrap();
            }
        }
        timeout(Duration::from_secs(2), async {
            loop {
                let ready = match backend.notifications_rx.try_lock() {
                    Ok(receiver) => saturated && receiver.len() == 1,
                    Err(_) => !saturated,
                };
                if ready {
                    break;
                }
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("bridge must reach the quiet receive or saturated send boundary");
        manager.shutdown_notification_poll_loops();
        // Keep the consumer open: permanent retirement itself must stop work.
        bridge_releases_receiver(&backend).await;
        assert_retired_ingress_and_live_requests(&manager, &backend).await;
        drop(stream);
        drop(manager);
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_retirement_cancels_pending_lock_before_draining() {
        let (backend, input, server) = notification_backend().await;
        let backend = Arc::new(backend);
        let manager = retaining_manager(&backend);
        input.send(json!({"buffered": true})).unwrap();
        let receiver = backend.notifications_rx.lock().await;
        let (tx, rx) = mpsc::channel(100);
        let mut bridge = Box::pin(forward_notifications(
            Arc::clone(&backend.notifications_rx),
            tx,
            backend.notification_shutdown.subscribe(),
        ));
        assert!(futures::poll!(bridge.as_mut()).is_pending());
        manager.shutdown_notification_poll_loops();
        assert!(futures::poll!(bridge.as_mut()).is_pending());
        // The worker must leave its pending receive/lock and close output
        // before waiting to acquire the receiver for final buffer disposal.
        assert!(
            rx.is_closed(),
            "retirement must cancel the pending receive before cleanup"
        );
        assert!(backend.notifications_rx.try_lock().is_err());
        drop(receiver);
        timeout(Duration::from_secs(2), bridge).await.unwrap();
        assert_retired_ingress_and_live_requests(&manager, &backend).await;
        drop(manager);
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    #[tokio::test]
    async fn notification_stream_drop_preserves_other_consumers_and_resubscription() {
        let (backend, input, server) = notification_backend().await;
        let first = backend.subscribe_to_notifications();
        timeout(Duration::from_secs(2), async {
            while backend.notifications_rx.try_lock().is_ok() {
                tokio::task::yield_now().await;
            }
        })
        .await
        .unwrap();
        let mut second = backend.subscribe_to_notifications();
        drop(first);
        input.send(json!({"sequence": 1})).unwrap();
        assert_eq!(
            timeout(Duration::from_secs(2), second.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            json!({"sequence": 1})
        );
        drop(second);
        bridge_releases_receiver(&backend).await;
        input.send(json!({"sequence": 2})).unwrap();
        let mut third = backend.subscribe_to_notifications();
        assert_eq!(
            timeout(Duration::from_secs(2), third.next())
                .await
                .unwrap()
                .unwrap()
                .unwrap(),
            json!({"sequence": 2})
        );
        drop(third);
        bridge_releases_receiver(&backend).await;
        drop(backend);
        timeout(Duration::from_secs(2), server)
            .await
            .unwrap()
            .unwrap();
    }

    fn test_sse_config(url: String) -> McpServerConfig {
        McpServerConfig {
            name: "test-sse".to_string(),
            command: None,
            args: vec![],
            env: HashMap::new(),
            url: Some(url),
            server_type: "sse".to_string(),
        }
    }

    async fn serve_single_response(status_line: &str, content_type: &str, body: &str) -> String {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind test listener");
        let addr = listener.local_addr().expect("listener addr");
        let response = format!(
            "HTTP/1.1 {status_line}\r\nContent-Type: {content_type}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
            body.len()
        );
        tokio::spawn(async move {
            let (mut stream, _) = listener.accept().await.expect("accept test connection");
            let mut buf = [0u8; 4096];
            let _ = stream.read(&mut buf).await;
            stream
                .write_all(response.as_bytes())
                .await
                .expect("write test response");
            let _ = stream.shutdown().await;
        });
        format!("http://{addr}")
    }

    async fn fetch_response(
        status_line: &str,
        content_type: &str,
        body: &str,
    ) -> reqwest::Response {
        let url = serve_single_response(status_line, content_type, body).await;
        reqwest::Client::new()
            .get(url)
            .send()
            .await
            .expect("fetch test response")
    }

    #[test]
    fn build_client_info_sets_expected_protocol_and_identity() {
        let info = build_client_info(rmcp_model::ProtocolVersion::V_2024_11_05);
        assert_eq!(
            info.protocol_version,
            rmcp_model::ProtocolVersion::V_2024_11_05
        );
        assert_eq!(info.client_info.name, claurst_core::constants::APP_NAME);
        assert_eq!(
            info.client_info.version,
            claurst_core::constants::APP_VERSION
        );
        assert_eq!(
            info.capabilities
                .roots
                .as_ref()
                .and_then(|roots| roots.list_changed),
            Some(false)
        );
    }

    #[tokio::test]
    async fn legacy_sse_transport_connect_discovers_endpoint_event() {
        let body = "event: endpoint\ndata: /messages\n\n";
        let url = serve_single_response("200 OK", "text/event-stream", body).await;
        let config = test_sse_config(url.clone());

        let transport = LegacySseRmcpTransport::connect(&config, None, None)
            .await
            .expect("connect legacy sse transport");

        let endpoint = transport
            .post_endpoint
            .lock()
            .expect("endpoint mutex poisoned")
            .clone();
        let expected = format!("{url}/messages");
        assert_eq!(endpoint.as_deref(), Some(expected.as_str()));
    }

    #[tokio::test]
    async fn legacy_sse_get_failure_does_not_echo_response_body() {
        let url = serve_single_response(
            "401 Unauthorized",
            "text/plain",
            "canary-credential-in-get-error",
        )
        .await;
        let config = test_sse_config(url);

        let error = match LegacySseRmcpTransport::connect(&config, None, None).await {
            Ok(_) => panic!("unauthorized SSE stream must fail"),
            Err(error) => error,
        };
        let rendered = error.to_string();
        assert!(rendered.contains("401"), "{rendered}");
        assert!(
            !rendered.contains("canary-credential-in-get-error"),
            "{rendered}"
        );
    }

    #[tokio::test]
    async fn legacy_sse_post_failure_does_not_echo_response_body() {
        let response = fetch_response(
            "401 Unauthorized",
            "text/plain",
            "canary-credential-in-post-error",
        )
        .await;
        let (tx, _) = mpsc::unbounded_channel();
        let tasks = Arc::new(StdMutex::new(Vec::new()));

        let error = handle_legacy_sse_http_response("test".into(), response, tx, tasks)
            .await
            .expect_err("unauthorized SSE POST must fail");
        let rendered = error.to_string();
        assert!(rendered.contains("401"), "{rendered}");
        assert!(
            !rendered.contains("canary-credential-in-post-error"),
            "{rendered}"
        );
    }

    #[tokio::test]
    async fn handle_legacy_sse_http_response_queues_json_message() {
        let response = fetch_response(
            "200 OK",
            "application/json",
            r#"{"jsonrpc":"2.0","id":1,"result":{}}"#,
        )
        .await;
        let (tx, mut rx) = mpsc::unbounded_channel();
        let tasks = Arc::new(StdMutex::new(Vec::new()));

        handle_legacy_sse_http_response("test".to_string(), response, tx, Arc::clone(&tasks))
            .await
            .expect("handle json response");

        let message = timeout(Duration::from_secs(1), rx.recv())
            .await
            .expect("json response timeout")
            .expect("json response message");
        assert!(matches!(
            message,
            rmcp::service::RxJsonRpcMessage::<RoleClient>::Response(_)
        ));
    }

    #[tokio::test]
    async fn handle_legacy_sse_http_response_queues_sse_message() {
        let response = fetch_response(
            "200 OK",
            "text/event-stream",
            "data: {\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}\n\n",
        )
        .await;
        let (tx, mut rx) = mpsc::unbounded_channel();
        let tasks = Arc::new(StdMutex::new(Vec::new()));

        handle_legacy_sse_http_response("test".to_string(), response, tx, Arc::clone(&tasks))
            .await
            .expect("handle sse response");

        let message = timeout(Duration::from_secs(1), rx.recv())
            .await
            .expect("sse response timeout")
            .expect("sse response message");
        assert!(matches!(
            message,
            rmcp::service::RxJsonRpcMessage::<RoleClient>::Response(_)
        ));
    }

    #[tokio::test]
    async fn legacy_sse_transport_drop_aborts_background_tasks() {
        let task = tokio::spawn(async move {
            loop {
                tokio::task::yield_now().await;
            }
        });

        let transport = LegacySseRmcpTransport {
            server_name: "test".to_string(),
            sse_url: "http://localhost/sse".to_string(),
            client: reqwest::Client::new(),
            auth_token: None,
            post_endpoint: Arc::new(StdMutex::new(None)),
            incoming_tx: mpsc::unbounded_channel().0,
            incoming_rx: Arc::new(Mutex::new(mpsc::unbounded_channel().1)),
            background_tasks: Arc::new(StdMutex::new(vec![task])),
        };

        let background_tasks = Arc::clone(&transport.background_tasks);
        drop(transport);

        let is_empty = background_tasks
            .lock()
            .expect("task mutex poisoned")
            .is_empty();
        assert!(is_empty);
    }
    #[tokio::test]
    async fn plugin_initialize_failure_preserves_transport_cleanup_error() {
        struct FailingTransport;
        impl rmcp::transport::Transport<RoleClient> for FailingTransport {
            type Error = std::io::Error;
            fn send(
                &mut self,
                _: rmcp::service::TxJsonRpcMessage<RoleClient>,
            ) -> impl std::future::Future<Output = Result<(), Self::Error>> + Send + 'static
            {
                std::future::ready(Err(std::io::Error::other("fixture initialize failure")))
            }
            async fn receive(&mut self) -> Option<rmcp::service::RxJsonRpcMessage<RoleClient>> {
                futures::future::pending().await
            }
            async fn close(&mut self) -> Result<(), Self::Error> {
                Err(std::io::Error::other("fixture close failure"))
            }
        }
        let (_stop, shutdown) = watch::channel(false);
        let result = timeout(
            Duration::from_secs(2),
            RmcpClientBackend::connect_with_transport(
                &test_sse_config("unused".into()),
                FailingTransport,
                build_client_info(rmcp_model::ProtocolVersion::default()),
                "fixture",
                Some(shutdown),
            ),
        )
        .await
        .unwrap();
        let error = match result {
            Ok(_) => panic!("fixture must fail initialization"),
            Err(error) => error,
        };
        assert!(
            error
                .downcast_ref::<crate::owned_transport::RetirementError>()
                .is_some(),
            "{error:#}"
        );
        assert!(error.to_string().contains("fixture close failure"));
    }

    #[tokio::test]
    async fn legacy_sse_close_joins_all_owned_tasks_before_returning() {
        struct Receipt(Option<oneshot::Sender<()>>);
        impl Drop for Receipt {
            fn drop(&mut self) {
                if let Some(sender) = self.0.take() {
                    let _ = sender.send(());
                }
            }
        }
        let mut receipts = Vec::new();
        let mut tasks = Vec::new();
        for _ in 0..2 {
            let (closed, receipt) = oneshot::channel();
            let (started, ready) = oneshot::channel();
            tasks.push(tokio::spawn(async move {
                let _receipt = Receipt(Some(closed));
                let _ = started.send(());
                futures::future::pending::<()>().await;
            }));
            ready.await.unwrap();
            receipts.push(receipt);
        }
        let mut transport = LegacySseRmcpTransport {
            server_name: "fixture".into(),
            sse_url: "unused".into(),
            client: reqwest::Client::new(),
            auth_token: None,
            post_endpoint: Arc::new(StdMutex::new(None)),
            incoming_tx: mpsc::unbounded_channel().0,
            incoming_rx: Arc::new(Mutex::new(mpsc::unbounded_channel().1)),
            background_tasks: Arc::new(StdMutex::new(tasks)),
        };
        rmcp::transport::Transport::close(&mut transport)
            .await
            .unwrap();
        for mut receipt in receipts {
            assert!(
                receipt.try_recv().is_ok(),
                "close must join every task before reporting completion"
            );
        }
        assert!(transport.background_tasks.lock().unwrap().is_empty());
    }
    #[tokio::test]
    async fn plugin_http_withdrawal_before_first_protocol_message_joins_worker() {
        // Simulate withdrawal between the caller's admission check and the
        // actual HTTP transport construction. No network request is needed.
        let (_stop, shutdown) = watch::channel(true);
        let mut config = test_sse_config("http://127.0.0.1:1/unused".into());
        config.server_type = "http".into();
        let result = timeout(
            Duration::from_secs(2),
            RmcpClientBackend::connect_http(
                &config,
                None,
                rmcp_model::ProtocolVersion::default(),
                Some(shutdown),
            ),
        )
        .await;
        assert!(
            result.is_ok(),
            "withdrawal must join a worker waiting for its first protocol message"
        );
        assert!(
            result.unwrap().is_err(),
            "withdrawn initialization must fail closed"
        );
    }
}
