// @oagen-ignore-file

import Foundation

/// A single page of a cursor-paginated list response.
public struct Page<Element: Codable & Sendable>: Codable, Sendable {
    public let data: [Element]
    public let listMetadata: PageMetadata

    public init(data: [Element], listMetadata: PageMetadata) {
        self.data = data
        self.listMetadata = listMetadata
    }

    private enum CodingKeys: String, CodingKey {
        case data
        case listMetadata = "list_metadata"
    }
}

/// Cursor metadata for a paginated list response. Named `PageMetadata` to avoid
/// colliding with a spec-defined `ListMetadata` model in the same module.
public struct PageMetadata: Codable, Sendable, Equatable {
    public let before: String?
    public let after: String?

    public init(before: String? = nil, after: String? = nil) {
        self.before = before
        self.after = after
    }
}

/// An `AsyncSequence` that transparently fetches successive pages until the
/// cursor is exhausted. Drive it with `for try await item in ...`.
public struct AutoPagingSequence<Element: Codable & Sendable>: AsyncSequence, Sendable {
    let fetch: @Sendable (String?) async throws -> Page<Element>

    public init(fetch: @escaping @Sendable (String?) async throws -> Page<Element>) {
        self.fetch = fetch
    }

    public func makeAsyncIterator() -> AsyncIterator {
        AsyncIterator(fetch: fetch)
    }

    public struct AsyncIterator: AsyncIteratorProtocol {
        let fetch: @Sendable (String?) async throws -> Page<Element>
        var buffer: [Element] = []
        var cursor: String?
        var finished = false

        public mutating func next() async throws -> Element? {
            if !buffer.isEmpty { return buffer.removeFirst() }
            if finished { return nil }
            let page = try await fetch(cursor)
            buffer = page.data
            cursor = page.listMetadata.after
            if cursor == nil || buffer.isEmpty { finished = true }
            return buffer.isEmpty ? nil : buffer.removeFirst()
        }
    }
}
