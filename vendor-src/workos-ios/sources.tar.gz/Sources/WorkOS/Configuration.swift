// @oagen-ignore-file

import Foundation

/// Client configuration: credentials, endpoint, and request-policy defaults.
public struct Configuration: Sendable {
    /// The API key sent as a bearer token on every request.
    public var apiKey: String
    /// The base URL all request paths are resolved against.
    public var baseURL: URL
    /// The default per-request timeout, in seconds.
    public var timeout: TimeInterval
    /// The maximum number of retries for retryable failures.
    public var maxRetries: Int
    /// HTTP status codes that trigger a retry.
    public var retryableStatusCodes: Set<Int>
    /// An optional client identifier used by some operations.
    public var clientID: String?

    public static let defaultBaseURL = URL(string: "https://api.workos.com")!

    public init(
        apiKey: String,
        baseURL: URL? = nil,
        timeout: TimeInterval = 60.0,
        maxRetries: Int = 3,
        retryableStatusCodes: Set<Int> = [429, 500, 502, 503, 504],
        clientID: String? = nil
    ) {
        self.apiKey = apiKey
        self.baseURL = baseURL ?? Configuration.defaultBaseURL
        self.timeout = timeout
        self.maxRetries = maxRetries
        self.retryableStatusCodes = retryableStatusCodes
        self.clientID = clientID
    }
}
